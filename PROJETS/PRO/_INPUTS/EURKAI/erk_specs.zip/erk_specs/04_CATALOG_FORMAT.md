# CATALOG FORMAT

## Format d'import simplifié

```
<objectname ou lineage>:
  [<attr1>, <attr2>, ...]
  [<relation1>, <relation2>, ...]
```

## Inférence automatique

Le script reconnaît le type :
- Mots simples minuscules → attributs (`name`, `scope`, `model`)
- Mots-clés de relation → relations (`depends_on X`, `scope_of Y`, `related_to Z`)

## Exemples

```
Agent:
  [name, model, scope]
  [depends_on Provider, scope_of Create]

CentralMethod:
  [signature, returnType]
  [related_to Object]
```

## Résolution des noms

Quand on écrit `Create` :
1. Chercher un objet existant dont le nom finit par `Create`
2. Préférer les chemins sous `Object:`
3. Si non trouvé, créer sous le préfixe approprié (ex: `Object:Function:Method:CentralMethod:Create`)

## Valeurs dans les bundles

Format simplifié (tableau de noms) :
```
CentralMethod.Bundle.methods = ['Create', 'Read', 'Update', 'Delete', 'Orchestrate', 'Engage']
```

Équivalent à :
```
CentralMethod.Bundle.methods.owned = [
  { ref: 'Object:Function:Method:CentralMethod:Create' },
  { ref: 'Object:Function:Method:CentralMethod:Read' },
  ...
]
```
