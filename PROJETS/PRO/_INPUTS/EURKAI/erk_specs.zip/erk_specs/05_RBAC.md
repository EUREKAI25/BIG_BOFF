# RBAC (Role-Based Access Control)

## Principe

Pas de relation directe Agent → Method.

Chaîne :
```
Agent → Rôle → Permission → Méthode
```

## Attribut scope

`scope` est un attribut de type bundle/liste.

Contenu : références vers les objets qui appartiennent à ce scope.

## Déclaration

```
AIAgent IN GeneratorRole.scope
GeneratorRole IN CreatePermission.scope
```

Ou en syntaxe canonique :
```
AIAgent scope_of GeneratorRole
GeneratorRole scope_of CreatePermission
```

## Logique d'autorisation

Pour savoir si `AIAgent` peut exécuter `Create` :

1. Quels rôles contiennent AIAgent dans leur scope ? → `GeneratorRole`
2. Quelles permissions contiennent GeneratorRole dans leur scope ? → `CreatePermission`
3. Le nom de la permission implique la méthode : `CreatePermission` → `Create`
4. → Autorisé

## Pas de relation "enables"

Le nom de la permission IMPLIQUE ce qu'elle permet.

- `CreatePermission` → permet Create
- `ReadPermission` → permet Read
- `DeletePermission` → permet Delete

Pas besoin de relation explicite Permission → Method.
