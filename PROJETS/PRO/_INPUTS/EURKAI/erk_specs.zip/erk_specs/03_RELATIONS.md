# RELATIONS

## Types de relations

| Relation | Usage |
|----------|-------|
| `inherits_from` | Héritage (implicite via parent dans le lineage) |
| `depends_on` | Dépendance fonctionnelle |
| `related_to` | Association générique |
| `scope_of` | Appartenance à un scope (contexte RBAC) |

## inherits_from

Implicite. Déduit du lineage.

`Object:Entity:Agent` → Agent `inherits_from` Entity (automatique).

Affiché dans le cockpit mais pas stocké explicitement.

## scope_of

Relation canonique pour RBAC.

```
Generator scope_of Create
```

Signifie : le rôle Generator a la permission d'exécuter Create.

## Syntaxes acceptées en lecture

Toutes ces formes sont équivalentes :

```
Generator scope_of Create
Generator IN CreatePermission.scope
Role:Generator IN CreatePermissionScope
```

## Syntaxe canonique en écriture/génération

Toujours utiliser `scope_of` :

```
Generator scope_of Create
```
