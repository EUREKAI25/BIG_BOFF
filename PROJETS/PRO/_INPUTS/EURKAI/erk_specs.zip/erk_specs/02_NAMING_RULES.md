# NAMING RULES

## Unicité

Les labels doivent être uniques, indépendamment de la casse.

Un attribut `name` et une méthode `Name` = INTERDIT.

## Conventions

| Type | Convention | Exemples |
|------|------------|----------|
| Attributs | minuscule | `name`, `scope`, `model` |
| Méthodes | `<Object><Action>` | `AgentCreate`, `CatalogRead`, `VectorGenerate` |
| Objets/Types | PascalCase | `CentralMethod`, `AIAgent`, `CreatePermission` |

## Lineage

Format : `Segment:Segment:Segment`

Chaque segment en PascalCase.

Exemples valides :
- `Object`
- `Object:Entity:Agent`
- `Object:Function:Method:CentralMethod:Create`

## Bundles

Nommés d'après leur objet parent :
- `Object` → `ObjectBundle`, `ObjectAttributeBundle`, etc.
- `CentralMethod` → `CentralMethodBundle`
