# ERK SPECS — INDEX

Version de travail. À enrichir lors des mises à jour du cockpit.

## Fichiers

1. **01_OBJECT_STRUCTURE.md** — Structure objet = bundle, alias, raccourcis
2. **02_NAMING_RULES.md** — Conventions de nommage, unicité
3. **03_RELATIONS.md** — Types de relations (inherits_from, depends_on, related_to, scope_of)
4. **04_CATALOG_FORMAT.md** — Format d'import simplifié pour les catalogues
5. **05_RBAC.md** — Rôles, permissions, scope
6. **06_METASCHEMA.md** — Structure canonique JSON

## Principes clés

- Tout objet EST un bundle
- `.owned` par défaut
- Labels uniques (insensibles à la casse)
- `scope_of` = syntaxe canonique RBAC
- Pas de relation `enables`
- Permission implique la méthode par son nom

## À définir plus tard

- Syntaxe ERK complète (après stabilisation cockpit)
- Vectors
- Hooks
- Scenarios
