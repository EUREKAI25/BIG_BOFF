# OBJECT STRUCTURE

## Principe fondamental

Tout objet EST un bundle. Pas d'étape intermédiaire.

## Structure canonique

```
Object = [
  ObjectAttributeBundle,
  ObjectRelationBundle,
  ObjectMethodBundle,
  ObjectRuleBundle
]
```

Chaque bundle contient :
```
{
  inherited: [...],
  injected: [...],
  owned: [...]
}
```

## Alias automatiques

| Complet | Alias |
|---------|-------|
| `Object.ObjectBundle` | `Object.Bundle` |
| `ObjectBundle` | `Object.Bundle` |
| `CentralMethod.CentralMethodBundle` | `CentralMethod.Bundle` |

## Valeur par défaut

`.owned` est implicite. Donc :
```
CentralMethod.Bundle.methods = ['Create', 'Read']
```
équivaut à :
```
CentralMethod.Bundle.methods.owned = ['Create', 'Read']
```

## Raccourcis de chemin

Résolution automatique du chemin le plus court :

| Complet | Raccourci |
|---------|-----------|
| `Object.ObjectBundle.attributes` | `Object.attributes` |
| `Object.ObjectBundle.attributes.scope` | `Object.scope` |

Règle : on remonte jusqu'à trouver l'élément. Pas d'ambiguïté si noms uniques.
