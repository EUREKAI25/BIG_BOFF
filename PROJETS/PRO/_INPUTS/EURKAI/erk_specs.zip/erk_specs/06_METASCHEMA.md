# METASCHEMA

## Principe

MetaSchema définit la structure récursive canonique de tous les ObjectTypes.

Tout objet EST un bundle.

## Structure JSON

```json
{
  "Object": {
    "ObjectAttributeBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    },
    "ObjectRelationBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    },
    "ObjectMethodBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    },
    "ObjectRuleBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    }
  }
}
```

## Sémantique des bundles

| Bundle | Contenu |
|--------|---------|
| `inherited` | Hérité des parents (via lineage) |
| `injected` | Injecté dynamiquement (providers, environnement) |
| `owned` | Défini directement pour cet objet |

## Priorité de résolution

`owned` > `injected` > `inherited`

Un élément owned écrase un élément inherited de même nom.
