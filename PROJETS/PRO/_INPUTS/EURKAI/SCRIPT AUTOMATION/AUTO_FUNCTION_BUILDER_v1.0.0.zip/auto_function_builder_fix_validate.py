"""Validation du résultat de correction."""

from report_actions import report_actions


def auto_function_builder_fix_validate(builder_state: dict) -> dict:
    """Valide si la correction a réussi.

    Args:
        builder_state: État global après rerun des tests.

    Returns:
        dict: builder_state avec fix.status mis à jour.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_VALIDATE",
        level="info",
        message="Validation de la correction."
    )
    
    from auto_function_builder_fix_check_success import auto_function_builder_fix_check_success
    
    # Vérifier le succès
    success = auto_function_builder_fix_check_success(builder_state)
    
    if success:
        builder_state["fix"]["status"] = "success"
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_VALIDATE_SUCCESS",
            level="info",
            message="Correction validée avec succès."
        )
    else:
        builder_state["fix"]["status"] = "in_progress"
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_VALIDATE_CONTINUE",
            level="warning",
            message="Correction incomplète, itération nécessaire."
        )
    
    return builder_state
