"""Vérification des critères de succès."""

from report_actions import report_actions


def auto_function_builder_fix_check_success(builder_state: dict) -> bool:
    """Vérifie si la correction satisfait les critères de succès.

    Args:
        builder_state: État global avec tests.

    Returns:
        bool: True si succès, False sinon.
    """
    tests_status = builder_state.get("tests", {}).get("status")
    
    # Critère principal : tous les tests passent
    if tests_status == "success":
        return True
    
    # Critère alternatif : amélioration significative
    # (si on veut être moins strict)
    current_failed = len(builder_state.get("tests", {}).get("report", {}).get("failed_tests", []))
    
    # Si aucun test échoué
    if current_failed == 0:
        return True
    
    return False
