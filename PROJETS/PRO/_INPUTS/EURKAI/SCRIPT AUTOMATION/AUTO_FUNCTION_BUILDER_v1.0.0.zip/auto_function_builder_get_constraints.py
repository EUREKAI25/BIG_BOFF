"""Chargement des contraintes de l'agence et du langage."""

from report_actions import report_actions


def auto_function_builder_get_constraints(builder_state: dict) -> dict:
    """Charge les contraintes agence et langage applicables.

    Args:
        builder_state: État global contenant 'function_request' avec 'language'.

    Returns:
        dict: builder_state avec 'constraints' ajouté.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GET_CONSTRAINTS",
        level="info",
        message="Chargement des contraintes."
    )
    
    language = builder_state.get("function_request", {}).get("language", "python")
    
    # Définition des contraintes par défaut
    constraints = {
        "language_constraints": _get_language_constraints(language),
        "agency_constraints": _get_agency_constraints(),
        "tests_constraints": _get_tests_constraints(),
        "metadata_constraints": _get_metadata_constraints()
    }
    
    # Mise à jour
    builder_state["constraints"] = constraints
    
    report_actions(
        event="AUTO_FUNC_BUILD_GET_CONSTRAINTS_SUCCESS",
        level="info",
        message="Contraintes chargées avec succès."
    )
    
    return builder_state


def _get_language_constraints(language: str) -> dict:
    """Retourne les contraintes spécifiques au langage."""
    if language == "python":
        return {
            "version": "3.11",
            "disallowed_features": [],
            "allowed_stdlib": []  # Si vide, tous les modules stdlib sont autorisés
        }
    return {}


def _get_agency_constraints() -> dict:
    """Retourne les contraintes de l'agence."""
    return {
        "one_function_per_file": True,
        "use_report_actions": True,
        "no_print": True,
        "docstring_style": "google",
        "metadata_required": True,
        "snake_case_naming": True
    }


def _get_tests_constraints() -> dict:
    """Retourne les contraintes pour les tests."""
    return {
        "framework": "pytest",
        "min_cases": 3,
        "require_error_cases": True,
        "require_nominal_case": True,
        "require_edge_cases": True
    }


def _get_metadata_constraints() -> dict:
    """Retourne les contraintes pour les métadonnées."""
    return {
        "required_fields": [
            "name",
            "description",
            "version",
            "tags",
            "object_type",
            "author",
            "language",
            "module"
        ]
    }
