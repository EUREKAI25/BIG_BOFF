"""Application de la correction via IA."""

import json
from call_llm import call_llm, parse_json_response
from report_actions import report_actions


def auto_function_builder_fix_apply(builder_state: dict) -> dict:
    """Génère une version corrigée du code via IA.

    Args:
        builder_state: État global avec fix_context et function_code actuel.

    Returns:
        dict: builder_state avec function_code_fixed dans artifacts.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_APPLY_START",
        level="info",
        message="Génération de la correction via IA."
    )
    
    # Construire le prompt
    prompt = _build_fix_prompt(builder_state)
    
    try:
        # Appel IA
        response = call_llm(prompt, temperature=0.1, max_tokens=3000)
        
        # Parser la réponse
        parsed = parse_json_response(response)
        
        if parsed.get("mode") != "fix_apply":
            raise ValueError("Mode de réponse incorrect.")
        
        if "function_code_fixed" not in parsed:
            raise ValueError("function_code_fixed manquant.")
        
        # Mise à jour
        builder_state["artifacts"]["function_code"] = parsed["function_code_fixed"]
        
        # Historique
        attempt = builder_state["fix"]["attempts"]
        builder_state["fix"]["history"].append({
            "attempt": attempt,
            "code": parsed["function_code_fixed"],
            "notes": parsed.get("validation_notes", [])
        })
        
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_APPLY_SUCCESS",
            level="info",
            message="Correction générée."
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_APPLY_ERROR",
            level="error",
            message=f"Erreur lors de la correction: {str(e)}"
        )
        raise


def _build_fix_prompt(builder_state: dict) -> str:
    """Construit le prompt de correction."""
    function_spec = builder_state.get("function_spec", {})
    function_code = builder_state.get("artifacts", {}).get("function_code", "")
    fix_context = builder_state.get("fix_context", {})
    error_summary = fix_context.get("error_summary", "")
    
    prompt = f"""Tu es intégré dans un système d'agence autonome nommé laNostr'AI / EUREKAI.

RÔLE:
Développeur senior en charge de la correction de bugs

OBJECTIF:
Corriger le code de la fonction qui échoue aux tests.

FUNCTION_SPEC:
{json.dumps(function_spec, indent=2, ensure_ascii=False)}

CODE ACTUEL (avec erreurs):
{function_code}

RAPPORT D'ERREURS:
{error_summary}

INSTRUCTIONS:
1. Analyser les erreurs
2. Identifier la cause racine
3. Proposer une correction minimale
4. Préserver la structure et les conventions
5. Ne PAS changer la signature de fonction

FORMAT DE RÉPONSE:
{{
  "mode": "fix_apply",
  "function_code_fixed": "code Python corrigé complet",
  "validation_notes": ["explication des corrections"],
  "readme_notes": []
}}
"""
    return prompt
