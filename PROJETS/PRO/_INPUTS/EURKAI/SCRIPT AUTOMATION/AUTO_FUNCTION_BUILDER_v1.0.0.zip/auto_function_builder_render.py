"""Orchestration de la phase RENDER."""

from report_actions import report_actions


def auto_function_builder_render(builder_state: dict) -> dict:
    """Orchestre la phase RENDER : rapport, outputs index, logs finaux.

    Args:
        builder_state: État global après validation.

    Returns:
        dict: builder_state avec outputs_index enrichi.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_RENDER_START",
        level="info",
        message="Démarrage de la phase RENDER."
    )
    
    from auto_function_builder_render_report import auto_function_builder_render_report
    from auto_function_builder_render_outputs import auto_function_builder_render_outputs
    from auto_function_builder_render_logs import auto_function_builder_render_logs
    
    try:
        # Étape 1 : Générer le rapport
        builder_state = auto_function_builder_render_report(builder_state)
        
        # Étape 2 : Construire l'index des outputs
        builder_state = auto_function_builder_render_outputs(builder_state)
        
        # Étape 3 : Finaliser les logs
        builder_state = auto_function_builder_render_logs(builder_state)
        
        report_actions(
            event="AUTO_FUNC_BUILD_RENDER_SUCCESS",
            level="info",
            message="Phase RENDER terminée avec succès."
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_RENDER_ERROR",
            level="error",
            message=f"Erreur durant la phase RENDER: {str(e)}"
        )
        raise
