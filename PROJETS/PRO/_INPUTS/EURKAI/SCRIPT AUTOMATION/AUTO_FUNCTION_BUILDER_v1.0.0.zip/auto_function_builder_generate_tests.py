"""Génération des tests unitaires via IA."""

import json
from call_llm import call_llm, parse_json_response
from report_actions import report_actions


def auto_function_builder_generate_tests(builder_state: dict) -> dict:
    """Génère les tests unitaires via IA.

    Args:
        builder_state: État global contenant function_spec et function_code.

    Returns:
        dict: builder_state avec 'tests_code' ajouté dans artifacts.

    Raises:
        RuntimeError: Si l'appel IA échoue ou si la réponse est invalide.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GENERATE_TESTS_START",
        level="info",
        message="Génération des tests via IA."
    )
    
    # Construire le prompt
    prompt = _build_generate_tests_prompt(builder_state)
    
    try:
        # Appel IA
        response = call_llm(prompt, temperature=0.2, max_tokens=3000)
        
        # Parser la réponse JSON
        parsed = parse_json_response(response)
        
        # Validation du format
        if parsed.get("mode") != "generate_tests":
            raise ValueError("Mode de réponse incorrect.")
        
        if "tests_code" not in parsed:
            raise ValueError("tests_code manquant dans la réponse.")
        
        # Mise à jour du builder_state
        if "artifacts" not in builder_state:
            builder_state["artifacts"] = {}
        
        builder_state["artifacts"]["tests_code"] = parsed["tests_code"]
        
        # Ajouter les notes
        if "validation_notes" in parsed:
            builder_state["artifacts"].setdefault("validation_notes", []).extend(
                parsed["validation_notes"]
            )
        
        if "readme_notes" in parsed:
            builder_state["artifacts"].setdefault("readme_notes", []).extend(
                parsed["readme_notes"]
            )
        
        report_actions(
            event="AUTO_FUNC_BUILD_GENERATE_TESTS_SUCCESS",
            level="info",
            message="Tests générés avec succès."
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_GENERATE_TESTS_ERROR",
            level="error",
            message=f"Erreur lors de la génération des tests: {str(e)}"
        )
        raise RuntimeError(f"Échec de la génération des tests: {str(e)}")


def _build_generate_tests_prompt(builder_state: dict) -> str:
    """Construit le prompt pour la génération de tests."""
    function_spec = builder_state.get("function_spec", {})
    function_code = builder_state.get("artifacts", {}).get("function_code", "")
    function_name = function_spec.get("name", "unknown")
    language = builder_state.get("function_request", {}).get("language", "python")
    constraints = builder_state.get("constraints", {})
    tests_constraints = constraints.get("tests_constraints", {})
    
    prompt = f"""Tu es intégré dans un système d'agence autonome nommé laNostr'AI / EUREKAI.

RÔLE:
Ingénieur QA / Tests

OBJECTIF:
Générer des tests unitaires complets et robustes pour la fonction fournie.

CONTEXTE PROJET:
- Chantier: AUTO_FUNCTION_BUILDER
- Langage: {language}

FUNCTION_SPEC:
{json.dumps(function_spec, indent=2, ensure_ascii=False)}

CODE DE LA FONCTION:
{function_code}

CONTRAINTES TESTS:
{_format_constraints(tests_constraints)}

RÈGLES IMPORTANTES:
1. Framework: pytest
2. Minimum 3 cas de test (nominal, erreur, limite)
3. Utiliser des fixtures pytest si nécessaire
4. Tests isolés et reproductibles
5. Noms de tests explicites (test_<fonction>_<scenario>)
6. Assertions claires et messages d'erreur utiles

TYPES DE TESTS REQUIS:
- Test nominal : cas d'usage normal
- Test d'erreur : comportement avec entrées invalides
- Test cas limite : valeurs extrêmes, cas edge

LIVRABLES REQUIS:
Code Python complet des tests, incluant:
- Imports nécessaires (pytest, fixtures, etc.)
- Tous les cas de test requis
- Fixtures si nécessaire
- Assertions appropriées

FORMAT DE RÉPONSE:
Tu dois répondre EXCLUSIVEMENT en JSON valide, sans texte autour.
Structure attendue :
{{
  "mode": "generate_tests",
  "tests_code": "code Python complet des tests ici",
  "validation_notes": ["note 1", "note 2"],
  "readme_notes": ["note pour le README"]
}}
"""
    return prompt


def _format_constraints(constraints_dict: dict) -> str:
    """Formate un dictionnaire de contraintes en texte."""
    lines = []
    for key, value in constraints_dict.items():
        lines.append(f"- {key}: {value}")
    return "\n".join(lines) if lines else "Aucune contrainte spécifique."
