"""Orchestration de la boucle de correction FIX."""

from report_actions import report_actions


def auto_function_builder_fix(builder_state: dict) -> dict:
    """Orchestre la boucle de correction si les tests échouent.

    Args:
        builder_state: État global avec tests.status.

    Returns:
        dict: builder_state avec fix.status mis à jour.

    Raises:
        RuntimeError: Si la boucle échoue de manière critique.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_START",
        level="info",
        message="Démarrage de la boucle de correction.",
        context={"step": "fix"}
    )
    
    # Vérifier si correction nécessaire
    tests_status = builder_state.get("tests", {}).get("status")
    
    if tests_status == "success":
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_SKIP",
            level="info",
            message="Correction non nécessaire : tous les tests passent."
        )
        
        builder_state["fix"] = {
            "attempts": 0,
            "max_attempts": 3,
            "history": [],
            "status": "not_started"
        }
        
        return builder_state
    
    # Initialiser fix si nécessaire
    if "fix" not in builder_state:
        builder_state["fix"] = {
            "attempts": 0,
            "max_attempts": 3,
            "history": [],
            "status": "in_progress"
        }
    
    # Import des sous-fonctions
    from auto_function_builder_fix_get import auto_function_builder_fix_get
    from auto_function_builder_fix_execute import auto_function_builder_fix_execute
    from auto_function_builder_fix_validate import auto_function_builder_fix_validate
    from auto_function_builder_fix_render import auto_function_builder_fix_render
    from auto_function_builder_fix_log import auto_function_builder_fix_log
    
    try:
        max_attempts = builder_state["fix"]["max_attempts"]
        
        while builder_state["fix"]["attempts"] < max_attempts:
            builder_state["fix"]["attempts"] += 1
            attempt = builder_state["fix"]["attempts"]
            
            report_actions(
                event="AUTO_FUNC_BUILD_FIX_ATTEMPT",
                level="info",
                message=f"Tentative de correction {attempt}/{max_attempts}."
            )
            
            # Étape 1 : Préparer le contexte de correction
            builder_state = auto_function_builder_fix_get(builder_state)
            
            # Étape 2 : Exécuter la correction
            builder_state = auto_function_builder_fix_execute(builder_state)
            
            # Étape 3 : Valider le résultat
            builder_state = auto_function_builder_fix_validate(builder_state)
            
            # Vérifier le statut
            if builder_state["fix"]["status"] == "success":
                report_actions(
                    event="AUTO_FUNC_BUILD_FIX_SUCCESS",
                    level="info",
                    message=f"Correction réussie à la tentative {attempt}."
                )
                break
            
            # Si échec et pas de tentatives restantes
            if builder_state["fix"]["attempts"] >= max_attempts:
                builder_state["fix"]["status"] = "failed"
                
                report_actions(
                    event="AUTO_FUNC_BUILD_FIX_FAILED",
                    level="error",
                    message=f"Correction échouée après {max_attempts} tentatives."
                )
        
        # Étape 4 : Rendre le résumé
        builder_state = auto_function_builder_fix_render(builder_state)
        
        # Étape 5 : Logger
        builder_state = auto_function_builder_fix_log(builder_state)
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_ERROR",
            level="error",
            message=f"Erreur durant la boucle FIX: {str(e)}",
            context={"step": "fix"}
        )
        
        builder_state["fix"]["status"] = "failed"
        raise
