"""Résolution des chemins de fichiers pour les outputs."""

import os
from pathlib import Path
from report_actions import report_actions


def auto_function_builder_resolve_paths(builder_state: dict) -> dict:
    """Résout tous les chemins nécessaires pour les fichiers générés.

    Args:
        builder_state: État global contenant 'project' et 'function_request'.

    Returns:
        dict: builder_state avec 'paths' ajouté contenant tous les chemins résolus.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_RESOLVE_PATHS",
        level="info",
        message="Résolution des chemins de fichiers."
    )
    
    project_root = builder_state.get("project", {}).get("root", ".")
    function_name = builder_state.get("function_request", {}).get("function_name", "unknown")
    
    # Définir les répertoires de base
    base_output = os.path.join(project_root, "_OUTPUTS")
    
    paths = {
        "functions_dir": os.path.join(base_output, "FUNCTIONS"),
        "tests_dir": os.path.join(base_output, "TESTS"),
        "reports_dir": os.path.join(base_output, "REPORTS"),
        "logs_dir": os.path.join(base_output, "LOGS"),
        "metadata_dir": os.path.join(base_output, "METADATA"),
    }
    
    # Définir les fichiers spécifiques
    paths.update({
        "function_file": os.path.join(paths["functions_dir"], f"{function_name}.py"),
        "tests_file": os.path.join(paths["tests_dir"], f"test_{function_name}.py"),
        "report_file": os.path.join(paths["reports_dir"], f"{function_name}_validation_report.md"),
        "logs_file": os.path.join(paths["logs_dir"], "auto_function_builder_logs.jsonl"),
        "metadata_file": os.path.join(paths["metadata_dir"], f"{function_name}_metadata.json"),
    })
    
    # Créer les répertoires s'ils n'existent pas
    for dir_key in ["functions_dir", "tests_dir", "reports_dir", "logs_dir", "metadata_dir"]:
        dir_path = paths[dir_key]
        Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    # Mise à jour
    builder_state["paths"] = paths
    
    report_actions(
        event="AUTO_FUNC_BUILD_RESOLVE_PATHS_SUCCESS",
        level="info",
        message="Chemins résolus avec succès.",
        context={"function_file": paths["function_file"]}
    )
    
    return builder_state
