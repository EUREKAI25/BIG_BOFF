"""Module d'interface générique avec les APIs LLM."""

import os
import json
import re
from typing import Optional


def call_llm(
    prompt: str,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    temperature: float = 0.2,
    max_tokens: int = 3000
) -> str:
    """Appelle un LLM via une interface générique.

    Args:
        prompt: Le prompt à envoyer au modèle.
        provider: Provider à utiliser ("openai", "anthropic"). Si None, utilise DEFAULT_PROVIDER.
        model: Modèle à utiliser. Si None, utilise DEFAULT_MODEL.
        temperature: Température pour la génération (0.0-1.0).
        max_tokens: Nombre maximum de tokens à générer.

    Returns:
        La réponse textuelle du modèle.

    Raises:
        ValueError: Si le provider n'est pas supporté ou si la clé API est manquante.
        RuntimeError: Si l'appel API échoue.
    """
    provider = provider or os.getenv("DEFAULT_PROVIDER", "openai")
    model = model or os.getenv("DEFAULT_MODEL", "gpt-4")
    
    if provider == "openai":
        return _call_openai(prompt, model, temperature, max_tokens)
    elif provider == "anthropic":
        return _call_anthropic(prompt, model, temperature, max_tokens)
    else:
        raise ValueError(f"Provider non supporté: {provider}")


def _call_openai(prompt: str, model: str, temperature: float, max_tokens: int) -> str:
    """Appelle l'API OpenAI."""
    try:
        import openai
    except ImportError:
        raise RuntimeError("Le package 'openai' n'est pas installé.")
    
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY n'est pas définie.")
    
    openai.api_key = api_key
    
    try:
        response = openai.ChatCompletion.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=max_tokens
        )
        return response.choices[0].message.content
    except Exception as e:
        raise RuntimeError(f"Erreur lors de l'appel OpenAI: {str(e)}")


def _call_anthropic(prompt: str, model: str, temperature: float, max_tokens: int) -> str:
    """Appelle l'API Anthropic."""
    try:
        import anthropic
    except ImportError:
        raise RuntimeError("Le package 'anthropic' n'est pas installé.")
    
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY n'est pas définie.")
    
    client = anthropic.Anthropic(api_key=api_key)
    
    try:
        response = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text
    except Exception as e:
        raise RuntimeError(f"Erreur lors de l'appel Anthropic: {str(e)}")


def parse_json_response(response: str) -> dict:
    """Parse une réponse JSON depuis un texte, même si elle est dans un bloc markdown.

    Args:
        response: La réponse textuelle contenant du JSON.

    Returns:
        Le dictionnaire parsé.

    Raises:
        ValueError: Si le JSON ne peut pas être parsé.
    """
    # Tenter d'extraire un bloc ```json ... ```
    json_match = re.search(r'```json\s*(.*?)\s*```', response, re.DOTALL)
    if json_match:
        json_text = json_match.group(1)
    else:
        # Tenter de trouver le JSON directement
        json_text = response.strip()
    
    # Nettoyer : chercher le premier { et le dernier }
    start = json_text.find('{')
    end = json_text.rfind('}')
    
    if start == -1 or end == -1:
        raise ValueError("Aucun JSON valide trouvé dans la réponse.")
    
    json_text = json_text[start:end+1]
    
    try:
        return json.loads(json_text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Erreur de parsing JSON: {str(e)}\nTexte: {json_text[:200]}")
