"""Préparation du contexte de correction."""

from report_actions import report_actions


def auto_function_builder_fix_get(builder_state: dict) -> dict:
    """Prépare le contexte pour la correction.

    Args:
        builder_state: État global avec tests échoués.

    Returns:
        dict: builder_state avec contexte de correction préparé.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_GET",
        level="info",
        message="Préparation du contexte de correction."
    )
    
    from auto_function_builder_fix_get_failures import auto_function_builder_fix_get_failures
    
    # Extraire les échecs de tests
    builder_state = auto_function_builder_fix_get_failures(builder_state)
    
    return builder_state
