"""Validation du respect des conventions."""

from report_actions import report_actions


def auto_function_builder_validate_conventions(builder_state: dict) -> dict:
    """Vérifie le respect des conventions de l'agence.

    Args:
        builder_state: État global avec function_code.

    Returns:
        dict: builder_state avec conventions_validation mis à jour.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_CONVENTIONS",
        level="info",
        message="Validation des conventions."
    )
    
    function_code = builder_state.get("artifacts", {}).get("function_code", "")
    constraints = builder_state.get("constraints", {}).get("agency_constraints", {})
    
    issues = []
    
    # Vérifier no_print
    if constraints.get("no_print") and "print(" in function_code:
        issues.append("Utilisation de print() détectée")
    
    # Vérifier docstring
    if '"""' not in function_code:
        issues.append("Docstring manquante")
    
    # Déterminer le statut
    if not issues:
        builder_state["validation"]["conventions_validation"] = "ok"
        status = "ok"
    else:
        builder_state["validation"]["conventions_validation"] = "failed"
        builder_state["validation"]["conventions_issues"] = issues
        status = "failed"
    
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_CONVENTIONS_COMPLETE",
        level="info",
        message=f"Validation conventions: {status}",
        context={"issues": issues} if issues else None
    )
    
    return builder_state
