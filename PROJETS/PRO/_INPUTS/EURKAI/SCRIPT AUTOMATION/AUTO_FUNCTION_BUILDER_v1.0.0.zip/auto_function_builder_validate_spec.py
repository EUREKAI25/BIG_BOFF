"""Validation de la cohérence spec/code."""

from report_actions import report_actions


def auto_function_builder_validate_spec(builder_state: dict) -> dict:
    """Vérifie la cohérence entre function_spec et code final.

    Args:
        builder_state: État global avec function_spec et function_code.

    Returns:
        dict: builder_state avec spec_validation mis à jour.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_SPEC",
        level="info",
        message="Validation de la cohérence spec/code."
    )
    
    function_spec = builder_state.get("function_spec", {})
    function_code = builder_state.get("artifacts", {}).get("function_code", "")
    
    # Vérifications basiques
    spec_name = function_spec.get("name", "")
    
    # Vérifier que le nom de fonction est présent dans le code
    if f"def {spec_name}" in function_code:
        builder_state["validation"]["spec_validation"] = "ok"
        status = "ok"
    else:
        builder_state["validation"]["spec_validation"] = "failed"
        status = "failed"
    
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_SPEC_COMPLETE",
        level="info",
        message=f"Validation spec: {status}"
    )
    
    return builder_state
