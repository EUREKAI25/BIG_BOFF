"""Orchestration de la validation globale."""

from report_actions import report_actions


def auto_function_builder_validate(builder_state: dict) -> dict:
    """Orchestre la phase VALIDATE : spec, conventions, tests, metadata.

    Args:
        builder_state: État global après finalisation.

    Returns:
        dict: builder_state avec validation enrichie.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_START",
        level="info",
        message="Démarrage de la validation globale."
    )
    
    from auto_function_builder_validate_spec import auto_function_builder_validate_spec
    from auto_function_builder_validate_conventions import auto_function_builder_validate_conventions
    from auto_function_builder_validate_tests import auto_function_builder_validate_tests
    from auto_function_builder_validate_metadata import auto_function_builder_validate_metadata
    
    # Initialiser validation
    if "validation" not in builder_state:
        builder_state["validation"] = {}
    
    try:
        # Étape 1 : Validation spec
        builder_state = auto_function_builder_validate_spec(builder_state)
        
        # Étape 2 : Validation conventions
        builder_state = auto_function_builder_validate_conventions(builder_state)
        
        # Étape 3 : Validation tests
        builder_state = auto_function_builder_validate_tests(builder_state)
        
        # Étape 4 : Validation metadata
        builder_state = auto_function_builder_validate_metadata(builder_state)
        
        # Déterminer le statut global
        validation = builder_state["validation"]
        all_ok = all(
            validation.get(key) == "ok"
            for key in ["spec_validation", "conventions_validation", 
                       "tests_validation", "metadata_validation"]
        )
        
        builder_state["validation"]["global_status"] = "success" if all_ok else "failed"
        
        report_actions(
            event="AUTO_FUNC_BUILD_VALIDATE_SUCCESS",
            level="info",
            message=f"Validation terminée: {builder_state['validation']['global_status']}"
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_VALIDATE_ERROR",
            level="error",
            message=f"Erreur durant la validation: {str(e)}"
        )
        raise
