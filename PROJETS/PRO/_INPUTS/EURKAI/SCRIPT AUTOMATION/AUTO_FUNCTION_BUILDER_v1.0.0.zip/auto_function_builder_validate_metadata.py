"""Validation des métadonnées."""

from report_actions import report_actions


def auto_function_builder_validate_metadata(builder_state: dict) -> dict:
    """Vérifie la complétude et cohérence des métadonnées.

    Args:
        builder_state: État global avec metadata.

    Returns:
        dict: builder_state avec metadata_validation mis à jour.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_METADATA",
        level="info",
        message="Validation des métadonnées."
    )
    
    metadata = builder_state.get("metadata", {})
    constraints = builder_state.get("constraints", {}).get("metadata_constraints", {})
    required_fields = constraints.get("required_fields", [])
    
    # Vérifier la présence des champs requis
    missing = [field for field in required_fields if field not in metadata or not metadata[field]]
    
    if not missing:
        builder_state["validation"]["metadata_validation"] = "ok"
        status = "ok"
    else:
        builder_state["validation"]["metadata_validation"] = "failed"
        builder_state["validation"]["metadata_missing"] = missing
        status = "failed"
    
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_METADATA_COMPLETE",
        level="info",
        message=f"Validation metadata: {status}",
        context={"missing": missing} if missing else None
    )
    
    return builder_state
