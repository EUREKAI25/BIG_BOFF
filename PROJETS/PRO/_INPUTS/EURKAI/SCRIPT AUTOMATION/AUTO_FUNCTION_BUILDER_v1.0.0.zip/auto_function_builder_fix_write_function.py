"""Écriture de la fonction corrigée."""

from pathlib import Path
from report_actions import report_actions


def auto_function_builder_fix_write_function(builder_state: dict) -> dict:
    """Écrit la version corrigée de la fonction.

    Args:
        builder_state: État global avec function_code mis à jour.

    Returns:
        dict: builder_state inchangé.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_WRITE",
        level="info",
        message="Écriture de la fonction corrigée."
    )
    
    function_code = builder_state.get("artifacts", {}).get("function_code")
    function_file = builder_state.get("paths", {}).get("function_file")
    
    if not function_code or not function_file:
        raise RuntimeError("function_code ou function_file manquant.")
    
    try:
        with open(function_file, 'w', encoding='utf-8') as f:
            f.write(function_code)
        
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_WRITE_SUCCESS",
            level="info",
            message="Fonction corrigée écrite."
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_FIX_WRITE_ERROR",
            level="error",
            message=f"Erreur d'écriture: {str(e)}"
        )
        raise
