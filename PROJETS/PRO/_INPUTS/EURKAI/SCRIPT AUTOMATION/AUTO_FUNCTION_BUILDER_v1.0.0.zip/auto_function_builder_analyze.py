"""Analyse du brief via IA pour produire function_spec."""

from call_llm import call_llm, parse_json_response
from report_actions import report_actions


def auto_function_builder_analyze(builder_state: dict) -> dict:
    """Analyse le brief via IA et produit une function_spec structurée.

    Args:
        builder_state: État global contenant brief_normalized et constraints.

    Returns:
        dict: builder_state avec 'function_spec' ajouté et notes de validation.

    Raises:
        RuntimeError: Si l'appel IA échoue ou si la réponse est invalide.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_ANALYZE_START",
        level="info",
        message="Analyse du brief via IA."
    )
    
    # Construire le prompt
    prompt = _build_analyze_prompt(builder_state)
    
    try:
        # Appel IA
        response = call_llm(prompt, temperature=0.2, max_tokens=2000)
        
        # Parser la réponse JSON
        parsed = parse_json_response(response)
        
        # Validation du format
        if parsed.get("mode") != "analyze":
            raise ValueError("Mode de réponse incorrect.")
        
        if "function_spec" not in parsed:
            raise ValueError("function_spec manquante dans la réponse.")
        
        # Mise à jour du builder_state
        builder_state["function_spec"] = parsed["function_spec"]
        
        # Stocker les notes
        if "artifacts" not in builder_state:
            builder_state["artifacts"] = {}
        
        builder_state["artifacts"]["validation_notes"] = parsed.get("validation_notes", [])
        builder_state["artifacts"]["readme_notes"] = parsed.get("readme_notes", [])
        
        report_actions(
            event="AUTO_FUNC_BUILD_ANALYZE_SUCCESS",
            level="info",
            message="Analyse terminée avec succès.",
            context={"function_name": parsed["function_spec"].get("name")}
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_ANALYZE_ERROR",
            level="error",
            message=f"Erreur lors de l'analyse: {str(e)}"
        )
        raise RuntimeError(f"Échec de l'analyse: {str(e)}")


def _build_analyze_prompt(builder_state: dict) -> str:
    """Construit le prompt pour l'analyse."""
    brief = builder_state.get("function_request", {}).get("brief_normalized", "")
    language = builder_state.get("function_request", {}).get("language", "python")
    constraints = builder_state.get("constraints", {})
    
    prompt = f"""Tu es intégré dans un système d'agence autonome nommé laNostr'AI / EUREKAI.

RÔLE:
Analyste métier & architecte de fonction

OBJECTIF:
Analyser le brief fourni et produire une function_spec complète et cohérente.

CONTEXTE PROJET:
- Chantier: AUTO_FUNCTION_BUILDER
- Langage: {language}

BRIEF NORMALISÉ:
{brief}

CONTRAINTES AGENCE:
{_format_constraints(constraints.get("agency_constraints", {}))}

CONTRAINTES TESTS:
{_format_constraints(constraints.get("tests_constraints", {}))}

LIVRABLES REQUIS:
Produis une function_spec structurée avec:
- name: nom de la fonction (snake_case)
- description: description claire et concise
- inputs: liste des paramètres (name, type, description, required)
- outputs: liste des sorties (name, type, description)
- errors: liste des exceptions possibles (name, description)
- acceptance_criteria: liste des critères d'acceptation

FORMAT DE RÉPONSE:
Tu dois répondre EXCLUSIVEMENT en JSON valide, sans texte autour.
Structure attendue :
{{
  "mode": "analyze",
  "function_spec": {{
    "name": "string",
    "description": "string",
    "inputs": [],
    "outputs": [],
    "errors": [],
    "acceptance_criteria": []
  }},
  "validation_notes": [],
  "readme_notes": []
}}
"""
    return prompt


def _format_constraints(constraints_dict: dict) -> str:
    """Formate un dictionnaire de contraintes en texte."""
    lines = []
    for key, value in constraints_dict.items():
        lines.append(f"- {key}: {value}")
    return "\n".join(lines) if lines else "Aucune contrainte spécifique."
