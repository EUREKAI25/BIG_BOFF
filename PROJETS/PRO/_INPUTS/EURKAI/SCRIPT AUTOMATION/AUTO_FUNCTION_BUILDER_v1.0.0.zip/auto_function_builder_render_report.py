"""Génération du rapport de validation."""

from report_actions import report_actions


def auto_function_builder_render_report(builder_state: dict) -> dict:
    """Génère le rapport de validation final (Markdown).

    Args:
        builder_state: État global avec toutes les validations.

    Returns:
        dict: builder_state inchangé (rapport écrit sur disque).
    """
    report_actions(
        event="AUTO_FUNC_BUILD_RENDER_REPORT",
        level="info",
        message="Génération du rapport de validation."
    )
    
    report_content = _build_report_content(builder_state)
    report_file = builder_state.get("paths", {}).get("report_file")
    
    if report_file:
        from pathlib import Path
        Path(report_file).parent.mkdir(parents=True, exist_ok=True)
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        report_actions(
            event="AUTO_FUNC_BUILD_RENDER_REPORT_SUCCESS",
            level="info",
            message="Rapport généré.",
            context={"file": report_file}
        )
    
    return builder_state


def _build_report_content(builder_state: dict) -> str:
    """Construit le contenu du rapport."""
    function_name = builder_state.get("function_spec", {}).get("name", "unknown")
    validation = builder_state.get("validation", {})
    tests = builder_state.get("tests", {})
    fix = builder_state.get("fix", {})
    
    report = f"""# Rapport de validation - {function_name}

## Résumé

- **Fonction**: {function_name}
- **Statut global**: {validation.get('global_status', 'unknown')}
- **Date**: {_get_timestamp()}

## Validation

### Spécification
- Statut: {validation.get('spec_validation', 'pending')}

### Conventions
- Statut: {validation.get('conventions_validation', 'pending')}

### Tests
- Statut: {validation.get('tests_validation', 'pending')}
- Tests réussis: {len(tests.get('report', {}).get('passed_tests', []))}
- Tests échoués: {len(tests.get('report', {}).get('failed_tests', []))}

### Métadonnées
- Statut: {validation.get('metadata_validation', 'pending')}

## Corrections

- Tentatives: {fix.get('attempts', 0)}
- Statut final: {fix.get('status', 'not_started')}

## Fichiers générés

- Fonction: {builder_state.get('paths', {}).get('function_file', 'N/A')}
- Tests: {builder_state.get('paths', {}).get('tests_file', 'N/A')}
- Métadonnées: {builder_state.get('paths', {}).get('metadata_file', 'N/A')}

---
Généré automatiquement par AUTO FUNCTION BUILDER
"""
    return report


def _get_timestamp() -> str:
    """Retourne le timestamp actuel."""
    from datetime import datetime
    return datetime.utcnow().isoformat()
