"""Finalisation et enregistrement des logs."""

from report_actions import report_actions


def auto_function_builder_render_logs(builder_state: dict) -> dict:
    """Finalise et enregistre les logs dans le système de report_actions.

    Args:
        builder_state: État global final.

    Returns:
        dict: builder_state inchangé.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_COMPLETE",
        level="info",
        message="Génération de fonction terminée.",
        context={
            "function_name": builder_state.get("function_spec", {}).get("name"),
            "global_status": builder_state.get("validation", {}).get("global_status"),
            "tests_status": builder_state.get("tests", {}).get("status"),
            "fix_attempts": builder_state.get("fix", {}).get("attempts", 0)
        }
    )
    
    return builder_state
