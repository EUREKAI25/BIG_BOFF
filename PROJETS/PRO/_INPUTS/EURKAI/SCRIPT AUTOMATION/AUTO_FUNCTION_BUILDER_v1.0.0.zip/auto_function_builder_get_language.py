"""Détermination du langage de programmation cible."""

from report_actions import report_actions


def auto_function_builder_get_language(builder_state: dict) -> dict:
    """Détermine le langage de programmation à utiliser.

    Args:
        builder_state: État global contenant 'function_request'.

    Returns:
        dict: builder_state avec 'language' ajouté dans 'function_request'.

    Raises:
        ValueError: Si le langage spécifié n'est pas supporté.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GET_LANGUAGE",
        level="info",
        message="Détermination du langage de programmation."
    )
    
    function_request = builder_state.get("function_request", {})
    
    # Si le langage est déjà spécifié, le valider
    if "language" in function_request and function_request["language"]:
        language = function_request["language"]
    else:
        # Par défaut : Python
        language = "python"
    
    # Validation
    supported_languages = ["python"]  # Pour l'instant, uniquement Python
    
    if language.lower() not in supported_languages:
        raise ValueError(
            f"Langage '{language}' non supporté. "
            f"Langages supportés: {', '.join(supported_languages)}"
        )
    
    # Normalisation
    language = language.lower()
    
    # Mise à jour
    builder_state["function_request"]["language"] = language
    
    report_actions(
        event="AUTO_FUNC_BUILD_GET_LANGUAGE_SUCCESS",
        level="info",
        message="Langage déterminé.",
        context={"language": language}
    )
    
    return builder_state
