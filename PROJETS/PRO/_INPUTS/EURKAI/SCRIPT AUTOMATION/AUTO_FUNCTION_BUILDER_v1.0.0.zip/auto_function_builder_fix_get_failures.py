"""Extraction des échecs de tests."""

from report_actions import report_actions


def auto_function_builder_fix_get_failures(builder_state: dict) -> dict:
    """Extrait et structure les échecs de tests.

    Args:
        builder_state: État global contenant tests.report.

    Returns:
        dict: builder_state avec fix_context ajouté.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_GET_FAILURES",
        level="info",
        message="Extraction des échecs de tests."
    )
    
    tests_report = builder_state.get("tests", {}).get("report", {})
    failed_tests = tests_report.get("failed_tests", [])
    raw_output = tests_report.get("raw_output", "")
    
    # Structurer le contexte de correction
    fix_context = {
        "failed_count": len(failed_tests),
        "failed_tests": failed_tests,
        "error_summary": _extract_error_summary(raw_output),
        "raw_output": raw_output
    }
    
    # Ajouter au builder_state
    builder_state["fix_context"] = fix_context
    
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_GET_FAILURES_SUCCESS",
        level="info",
        message=f"Échecs extraits: {len(failed_tests)} tests échoués."
    )
    
    return builder_state


def _extract_error_summary(raw_output: str) -> str:
    """Extrait un résumé des erreurs depuis la sortie pytest."""
    lines = raw_output.split('\n')
    error_lines = []
    
    in_error_section = False
    
    for line in lines:
        # Détecter les sections d'erreur
        if "FAILED" in line or "ERROR" in line or "AssertionError" in line:
            in_error_section = True
        
        if in_error_section:
            error_lines.append(line)
            
            # Limiter à 20 lignes pour ne pas surcharger
            if len(error_lines) >= 20:
                break
    
    return '\n'.join(error_lines) if error_lines else "Aucune erreur détaillée trouvée."
