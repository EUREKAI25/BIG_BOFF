"""Génération du code de fonction via IA."""

import json
from call_llm import call_llm, parse_json_response
from report_actions import report_actions


def auto_function_builder_generate_code(builder_state: dict) -> dict:
    """Génère le code complet de la fonction via IA.

    Args:
        builder_state: État global contenant function_spec et function_skeleton.

    Returns:
        dict: builder_state avec 'function_code' ajouté dans artifacts.

    Raises:
        RuntimeError: Si l'appel IA échoue ou si la réponse est invalide.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GENERATE_CODE_START",
        level="info",
        message="Génération du code via IA."
    )
    
    # Construire le prompt
    prompt = _build_generate_code_prompt(builder_state)
    
    try:
        # Appel IA
        response = call_llm(prompt, temperature=0.2, max_tokens=3000)
        
        # Parser la réponse JSON
        parsed = parse_json_response(response)
        
        # Validation du format
        if parsed.get("mode") != "generate_code":
            raise ValueError("Mode de réponse incorrect.")
        
        if "function_code" not in parsed:
            raise ValueError("function_code manquante dans la réponse.")
        
        # Mise à jour du builder_state
        if "artifacts" not in builder_state:
            builder_state["artifacts"] = {}
        
        builder_state["artifacts"]["function_code"] = parsed["function_code"]
        
        # Ajouter les notes
        if "validation_notes" in parsed:
            builder_state["artifacts"].setdefault("validation_notes", []).extend(
                parsed["validation_notes"]
            )
        
        if "readme_notes" in parsed:
            builder_state["artifacts"].setdefault("readme_notes", []).extend(
                parsed["readme_notes"]
            )
        
        report_actions(
            event="AUTO_FUNC_BUILD_GENERATE_CODE_SUCCESS",
            level="info",
            message="Code généré avec succès."
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_GENERATE_CODE_ERROR",
            level="error",
            message=f"Erreur lors de la génération du code: {str(e)}"
        )
        raise RuntimeError(f"Échec de la génération du code: {str(e)}")


def _build_generate_code_prompt(builder_state: dict) -> str:
    """Construit le prompt pour la génération de code."""
    function_spec = builder_state.get("function_spec", {})
    skeleton = builder_state.get("artifacts", {}).get("function_skeleton", "")
    language = builder_state.get("function_request", {}).get("language", "python")
    constraints = builder_state.get("constraints", {})
    code_context = builder_state.get("code_context", {})
    
    prompt = f"""Tu es intégré dans un système d'agence autonome nommé laNostr'AI / EUREKAI.

RÔLE:
Développeur backend senior

OBJECTIF:
Générer le code complet de la fonction à partir de la spécification et du squelette fournis.

CONTEXTE PROJET:
- Chantier: AUTO_FUNCTION_BUILDER
- Langage: {language}

FUNCTION_SPEC:
{json.dumps(function_spec, indent=2, ensure_ascii=False)}

SQUELETTE DE FONCTION:
{skeleton}

CONTRAINTES AGENCE:
{_format_constraints(constraints.get("agency_constraints", {}))}

CONTEXTE CODE (fonctions disponibles):
{_format_code_context(code_context)}

RÈGLES IMPORTANTES:
1. Une seule fonction par fichier
2. Utiliser report_actions() au lieu de print() pour le logging
3. Docstring Google-style obligatoire
4. Imports propres et organisés
5. Gestion d'erreurs appropriée
6. Code production-ready et testé

LIVRABLES REQUIS:
Code Python complet et fonctionnel de la fonction, incluant:
- Tous les imports nécessaires
- La docstring complète
- L'implémentation fonctionnelle
- La gestion d'erreurs

FORMAT DE RÉPONSE:
Tu dois répondre EXCLUSIVEMENT en JSON valide, sans texte autour.
Structure attendue :
{{
  "mode": "generate_code",
  "function_code": "code Python complet ici",
  "validation_notes": ["note 1", "note 2"],
  "readme_notes": ["note pour le README"]
}}
"""
    return prompt


def _format_constraints(constraints_dict: dict) -> str:
    """Formate un dictionnaire de contraintes en texte."""
    lines = []
    for key, value in constraints_dict.items():
        lines.append(f"- {key}: {value}")
    return "\n".join(lines) if lines else "Aucune contrainte spécifique."


def _format_code_context(code_context: dict) -> str:
    """Formate le contexte de code."""
    related = code_context.get("related_functions", [])
    if not related:
        return "Aucune fonction liée disponible."
    
    lines = []
    for func in related[:5]:  # Limiter à 5 pour ne pas surcharger le prompt
        lines.append(f"- {func.get('name')}: {func.get('signature')}")
    
    return "\n".join(lines)
