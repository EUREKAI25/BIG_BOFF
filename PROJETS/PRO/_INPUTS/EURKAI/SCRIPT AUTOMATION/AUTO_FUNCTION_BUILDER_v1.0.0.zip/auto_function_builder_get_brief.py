"""Récupération et normalisation du brief utilisateur."""

from report_actions import report_actions


def auto_function_builder_get_brief(builder_state: dict) -> dict:
    """Récupère et normalise le brief fourni par l'utilisateur.

    Args:
        builder_state: État global contenant au minimum la clé 'function_request'
            avec le champ 'brief_raw'.

    Returns:
        dict: builder_state avec 'brief_normalized' ajouté dans 'function_request'.

    Raises:
        ValueError: Si le brief est vide ou invalide.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GET_BRIEF",
        level="info",
        message="Récupération et normalisation du brief."
    )
    
    # Récupération du brief brut
    function_request = builder_state.get("function_request", {})
    brief_raw = function_request.get("brief_raw", "")
    
    # Validation
    if not brief_raw or not brief_raw.strip():
        raise ValueError("Le brief est vide ou invalide.")
    
    # Normalisation
    brief_normalized = brief_raw.strip()
    
    # Suppression des retours à la ligne multiples
    import re
    brief_normalized = re.sub(r'\n\s*\n', '\n', brief_normalized)
    
    # Mise à jour du builder_state
    if "function_request" not in builder_state:
        builder_state["function_request"] = {}
    
    builder_state["function_request"]["brief_normalized"] = brief_normalized
    
    report_actions(
        event="AUTO_FUNC_BUILD_GET_BRIEF_SUCCESS",
        level="info",
        message="Brief normalisé avec succès.",
        context={"brief_length": len(brief_normalized)}
    )
    
    return builder_state
