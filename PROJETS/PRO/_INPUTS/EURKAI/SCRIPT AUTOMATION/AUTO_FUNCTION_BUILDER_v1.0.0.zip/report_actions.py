"""Module de logging structuré pour l'agence EUREKAI."""

import json
from datetime import datetime
from typing import Optional, Dict, Any
from pathlib import Path


def report_actions(
    event: str,
    level: str = "info",
    message: Optional[str] = None,
    context: Optional[Dict[str, Any]] = None,
    extra: Optional[Dict[str, Any]] = None
) -> None:
    """Enregistre un événement dans le système de logs de l'agence.

    Args:
        event: Identifiant court de l'événement (ex: "AUTO_FUNC_BUILD_START").
        level: Niveau de log (debug, info, warning, error, critical).
        message: Message lisible humain.
        context: Contexte structuré (paths, fonction en cours, step, etc.).
        extra: Données additionnelles spécifiques à l'événement.
    """
    log_entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "event": event,
        "level": level,
    }
    
    if message:
        log_entry["message"] = message
    
    if context:
        log_entry["context"] = context
    
    if extra:
        log_entry["extra"] = extra
    
    # Affichage console pour debug
    print(json.dumps(log_entry, ensure_ascii=False))
