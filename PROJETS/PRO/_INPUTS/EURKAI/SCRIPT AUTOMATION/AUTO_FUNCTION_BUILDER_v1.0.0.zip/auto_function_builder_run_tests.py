"""Exécution des tests unitaires."""

import subprocess
import sys
from report_actions import report_actions


def auto_function_builder_run_tests(builder_state: dict) -> dict:
    """Exécute les tests unitaires et collecte les résultats.

    Args:
        builder_state: État global contenant paths.tests_file.

    Returns:
        dict: builder_state avec 'tests' enrichi (status, report).

    Raises:
        RuntimeError: Si l'exécution des tests échoue de manière critique.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_RUN_TESTS_START",
        level="info",
        message="Exécution des tests."
    )
    
    tests_file = builder_state.get("paths", {}).get("tests_file")
    
    if not tests_file:
        raise RuntimeError("tests_file est manquant dans paths.")
    
    try:
        # Exécuter pytest
        result = subprocess.run(
            [sys.executable, "-m", "pytest", tests_file, "-v", "--tb=short"],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        # Analyser les résultats
        tests_status = "success" if result.returncode == 0 else "failed"
        
        # Parser les tests échoués et réussis
        failed_tests, passed_tests = _parse_pytest_output(result.stdout)
        
        # Mise à jour du builder_state
        builder_state["tests"] = {
            "status": tests_status,
            "report": {
                "raw_output": result.stdout + "\n" + result.stderr,
                "failed_tests": failed_tests,
                "passed_tests": passed_tests
            }
        }
        
        report_actions(
            event="AUTO_FUNC_BUILD_RUN_TESTS_COMPLETE",
            level="info" if tests_status == "success" else "warning",
            message=f"Tests terminés: {tests_status}",
            context={
                "status": tests_status,
                "passed": len(passed_tests),
                "failed": len(failed_tests)
            }
        )
        
        return builder_state
        
    except subprocess.TimeoutExpired:
        report_actions(
            event="AUTO_FUNC_BUILD_RUN_TESTS_TIMEOUT",
            level="error",
            message="Timeout lors de l'exécution des tests."
        )
        
        builder_state["tests"] = {
            "status": "failed",
            "report": {
                "raw_output": "Timeout après 60 secondes",
                "failed_tests": [],
                "passed_tests": []
            }
        }
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_RUN_TESTS_ERROR",
            level="error",
            message=f"Erreur lors de l'exécution des tests: {str(e)}"
        )
        raise RuntimeError(f"Échec de l'exécution des tests: {str(e)}")


def _parse_pytest_output(output: str) -> tuple:
    """Parse la sortie pytest pour extraire les tests échoués et réussis.

    Args:
        output: Sortie brute de pytest.

    Returns:
        Tuple (failed_tests, passed_tests) où chaque élément est une liste
        de dictionnaires avec 'name' et 'message'.
    """
    failed_tests = []
    passed_tests = []
    
    lines = output.split('\n')
    
    for line in lines:
        # Tests réussis : lignes commençant par "test_...::... PASSED"
        if "PASSED" in line:
            test_name = line.split("::")[0].strip() if "::" in line else line.strip()
            passed_tests.append({
                "name": test_name,
                "message": "Test réussi"
            })
        
        # Tests échoués : lignes commençant par "test_...::... FAILED"
        elif "FAILED" in line:
            test_name = line.split("::")[0].strip() if "::" in line else line.strip()
            failed_tests.append({
                "name": test_name,
                "message": "Test échoué (voir détails dans raw_output)"
            })
    
    return failed_tests, passed_tests
