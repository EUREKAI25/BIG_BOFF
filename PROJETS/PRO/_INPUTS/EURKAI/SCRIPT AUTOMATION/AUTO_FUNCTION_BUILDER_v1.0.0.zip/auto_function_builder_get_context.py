"""Chargement du contexte de code existant."""

import os
from pathlib import Path
from typing import List, Dict
from report_actions import report_actions


def auto_function_builder_get_context(builder_state: dict) -> dict:
    """Charge le contexte de code existant (fonctions liées, modules, etc.).

    Args:
        builder_state: État global contenant 'project'.

    Returns:
        dict: builder_state avec 'code_context' ajouté.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GET_CONTEXT",
        level="info",
        message="Chargement du contexte de code."
    )
    
    project = builder_state.get("project", {})
    project_root = project.get("root", ".")
    
    # Initialiser le contexte
    code_context = {
        "module_path": project_root,
        "related_functions": []
    }
    
    # Tenter de charger des fonctions liées (si un répertoire est spécifié)
    related_functions = _scan_related_functions(project_root)
    code_context["related_functions"] = related_functions
    
    # Mise à jour
    builder_state["code_context"] = code_context
    
    report_actions(
        event="AUTO_FUNC_BUILD_GET_CONTEXT_SUCCESS",
        level="info",
        message="Contexte de code chargé.",
        context={"related_functions_count": len(related_functions)}
    )
    
    return builder_state


def _scan_related_functions(project_root: str) -> List[Dict[str, str]]:
    """Scan le répertoire projet pour trouver des fonctions liées.

    Args:
        project_root: Chemin racine du projet.

    Returns:
        Liste de dictionnaires décrivant les fonctions trouvées.
    """
    related_functions = []
    
    # Vérifier si le répertoire existe
    root_path = Path(project_root)
    if not root_path.exists() or not root_path.is_dir():
        return related_functions
    
    # Scanner les fichiers Python
    try:
        for py_file in root_path.rglob("*.py"):
            # Ignorer les fichiers de test et __pycache__
            if "test_" in py_file.name or "__pycache__" in str(py_file):
                continue
            
            # Extraire les informations basiques
            function_info = _extract_function_info(py_file)
            if function_info:
                related_functions.append(function_info)
    
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_GET_CONTEXT_SCAN_ERROR",
            level="warning",
            message=f"Erreur lors du scan du contexte: {str(e)}"
        )
    
    return related_functions


def _extract_function_info(file_path: Path) -> Dict[str, str]:
    """Extrait les informations d'une fonction depuis un fichier.

    Args:
        file_path: Chemin vers le fichier Python.

    Returns:
        Dictionnaire avec name, path, signature, role (ou None si échec).
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extraction basique du nom de fonction (première fonction def)
        import re
        match = re.search(r'def\s+(\w+)\s*\((.*?)\):', content)
        if match:
            return {
                "name": match.group(1),
                "path": str(file_path),
                "signature": f"{match.group(1)}({match.group(2)})",
                "role": "helper"  # Par défaut
            }
    except Exception:
        pass
    
    return None
