"""Construction du squelette de fonction conforme aux conventions."""

from report_actions import report_actions


def auto_function_builder_build_skeleton(builder_state: dict) -> dict:
    """Construit le squelette de fonction conforme aux conventions agence.

    Args:
        builder_state: État global contenant function_spec.

    Returns:
        dict: builder_state avec 'function_skeleton' ajouté dans artifacts.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_SKELETON_START",
        level="info",
        message="Construction du squelette de fonction."
    )
    
    function_spec = builder_state.get("function_spec", {})
    
    # Extraire les informations
    name = function_spec.get("name", "unknown_function")
    description = function_spec.get("description", "")
    inputs = function_spec.get("inputs", [])
    outputs = function_spec.get("outputs", [])
    errors = function_spec.get("errors", [])
    
    # Construire la signature
    signature = _build_signature(name, inputs)
    
    # Construire la docstring
    docstring = _build_docstring(description, inputs, outputs, errors)
    
    # Construire le squelette complet
    skeleton = f'''"""Module généré automatiquement."""

{signature}
    """{docstring}"""
    # TODO: implémentation
    raise NotImplementedError("Fonction non encore implémentée.")
'''
    
    # Mise à jour
    if "artifacts" not in builder_state:
        builder_state["artifacts"] = {}
    
    builder_state["artifacts"]["function_skeleton"] = skeleton
    
    report_actions(
        event="AUTO_FUNC_BUILD_SKELETON_SUCCESS",
        level="info",
        message="Squelette construit avec succès.",
        context={"function_name": name}
    )
    
    return builder_state


def _build_signature(name: str, inputs: list) -> str:
    """Construit la signature de la fonction."""
    params = []
    
    for inp in inputs:
        param_name = inp.get("name", "param")
        param_type = inp.get("type", "Any")
        required = inp.get("required", True)
        
        if required:
            params.append(f"{param_name}: {param_type}")
        else:
            params.append(f"{param_name}: {param_type} = None")
    
    params_str = ", ".join(params)
    
    # Pour l'instant, on retourne Any si pas de spécification explicite
    return f"def {name}({params_str}):"


def _build_docstring(description: str, inputs: list, outputs: list, errors: list) -> str:
    """Construit la docstring Google-style."""
    lines = []
    
    # Description
    if description:
        lines.append(description)
        lines.append("")
    
    # Args
    if inputs:
        lines.append("Args:")
        for inp in inputs:
            param_name = inp.get("name", "param")
            param_desc = inp.get("description", "")
            param_type = inp.get("type", "")
            
            if param_type:
                lines.append(f"    {param_name} ({param_type}): {param_desc}")
            else:
                lines.append(f"    {param_name}: {param_desc}")
        lines.append("")
    
    # Returns
    if outputs:
        lines.append("Returns:")
        for out in outputs:
            out_type = out.get("type", "")
            out_desc = out.get("description", "")
            
            if out_type:
                lines.append(f"    {out_type}: {out_desc}")
            else:
                lines.append(f"    {out_desc}")
        lines.append("")
    
    # Raises
    if errors:
        lines.append("Raises:")
        for err in errors:
            err_name = err.get("name", "Exception")
            err_desc = err.get("description", "")
            lines.append(f"    {err_name}: {err_desc}")
    
    return "\n    ".join(lines)
