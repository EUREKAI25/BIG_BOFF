"""Exécution de la correction."""

from report_actions import report_actions


def auto_function_builder_fix_execute(builder_state: dict) -> dict:
    """Exécute la séquence de correction: apply → write → rerun.

    Args:
        builder_state: État global avec fix_context.

    Returns:
        dict: builder_state avec nouvelle version du code et résultats tests.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_EXECUTE",
        level="info",
        message="Exécution de la correction."
    )
    
    from auto_function_builder_fix_apply import auto_function_builder_fix_apply
    from auto_function_builder_fix_write_function import auto_function_builder_fix_write_function
    from auto_function_builder_fix_rerun_tests import auto_function_builder_fix_rerun_tests
    
    # Étape 1 : Proposer une correction (IA)
    builder_state = auto_function_builder_fix_apply(builder_state)
    
    # Étape 2 : Écrire le code corrigé
    builder_state = auto_function_builder_fix_write_function(builder_state)
    
    # Étape 3 : Relancer les tests
    builder_state = auto_function_builder_fix_rerun_tests(builder_state)
    
    return builder_state
