"""Écriture des tests générés sur disque."""

from pathlib import Path
from report_actions import report_actions


def auto_function_builder_write_tests(builder_state: dict) -> dict:
    """Écrit les tests générés dans le fichier cible.

    Args:
        builder_state: État global contenant tests_code et paths.

    Returns:
        dict: builder_state inchangé (confirmation d'écriture).

    Raises:
        RuntimeError: Si l'écriture échoue.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_WRITE_TESTS_START",
        level="info",
        message="Écriture des tests sur disque."
    )
    
    # Récupérer le code et le chemin
    tests_code = builder_state.get("artifacts", {}).get("tests_code")
    tests_file = builder_state.get("paths", {}).get("tests_file")
    
    if not tests_code:
        raise RuntimeError("tests_code est manquant dans artifacts.")
    
    if not tests_file:
        raise RuntimeError("tests_file est manquant dans paths.")
    
    try:
        # Créer le répertoire parent si nécessaire
        file_path = Path(tests_file)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Écrire le fichier
        with open(tests_file, 'w', encoding='utf-8') as f:
            f.write(tests_code)
        
        report_actions(
            event="AUTO_FUNC_BUILD_WRITE_TESTS_SUCCESS",
            level="info",
            message="Tests écrits avec succès.",
            context={"file": tests_file}
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_WRITE_TESTS_ERROR",
            level="error",
            message=f"Erreur lors de l'écriture des tests: {str(e)}"
        )
        raise RuntimeError(f"Échec de l'écriture des tests: {str(e)}")
