"""Relance des tests après correction."""

from report_actions import report_actions


def auto_function_builder_fix_rerun_tests(builder_state: dict) -> dict:
    """Relance les tests après correction.

    Args:
        builder_state: État global après correction.

    Returns:
        dict: builder_state avec tests mis à jour.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_RERUN",
        level="info",
        message="Relance des tests."
    )
    
    from auto_function_builder_run_tests import auto_function_builder_run_tests
    
    # Relancer les tests
    builder_state = auto_function_builder_run_tests(builder_state)
    
    return builder_state
