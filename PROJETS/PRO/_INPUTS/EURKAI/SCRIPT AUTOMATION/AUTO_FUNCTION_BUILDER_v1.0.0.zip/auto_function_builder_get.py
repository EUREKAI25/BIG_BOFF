"""Orchestration de la phase GET du builder."""

from report_actions import report_actions


def auto_function_builder_get(builder_state: dict) -> dict:
    """Orchestre la phase GET : collecte tous les paramètres nécessaires.

    Args:
        builder_state: État global contenant au minimum la clé 'function_request'
            avec 'brief_raw'.

    Returns:
        dict: builder_state enrichi avec brief_normalized, function_name,
        language, constraints, context, et paths.

    Raises:
        ValueError: Si le brief est invalide ou si une étape échoue.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GET_START",
        level="info",
        message="Démarrage de la phase GET.",
        context={"step": "get"}
    )
    
    # Import des sous-fonctions
    from auto_function_builder_get_brief import auto_function_builder_get_brief
    from auto_function_builder_get_function_name import auto_function_builder_get_function_name
    from auto_function_builder_get_language import auto_function_builder_get_language
    from auto_function_builder_get_constraints import auto_function_builder_get_constraints
    from auto_function_builder_get_context import auto_function_builder_get_context
    from auto_function_builder_resolve_paths import auto_function_builder_resolve_paths
    
    try:
        # Étape 1 : Brief
        builder_state = auto_function_builder_get_brief(builder_state)
        
        # Étape 2 : Nom de fonction
        builder_state = auto_function_builder_get_function_name(builder_state)
        
        # Étape 3 : Langage
        builder_state = auto_function_builder_get_language(builder_state)
        
        # Étape 4 : Contraintes
        builder_state = auto_function_builder_get_constraints(builder_state)
        
        # Étape 5 : Contexte
        builder_state = auto_function_builder_get_context(builder_state)
        
        # Étape 6 : Résolution des paths
        builder_state = auto_function_builder_resolve_paths(builder_state)
        
        report_actions(
            event="AUTO_FUNC_BUILD_GET_SUCCESS",
            level="info",
            message="Phase GET terminée avec succès.",
            context={
                "step": "get",
                "function_name": builder_state.get("function_request", {}).get("function_name")
            }
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_GET_ERROR",
            level="error",
            message=f"Erreur durant la phase GET: {str(e)}",
            context={"step": "get"}
        )
        raise
