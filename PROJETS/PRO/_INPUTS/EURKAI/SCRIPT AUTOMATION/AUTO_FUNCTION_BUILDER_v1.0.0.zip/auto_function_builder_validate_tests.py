"""Validation des tests."""

from report_actions import report_actions


def auto_function_builder_validate_tests(builder_state: dict) -> dict:
    """Vérifie que les tests requis sont présents et passent.

    Args:
        builder_state: État global avec tests.

    Returns:
        dict: builder_state avec tests_validation mis à jour.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_TESTS",
        level="info",
        message="Validation des tests."
    )
    
    tests = builder_state.get("tests", {})
    tests_status = tests.get("status")
    constraints = builder_state.get("constraints", {}).get("tests_constraints", {})
    
    min_cases = constraints.get("min_cases", 3)
    passed_tests = tests.get("report", {}).get("passed_tests", [])
    
    # Vérifier le statut et le nombre de tests
    if tests_status == "success" and len(passed_tests) >= min_cases:
        builder_state["validation"]["tests_validation"] = "ok"
        status = "ok"
    else:
        builder_state["validation"]["tests_validation"] = "failed"
        status = "failed"
    
    report_actions(
        event="AUTO_FUNC_BUILD_VALIDATE_TESTS_COMPLETE",
        level="info",
        message=f"Validation tests: {status}",
        context={"passed": len(passed_tests), "required": min_cases}
    )
    
    return builder_state
