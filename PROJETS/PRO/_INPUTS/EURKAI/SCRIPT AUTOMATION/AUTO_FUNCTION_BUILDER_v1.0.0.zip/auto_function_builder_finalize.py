"""Finalisation du processus de génération."""

from report_actions import report_actions


def auto_function_builder_finalize(builder_state: dict) -> dict:
    """Finalise la génération (formatage, métadonnées).

    Args:
        builder_state: État global après EXECUTE et FIX.

    Returns:
        dict: builder_state finalisé.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FINALIZE_START",
        level="info",
        message="Finalisation de la génération."
    )
    
    # Générer les métadonnées
    metadata = _generate_metadata(builder_state)
    builder_state["metadata"] = metadata
    
    # Écrire les métadonnées
    _write_metadata(builder_state)
    
    report_actions(
        event="AUTO_FUNC_BUILD_FINALIZE_SUCCESS",
        level="info",
        message="Finalisation terminée."
    )
    
    return builder_state


def _generate_metadata(builder_state: dict) -> dict:
    """Génère les métadonnées de la fonction."""
    from datetime import datetime
    
    function_spec = builder_state.get("function_spec", {})
    function_name = function_spec.get("name", "unknown")
    
    metadata = {
        "name": function_name,
        "description": function_spec.get("description", ""),
        "version": "1.0.0",
        "author": "laNostrAI",
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat(),
        "language": "python",
        "object_type": "function",
        "module": "AUTO_FUNCTION_BUILDER",
        "tags": ["generated", "auto"],
        "dependencies": ["report_actions"],
        "scenarios": ["AUTO_FUNCTION_BUILDER"],
        "inputs_schema": {inp["name"]: {"type": inp.get("type"), "required": inp.get("required", True)} 
                         for inp in function_spec.get("inputs", [])},
        "outputs_schema": {out["name"]: {"type": out.get("type")} 
                          for out in function_spec.get("outputs", [])}
    }
    
    return metadata


def _write_metadata(builder_state: dict):
    """Écrit les métadonnées dans un fichier JSON."""
    import json
    from pathlib import Path
    
    metadata = builder_state.get("metadata", {})
    metadata_file = builder_state.get("paths", {}).get("metadata_file")
    
    if metadata_file:
        Path(metadata_file).parent.mkdir(parents=True, exist_ok=True)
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
