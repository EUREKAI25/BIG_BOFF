"""Détermination du nom de fonction à partir du brief."""

import re
from report_actions import report_actions


def auto_function_builder_get_function_name(builder_state: dict) -> dict:
    """Détermine le nom de la fonction à partir du brief ou d'une spécification.

    Args:
        builder_state: État global contenant 'function_request' avec 'brief_normalized'.

    Returns:
        dict: builder_state avec 'function_name' ajouté dans 'function_request'.

    Raises:
        ValueError: Si le nom de fonction ne peut pas être déterminé.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_GET_FUNCTION_NAME",
        level="info",
        message="Détermination du nom de fonction."
    )
    
    function_request = builder_state.get("function_request", {})
    
    # Si le nom est déjà fourni, le valider
    if "function_name" in function_request and function_request["function_name"]:
        function_name = function_request["function_name"]
    else:
        # Extraire le nom depuis le brief
        brief = function_request.get("brief_normalized", "")
        function_name = _extract_function_name_from_brief(brief)
    
    # Validation du nom
    if not _is_valid_function_name(function_name):
        raise ValueError(f"Nom de fonction invalide: {function_name}")
    
    # Mise à jour
    builder_state["function_request"]["function_name"] = function_name
    
    report_actions(
        event="AUTO_FUNC_BUILD_GET_FUNCTION_NAME_SUCCESS",
        level="info",
        message="Nom de fonction déterminé.",
        context={"function_name": function_name}
    )
    
    return builder_state


def _extract_function_name_from_brief(brief: str) -> str:
    """Extrait un nom de fonction du brief (heuristique simple)."""
    # Chercher des patterns comme "fonction nommée X" ou "créer X"
    patterns = [
        r'fonction\s+(?:nommée|appelée)\s+["\']?(\w+)["\']?',
        r'créer\s+["\']?(\w+)["\']?',
        r'générer\s+["\']?(\w+)["\']?',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, brief, re.IGNORECASE)
        if match:
            return match.group(1)
    
    # Par défaut, utiliser un nom générique
    return "auto_generated_function"


def _is_valid_function_name(name: str) -> bool:
    """Vérifie que le nom de fonction est valide en Python."""
    if not name:
        return False
    
    # Doit commencer par une lettre ou underscore
    if not re.match(r'^[a-zA-Z_]', name):
        return False
    
    # Ne doit contenir que des lettres, chiffres et underscores
    if not re.match(r'^[a-zA-Z0-9_]+$', name):
        return False
    
    # Ne doit pas être un mot-clé Python
    import keyword
    if keyword.iskeyword(name):
        return False
    
    return True
