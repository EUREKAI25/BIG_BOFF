"""Orchestration de la phase EXECUTE du builder."""

from report_actions import report_actions


def auto_function_builder_execute(builder_state: dict) -> dict:
    """Orchestre la phase EXECUTE : analyse, génération code, génération tests, exécution.

    Args:
        builder_state: État global complet après GET.

    Returns:
        dict: builder_state enrichi avec function_spec, artifacts, et tests.

    Raises:
        RuntimeError: Si une étape échoue.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_EXECUTE_START",
        level="info",
        message="Démarrage de la phase EXECUTE.",
        context={"step": "execute"}
    )
    
    # Import des sous-fonctions
    from auto_function_builder_analyze import auto_function_builder_analyze
    from auto_function_builder_build_skeleton import auto_function_builder_build_skeleton
    from auto_function_builder_generate_code import auto_function_builder_generate_code
    from auto_function_builder_write_function import auto_function_builder_write_function
    from auto_function_builder_generate_tests import auto_function_builder_generate_tests
    from auto_function_builder_write_tests import auto_function_builder_write_tests
    from auto_function_builder_run_tests import auto_function_builder_run_tests
    
    try:
        # Étape 1 : Analyse du brief (IA)
        builder_state = auto_function_builder_analyze(builder_state)
        
        # Étape 2 : Construction du squelette
        builder_state = auto_function_builder_build_skeleton(builder_state)
        
        # Étape 3 : Génération du code (IA)
        builder_state = auto_function_builder_generate_code(builder_state)
        
        # Étape 4 : Écriture de la fonction
        builder_state = auto_function_builder_write_function(builder_state)
        
        # Étape 5 : Génération des tests (IA)
        builder_state = auto_function_builder_generate_tests(builder_state)
        
        # Étape 6 : Écriture des tests
        builder_state = auto_function_builder_write_tests(builder_state)
        
        # Étape 7 : Exécution des tests
        builder_state = auto_function_builder_run_tests(builder_state)
        
        report_actions(
            event="AUTO_FUNC_BUILD_EXECUTE_SUCCESS",
            level="info",
            message="Phase EXECUTE terminée avec succès.",
            context={
                "step": "execute",
                "tests_status": builder_state.get("tests", {}).get("status")
            }
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_EXECUTE_ERROR",
            level="error",
            message=f"Erreur durant la phase EXECUTE: {str(e)}",
            context={"step": "execute"}
        )
        raise
