"""Rendu du résumé de correction."""

from report_actions import report_actions


def auto_function_builder_fix_render(builder_state: dict) -> dict:
    """Produit un résumé de la boucle de correction.

    Args:
        builder_state: État global avec fix.

    Returns:
        dict: builder_state avec fix_summary ajouté.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_RENDER",
        level="info",
        message="Génération du résumé de correction."
    )
    
    fix = builder_state.get("fix", {})
    
    summary = {
        "total_attempts": fix.get("attempts", 0),
        "final_status": fix.get("status", "unknown"),
        "iterations": len(fix.get("history", [])),
        "final_tests_status": builder_state.get("tests", {}).get("status")
    }
    
    builder_state["fix_summary"] = summary
    
    return builder_state
