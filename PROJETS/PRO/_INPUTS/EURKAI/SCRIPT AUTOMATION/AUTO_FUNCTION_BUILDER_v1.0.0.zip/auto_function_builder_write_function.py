"""Écriture de la fonction générée sur disque."""

from pathlib import Path
from report_actions import report_actions


def auto_function_builder_write_function(builder_state: dict) -> dict:
    """Écrit le code de fonction généré dans le fichier cible.

    Args:
        builder_state: État global contenant function_code et paths.

    Returns:
        dict: builder_state inchangé (confirmation d'écriture).

    Raises:
        RuntimeError: Si l'écriture échoue.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_WRITE_FUNCTION_START",
        level="info",
        message="Écriture de la fonction sur disque."
    )
    
    # Récupérer le code et le chemin
    function_code = builder_state.get("artifacts", {}).get("function_code")
    function_file = builder_state.get("paths", {}).get("function_file")
    
    if not function_code:
        raise RuntimeError("function_code est manquant dans artifacts.")
    
    if not function_file:
        raise RuntimeError("function_file est manquant dans paths.")
    
    try:
        # Créer le répertoire parent si nécessaire
        file_path = Path(function_file)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Écrire le fichier
        with open(function_file, 'w', encoding='utf-8') as f:
            f.write(function_code)
        
        report_actions(
            event="AUTO_FUNC_BUILD_WRITE_FUNCTION_SUCCESS",
            level="info",
            message="Fonction écrite avec succès.",
            context={"file": function_file}
        )
        
        return builder_state
        
    except Exception as e:
        report_actions(
            event="AUTO_FUNC_BUILD_WRITE_FUNCTION_ERROR",
            level="error",
            message=f"Erreur lors de l'écriture de la fonction: {str(e)}"
        )
        raise RuntimeError(f"Échec de l'écriture: {str(e)}")
