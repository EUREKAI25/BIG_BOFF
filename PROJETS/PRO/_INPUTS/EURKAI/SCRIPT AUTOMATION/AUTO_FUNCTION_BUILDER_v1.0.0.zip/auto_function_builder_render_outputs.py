"""Construction de l'index des artefacts."""

from report_actions import report_actions


def auto_function_builder_render_outputs(builder_state: dict) -> dict:
    """Construit l'index des artefacts générés (outputs_index).

    Args:
        builder_state: État global avec paths.

    Returns:
        dict: builder_state avec outputs_index enrichi.
    """
    report_actions(
        event="AUTO_FUNC_BUILD_RENDER_OUTPUTS",
        level="info",
        message="Construction de l'index des outputs."
    )
    
    paths = builder_state.get("paths", {})
    
    outputs_index = [
        {
            "type": "function",
            "path": paths.get("function_file", ""),
            "description": "Fichier de la fonction générée"
        },
        {
            "type": "tests",
            "path": paths.get("tests_file", ""),
            "description": "Fichier des tests unitaires"
        },
        {
            "type": "report",
            "path": paths.get("report_file", ""),
            "description": "Rapport de validation"
        },
        {
            "type": "logs",
            "path": paths.get("logs_file", ""),
            "description": "Logs de génération"
        },
        {
            "type": "metadata",
            "path": paths.get("metadata_file", ""),
            "description": "Métadonnées de la fonction"
        }
    ]
    
    builder_state["outputs_index"] = outputs_index
    
    report_actions(
        event="AUTO_FUNC_BUILD_RENDER_OUTPUTS_SUCCESS",
        level="info",
        message=f"Index des outputs construit: {len(outputs_index)} fichiers."
    )
    
    return builder_state
