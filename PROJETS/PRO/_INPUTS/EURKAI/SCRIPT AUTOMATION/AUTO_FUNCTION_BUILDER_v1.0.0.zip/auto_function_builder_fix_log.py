"""Logging de la boucle de correction."""

from report_actions import report_actions


def auto_function_builder_fix_log(builder_state: dict) -> dict:
    """Enregistre les logs de la boucle de correction.

    Args:
        builder_state: État global avec fix_summary.

    Returns:
        dict: builder_state inchangé.
    """
    fix_summary = builder_state.get("fix_summary", {})
    
    report_actions(
        event="AUTO_FUNC_BUILD_FIX_LOG",
        level="info",
        message="Logging de la boucle de correction.",
        context=fix_summary
    )
    
    return builder_state
