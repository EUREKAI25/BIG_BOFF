# GLOBAL_RECURSIVE_METHOD

Method:GlobalRecursiveMethod
GlobalRecursiveMethod.VectorIdent = Vector:GlobalRecursiveMethodVectorIdent
GlobalRecursiveMethod.Name = "GlobalRecursiveMethod"

## Description
GlobalRecursiveMethod.Description.EN = Vector:GlobalRecursiveMethodDescriptionEN
GlobalRecursiveMethod.Description.FR = Vector:GlobalRecursiveMethodDescriptionFR

## Functioning
GlobalRecursiveMethod.Functioning = Vector:GlobalRecursiveMethodFunctioning

## Schema
GlobalRecursiveMethod.Input.Type = "Fractal"
GlobalRecursiveMethod.Output.Type = "Fractal"
GlobalRecursiveMethod.Category = MethodCategory:Core
