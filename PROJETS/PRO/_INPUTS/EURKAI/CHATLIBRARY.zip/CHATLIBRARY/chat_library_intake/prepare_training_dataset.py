def prepare_training_dataset(data):
    return {'dataset': True}
