def chat_intake_validate():
    return {'validated':True}
