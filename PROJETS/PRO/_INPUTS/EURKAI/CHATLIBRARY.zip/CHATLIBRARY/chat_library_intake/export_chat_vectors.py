def export_chat_vectors(entries):
    return {'vectors': len(entries)}
