def build_chat_index(data):
    return {'index': True}
