def chat_intake_render():
    return {'render':'done'}
