def chat_intake_get():
    return {'status':'ok'}
