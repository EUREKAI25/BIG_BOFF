def parse_chat_json(raw):
    return {'parsed': raw}
