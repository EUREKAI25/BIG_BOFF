def scan_chats(path):
    return {'scanned': path}
