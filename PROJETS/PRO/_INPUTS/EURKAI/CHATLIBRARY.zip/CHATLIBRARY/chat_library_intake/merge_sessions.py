def merge_sessions(sessions):
    return {'merged': len(sessions)}
