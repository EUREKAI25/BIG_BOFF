def scan_conversations():
    return {
        'function':'scan_conversations',
        'status':'ok',
        'message':'Executed successfully'
    }
