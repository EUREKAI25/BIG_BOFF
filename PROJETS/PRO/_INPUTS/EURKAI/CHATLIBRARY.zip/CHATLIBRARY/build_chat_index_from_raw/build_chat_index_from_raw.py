def build_chat_index_from_raw():
    return {
        'function':'build_chat_index_from_raw',
        'status':'ok',
        'message':'Executed successfully'
    }
