def chat_intake_render():
    return {
        'function':'chat_intake_render',
        'status':'ok',
        'message':'Executed successfully'
    }
