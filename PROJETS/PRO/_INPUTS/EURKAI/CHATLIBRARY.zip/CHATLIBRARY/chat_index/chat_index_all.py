"""Stub chat_index_all."""
def chat_index_all():
    return {
        "function": "chat_index_all",
        "status": "ok",
        "message": "Stub implementation"
    }
