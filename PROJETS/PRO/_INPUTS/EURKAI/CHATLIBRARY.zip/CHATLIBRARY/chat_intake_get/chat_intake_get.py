def chat_intake_get():
    return {
        'function':'chat_intake_get',
        'status':'ok',
        'message':'Executed successfully'
    }
