def process_chats_with_ia():
    return {
        'function':'process_chats_with_ia',
        'status':'ok',
        'message':'Executed successfully'
    }
