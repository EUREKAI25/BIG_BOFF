def chat_intake_render(result):
    """
    Retourne une petite représentation textuelle du résultat.
    """
    status = result.get("status", "unknown")
    processed = result.get("processed", False)
    return f"chat_intake(status={status}, processed={processed})"
