def chat_intake_validate(result):
    """
    Valide le résultat de chat_intake_execute.
    """
    if not isinstance(result, dict):
        return {"status": "error", "error": "invalid_result_type"}

    if result.get("status") != "ok":
        return {"status": "error", "error": "execute_failed"}

    if "processed" not in result:
        return {"status": "error", "error": "missing_processed_flag"}

    return {"status": "ok", "valid": True}
