def chat_intake_get():
    """
    Retourne la config de base de l’intake de chats.
    """
    return {
        "status": "ok",
        "source_root": "/Users/nathalie/Dropbox/____BIG_BOFF___/PROJETS/PRO/_INPUTS/EURKAI/CHATLIBRARY/raw",
        "output_root": "/Users/nathalie/Dropbox/____BIG_BOFF___/PROJETS/PRO/_OUTPUTS/EURKAI/CHATLIBRARY",
        "index_files": {
            "files": "__EUREKAI_CHAT_FILES_INDEX.csv",
            "topics": "__EUREKAI_CHAT_TOPICS_INDEX.csv",
            "projects": "__EUREKAI_CHAT_PROJECTS_INDEX.csv",
            "messages": "__EUREKAI_CHAT_MESSAGES_INDEX.csv",
        }
    }
