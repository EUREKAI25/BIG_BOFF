def chat_intake_execute(config):
    """
    Simule l’exécution de l’intake à partir d’une config.
    """
    if not isinstance(config, dict):
        return {"status": "error", "error": "invalid_config_type"}

    required = ["source_root", "output_root", "index_files"]
    missing = [k for k in required if k not in config]
    if missing:
        return {"status": "error", "error": "missing_keys", "missing": missing}

    return {
        "status": "ok",
        "processed": True,
        "source_root": config["source_root"],
        "output_root": config["output_root"],
    }
