def load_json(path): import json; return json.load(open(path))
