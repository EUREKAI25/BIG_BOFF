def save_json(path,obj): import json; json.dump(obj,open(path,"w"))
