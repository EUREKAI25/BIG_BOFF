def extract_metadata(text): return {"lines":len(text.splitlines())}
