def read_chat_file(path): return {"status":"ok","data":open(path,"r").read()}
