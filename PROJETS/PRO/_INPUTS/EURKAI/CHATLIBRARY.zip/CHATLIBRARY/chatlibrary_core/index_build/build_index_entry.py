def build_index_entry(meta): return {"id":"dummy","meta":meta}
