def combine_indexes(i1,i2): return {"combined":[i1,i2]}
