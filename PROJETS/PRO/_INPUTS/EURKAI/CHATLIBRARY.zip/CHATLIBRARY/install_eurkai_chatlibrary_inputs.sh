#!/bin/zsh

BASE="/Users/nathalie/Dropbox/____BIG_BOFF___/PROJETS/PRO/_TESTS/EURKAI/CHATLIBRARY"

INPUTS="/Users/nathalie/Dropbox/____BIG_BOFF___/PROJETS/PRO/_INPUTS/EURKAI/CHATLIBRARY"

mkdir -p "$BASE/chat_intake"
mkdir -p "$BASE/chat_index"

echo 'import importlib.util

spec = importlib.util.spec_from_file_location("chat_intake_get", "'"$INPUTS"'/chat_intake/chat_intake_get.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_chat_intake_get():
    r = mod.chat_intake_get("Hello")
    assert r["status"] == "ok"
    assert r["received"] == "Hello"' > "$BASE/chat_intake/test_chat_intake_get.py"

echo 'import importlib.util

spec = importlib.util.spec_from_file_location("chat_intake_execute", "'"$INPUTS"'/chat_intake/chat_intake_execute.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_chat_intake_execute():
    r = mod.chat_intake_execute("  Hi  ")
    assert r["cleaned"] == "Hi"' > "$BASE/chat_intake/test_chat_intake_execute.py"

echo 'import importlib.util

spec = importlib.util.spec_from_file_location("chat_intake_validate", "'"$INPUTS"'/chat_intake/chat_intake_validate.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_chat_intake_validate():
    assert mod.chat_intake_validate("Hello")["status"] == "ok"
    assert mod.chat_intake_validate("")["status"] == "error"' > "$BASE/chat_intake/test_chat_intake_validate.py"

echo 'import importlib.util

spec = importlib.util.spec_from_file_location("chat_intake_render", "'"$INPUTS"'/chat_intake/chat_intake_render.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_chat_intake_render():
    r = mod.chat_intake_render("Hello")
    assert "Message reçu" in r["rendered"]' > "$BASE/chat_intake/test_chat_intake_render.py"

echo 'import importlib.util

spec = importlib.util.spec_from_file_location("chat_index_get", "'"$INPUTS"'/chat_index/chat_index_get.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_chat_index_get():
    r = mod.chat_index_get()
    assert r["status"] == "ok"
    assert isinstance(r["index"], list)' > "$BASE/chat_index/test_chat_index_get.py"

echo 'import importlib.util

spec = importlib.util.spec_from_file_location("chat_index_update", "'"$INPUTS"'/chat_index/chat_index_update.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_chat_index_update():
    r = mod.chat_index_update("conv1", {"txt": "Salut"})
    assert r["status"] == "ok"
    assert r["updated"] == "conv1"' > "$BASE/chat_index/test_chat_index_update.py"

echo 'import importlib.util

spec = importlib.util.spec_from_file_location("chat_index_all", "'"$INPUTS"'/chat_index/chat_index_all.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_chat_index_all():
    r = mod.chat_index_all()
    assert r["status"] == "ok"
    assert len(r["all"]) >= 3' > "$BASE/chat_index/test_chat_index_all.py"
