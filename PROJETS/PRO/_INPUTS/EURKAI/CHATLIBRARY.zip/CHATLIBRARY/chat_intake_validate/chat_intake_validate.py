def chat_intake_validate():
    return {
        'function':'chat_intake_validate',
        'status':'ok',
        'message':'Executed successfully'
    }
