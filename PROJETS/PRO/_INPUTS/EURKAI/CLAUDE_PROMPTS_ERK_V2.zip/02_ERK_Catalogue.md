# 📚 Prompt Claude — Catalogue ERK Officiel (v1)

## 🎯 OBJECTIF
Créer le **Catalogue officiel ERK**, contenant :
- tous les types d’objets utilisés par Eurkai,
- leurs attributs,
- leurs méthodes,
- leurs règles ERK,
- leurs relations,
- leurs exemples JSON-like.

Ce catalogue servira :
- à la génération dynamique des formulaires,
- à l’autocomplétion des agents IA,
- à la validation de la fractale,
- au rendu cockpit.

---

## 📦 OBJEts à définir

### 1. Object (base universelle)
- attributs obligatoires,
- méthodes minimales,
- règles ERK globales,
- relations autorisées.

### 2. Field (formulaire cockpit)
Types :
- input
- textarea
- select
- radio
- checkbox

Attributs :
- label
- type
- required
- defaultValue
- description
- options (si applicable)
- rules (ERK)

Règle essentielle :
```
when Field.type in ["select","radio","checkbox"]
then Field.options.count > 0
```

### 3. Option
Objet utilisé pour Select / Radio / Checkbox.

### 4. Schema
Décrit les caractéristiques structurelles d’un type d’objet.

### 5. Prompt
Objet représentant un prompt IA structuré.

### 6. Module
Composant réutilisable (logique ou interface).

### 7. SuperTool
Définition d’un outil CRUDOE :
- SuperCreate
- SuperRead
- SuperUpdate
- SuperDelete
- SuperOrchestrate
- SuperEngage

### 8. Project
Objet qui instancie un projet dans Eurkai.

### 9. UIComponent
Chaque élément d’interface cockpit est un objet ERK.

---

## 📌 POUR CHAQUE OBJET, PRODUIRE
1. `lineage`
2. `attributs`
3. `méthodes`
4. `règles ERK`
5. `relations`
6. `exemple JSON-like`

---

## 🚀 LIVRABLE ATTENDU
Un fichier **ERK_CATALOGUE_OFFICIEL.md** contenant le catalogue complet.