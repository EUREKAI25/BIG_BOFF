# RELATIONS

---

## Types de relations (système)

`[STRUCTURE]`

| Relation | Usage |
|----------|-------|
| `inherits_from` | Héritage (implicite via parent dans le lineage) |
| `depends_on` | Dépendance stricte (A ne fonctionne pas sans B) |
| `related_to` | Association (A est lié à B mais peut exister sans) |

---

## inherits_from

`[COMPORTEMENT]` Implicite. Déduit du lineage.

`Object:Entity:Agent` → Agent `inherits_from` Entity (automatique).

Affiché dans le cockpit mais pas stocké explicitement.

### Création automatique sous Object

`[COMPORTEMENT]` Si l'objet racine n'existe pas, il devient enfant de Object.

```
NewRoot:NewChild → Object:NewRoot:NewChild
```

---

## depends_on vs related_to

`[STRUCTURE]`

| Relation | Sémantique |
|----------|------------|
| `depends_on` | B doit exister pour que A fonctionne |
| `related_to` | Lien sans dépendance stricte |

Usage :
- Validation : `depends_on` → vérifier que B existe
- Génération : `depends_on` → générer B avant A

---

## Alias dynamiques

`[ALIAS]` Les alias se déclenchent selon le contexte de la cible.

### scope_of

Quand la cible est liée à un objet `<Object>Scope` :

```
Generator scope_of Create
```

Équivaut à :

```
Generator related_to CreatePermission.scope
```

`scope_of` n'est PAS une relation système. C'est un alias de `related_to` dans ce contexte.

### <object>_of

Quand un objet est lié à un `<Object>Bundle` :

```
Create method_of CentralMethod
```

Équivaut à :

```
Create related_to CentralMethod.CentralMethodBundle
```

ou `depends_on` selon ce qui est stocké. L'alias lit la relation sous-jacente.

### type_of

Alias de `inherits_from` pour une lecture plus naturelle :

```
Agent type_of Entity
```

Équivaut à :

```
Agent inherits_from Entity
```

---

## Tableau récapitulatif des alias

`[ALIAS]`

| Alias | Contexte | Résout vers |
|-------|----------|-------------|
| `scope_of` | cible = `<Object>Scope` | `related_to` |
| `<object>_of` | cible = `<Object>Bundle` | `related_to` ou `depends_on` (selon stockage) |
| `type_of` | héritage | `inherits_from` |
