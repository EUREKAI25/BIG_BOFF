# OBJECT STRUCTURE

---

## Écritures interchangeables

`[ALIAS]` Toutes ces formes sont équivalentes et interchangeables :

### Bundle d'un objet

```
Object.ObjectBundle
Object.Bundle
ObjectBundle
```

### Accès aux attributs

```
Object.ObjectBundle.ObjectAttributeBundle
Object.ObjectAttributeBundle
Object.AttributeBundle
Object.attributes
```

### Accès à un attribut spécifique

```
Object.ObjectBundle.ObjectAttributeBundle.scope
Object.AttributeBundle.scope
Object.attributes.scope
Object.scope
```

### Chaînage

```
Method.Create.param.format
Method:Create.param.format
```

Pas de limite de profondeur tant que le chemin existe.

---

## Principe fondamental

`[STRUCTURE]` Tout objet EST un bundle. Pas d'étape intermédiaire.

---

## Structure canonique

`[STRUCTURE]`

```
Object = [
  ObjectAttributeBundle,
  ObjectRelationBundle,
  ObjectMethodBundle,
  ObjectRuleBundle
]
```

Chaque bundle contient :
```
{
  inherited: [...],
  injected: [...],
  owned: [...]
}
```

---

## Accès aux bundles

`[COMPORTEMENT]`

| Écriture | Résultat |
|----------|----------|
| `Object.methods` | all (inherited + injected + owned fusionnés) |
| `Object.methods.owned` | owned seul |
| `Object.methods.inherited` | inherited seul |
| `Object.methods.injected` | injected seul |

---

## Priorité de résolution

`[RESOLUTION]`

`owned` > `injected` > `inherited`

Un élément owned écrase un élément inherited/injected de même nom.

---

## Validation de chemin

`[VALIDATION]`

Chaque segment est validé à la résolution. Si un segment n'existe pas → erreur immédiate.
