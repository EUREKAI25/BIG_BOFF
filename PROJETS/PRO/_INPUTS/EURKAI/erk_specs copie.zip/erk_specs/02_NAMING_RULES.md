# NAMING RULES

---

## Unicité

`[VALIDATION]` Les labels doivent être uniques, indépendamment de la casse.

Un attribut `name` et une méthode `Name` dans le même objet = INTERDIT.

---

## Conventions

`[NOMMAGE]`

| Type | Convention | Exemples |
|------|------------|----------|
| Objets/Types | PascalCase | `CentralMethod`, `AIAgent`, `CreatePermission` |
| Attributs | lowercase | `name`, `scope`, `model`, `layer` |
| Méthodes | `<Object><Action>` | `AgentCreate`, `CatalogRead`, `VectorGenerate` |

---

## Objet utilisé comme attribut

`[NOMMAGE]` Tout attribut préexiste en tant qu'objet.

Quand un objet est utilisé comme attribut, on utilise lowercase :

| Objet | Utilisé comme attribut |
|-------|------------------------|
| `Object:Layer` | `object.layer` |
| `Object:Entity` | `agent.entity` |
| `Object:Attribute:Scope` | `role.scope` |

---

## Lineage

`[STRUCTURE]` Format : `Segment:Segment:Segment`

Chaque segment en PascalCase.

### Exemples simples

```
Object
Object:Entity:Agent
Object:Function:Method:CentralMethod:Create
```

### Exemples avec attributs (syntaxe enrichie)

```
Method:Create.param
Method:Create.param:string
Method:Create.param:string.format:lowercase
Agent.name.maxLength:50
```

### Équivalences lineage / chemin

`[ALIAS]`

| Lineage | Chemin objet |
|---------|--------------|
| `Object:Entity:Agent` | `Object.Entity.Agent` |
| `Method:Create` | `Object:Function:Method:CentralMethod:Create` |
| `Create` | résolu vers le chemin complet si unique |

---

## Liberté syntaxique

`[ALIAS]` On peut utiliser n'importe quelle forme d'écriture et les mélanger :

```
<lineage> IN <alias>
<objectname> scope_of <methodname>
Object:Entity:Agent.permissions
Agent.permissions
```

À l'avenir : balises PHP, SQL ou tout autre langage intégrables.
