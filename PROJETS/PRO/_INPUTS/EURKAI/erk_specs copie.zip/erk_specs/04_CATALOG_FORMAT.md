# CATALOG FORMAT

---

## Format d'import simplifié

`[STRUCTURE]`

```
<objectname ou lineage>:
  [<attr1>, <attr2>, ...]
  [<relation1>, <relation2>, ...]
```

---

## Inférence automatique

`[COMPORTEMENT]` Le script reconnaît le type :

- Mots simples lowercase → attributs (`name`, `scope`, `model`)
- Mots-clés de relation → relations (`depends_on X`, `scope_of Y`, `related_to Z`)

---

## Exemples

```
Agent:
  [name, model, scope]
  [depends_on Provider, scope_of Create]

CentralMethod:
  [signature, returnType]
  [related_to Object]
```

---

## Résolution des noms

`[RESOLUTION]`

Quand on écrit `Create` :

1. Chercher un objet existant dont le nom EST `Create`
2. Préférer les chemins sous `Object:`
3. Si non trouvé, créer sous le préfixe approprié

---

## Valeurs dans les bundles

`[ALIAS]` Format simplifié (tableau de noms) :

```
CentralMethod.Bundle.methods = ['Create', 'Read', 'Update', 'Delete']
```

Équivalent complet :

```
CentralMethod.Bundle.methods.owned = [
  { ref: 'Object:Function:Method:CentralMethod:Create' },
  { ref: 'Object:Function:Method:CentralMethod:Read' },
  ...
]
```

---

## Accès aux bundles

`[COMPORTEMENT]`

| Écriture | Résultat |
|----------|----------|
| `Object.methods` | all (fusion inherited + injected + owned) |
| `Object.methods.owned` | owned seul |
| `Object.methods.inherited` | inherited seul |
| `Object.methods.injected` | injected seul |
