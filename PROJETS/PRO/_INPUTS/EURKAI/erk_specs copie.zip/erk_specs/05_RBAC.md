# RBAC (Role-Based Access Control)

---

## Principe

`[STRUCTURE]` Pas de relation directe Agent → Method.

Chaîne :
```
Agent → Rôle → Permission → Méthode
```

---

## Attribut scope

`[STRUCTURE]` `scope` est un attribut comme les autres (tout est objet).

Contient les références vers les objets appartenant à ce scope.

---

## Déclaration

`[ALIAS]` Toutes ces formes sont équivalentes :

```
AIAgent IN GeneratorRole.scope
AIAgent scope_of GeneratorRole
GeneratorRole related_to AIAgent
```

---

## Logique d'autorisation

`[COMPORTEMENT]`

**En une ligne :**
```
AIAgent.permissions = AIAgent.roles.flatMap(role => role.permissions)
```

**Étapes détaillées :**

1. Quels rôles contiennent AIAgent dans leur scope ? → `GeneratorRole`
2. Quelles permissions contiennent GeneratorRole dans leur scope ? → `CreatePermission`
3. Le nom de la permission implique la méthode : `CreatePermission` → `Create`
4. → Autorisé

---

## Pas de relation "enables"

`[STRUCTURE]` Le nom de la permission IMPLIQUE ce qu'elle permet.

| Permission | Permet |
|------------|--------|
| `CreatePermission` | `Create` |
| `ReadPermission` | `Read` |
| `DeletePermission` | `Delete` |

Pas besoin de relation explicite Permission → Method.

---

## Override méthodes secondaires

`[COMPORTEMENT]` Les permissions spécifiques des méthodes secondaires écrasent celles des méthodes centrales.

Logique standard : `owned > injected > inherited`

Exemple :
- `GeneratorRole` a `CreatePermission` (central)
- `GeneratorRole` a `AgentCreatePermission` (secondaire, spécifique)
- → `AgentCreatePermission` s'applique pour `AgentCreate`

---

## Liberté syntaxique

`[ALIAS]` On peut mélanger toutes les formes d'écriture :

```
<lineage> IN <alias>
<vectorname> scope_of <vectormethod>
Object:Entity:Agent IN Role:Generator.scope
Agent scope_of Generator
```

Toutes résolvent vers la même relation sous-jacente.
