# ERK SPECS — INDEX

Version de travail. À enrichir lors des mises à jour du cockpit.

---

## Légende — Types de règles

| Tag | Signification |
|-----|---------------|
| `[STRUCTURE]` | Structure fondamentale du système |
| `[NOMMAGE]` | Convention de nommage |
| `[ALIAS]` | Écriture alternative interchangeable |
| `[COMPORTEMENT]` | Comportement automatique du système |
| `[RESOLUTION]` | Logique de résolution/recherche |
| `[VALIDATION]` | Règle de validation |

---

## Fichiers

1. **01_OBJECT_STRUCTURE.md** — Structure objet = bundle, écritures interchangeables
2. **02_NAMING_RULES.md** — Conventions de nommage, unicité
3. **03_RELATIONS.md** — Types de relations et alias dynamiques
4. **04_CATALOG_FORMAT.md** — Format d'import simplifié pour les catalogues
5. **05_RBAC.md** — Rôles, permissions, scope
6. **06_METASCHEMA.md** — Structure canonique JSON

---

## Principes clés

- Tout objet EST un bundle
- Labels uniques (insensibles à la casse)
- Syntaxes librement interchangeables
- Alias dynamiques selon le contexte
- Pas de relation `enables`

---

## À définir plus tard

- Syntaxe ERK complète (après stabilisation cockpit)
- Vectors
- Hooks
- Scenarios
