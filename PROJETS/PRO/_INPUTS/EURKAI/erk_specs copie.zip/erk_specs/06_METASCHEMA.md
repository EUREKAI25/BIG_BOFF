# METASCHEMA

---

## Principe

`[STRUCTURE]` MetaSchema définit la structure récursive canonique de tous les ObjectTypes.

Tout objet EST un bundle. Pas d'étape intermédiaire.

---

## Structure JSON

`[STRUCTURE]`

```json
{
  "Object": {
    "ObjectAttributeBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    },
    "ObjectRelationBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    },
    "ObjectMethodBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    },
    "ObjectRuleBundle": {
      "inherited": [],
      "injected": [],
      "owned": []
    }
  }
}
```

---

## Sémantique des bundles

`[STRUCTURE]`

| Bundle | Contenu |
|--------|---------|
| `inherited` | Hérité des parents (via lineage) |
| `injected` | Injecté dynamiquement (providers, environnement) |
| `owned` | Défini directement pour cet objet |

---

## Priorité de résolution

`[RESOLUTION]`

`owned` > `injected` > `inherited`

Un élément owned écrase un élément inherited/injected de même nom.

---

## Accès

`[COMPORTEMENT]`

| Écriture | Résultat |
|----------|----------|
| `Object.attributes` | all (fusion) |
| `Object.attributes.owned` | owned seul |
| `Object.attributes.inherited` | inherited seul |
| `Object.attributes.injected` | injected seul |
