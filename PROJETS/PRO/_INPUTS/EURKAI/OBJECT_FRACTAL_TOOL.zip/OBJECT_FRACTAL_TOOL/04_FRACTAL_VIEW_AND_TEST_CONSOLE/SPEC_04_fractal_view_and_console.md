# SPEC 04 — Fractal View & Test Console

Goal: provide a detailed **XFractal view** and a small **test console**.

Features:

1. **Fractal view**
   - For the selected ObjectType (or vector):
     - display attributes, secondary methods, ERK rules, relations.
     - group them by:
       - owned
       - inherited
       - injected
   - For inherited/injected elements, show the **source**:
     - ancestor ObjectType
     - or transversal logic / tag.
   - Depth control:
     - slider or numeric input to limit the maximum depth of the fractal expansion.
     - beyond this depth, show a placeholder or a "continue" indication.

2. **Vector visualisation**
   - Each lineage effectively represents a vector in the catalogue.
   - In this view, clicking on the vector name or on the lineage should open the complete fractal view.

3. **Test console**
   - Input for expressions such as:
     - `methodA(inputs).result.message`
   - For V1, methods can be mocked: the goal is to test the wiring, not real business logic.
   - Show:
     - success result (formatted)
     - or error with an understandable message.

Notes:
- This view is a diagnostic / introspection tool for the architect.
- It must rely on the same JSON data structures as other modules.
