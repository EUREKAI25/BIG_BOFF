# TEST 04 — Fractal View & Test Console

Manual test checklist:

- [ ] Selecting an ObjectType shows its XFractal:
  - [ ] attributes
  - [ ] secondary methods
  - [ ] ERK rules
  - [ ] relations
- [ ] For each element, I can see:
  - [ ] whether it is owned / inherited / injected.
  - [ ] if not owned, its source.
- [ ] The depth control effectively limits the displayed inheritance depth.
- [ ] The vector representation is clickable, and opens the detailed fractal view.
- [ ] I can type a test expression like `fakeMethod({test:1}).result.message`:
  - [ ] I get a mock result or a controlled error message.
