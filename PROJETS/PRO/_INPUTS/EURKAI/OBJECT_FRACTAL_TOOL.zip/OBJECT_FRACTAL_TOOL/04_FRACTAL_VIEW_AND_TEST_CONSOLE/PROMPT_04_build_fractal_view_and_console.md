# PROMPT 04 — Build Fractal View & Test Console

You are a front-end developer AI.

Read:
- `SPEC_04_fractal_view_and_console.md`
- Data structures from 00_GLOBAL and current implementation from 01–03.

Task:
- Implement a **Fractal & Tests** view:
  1. For the selected ObjectType or vector:
     - display XFractal:
       - attributes
       - secondary methods
       - ERK rules
       - relations
     - each item must indicate whether it is:
       - owned
       - inherited
       - injected
     - for non-owned, show the source (ancestor, transversal logic).
     - limit expansion depth with a slider or input.
  2. Add a **test console**:
     - one input line for an expression like `methodA(inputs).result.message`.
     - interpret this expression by calling minimal mock functions in JS.
     - show the result or a clear error.

Requirements:
- Reuse / extend existing UI where possible.
- Keep the focus on introspection and testing, not on full business execution.
- Code must be modular enough to be extended later.

Output:
- HTML/JS for this view or module.
