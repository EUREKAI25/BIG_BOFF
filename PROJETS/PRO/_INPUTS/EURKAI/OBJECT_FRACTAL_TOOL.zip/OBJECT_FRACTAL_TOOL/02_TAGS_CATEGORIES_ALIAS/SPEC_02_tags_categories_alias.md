# SPEC 02 — Tags, Categories & Alias

Goal: add **tagging**, **categories** and **alias** features to the tool.

Features:

1. **Tags sidebar**
   - Right sidebar listing all tags in **alphabetical order**.
   - Scrollable list.
   - Tags are draggable.

2. **Tag assignment**
   - Drag & drop a tag from the sidebar onto an ObjectType in the tree.
   - The ObjectType gains this tag in its metadata.
   - Multiple tags per ObjectType are allowed.

3. **Tag as category**
   - Right click on a tag in the sidebar:
     - toggle `isCategory` (true/false)
     - when `isCategory` is true, allow setting a `parentCategory` (another tag).
   - This lets some tags act as higher-level categories for organisation / transversal logics.

4. **Alias management**
   - An alias is a short name pointing to a **vector** (lineage + state).
   - UI (can be simple at first):
     - On the ObjectType / vector view, a section “Aliases”:
       - list of aliases attached
       - button “Add alias” to create a new one.
   - The alias should be resolvable later to jump directly to a given vector / object.

No backend yet: all of this is kept in memory and in JSON structures.

