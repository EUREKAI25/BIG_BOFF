# TEST 02 — Tags, Categories & Alias

Manual test checklist:

- [ ] Tags sidebar shows all tags in alphabetical order.
- [ ] Scrolling works with many tags.
- [ ] Drag & drop a tag onto an ObjectType:
  - [ ] ObjectType metadata now includes this tag.
- [ ] Right-click on a tag:
  - [ ] I can toggle `isCategory`.
  - [ ] If `isCategory` is true, I can set a `parentCategory` from a list of tags.
- [ ] On an ObjectType detail view:
  - [ ] I can see a list of aliases.
  - [ ] I can add a new alias.
  - [ ] Aliases are persisted in JSON (in memory for V1).
