# PROMPT 02 — Build Tags, Categories & Alias Module

You are a front-end developer AI.

Read:
- `SPEC_02_tags_categories_alias.md`
- The JSON structure decided in 00_GLOBAL and used in 01_LINEAGE_EXPLORER.

Task:
- Extend the existing Lineage Explorer with:
  1. **Tags sidebar** (right side):
     - alphabetical list
     - scrollable
     - draggable tags.
  2. **Tag assignment**:
     - drag tag onto an ObjectType node in the tree.
     - update JSON: add this tag to the ObjectType metadata.
  3. **Tag as category**:
     - right-click on a tag opens a small menu:
       - toggle `isCategory`
       - optional `parentCategory` selection among existing tags.
  4. **Alias management**:
     - for the selected ObjectType (and later for a given vector), show a list of aliases.
     - simple form to add a new alias.

Requirements:
- Keep data in the same JSON model as 01.
- Clearly separate UI code from data update code.
- Provide basic, functional styling only.

Output:
- Updated HTML/JS code with the tags sidebar and alias handling.
