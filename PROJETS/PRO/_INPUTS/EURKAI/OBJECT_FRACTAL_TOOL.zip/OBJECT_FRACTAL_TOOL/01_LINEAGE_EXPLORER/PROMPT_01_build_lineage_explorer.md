# PROMPT 01 — Build Lineage Explorer (Front)

You are a front-end developer AI.

Read:
- `SPEC_01_lineage_explorer.md`
- `SPEC_00_overview.md` and the JSON schema from 00_GLOBAL when available.

Task:
- Implement the **Lineage Explorer** view as described in SPEC_01:
  - Tree of ObjectTypes on the left.
  - Fractal / lineage view of the selected object in the center.
  - Input to add an object by typing its full lineage.

Requirements:
- Use plain HTML + JavaScript (you may use a minimal framework if absolutely necessary).
- Use an in-memory JSON object to represent:
  - ObjectTypes
  - their parent / children
  - their lineage string
- Implement:
  - Tree rendering
  - Click to select node
  - Drag & drop re-parenting (update parent, lineage, and JSON)
  - Input to create object(s) from a typed lineage, with:
    - parsing
    - creation of missing nodes
    - `toFinalize: true` flag for newly created nodes

Output:
- HTML/JS code for this view.
- Functions clearly separated for:
  - rendering the tree
  - handling selection
  - handling drag & drop
  - parsing and adding lineages.
