# TEST 01 — Lineage Explorer

Manual test checklist:

- [ ] Load initial JSON data and see a tree of ObjectTypes.
- [ ] Click on an ObjectType:
  - [ ] Its lineage appears in the center.
  - [ ] The fractal view shows at least the ancestor chain.
- [ ] Use the depth control:
  - [ ] Reducing depth hides deeper ancestors / fractal layers.
- [ ] Drag & drop an ObjectType under another:
  - [ ] Parent in JSON is updated.
  - [ ] Lineage string is recomputed.
  - [ ] Lineage passes the regex validation.
- [ ] Type a new lineage in the input:
  - [ ] Missing nodes are created.
  - [ ] They are flagged as `toFinalize: true`.
  - [ ] The tree refreshes and shows them.
