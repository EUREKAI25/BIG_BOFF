# SPEC 01 — Lineage Explorer

Goal: implement the **Lineage Explorer** view.

Layout (first version):
- Left: tree of ObjectTypes (lineages).
- Center: fractal view (complete or partial) of the selected object:
  - show the lineage (ancestors → selected).
  - show XFractal at the chosen depth.
- Top or center: breadcrumb of level-1 objects (root ObjectTypes) in alphabetical order.
- Optionally: a simple panel or section listing basic details.

Core features:
1. **Tree of ObjectTypes**
   - Display all ObjectTypes as a tree according to their lineage.
   - Clicking on an ObjectType selects it.
   - Drag & drop an ObjectType to re-parent it under another parent:
     - recompute its lineage,
     - validate the lineage against the regex,
     - update JSON data,
     - propagate inheritance changes (XFractal will be recalculated later).

2. **Lineage input (manual)**
   - An input where the user can type a full lineage name.
   - The system parses the lineage, checks nomenclature,
   - creates any missing intermediate ObjectTypes,
   - marks them with `toFinalize: true`.

3. **Fractal view (center)**
   - For the selected ObjectType, display:
     - its lineage (ancestors, one per line),
     - and for each level, the contribution to XFractal (in a simple textual form for now).
   - A slider (or numeric input) controls the maximum depth of fractal display.
   - If depth limit is reached, display a placeholder such as “more… (use method for continuation)”.

This step focuses on:
- Rendering the tree.
- Managing selection.
- Implementing drag & drop re-parenting.
- Handling manual lineage input and creation of missing nodes.
- Displaying lineage + fractal structure (owned/inherited distinction can come later).

No need (yet) for:
- tags / alias
- full blown styling
- test console
