# Generic Prompt Template for Future Tasks

You are a developer AI.

Context:
- We are working on an internal tool called **Object Fractal Tool**.
- Please read the following spec file(s) before doing anything: `[LIST SPEC FILES HERE]`.
- The tool manipulates ObjectTypes, lineages, XFractals, tags, schemas and a catalogue of vectors.

Task:
- [Describe precisely what you want: new feature, refactor, fix, etc.]

Constraints:
- Respect existing JSON structures and conventions.
- Do not break the existing views / modules.
- Keep functions modular and documented when relevant.

Output expected:
- [Code / design / tests / migration notes…]
