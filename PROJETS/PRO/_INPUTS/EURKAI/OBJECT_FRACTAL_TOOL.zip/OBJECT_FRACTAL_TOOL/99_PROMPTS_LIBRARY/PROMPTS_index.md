# PROMPTS Index

This folder centralises the prompts used for each step of the Object Fractal Tool.

- `PROMPT_00_global_architecture.md`
- `PROMPT_01_build_lineage_explorer.md`
- `PROMPT_02_build_tags_module.md`
- `PROMPT_03_build_schemas_editor.md`
- `PROMPT_04_build_fractal_view_and_console.md`

Use them step by step, always attaching the relevant SPEC files and current JSON data.

