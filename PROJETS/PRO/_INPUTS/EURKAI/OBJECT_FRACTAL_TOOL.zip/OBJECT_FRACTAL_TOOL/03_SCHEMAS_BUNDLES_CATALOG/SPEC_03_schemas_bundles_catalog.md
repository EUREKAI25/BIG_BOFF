# SPEC 03 — Schemas, Bundles & Catalog

Goal: provide a page to define/edit **bundle schemas** and instantiate example objects for the catalog.

Features:

1. **ObjectType selection**
   - An input with auto-complete (suggestions after 2 characters).
   - The user chooses the ObjectType whose schema they want to edit or instantiate.

2. **Bundle schema editor**
   - For the selected ObjectType, display a list of bundle elements:
     - `elementName`
     - `expectedObjectType`
     - `quantity` (min/max or exact)
     - `required` (checkbox)
   - Allow:
     - adding a new bundle element
     - editing an existing one
     - deleting one

3. **Instantiation for catalog**
   - A button “Instantiate for catalog”:
     - creates a sample instance of this ObjectType,
     - stores it in a `catalog.examples` section in JSON (structure to be defined in 00_GLOBAL).

Notes:
- Schemas may be pre-populated automatically by heritage and tags, but this view allows manual fine-tuning.
- This view does not execute behaviour, it only defines structure.
