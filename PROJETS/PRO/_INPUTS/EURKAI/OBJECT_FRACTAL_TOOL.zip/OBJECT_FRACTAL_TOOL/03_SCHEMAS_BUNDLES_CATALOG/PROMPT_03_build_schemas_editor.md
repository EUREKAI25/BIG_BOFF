# PROMPT 03 — Build Schemas / Bundles Editor

You are a front-end developer AI.

Read:
- `SPEC_03_schemas_bundles_catalog.md`
- JSON definitions from 00_GLOBAL and current state from steps 01 and 02.

Task:
- Implement a **Schemas page** with:
  1. ObjectType search input with auto-complete (suggestions after 2 characters).
  2. Display and edit the bundle schema of the selected ObjectType:
     - elementName
     - expectedObjectType
     - quantity
     - required
  3. A button "Instantiate for catalog" that creates a sample instance based on the schema and appends it to a `catalog.examples` section.

Requirements:
- Respect current JSON structures.
- Clean separation:
  - UI rendering
  - data editing functions
  - catalogue update.

Output:
- HTML/JS code for this page or module.
