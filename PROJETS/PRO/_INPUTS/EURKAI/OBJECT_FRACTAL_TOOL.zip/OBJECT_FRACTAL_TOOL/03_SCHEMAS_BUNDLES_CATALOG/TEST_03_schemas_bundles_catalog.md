# TEST 03 — Schemas, Bundles & Catalog

Manual test checklist:

- [ ] I can type at least 2 characters and see ObjectType suggestions.
- [ ] Selecting an ObjectType displays its current bundle schema.
- [ ] I can add a bundle element:
  - [ ] with elementName, expectedObjectType, quantity, required.
- [ ] I can edit an element and see JSON updated accordingly.
- [ ] I can delete an element from the schema.
- [ ] Clicking "Instantiate for catalog":
  - [ ] creates an example instance in `catalog.examples`.
  - [ ] instance refers to the right ObjectType and schema.
