# PROMPT 00 — Global Architecture

You are a developer AI. Your task is to design the architecture of an internal web tool called **Object Fractal Tool**.

Read carefully:
- `SPEC_00_overview.md`
- `SPEC_00_metaschema_and_rules.md` (even if some parts are still TODO).

Context:
- The tool manipulates **ObjectTypes** structured by a metaschema:
  - Every object is a Bundle of elements.
  - Each object `X` has an associated `XFractal` describing attributes, secondary methods, ERK rules and relations, coming from:
    - its own level (**owned**),
    - its ancestors (**inherited**),
    - transversal logics / tags (**injected**).
- Lineages follow a strict nomenclature and must pass a regex validation.
- Data should be stored as JSON for the first version.
- Front-end is a single-page style HTML/JS application (lightweight).

Your tasks:
1. Propose a simple but modular **technical architecture**:
   - Data structures (JSON) for:
     - ObjectTypes
     - lineages
     - tags / categories
     - aliases
     - bundle schemas
     - XFractal
   - Main UI components:
     - Lineage explorer (tree)
     - Fractal view
     - Tags/categories/alias sidebar
     - Schemas editor
     - Test console
2. Explain how the different steps 01, 02, 03, 04 will plug into this architecture.
3. Describe how changes in the UI (drag & drop, editing schemas, adding tags…) update the JSON.

Output expected:
- A clear architecture document (sections: Data, UI components, Update flows, Extensibility).
- No full implementation yet, only structure and plan.
