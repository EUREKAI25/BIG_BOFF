# SPEC 00 — Metaschema & Rules (SKELETON)

> ⚠️ This file is a placeholder. It must be filled by Nathalie with the **final metaschema** and core rules.

## 1. Metaschema

Describe here the *definitive* metaschema:

- Every object is a Bundle of elements.
- Each element points to another object (also a Bundle).
- For every object `X`, `XFractal` describes:
  - attributes
  - secondary methods
  - ERK rules
  - relations

You should add here, in YOUR words:
- the list of core fields that every object has (PGCD),
- how X and XFractal are linked,
- how bundles are represented.

## 2. Lineage nomenclature & regex

Add the **naming convention** and the **regex** that every lineage must respect.

Example placeholder (to be replaced):

- Pattern explanation in natural language.
- Regex: `^YOUR_REGEX_HERE$`

## 3. Relations

List the **3 fundamental relations** you mentioned, and their aliases.

For each relation:
- name
- direction (A→B, B→A or both)
- meaning
- impact on the fractal (inheritance? dependency? composition?)

## 4. Meta-logics (optional but recommended)

List here the families of meta-logics if you want (e.g. conditionnelle, temporelle, associative…).

For each family:
- name
- short description
- what it typically injects (attributes, methods, rules)
