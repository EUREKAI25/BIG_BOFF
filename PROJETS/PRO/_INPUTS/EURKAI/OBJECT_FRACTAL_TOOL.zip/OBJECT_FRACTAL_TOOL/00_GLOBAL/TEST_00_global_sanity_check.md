# TEST 00 — Global Sanity Check

Checklist for the global design:

- [ ] JSON structures can represent:
  - [ ] ObjectTypes
  - [ ] lineages
  - [ ] tags / categories
  - [ ] aliases
  - [ ] bundle schemas
  - [ ] XFractal (attributes, methods, rules, relations, with ownership flags).
- [ ] It is possible to distinguish **owned**, **inherited**, **injected** elements in data.
- [ ] Lineage naming convention can be validated with a regex.
- [ ] Adding new fields later should not break the architecture.
- [ ] Each future step (01, 02, 03, 04) has a clear integration point in this architecture.
