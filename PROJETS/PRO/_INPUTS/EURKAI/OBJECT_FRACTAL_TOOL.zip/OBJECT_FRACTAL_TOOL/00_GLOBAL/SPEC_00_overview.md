# SPEC 00 — Overview

This tool is an internal HTML/JS application called **Object Fractal Tool**.

Its purposes:
- Manage the genealogy (lineages) of **ObjectTypes**.
- Visualize the **fractale** (complete or partial) of any selected ObjectType.
- Distinguish between:
  - **owned** elements (defined at this level)
  - **inherited** elements (from ancestors)
  - **injected** elements (from transversal / tagged logics)
- Attach and inspect:
  - attributes
  - secondary methods
  - ERK rules
  - relations (3 fundamental ones, others as aliases)
- Manipulate tags, categories and aliases.
- Edit **schemas** of bundles (expected children, quantity, required).
- Instantiate example objects to feed a catalogue.
- Test simple method expressions like `methodA(inputs).result.message` in a mini console.

Front-end target:
- Simple HTML + JavaScript (framework optional, but not mandatory).
- Data layer: JSON files (backend can be added later).

Core concepts:
- Every object is a **Bundle**: a list of elements, each element being an object (itself a bundle).
- For every object `X`, there exists `XFractal` describing, at a given time:
  - attributes
  - secondary methods
  - ERK rules
  - relations
- ObjectTypes are arranged in **lineages** (inheritance chains).
- For each object, we must be able to see, for each element in its XFractal:
  - whether it is owned / inherited / injected
  - and, if not owned, its exact source (ancestor or transversal logic).
