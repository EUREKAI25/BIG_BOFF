# 🔴 MÉTHODES & SUPERTOOLS — PATTERNS D’EXÉCUTION (ERK SYSTEM)

## 1. Méthodes centrales (GEVR)
Toutes les entités fractales possèdent les quatre méthodes centrales :

- **GET**
- **EXECUTE**
- **VALIDATE**
- **RENDER**

Elles constituent le pipeline universel GEVR.

### GET
Récupère les données d’entrée, prépare le contexte fractal.

### EXECUTE
Déclenche l’action principale (ou délègue à un SuperTool).

### VALIDATE
Normalise, contrôle, authentifie, restructure selon les règles fractales.

### RENDER
Produit la sortie dans le format demandé.

---

## 2. SuperTools
Les SuperTools incarnent les “méta-outils” :  
Convert, SuperScan, SuperQuery, SuperAssemble…

### Pattern d’exécution d’un SuperTool
Un SuperTool utilise *toujours* :

1. **hook_before** → conversion de l’objet en fractal propriétaire (Convert)
2. **call()** → exécution de la méthode interne du SuperTool  
3. **hook_validate** → validation fractale structurelle  
4. **hook_after** → reformattage (si nécessaire)

### Points essentiels :
- Tous les SuperTools utilisent la **Méthode Récursive Globale**.
- Le “core” d’un SuperTool ne fait qu’UNE seule chose.  
- Toute adaptation de format se fait **avant/ après**, jamais dans le core.

