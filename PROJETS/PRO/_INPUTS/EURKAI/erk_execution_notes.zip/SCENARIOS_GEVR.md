# 🔴 LOGIQUE DES SCÉNARIOS (ORCHESTRATION GEVR)

## 1. Structure d’un scénario
Un scénario = une séquence strictement ordonnée de GEVR.

Exemple :
- Step 1 : GET  
- Step 2 : EXECUTE  
- Step 3 : VALIDATE  
- Step 4 : RENDER  

## 2. Pipeline GEVR
### 1. GET
- charger les inputs  
- détecter le type d’objet  
- récupérer les métadonnées  
- charger le lineage et le scope  

### 2. EXECUTE
- exécute la méthode de l’objet  
- délègue si nécessaire à un SuperTool  
- évalue les sub-steps récursivement  

### 3. VALIDATE
- applique les règles fractales  
- convertit en format propriétaire  
- certifie les structures internes  
- vérifie les vecteurs  

### 4. RENDER
- sortie structurée  
- conversion optionnelle selon format demandé  
- encapsulation finale fractale  

## 3. Exécution récursive
Chaque step peut appeler :
- un sous-scenario  
- une sous-méthode  
- un SuperTool

La Méthode Récursive Globale gère toute la “descente / remontée”.

