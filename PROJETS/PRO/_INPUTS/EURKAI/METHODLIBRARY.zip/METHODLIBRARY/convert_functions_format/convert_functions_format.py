def convert_functions_format():
    return {
        'function':'convert_functions_format',
        'status':'ok',
        'message':'Executed successfully'
    }
