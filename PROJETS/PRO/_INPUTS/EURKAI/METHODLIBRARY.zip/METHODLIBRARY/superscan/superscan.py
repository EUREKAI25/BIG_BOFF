def superscan():
    return {
        'function':'superscan',
        'status':'ok',
        'message':'Executed successfully'
    }
