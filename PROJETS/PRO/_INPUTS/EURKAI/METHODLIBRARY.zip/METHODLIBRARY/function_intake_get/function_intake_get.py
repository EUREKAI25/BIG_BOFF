def function_intake_get():
    return {
        'function':'function_intake_get',
        'status':'ok',
        'message':'Executed successfully'
    }
