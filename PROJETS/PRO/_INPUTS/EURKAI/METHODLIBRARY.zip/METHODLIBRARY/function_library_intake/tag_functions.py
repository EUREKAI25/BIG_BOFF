#!/usr/bin/env python3

"""
Assign basic object, central_method and tags to function records.
"""

from typing import Dict, List


def tag_functions(
    records: List[Dict[str, str]],
    default_object: str = "Object",
    default_central_method: str = "Execute",
) -> List[Dict[str, str]]:
    """
    Add simple tagging fields. This is a placeholder until
    the full AI-based classification is plugged in.
    """
    tagged: List[Dict[str, str]] = []

    for record in records:
        enriched = dict(record)
        enriched.setdefault("object", default_object)
        enriched.setdefault("central_method", default_central_method)
        enriched.setdefault("tags", "")
        tagged.append(enriched)

    return tagged
