#!/usr/bin/env python3

"""
Build a simple index view for function records.
"""

from typing import Dict, List, Any


def export_functions_index(
    records: List[Dict[str, str]],
) -> Dict[str, Any]:
    """
    Returns a minimal index:
      - by_id: dict id -> record
      - all_ids: list of ids
    """
    by_id: Dict[str, Dict[str, str]] = {}
    for r in records:
        rid = r.get("id")
        if not rid:
            continue
        by_id[rid] = r

    index = {
        "by_id": by_id,
        "all_ids": list(by_id.keys()),
    }
    return index
