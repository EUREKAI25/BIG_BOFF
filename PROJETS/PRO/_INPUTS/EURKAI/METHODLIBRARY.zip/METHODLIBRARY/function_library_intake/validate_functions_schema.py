#!/usr/bin/env python3

"""
Check presence of required fields on function records.
"""

from typing import Dict, List, Tuple


REQUIRED_FIELDS = ["id", "name", "path"]


def validate_functions_schema(
    records: List[Dict[str, str]],
) -> Tuple[bool, List[str]]:
    """
    Return (ok, errors). Errors are textual messages.
    """
    errors: List[str] = []

    for idx, record in enumerate(records):
        for field in REQUIRED_FIELDS:
            if field not in record or record[field] in (None, ""):
                errors.append(f"Record {idx}: missing field '{field}'")

    return len(errors) == 0, errors
