#!/usr/bin/env python3

"""
EXECUTE step: convert + tag function entries.
"""

from typing import Any, Dict
from .superscan import superscan
from .convert_functions_format import convert_functions_format
from .tag_functions import tag_functions


def function_intake_execute(context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Use raw_files → catalog → converted → tagged.
    """
    raw_files = context.get("raw_files", [])
    catalog = superscan(raw_files)
    converted = convert_functions_format(catalog)
    tagged = tag_functions(converted)
    context["function_catalog"] = tagged
    return context
