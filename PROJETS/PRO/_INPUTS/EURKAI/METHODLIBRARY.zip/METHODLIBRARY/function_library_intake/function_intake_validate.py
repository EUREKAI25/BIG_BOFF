#!/usr/bin/env python3

"""
VALIDATE step: run schema + index validation.
"""

from typing import Any, Dict
from .validate_functions_schema import validate_functions_schema
from .validate_functions_index import validate_functions_index


def function_intake_validate(context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate function_catalog structure and consistency.
    """
    records = context.get("function_catalog", [])

    schema_ok, schema_errors = validate_functions_schema(records)
    index_ok, index_errors = validate_functions_index(records)

    context["validation"] = {
        "schema_ok": schema_ok,
        "schema_errors": schema_errors,
        "index_ok": index_ok,
        "index_errors": index_errors,
        "ok": schema_ok and index_ok,
    }

    return context
