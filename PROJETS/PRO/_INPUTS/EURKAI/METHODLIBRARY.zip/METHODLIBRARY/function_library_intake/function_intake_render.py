#!/usr/bin/env python3

"""
RENDER step: prepare final payload for METHODLIBRARY.
"""

from typing import Any, Dict
from .prepare_vector_data import prepare_vector_data
from .export_functions_index import export_functions_index


def function_intake_render(context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build vector payload + export-ready index, store them in context["render"].
    """
    records = context.get("function_catalog", [])
    vectors = prepare_vector_data(records)
    index_view = export_functions_index(records)

    context["render"] = {
        "vector_payload": vectors,
        "index_view": index_view,
    }
    return context
