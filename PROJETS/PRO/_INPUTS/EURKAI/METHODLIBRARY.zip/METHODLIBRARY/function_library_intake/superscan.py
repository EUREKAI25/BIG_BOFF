#!/usr/bin/env python3

"""
SuperScan: normalize a list of raw paths into a simple catalog structure.
"""

import os
from typing import Dict, List


def superscan(file_paths: List[str]) -> List[Dict[str, str]]:
    """
    Turn a list of file paths into a small catalog:
      - path
      - file_name
      - dir_name
    """
    catalog: List[Dict[str, str]] = []

    for path in file_paths:
        file_name = os.path.basename(path)
        dir_name = os.path.dirname(path)
        catalog.append(
            {
                "path": path,
                "file_name": file_name,
                "dir_name": dir_name,
            }
        )

    return catalog
