#!/usr/bin/env python3

"""
Check basic index consistency for function records.
"""

from typing import Dict, List, Tuple


def validate_functions_index(
    records: List[Dict[str, str]],
) -> Tuple[bool, List[str]]:
    """
    Minimal check:
      - no duplicate ids
      - no duplicate (name, path) pairs
    """
    errors: List[str] = []
    seen_ids = set()
    seen_name_path = set()

    for idx, record in enumerate(records):
        rid = record.get("id")
        key = (record.get("name"), record.get("path"))

        if rid in seen_ids:
            errors.append(f"Record {idx}: duplicate id '{rid}'")
        else:
            seen_ids.add(rid)

        if key in seen_name_path:
            errors.append(f"Record {idx}: duplicate (name, path) {key}")
        else:
            seen_name_path.add(key)

    return len(errors) == 0, errors
