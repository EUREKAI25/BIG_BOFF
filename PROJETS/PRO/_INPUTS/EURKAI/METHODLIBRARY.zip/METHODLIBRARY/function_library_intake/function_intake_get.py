#!/usr/bin/env python3

"""
GET step: collect raw function files from filesystem.
"""

from typing import Any, Dict, List
from .scan_local_files import scan_local_files


def function_intake_get(
    context: Dict[str, Any],
    root_paths: List[str],
) -> Dict[str, Any]:
    """
    Populate context["raw_files"] with a list of .py files.
    """
    raw_files = scan_local_files(root_paths)
    context["raw_files"] = raw_files
    return context
