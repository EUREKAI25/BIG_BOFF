#!/usr/bin/env python3

"""
Convert raw catalog entries into internal function records.
"""

import os
from typing import Dict, List


def convert_functions_format(
    catalog: List[Dict[str, str]],
) -> List[Dict[str, str]]:
    """
    Basic conversion:
      - id: file stem
      - name: file stem
      - path: absolute path
    """
    records: List[Dict[str, str]] = []

    for entry in catalog:
        path = entry["path"]
        stem, _ = os.path.splitext(os.path.basename(path))
        record = {
            "id": stem,
            "name": stem,
            "path": path,
        }
        records.append(record)

    return records
