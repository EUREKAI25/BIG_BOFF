#!/usr/bin/env python3

"""
Prepare a simple vector-ready payload for functions.
"""

from typing import Dict, List, Any


def prepare_vector_data(
    records: List[Dict[str, str]],
) -> Dict[str, Any]:
    """
    For now: minimal payload with id, name, path only.
    """
    items = [
        {
            "id": r.get("id"),
            "name": r.get("name"),
            "path": r.get("path"),
        }
        for r in records
    ]

    return {"type": "function_library", "items": items}
