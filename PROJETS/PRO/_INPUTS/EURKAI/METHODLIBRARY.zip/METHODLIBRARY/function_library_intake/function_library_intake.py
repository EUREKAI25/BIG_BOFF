#!/usr/bin/env python3

"""
Orchestrator for the FunctionLibrary_Intake scenario (GEVR).
"""

from typing import Any, Dict, List

from .function_intake_get import function_intake_get
from .function_intake_execute import function_intake_execute
from .function_intake_validate import function_intake_validate
from .function_intake_render import function_intake_render


def function_library_intake(
    root_paths: List[str],
    options: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """
    Run the full FunctionLibrary_Intake scenario:
    - GET: scan local files, build raw catalog
    - EXECUTE: convert and tag functions
    - VALIDATE: run schema + index checks
    - RENDER: prepare final payload
    """
    if options is None:
        options = {}

    context: Dict[str, Any] = {"options": options}

    context = function_intake_get(context, root_paths)
    context = function_intake_execute(context)
    context = function_intake_validate(context)
    context = function_intake_render(context)

    return context
