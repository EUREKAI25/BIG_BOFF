#!/usr/bin/env python3

"""
Scan local directories to find candidate Python function files.
"""

import os
from typing import List


def scan_local_files(root_paths: List[str]) -> List[str]:
    """
    Return a list of absolute paths to .py files under the given roots.
    """
    results: List[str] = []

    for root in root_paths:
        if not os.path.isdir(root):
            continue

        for dirpath, _, filenames in os.walk(root):
            for name in filenames:
                if name.endswith(".py"):
                    full_path = os.path.join(dirpath, name)
                    results.append(os.path.abspath(full_path))

    return results
