def function_intake_validate():
    return {
        'function':'function_intake_validate',
        'status':'ok',
        'message':'Executed successfully'
    }
