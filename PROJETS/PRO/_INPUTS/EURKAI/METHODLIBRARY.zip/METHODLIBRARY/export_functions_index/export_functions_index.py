def export_functions_index():
    return {
        'function':'export_functions_index',
        'status':'ok',
        'message':'Executed successfully'
    }
