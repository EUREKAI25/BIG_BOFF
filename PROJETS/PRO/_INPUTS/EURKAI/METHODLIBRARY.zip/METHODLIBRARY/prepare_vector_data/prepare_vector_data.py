def prepare_vector_data():
    return {
        'function':'prepare_vector_data',
        'status':'ok',
        'message':'Executed successfully'
    }
