def function_intake_render():
    return {
        'function':'function_intake_render',
        'status':'ok',
        'message':'Executed successfully'
    }
