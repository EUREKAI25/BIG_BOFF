#!/bin/zsh

BASE="/Users/nathalie/Dropbox/____BIG_BOFF___/PROJETS/PRO/_INPUTS/EURKAI/METHODLIBRARY"

cd "$BASE" || exit

mkdir -p function_library_intake

create() {
  FILE="$BASE/function_library_intake/$1"
  echo "$2" > "$FILE"
}

create "scan_local_files.py" '
import os

def scan_local_files(directory):
    results = []
    for root, dirs, files in os.walk(directory):
        for f in files:
            if f.endswith(".py"):
                results.append(os.path.join(root, f))
    return {"files": results}
'

create "superscan.py" '
import json
import os

def superscan(path):
    if os.path.isdir(path):
        items = os.listdir(path)
        return {"type": "directory", "items": items}
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        return {"type": "file", "content": content}
    return {"error": "not_found"}
'

create "function_intake_get.py" '
from superscan import superscan

def function_intake_get(target):
    return superscan(target)
'

create "convert_functions_format.py" '
def convert_functions_format(data):
    converted = []
    for f in data.get("files", []):
        converted.append({"path": f, "name": f.split("/")[-1]})
    return {"converted": converted}
'

create "prepare_vector_data.py" '
def prepare_vector_data(functions_list):
    vectors = []
    for f in functions_list.get("converted", []):
        vectors.append({"id": f["name"], "text": f["name"]})
    return {"vectors": vectors}
'

create "tag_functions.py" '
def tag_functions(converted):
    tagged = []
    for c in converted.get("converted", []):
        if "validate" in c["name"]:
            tag = "validator"
        elif "render" in c["name"]:
            tag = "renderer"
        elif "execute" in c["name"]:
            tag = "executor"
        else:
            tag = "generic"
        tagged.append({"name": c["name"], "tag": tag})
    return {"tagged": tagged}
'

create "function_intake_validate.py" '
def function_intake_validate(data):
    if "files" not in data:
        return {"valid": False, "error": "missing_files"}
    if not data["files"]:
        return {"valid": False, "error": "empty"}
    return {"valid": True}
'

create "function_intake_execute.py" '
from function_intake_get import function_intake_get
from convert_functions_format import convert_functions_format
from prepare_vector_data import prepare_vector_data
from tag_functions import tag_functions
from function_intake_validate import function_intake_validate

def function_intake_execute(directory):
    raw = function_intake_get(directory)
    validation = function_intake_validate(raw)
    if not validation["valid"]:
        return {"error": validation["error"], "stage": "validate"}

    converted = convert_functions_format(raw)
    vectors = prepare_vector_data(converted)
    tags = tag_functions(converted)

    return {
        "raw": raw,
        "converted": converted,
        "vectors": vectors,
        "tags": tags
    }
'
