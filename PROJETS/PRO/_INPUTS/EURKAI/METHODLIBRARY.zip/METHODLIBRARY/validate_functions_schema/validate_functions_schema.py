def validate_functions_schema():
    return {
        'function':'validate_functions_schema',
        'status':'ok',
        'message':'Executed successfully'
    }
