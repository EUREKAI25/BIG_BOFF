def scan_local_files():
    return {
        'function':'scan_local_files',
        'status':'ok',
        'message':'Executed successfully'
    }
