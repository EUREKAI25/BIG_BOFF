def tag_functions():
    return {
        'function':'tag_functions',
        'status':'ok',
        'message':'Executed successfully'
    }
