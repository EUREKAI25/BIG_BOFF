def validate_functions_index():
    return {
        'function':'validate_functions_index',
        'status':'ok',
        'message':'Executed successfully'
    }
