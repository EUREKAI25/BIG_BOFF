import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

// ============================================================================
// CORE DATA - Fondamentaux ERK (dans l'extension)
// ============================================================================

const ERK_CORE = {
  relations: ['depends_on', 'related_to', 'inherits_from'],
  relationAliases: {
    'IN': 'related_to',
    'tag_of': 'related_to',
    'type_of': 'inherits_from',
    'scope_of': 'related_to'
  },
  keywords: ['IF', 'THEN', 'ELSE', 'DO', 'WHEN', 'UNTIL', 'BEFORE', 'AFTER', 'AND', 'OR', 'NOT', 'XOR', 'IN'],
  types: ['str', 'string', 'int', 'number', 'bool', 'date', 'json', 'lineage'],
  centralMethods: ['Create', 'Read', 'Update', 'Delete', 'Orchestrate', 'Engage'],
  gevr: ['GetStep', 'ExecuteStep', 'ValidateStep', 'RenderStep'],
  bundles: ['AttributeList', 'MethodList', 'RuleList', 'RelationList']
};

// ============================================================================
// STATE - État du projet
// ============================================================================

interface EurekaiObject {
  lineage: string;
  name: string;
  parent: string;
  attributes: Map<string, any>;
  methods: string[];
  rules: string[];
  relations: Array<{ type: string; target: string }>;
  source: string; // filepath
}

class EurekaiState {
  private objects: Map<string, EurekaiObject> = new Map();
  private diagnosticCollection: vscode.DiagnosticCollection;
  
  constructor() {
    this.diagnosticCollection = vscode.languages.createDiagnosticCollection('erk');
  }
  
  getObjects(): Map<string, EurekaiObject> {
    return this.objects;
  }
  
  getObject(lineage: string): EurekaiObject | undefined {
    return this.objects.get(lineage);
  }
  
  hasObject(lineage: string): boolean {
    return this.objects.has(lineage);
  }
  
  getAllLineages(): string[] {
    return Array.from(this.objects.keys());
  }
  
  getChildren(lineage: string): string[] {
    const prefix = lineage + ':';
    return this.getAllLineages().filter(l => 
      l.startsWith(prefix) && 
      l.substring(prefix.length).indexOf(':') === -1
    );
  }
  
  addObject(obj: EurekaiObject): void {
    this.objects.set(obj.lineage, obj);
  }
  
  // Parse un fichier ERK et extrait les objets
  parseFile(document: vscode.TextDocument): void {
    const text = document.getText();
    const lines = text.split('\n');
    const diagnostics: vscode.Diagnostic[] = [];
    
    let currentLineage: string | null = null;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      
      // Skip comments and empty lines
      if (trimmed.startsWith('#') || trimmed.startsWith('//') || trimmed === '') {
        continue;
      }
      
      // Lineage declaration: Object:Parent:Child:
      const lineageMatch = trimmed.match(/^([A-Z][A-Za-z0-9_]*(?::[A-Z][A-Za-z0-9_]*)*):$/);
      if (lineageMatch) {
        currentLineage = lineageMatch[1];
        const segments = currentLineage.split(':');
        
        // Create object
        this.addObject({
          lineage: currentLineage,
          name: segments[segments.length - 1],
          parent: segments.slice(0, -1).join(':') || '',
          attributes: new Map(),
          methods: [],
          rules: [],
          relations: [],
          source: document.uri.fsPath
        });
        
        continue;
      }
      
      // Relation: X depends_on Y, X IN Y, etc.
      const relationMatch = trimmed.match(/^([A-Z][A-Za-z0-9_:]*)\s+(depends_on|related_to|inherits_from|IN|tag_of|type_of|scope_of)\s+([A-Z][A-Za-z0-9_:]*)/);
      if (relationMatch) {
        const [, source, relType, target] = relationMatch;
        const canonicalRel = (ERK_CORE.relationAliases as any)[relType] || relType;
        
        // Check if target exists
        if (!this.hasObject(target) && !target.startsWith('Object:')) {
          const fullTarget = 'Object:' + target;
          if (!this.hasObject(fullTarget)) {
            // Propose creation
            const range = new vscode.Range(i, 0, i, line.length);
            const diagnostic = new vscode.Diagnostic(
              range,
              `Object "${target}" does not exist. Create it?`,
              vscode.DiagnosticSeverity.Warning
            );
            diagnostic.code = 'create-object';
            (diagnostic as any).target = target;
            diagnostics.push(diagnostic);
          }
        }
        
        continue;
      }
      
      // Attribute: .attr = value
      const attrMatch = trimmed.match(/^\.([a-z][A-Za-z0-9_]*)\s*=\s*(.+)$/);
      if (attrMatch && currentLineage) {
        const [, attrName, value] = attrMatch;
        const obj = this.getObject(currentLineage);
        if (obj) {
          obj.attributes.set(attrName, value);
        }
        continue;
      }
      
      // Validate lineage format where expected
      const invalidLineage = trimmed.match(/^([a-z][A-Za-z0-9_]*(?::[A-Za-z][A-Za-z0-9_]*)*):$/);
      if (invalidLineage) {
        const range = new vscode.Range(i, 0, i, line.length);
        diagnostics.push(new vscode.Diagnostic(
          range,
          'Lineage must start with uppercase letter',
          vscode.DiagnosticSeverity.Error
        ));
      }
    }
    
    this.diagnosticCollection.set(document.uri, diagnostics);
  }
  
  dispose(): void {
    this.diagnosticCollection.dispose();
  }
}

// ============================================================================
// COMPLETION PROVIDER
// ============================================================================

class ErkCompletionProvider implements vscode.CompletionItemProvider {
  constructor(private state: EurekaiState) {}
  
  provideCompletionItems(
    document: vscode.TextDocument,
    position: vscode.Position
  ): vscode.CompletionItem[] {
    const linePrefix = document.lineAt(position).text.substring(0, position.character);
    const items: vscode.CompletionItem[] = [];
    
    // After ":" - suggest children or new segment
    if (linePrefix.endsWith(':')) {
      const lineagePart = linePrefix.slice(0, -1).trim().split(/\s+/).pop() || '';
      const children = this.state.getChildren(lineagePart);
      
      for (const child of children) {
        const name = child.split(':').pop() || '';
        const item = new vscode.CompletionItem(name, vscode.CompletionItemKind.Class);
        item.detail = child;
        items.push(item);
      }
      
      // Suggest bundles
      for (const bundle of ERK_CORE.bundles) {
        const item = new vscode.CompletionItem(bundle, vscode.CompletionItemKind.Module);
        item.detail = `${lineagePart}:${bundle}`;
        items.push(item);
      }
      
      return items;
    }
    
    // After "." - suggest attributes, methods, rules
    if (linePrefix.endsWith('.')) {
      // Common attributes
      const attrs = ['name', 'type', 'value', 'default', 'wrapper', 'scope', 'source'];
      for (const attr of attrs) {
        items.push(new vscode.CompletionItem(attr, vscode.CompletionItemKind.Property));
      }
      
      // method: and rule: shortcuts
      items.push(new vscode.CompletionItem('method:', vscode.CompletionItemKind.Method));
      items.push(new vscode.CompletionItem('rule:', vscode.CompletionItemKind.Event));
      
      return items;
    }
    
    // After space - suggest keywords and relations
    if (linePrefix.endsWith(' ') || linePrefix === '') {
      // Keywords
      for (const kw of ERK_CORE.keywords) {
        const item = new vscode.CompletionItem(kw, vscode.CompletionItemKind.Keyword);
        items.push(item);
      }
      
      // Relations
      for (const rel of ERK_CORE.relations) {
        const item = new vscode.CompletionItem(rel, vscode.CompletionItemKind.Reference);
        item.insertText = new vscode.SnippetString(`${rel} \${1:Target}`);
        items.push(item);
      }
      
      // Relation aliases
      for (const alias of Object.keys(ERK_CORE.relationAliases)) {
        const item = new vscode.CompletionItem(alias, vscode.CompletionItemKind.Reference);
        items.push(item);
      }
      
      return items;
    }
    
    // Default - suggest all lineages
    for (const lineage of this.state.getAllLineages()) {
      const name = lineage.split(':').pop() || '';
      const item = new vscode.CompletionItem(name, vscode.CompletionItemKind.Class);
      item.detail = lineage;
      item.insertText = lineage;
      items.push(item);
    }
    
    return items;
  }
}

// ============================================================================
// CODE ACTIONS - Create missing objects
// ============================================================================

class ErkCodeActionProvider implements vscode.CodeActionProvider {
  constructor(private state: EurekaiState) {}
  
  provideCodeActions(
    document: vscode.TextDocument,
    range: vscode.Range,
    context: vscode.CodeActionContext
  ): vscode.CodeAction[] {
    const actions: vscode.CodeAction[] = [];
    
    for (const diagnostic of context.diagnostics) {
      if (diagnostic.code === 'create-object') {
        const target = (diagnostic as any).target;
        
        const action = new vscode.CodeAction(
          `Create object "${target}"`,
          vscode.CodeActionKind.QuickFix
        );
        
        action.command = {
          command: 'eurekai.createObjectFromDiagnostic',
          title: 'Create Object',
          arguments: [target, document]
        };
        
        actions.push(action);
      }
    }
    
    return actions;
  }
}

// ============================================================================
// TREE VIEW - Fractale
// ============================================================================

class FractaleTreeItem extends vscode.TreeItem {
  constructor(
    public readonly lineage: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState
  ) {
    super(lineage.split(':').pop() || lineage, collapsibleState);
    this.tooltip = lineage;
    this.description = lineage;
    
    // Icon based on type
    if (lineage.includes(':Entity:')) {
      this.iconPath = new vscode.ThemeIcon('person');
    } else if (lineage.includes(':Function:')) {
      this.iconPath = new vscode.ThemeIcon('symbol-function');
    } else if (lineage.includes(':Rule:')) {
      this.iconPath = new vscode.ThemeIcon('checklist');
    } else {
      this.iconPath = new vscode.ThemeIcon('symbol-class');
    }
  }
}

class FractaleTreeProvider implements vscode.TreeDataProvider<FractaleTreeItem> {
  private _onDidChangeTreeData = new vscode.EventEmitter<FractaleTreeItem | undefined>();
  readonly onDidChangeTreeData = this._onDidChangeTreeData.event;
  
  constructor(private state: EurekaiState) {}
  
  refresh(): void {
    this._onDidChangeTreeData.fire(undefined);
  }
  
  getTreeItem(element: FractaleTreeItem): vscode.TreeItem {
    return element;
  }
  
  getChildren(element?: FractaleTreeItem): FractaleTreeItem[] {
    if (!element) {
      // Root - return top-level objects (direct children of Object)
      const children = this.state.getChildren('Object');
      if (children.length === 0) {
        // Return Object itself if no children
        return [new FractaleTreeItem('Object', vscode.TreeItemCollapsibleState.Collapsed)];
      }
      return children.map(l => new FractaleTreeItem(
        l,
        this.state.getChildren(l).length > 0 
          ? vscode.TreeItemCollapsibleState.Collapsed 
          : vscode.TreeItemCollapsibleState.None
      ));
    }
    
    const children = this.state.getChildren(element.lineage);
    return children.map(l => new FractaleTreeItem(
      l,
      this.state.getChildren(l).length > 0 
        ? vscode.TreeItemCollapsibleState.Collapsed 
        : vscode.TreeItemCollapsibleState.None
    ));
  }
}

// ============================================================================
// ACTIVATION
// ============================================================================

export function activate(context: vscode.ExtensionContext) {
  console.log('EUREKAI ERK extension activated');
  
  const state = new EurekaiState();
  
  // Register completion provider
  context.subscriptions.push(
    vscode.languages.registerCompletionItemProvider(
      { language: 'erk', scheme: 'file' },
      new ErkCompletionProvider(state),
      ':', '.', ' '
    )
  );
  
  // Register code action provider
  context.subscriptions.push(
    vscode.languages.registerCodeActionsProvider(
      { language: 'erk', scheme: 'file' },
      new ErkCodeActionProvider(state),
      { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] }
    )
  );
  
  // Register tree view
  const fractaleProvider = new FractaleTreeProvider(state);
  vscode.window.registerTreeDataProvider('eurekaiExplorer', fractaleProvider);
  
  // Parse files on open/save
  vscode.workspace.onDidOpenTextDocument(doc => {
    if (doc.languageId === 'erk') {
      state.parseFile(doc);
      fractaleProvider.refresh();
    }
  });
  
  vscode.workspace.onDidSaveTextDocument(doc => {
    if (doc.languageId === 'erk') {
      state.parseFile(doc);
      fractaleProvider.refresh();
    }
  });
  
  // Parse all open ERK files
  vscode.workspace.textDocuments.forEach(doc => {
    if (doc.languageId === 'erk') {
      state.parseFile(doc);
    }
  });
  
  // Commands
  context.subscriptions.push(
    vscode.commands.registerCommand('eurekai.createSeed', () => {
      createNewFile('.s.gev', 'seed');
    }),
    vscode.commands.registerCommand('eurekai.createType', () => {
      createNewFile('.t.gev', 'type');
    }),
    vscode.commands.registerCommand('eurekai.createInstance', () => {
      createNewFile('.i.gev', 'instance');
    }),
    vscode.commands.registerCommand('eurekai.createManifest', () => {
      createNewFile('.m.gev', 'manifest');
    }),
    vscode.commands.registerCommand('eurekai.createObjectFromDiagnostic', async (target: string, document: vscode.TextDocument) => {
      const edit = new vscode.WorkspaceEdit();
      const fullLineage = target.startsWith('Object:') ? target : `Object:${target}`;
      const newContent = `\n\n${fullLineage}:\n  # Define attributes here\n`;
      
      edit.insert(document.uri, new vscode.Position(document.lineCount, 0), newContent);
      await vscode.workspace.applyEdit(edit);
      
      vscode.window.showInformationMessage(`Created ${fullLineage}`);
    }),
    vscode.commands.registerCommand('eurekai.showFractale', () => {
      vscode.commands.executeCommand('eurekaiExplorer.focus');
    }),
    vscode.commands.registerCommand('eurekai.connectEurekai', async () => {
      const serverUrl = vscode.workspace.getConfiguration('eurekai').get('serverUrl');
      vscode.window.showInformationMessage(`Connecting to ${serverUrl}...`);
      // TODO: Implement connection
    }),
    vscode.commands.registerCommand('eurekai.publish', async () => {
      vscode.window.showInformationMessage('Publishing...');
      // TODO: Implement publish
    })
  );
  
  context.subscriptions.push({ dispose: () => state.dispose() });
}

async function createNewFile(extension: string, type: string) {
  const name = await vscode.window.showInputBox({
    prompt: `Enter ${type} name`,
    placeHolder: `my-${type}`
  });
  
  if (!name) return;
  
  const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
  if (!workspaceFolder) {
    vscode.window.showErrorMessage('No workspace folder open');
    return;
  }
  
  const dirMap: Record<string, string> = {
    'seed': 'seeds',
    'type': 'types',
    'instance': 'instances',
    'manifest': 'manifests'
  };
  
  const dir = dirMap[type] || '';
  const filePath = path.join(workspaceFolder.uri.fsPath, dir, `${name}${extension}`);
  
  // Create directory if needed
  const dirPath = path.dirname(filePath);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
  
  // Create file with template
  const template = `# EUREKAI ${type.toUpperCase()}\n# Created: ${new Date().toISOString()}\n\nObject:\n`;
  fs.writeFileSync(filePath, template);
  
  // Open file
  const doc = await vscode.workspace.openTextDocument(filePath);
  vscode.window.showTextDocument(doc);
}

export function deactivate() {}
