# EUREKAI ERK Extension for VSCode

Language support for ERK (EUREKAI Rule Kernel) - the declarative language for EUREKAI's fractal architecture.

## Features

### Syntax Highlighting
- **Lineages** - Blue, bold
- **Attributes** - Green, bold  
- **Methods** - Yellow, bold
- **Relations** - Orange, bold
- **Rules** - Pink, bold
- **Invalid** - Gray background until corrected

### Autocompletion
- After `:` → suggests children and bundles
- After `.` → suggests attributes, methods, rules
- After space → suggests keywords and relations

### Validation
- Invalid lineage format → red error with tooltip
- Reference to non-existent object → warning with quick fix to create

### Panels
- **Fractale** - Tree view of all objects
- **Rules** - Rule management (coming soon)
- **Preview** - HTML preview (coming soon)

### Commands
- `EUREKAI: New Seed (.s.gev)`
- `EUREKAI: New Type (.t.gev)`
- `EUREKAI: New Instance (.i.gev)`
- `EUREKAI: New Manifest (.m.gev)`
- `EUREKAI: Connect to System`
- `EUREKAI: Publish`

## File Extensions

| Extension | Purpose |
|-----------|---------|
| `.erk` | Generic ERK file |
| `.s.gev` | Seed (initial data) |
| `.t.gev` | Type (ObjectType definition) |
| `.i.gev` | Instance (object instance) |
| `.m.gev` | Manifest (deployment) |

## Installation

1. Copy the `eurekai-erk` folder to `~/.vscode/extensions/`
2. Run `npm install` in the extension folder
3. Run `npm run compile`
4. Restart VSCode

Or for development:
1. Open the extension folder in VSCode
2. Press F5 to launch Extension Development Host

## ERK Quick Reference

```erk
# Object declaration
Object:Entity:Agent:

# Attributes
Agent.temperature = 0.7
.name = "MyAgent"

# Methods
Agent.method:CreateFrom

# Rules
Agent.rule:NotEmpty

# Relations
Agent depends_on Role
Explorer IN TabList

# Control flow
IF Agent.active THEN Agent.process
DO Agent.save
WHEN Event.trigger DO Handler.execute
```

## Theme

The extension includes "EUREKAI Dark" theme optimized for ERK files.

To activate: `Preferences > Color Theme > EUREKAI Dark`

---

© EUREKAI 2025
