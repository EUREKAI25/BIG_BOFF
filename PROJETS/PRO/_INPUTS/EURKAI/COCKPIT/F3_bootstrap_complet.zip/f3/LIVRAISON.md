# F3/6 — Bootstrapping Complet de Projet EUREKAI

## 1. PIPELINE DE BOOTSTRAPPING

### 1.1 Vue d'ensemble

Le bootstrapping EUREKAI suit un pipeline en 7 phases, inspiré du pattern GEVR étendu :

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        PIPELINE DE BOOTSTRAPPING                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   MANIFEST (F1)                                                             │
│        │                                                                    │
│        ▼                                                                    │
│   ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐               │
│   │   READ   │──▶│ VALIDATE │──▶│ GENERATE │──▶│  WRITE   │               │
│   │ Manifest │   │ Structure│   │ Modules  │   │  Files   │               │
│   └──────────┘   └──────────┘   └──────────┘   └──────────┘               │
│        │              │              │              │                       │
│        ▼              ▼              ▼              ▼                       │
│   ProjectManifest  Errors/OK    FileTree      Disk Files                   │
│                                                     │                       │
│                                                     ▼                       │
│                              ┌──────────┐   ┌──────────┐   ┌──────────┐   │
│                              │  SETUP   │──▶│  TESTS   │──▶│ FINALIZE │   │
│                              │   Env    │   │  Initial │   │  Report  │   │
│                              └──────────┘   └──────────┘   └──────────┘   │
│                                   │              │              │          │
│                                   ▼              ▼              ▼          │
│                              Virtualenv     Results      BootstrapResult  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Description des Phases

| Phase | Nom | Description | Input | Output |
|-------|-----|-------------|-------|--------|
| 1 | **READ_MANIFEST** | Lecture et parsing du manifest | JSON/YAML/Dict | `ProjectManifest` |
| 2 | **VALIDATE** | Validation de la structure | `ProjectManifest` | Errors/Warnings |
| 3 | **GENERATE** | Génération via F2 | Fractal manifest | `FileTree` |
| 4 | **WRITE** | Écriture sur disque | `FileTree` | Files created |
| 5 | **SETUP_ENV** | Configuration environnement | Options | Virtualenv + deps |
| 6 | **RUN_TESTS** | Tests initiaux | Project path | Test results |
| 7 | **FINALIZE** | Création du rapport | All data | `BootstrapResult` |

### 1.3 Points de Contrôle (Checkpoints)

Chaque phase crée un checkpoint permettant le rollback partiel :

```python
# Exemple de checkpoint après écriture
Checkpoint(
    id="files_written",
    phase=BootstrapPhase.WRITE,
    timestamp="2025-06-01T10:00:00Z",
    state={"file_count": 15},
    files_created=["src/...", "tests/..."],
    dirs_created=["src/models", "scenarios"],
    reversible=True
)
```

---

## 2. API CONCEPTUELLE

### 2.1 Signature Principale

```python
def bootstrapProject(
    manifest: Union[str, Path, Dict],
    options: BootstrapOptions
) -> BootstrapResult:
    """
    Bootstrap un projet EUREKAI complet.
    
    Args:
        manifest: Source du manifest (fichier, JSON, ou dict)
        options: Options de configuration
        
    Returns:
        BootstrapResult contenant:
        - status: SUCCESS | PARTIAL | FAILED | ROLLED_BACK
        - paths: Liste des fichiers/répertoires créés
        - logs: Journal complet avec checkpoints
    """
```

### 2.2 Structure des Options

```python
@dataclass
class BootstrapOptions:
    # Chemins
    output_dir: Path = Path("./project")
    manifest_path: Optional[Path] = None
    
    # Environnement
    env_type: EnvironmentType = EnvironmentType.DEVELOPMENT
    project_type: ProjectType = ProjectType.APPLICATION
    python_version: str = "3.11"
    
    # Comportement
    create_venv: bool = True
    install_deps: bool = True
    run_initial_tests: bool = True
    init_git: bool = True
    
    # Génération
    generate_tests: bool = True
    generate_docs: bool = True
    
    # Sécurité
    dry_run: bool = False
    allow_overwrite: bool = False
    backup_existing: bool = True
```

### 2.3 Structure du Résultat

```python
@dataclass
class BootstrapResult:
    # Statut global
    status: BootstrapStatus  # SUCCESS | PARTIAL | FAILED | ROLLED_BACK
    
    # Chemins
    project_path: Path
    manifest_hash: str
    
    # Fichiers générés
    files: List[GeneratedFile]
    directories: List[Path]
    
    # Environnement
    venv_path: Optional[Path]
    installed_packages: List[str]
    
    # Tests
    tests_run: int
    tests_passed: int
    tests_failed: int
    
    # Métriques
    duration_ms: int
    started_at: str
    completed_at: str
    
    # Logs complets
    logs: BootstrapLog
```

---

## 3. EXEMPLES DE SCÉNARIOS

### 3.1 Exemple 1: Blog EUREKAI

**Entrée** (`blog_manifest.yaml`):
```yaml
name: "eurekai-blog"
version: "1.0.0"
project_type: "application"

fractal:
  objects:
    Article:
      identity:
        id: string
        title: string
        content: string
        status: enum[draft, published]
    Author:
      identity:
        id: string
        username: string
    Comment:
      identity:
        id: string
        article_id: string
        content: string
  
  scenarios:
    CreateArticle:
      trigger: "api.request.POST:/articles"
      steps:
        - validate_input
        - create_article
        - notify_created
```

**Actions**:
1. Lire et parser le manifest YAML
2. Valider la structure (3 objets, 1 scénario)
3. Générer:
   - `src/eurekai_blog/models/article.py`
   - `src/eurekai_blog/models/author.py`
   - `src/eurekai_blog/models/comment.py`
   - `src/eurekai_blog/scenarios/create_article.py`
4. Écrire les fichiers + configurations
5. Créer virtualenv + installer dépendances
6. Exécuter tests de syntaxe

**Sortie**:
```python
BootstrapResult(
    status=BootstrapStatus.SUCCESS,
    project_path=Path("./eurekai-blog"),
    manifest_hash="sha256:a1b2c3d4e5f6...",
    files=[
        GeneratedFile(path="src/eurekai_blog/models/article.py", ...),
        GeneratedFile(path="src/eurekai_blog/models/author.py", ...),
        # ... 15 fichiers au total
    ],
    tests_run=3,
    tests_passed=3,
    tests_failed=0,
    duration_ms=4523
)
```

### 3.2 Exemple 2: Labo EUREKAI

**Entrée** (`labo_manifest.yaml`):
```yaml
name: "eurekai-labo"
version: "1.0.0"
project_type: "service"

fractal:
  objects:
    Experiment:
      identity:
        id: string
        code: string
        status: enum[draft, running, completed]
        protocol_id: string
      view:
        methods:
          - start() -> void
          - complete(results: dict) -> void
    
    Sample:
      identity:
        id: string
        barcode: string
        type: enum[tissue, blood, dna]
        quantity: float
    
    Protocol:
      identity:
        id: string
        name: string
        steps: list
        safety_level: enum[bsl1, bsl2, bsl3]
    
    Researcher:
      identity:
        id: string
        name: string
        certifications: list
  
  scenarios:
    StartExperiment:
      steps:
        - validate_experiment_id
        - check_protocol_approved
        - verify_researcher_clearance
        - reserve_equipment
        - set_running_status
    
    RegisterSample:
      steps:
        - validate_input
        - generate_barcode
        - assign_location
```

**Actions**:
1. Lire manifest complexe (4 objets, 2 scénarios)
2. Résoudre l'héritage et les relations
3. Générer structure complète:
   ```
   eurekai-labo/
   ├── src/eurekai_labo/
   │   ├── models/
   │   │   ├── experiment.py
   │   │   ├── sample.py
   │   │   ├── protocol.py
   │   │   └── researcher.py
   │   └── scenarios/
   │       ├── start_experiment.py
   │       └── register_sample.py
   ├── tests/
   │   ├── test_experiment.py
   │   ├── test_sample.py
   │   └── ...
   └── pyproject.toml
   ```
4. Configuration avec règles de compliance GxP

**Sortie**:
```python
BootstrapResult(
    status=BootstrapStatus.SUCCESS,
    project_path=Path("./eurekai-labo"),
    files=[...],  # 25+ fichiers
    duration_ms=6234
)
```

---

## 4. CAS DE TEST

### 4.1 Projet Minimal

```python
def test_bootstrap_minimal():
    """Test: projet avec un seul objet."""
    manifest = {
        "name": "minimal",
        "version": "1.0.0",
        "fractal": {
            "objects": {
                "Item": {
                    "identity": {"id": "string", "name": "string"}
                }
            }
        }
    }
    
    result = bootstrap_project(manifest, output_dir="./test_minimal")
    
    assert result.status == BootstrapStatus.SUCCESS
    assert result.file_count >= 5  # init, model, test, pyproject, readme
    assert (Path("./test_minimal/src/minimal/models/item.py")).exists()
```

### 4.2 Projet Moyen

```python
def test_bootstrap_medium():
    """Test: projet avec plusieurs objets et scénarios."""
    manifest = {
        "name": "medium-project",
        "version": "1.0.0",
        "dependencies": [
            {"name": "pydantic", "version": ">=2.0"}
        ],
        "fractal": {
            "objects": {
                "User": {...},
                "Task": {...},
                "Project": {...}
            },
            "scenarios": {
                "CreateTask": {...},
                "AssignTask": {...}
            }
        }
    }
    
    result = bootstrap_project(manifest, output_dir="./test_medium")
    
    assert result.success
    assert result.file_count >= 15
    assert len(result.warnings) == 0
```

### 4.3 Dry Run

```python
def test_dry_run():
    """Test: prévisualisation sans écriture."""
    result = bootstrap_project(
        manifest={"name": "dry", "version": "1.0.0", "fractal": {}},
        dry_run=True
    )
    
    assert result.success
    assert result.file_count > 0
    assert not Path("./project/pyproject.toml").exists()
```

### 4.4 Rollback sur Erreur

```python
def test_rollback_on_error():
    """Test: rollback si échec en cours de route."""
    # Simuler une erreur pendant l'écriture
    with patch("ProjectWriter.write_file", side_effect=IOError("Disk full")):
        result = bootstrap_project(manifest, output_dir="./test_error")
    
    assert result.status == BootstrapStatus.FAILED
    # Vérifier que les fichiers partiels sont nettoyés
```

---

## 5. CHECKLIST DE VALIDATION

- [x] **Pipeline défini étape par étape**
  - 7 phases clairement identifiées
  - Transitions et checkpoints documentés
  
- [x] **Fonction peut prendre un manifest et produire un projet complet**
  - API `bootstrap_project(manifest, options) -> BootstrapResult`
  - Support JSON, YAML, et dict
  
- [x] **Logs et points de contrôle prévus**
  - `BootstrapLog` avec entrées par phase
  - Checkpoints pour rollback partiel
  
- [x] **Exemples fournis**
  - Blog EUREKAI (application web)
  - Labo EUREKAI (système métier complexe)
  
- [x] **Cas de test inclus**
  - Projet minimal
  - Projet moyen
  - Dry run
  - Gestion d'erreurs

---

## 6. STRUCTURE DU LIVRABLE

```
F3_bootstrap/
├── eurekai_bootstrap/
│   ├── __init__.py          # Exports publics
│   ├── bootstrap.py         # Pipeline principal
│   └── types.py             # Types et structures
├── examples/
│   ├── blog_manifest.yaml   # Exemple Blog
│   ├── labo_manifest.yaml   # Exemple Labo
│   └── demo_bootstrap.py    # Script de démonstration
├── tests/
│   ├── __init__.py
│   └── test_bootstrap.py    # Tests complets
├── pyproject.toml           # Configuration projet
└── LIVRAISON.md             # Cette documentation
```

---

## 7. INTÉGRATION AVEC F1/F2

### Dépendances

```
F1 (Manifest Fractal) ──────────────────┐
                                        │
                                        ▼
F2 (Module Generator) ──────────► F3 (Bootstrapper)
                                        │
                                        ▼
                                  Projet Complet
```

### Points d'Intégration

1. **F1 → F3**: Le manifest fractal est embarqué dans le `ProjectManifest.fractal`
2. **F2 → F3**: La génération des modules délègue au `ModuleGenerator` de F2
3. **F3 Output**: Projet prêt à l'emploi avec venv, tests, et configurations

---

## 8. UTILISATION

### Installation

```bash
cd F3_bootstrap
pip install -e ".[dev]"
```

### CLI

```bash
# Bootstrapping complet
eurekai-bootstrap manifest.yaml -o ./my-project

# Dry run (prévisualisation)
eurekai-bootstrap manifest.yaml --dry-run

# Sans virtualenv
eurekai-bootstrap manifest.yaml --no-venv
```

### API Python

```python
from eurekai_bootstrap import bootstrap_project

result = bootstrap_project(
    manifest="project.yaml",
    output_dir="./my_project",
    create_venv=True,
    run_initial_tests=True
)

if result.success:
    print(f"Projet créé: {result.project_path}")
    print(f"Fichiers: {result.file_count}")
else:
    for error in result.errors:
        print(f"Erreur: {error.message}")
```

---

*Généré par EUREKAI F3/6 — Pipeline de Bootstrapping*
