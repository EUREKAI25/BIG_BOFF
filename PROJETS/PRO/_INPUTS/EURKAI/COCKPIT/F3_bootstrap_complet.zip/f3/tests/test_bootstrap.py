"""
Tests pour le bootstrapper EUREKAI F3/6.

Couvre:
- Lecture de manifest
- Génération de fichiers
- Pipeline complet
- Cas limites
"""

import json
import pytest
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from eurekai_bootstrap import (
    bootstrap_project,
    ProjectBootstrapper,
    ManifestReader,
    ProjectWriter,
    ConfigGenerator,
    BootstrapOptions,
    BootstrapStatus,
    BootstrapPhase,
    BootstrapLog,
    ProjectManifest,
    ProjectType,
)


# ═══════════════════════════════════════════════════════════════════════════════
# FIXTURES
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def minimal_manifest():
    """Manifest minimal valide."""
    return {
        "name": "test-project",
        "version": "1.0.0",
        "description": "Test project",
        "project_type": "library",
        "fractal": {
            "meta": {
                "name": "TestFractal",
                "version": "1.0.0"
            },
            "objects": {
                "TestItem": {
                    "identity": {
                        "id": "string",
                        "name": "string"
                    }
                }
            },
            "scenarios": {}
        }
    }


@pytest.fixture
def full_manifest():
    """Manifest complet avec tous les éléments."""
    return {
        "name": "full-test-project",
        "version": "2.0.0",
        "description": "Full test project with all features",
        "project_type": "application",
        "python_version": ">=3.10",
        "author": "Test Author",
        "license": "MIT",
        "dependencies": [
            {"name": "pydantic", "version": ">=2.0.0"},
            {"name": "fastapi", "version": ">=0.100.0"}
        ],
        "dev_dependencies": [
            {"name": "pytest", "version": ">=7.0.0"}
        ],
        "fractal": {
            "meta": {
                "name": "FullTestFractal",
                "version": "2.0.0",
                "lineage": ["@eurekai/core"]
            },
            "objects": {
                "User": {
                    "identity": {
                        "id": "string",
                        "username": "string",
                        "email": "string",
                        "created_at": "datetime"
                    },
                    "view": {
                        "methods": [
                            "activate() -> void",
                            "deactivate() -> void",
                            "get_profile() -> dict"
                        ],
                        "properties": [
                            "is_active: bool (computed)"
                        ]
                    },
                    "context": {
                        "defaults": {
                            "is_active": True
                        }
                    }
                },
                "Task": {
                    "identity": {
                        "id": "string",
                        "title": "string",
                        "status": "enum[pending, done]",
                        "user_id": "string"
                    },
                    "view": {
                        "methods": [
                            "complete() -> void"
                        ]
                    },
                    "relations": [
                        {"type": "uses", "target": "User"}
                    ]
                }
            },
            "scenarios": {
                "CreateUser": {
                    "trigger": "api.request.POST:/users",
                    "steps": [
                        "validate_input",
                        "check_uniqueness",
                        "create_user",
                        "send_welcome_email"
                    ]
                }
            },
            "meta_rules": [
                "@validate/required: [id, username]",
                "@audit/track_changes"
            ]
        },
        "config": {
            "database": {
                "driver": "sqlite"
            }
        }
    }


@pytest.fixture
def temp_output_dir():
    """Répertoire temporaire pour les tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


# ═══════════════════════════════════════════════════════════════════════════════
# TESTS: ManifestReader
# ═══════════════════════════════════════════════════════════════════════════════

class TestManifestReader:
    """Tests pour la lecture de manifest."""
    
    def test_read_from_dict(self, minimal_manifest):
        """Lecture depuis un dictionnaire."""
        manifest = ManifestReader.read(minimal_manifest)
        
        assert manifest.name == "test-project"
        assert manifest.version == "1.0.0"
        assert manifest.project_type == ProjectType.LIBRARY
    
    def test_read_from_json_string(self, minimal_manifest):
        """Lecture depuis une chaîne JSON."""
        json_str = json.dumps(minimal_manifest)
        manifest = ManifestReader.read(json_str)
        
        assert manifest.name == "test-project"
    
    def test_read_from_json_file(self, minimal_manifest, temp_output_dir):
        """Lecture depuis un fichier JSON."""
        filepath = temp_output_dir / "manifest.json"
        filepath.write_text(json.dumps(minimal_manifest))
        
        manifest = ManifestReader.read(filepath)
        
        assert manifest.name == "test-project"
    
    def test_read_full_manifest(self, full_manifest):
        """Lecture d'un manifest complet."""
        manifest = ManifestReader.read(full_manifest)
        
        assert manifest.name == "full-test-project"
        assert manifest.version == "2.0.0"
        assert len(manifest.dependencies) == 2
        assert len(manifest.dev_dependencies) == 1
        assert manifest.author == "Test Author"
    
    def test_compute_hash(self, minimal_manifest):
        """Calcul du hash du manifest."""
        manifest = ManifestReader.read(minimal_manifest)
        hash1 = ManifestReader.compute_hash(manifest)
        
        assert hash1.startswith("sha256:")
        assert len(hash1) == 23  # "sha256:" + 16 chars
        
        # Même manifest = même hash
        hash2 = ManifestReader.compute_hash(manifest)
        assert hash1 == hash2


# ═══════════════════════════════════════════════════════════════════════════════
# TESTS: ProjectWriter
# ═══════════════════════════════════════════════════════════════════════════════

class TestProjectWriter:
    """Tests pour l'écriture de fichiers."""
    
    def test_write_file(self, temp_output_dir):
        """Écriture d'un fichier simple."""
        log = BootstrapLog()
        writer = ProjectWriter(temp_output_dir, log)
        
        result = writer.write_file(
            Path("test.py"),
            "print('hello')",
            source_ref="test"
        )
        
        assert result.path == Path("test.py")
        assert result.checksum.startswith("sha256:")
        assert (temp_output_dir / "test.py").exists()
        assert (temp_output_dir / "test.py").read_text() == "print('hello')"
    
    def test_ensure_dir(self, temp_output_dir):
        """Création de répertoires."""
        log = BootstrapLog()
        writer = ProjectWriter(temp_output_dir, log)
        
        path = writer.ensure_dir(Path("src/models"))
        
        assert path.exists()
        assert path.is_dir()
    
    def test_dry_run(self, temp_output_dir):
        """Mode dry-run (pas d'écriture réelle)."""
        log = BootstrapLog()
        writer = ProjectWriter(temp_output_dir, log, dry_run=True)
        
        writer.write_file(Path("test.py"), "content")
        
        assert not (temp_output_dir / "test.py").exists()
    
    def test_rollback(self, temp_output_dir):
        """Rollback des fichiers créés."""
        log = BootstrapLog()
        writer = ProjectWriter(temp_output_dir, log)
        
        writer.write_file(Path("file1.py"), "content1")
        writer.write_file(Path("file2.py"), "content2")
        writer.ensure_dir(Path("subdir"))
        
        assert (temp_output_dir / "file1.py").exists()
        assert (temp_output_dir / "file2.py").exists()
        
        count = writer.rollback()
        
        assert count >= 2
        assert not (temp_output_dir / "file1.py").exists()
        assert not (temp_output_dir / "file2.py").exists()


# ═══════════════════════════════════════════════════════════════════════════════
# TESTS: ConfigGenerator
# ═══════════════════════════════════════════════════════════════════════════════

class TestConfigGenerator:
    """Tests pour la génération de fichiers de configuration."""
    
    def test_generate_pyproject_toml(self, full_manifest):
        """Génération de pyproject.toml."""
        manifest = ManifestReader.read(full_manifest)
        content = ConfigGenerator.generate_pyproject_toml(manifest)
        
        assert 'name = "full-test-project"' in content
        assert 'version = "2.0.0"' in content
        assert '"pydantic' in content
        assert '"fastapi' in content
        assert '[tool.pytest.ini_options]' in content
    
    def test_generate_conftest(self, minimal_manifest):
        """Génération de conftest.py."""
        manifest = ManifestReader.read(minimal_manifest)
        content = ConfigGenerator.generate_conftest(manifest)
        
        assert "import pytest" in content
        assert "@pytest.fixture" in content
        assert "test_project_config" in content


# ═══════════════════════════════════════════════════════════════════════════════
# TESTS: BootstrapLog
# ═══════════════════════════════════════════════════════════════════════════════

class TestBootstrapLog:
    """Tests pour le système de logging."""
    
    def test_add_entries(self):
        """Ajout d'entrées de log."""
        log = BootstrapLog()
        
        log.info(BootstrapPhase.INIT, "Starting")
        log.warning(BootstrapPhase.VALIDATE, "Warning message")
        log.error(BootstrapPhase.GENERATE, "Error message")
        
        assert len(log.entries) == 3
        assert log.entries[0].level == "INFO"
        assert log.entries[1].level == "WARNING"
        assert log.entries[2].level == "ERROR"
    
    def test_get_errors(self):
        """Récupération des erreurs."""
        log = BootstrapLog()
        
        log.info(BootstrapPhase.INIT, "Info")
        log.error(BootstrapPhase.GENERATE, "Error 1")
        log.error(BootstrapPhase.WRITE, "Error 2")
        
        errors = log.get_errors()
        
        assert len(errors) == 2
        assert all(e.level == "ERROR" for e in errors)
    
    def test_checkpoint(self):
        """Création de checkpoints."""
        log = BootstrapLog()
        
        cp = log.checkpoint(
            "test_cp",
            BootstrapPhase.WRITE,
            {"key": "value"},
            files_created=["file1.py"]
        )
        
        assert cp.id == "test_cp"
        assert cp.phase == BootstrapPhase.WRITE
        assert cp.state == {"key": "value"}
        assert len(log.checkpoints) == 1
    
    def test_to_dict(self):
        """Sérialisation en dictionnaire."""
        log = BootstrapLog()
        log.info(BootstrapPhase.INIT, "Test")
        log.checkpoint("cp1", BootstrapPhase.INIT, {})
        
        data = log.to_dict()
        
        assert "entries" in data
        assert "checkpoints" in data
        assert len(data["entries"]) == 1
        assert len(data["checkpoints"]) == 1


# ═══════════════════════════════════════════════════════════════════════════════
# TESTS: ProjectBootstrapper (Pipeline complet)
# ═══════════════════════════════════════════════════════════════════════════════

class TestProjectBootstrapper:
    """Tests pour le pipeline de bootstrapping complet."""
    
    def test_bootstrap_minimal(self, minimal_manifest, temp_output_dir):
        """Bootstrapping d'un projet minimal."""
        result = bootstrap_project(
            manifest=minimal_manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        assert result.status in (BootstrapStatus.SUCCESS, BootstrapStatus.PARTIAL)
        assert result.project_path == temp_output_dir
        assert result.file_count > 0
        assert result.manifest_hash.startswith("sha256:")
        
        # Vérifier les fichiers essentiels
        assert (temp_output_dir / "pyproject.toml").exists()
        assert (temp_output_dir / "README.md").exists()
        assert (temp_output_dir / "src/test_project/__init__.py").exists()
    
    def test_bootstrap_full(self, full_manifest, temp_output_dir):
        """Bootstrapping d'un projet complet."""
        result = bootstrap_project(
            manifest=full_manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        assert result.success
        
        # Vérifier les models
        models_dir = temp_output_dir / "src/full_test_project/models"
        assert models_dir.exists()
        assert (models_dir / "user.py").exists()
        assert (models_dir / "task.py").exists()
        
        # Vérifier les scénarios
        scenarios_dir = temp_output_dir / "src/full_test_project/scenarios"
        assert scenarios_dir.exists()
        assert (scenarios_dir / "create_user.py").exists()
        
        # Vérifier les tests
        tests_dir = temp_output_dir / "tests"
        assert tests_dir.exists()
        assert (tests_dir / "test_user.py").exists()
    
    def test_bootstrap_dry_run(self, minimal_manifest, temp_output_dir):
        """Bootstrapping en mode dry-run."""
        result = bootstrap_project(
            manifest=minimal_manifest,
            output_dir=temp_output_dir,
            dry_run=True
        )
        
        assert result.success
        assert result.file_count > 0
        
        # Aucun fichier ne doit exister
        assert not (temp_output_dir / "pyproject.toml").exists()
    
    def test_bootstrap_invalid_manifest(self, temp_output_dir):
        """Échec avec manifest invalide."""
        invalid_manifest = {
            # name manquant
            "version": "1.0.0"
        }
        
        result = bootstrap_project(
            manifest=invalid_manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        assert result.status == BootstrapStatus.FAILED
        assert len(result.errors) > 0
    
    def test_generated_model_content(self, minimal_manifest, temp_output_dir):
        """Vérification du contenu des modèles générés."""
        bootstrap_project(
            manifest=minimal_manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        model_path = temp_output_dir / "src/test_project/models/test_item.py"
        content = model_path.read_text()
        
        assert "class TestItem:" in content
        assert "id: str" in content
        assert "name: str" in content
        assert "EUREKAI:GENERATED:BEGIN" in content
        assert "EUREKAI:CUSTOM:BEGIN" in content
    
    def test_generated_scenario_content(self, full_manifest, temp_output_dir):
        """Vérification du contenu des scénarios générés."""
        bootstrap_project(
            manifest=full_manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        scenario_path = temp_output_dir / "src/full_test_project/scenarios/create_user.py"
        content = scenario_path.read_text()
        
        assert "class CreateUserScenario:" in content
        assert "def execute" in content
        assert "validate_input" in content
        assert "create_user" in content
    
    def test_bootstrap_result_to_dict(self, minimal_manifest, temp_output_dir):
        """Sérialisation du résultat."""
        result = bootstrap_project(
            manifest=minimal_manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        data = result.to_dict()
        
        assert "status" in data
        assert "project_path" in data
        assert "stats" in data
        assert "files" in data
        assert "logs" in data
        
        # Vérifier qu'on peut sérialiser en JSON
        json_str = json.dumps(data, default=str)
        assert len(json_str) > 0


# ═══════════════════════════════════════════════════════════════════════════════
# TESTS: Cas limites
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeCases:
    """Tests des cas limites."""
    
    def test_empty_fractal(self, temp_output_dir):
        """Manifest sans fractal."""
        manifest = {
            "name": "empty-fractal",
            "version": "1.0.0",
            "fractal": {}
        }
        
        result = bootstrap_project(
            manifest=manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        # Doit réussir mais avec un warning
        assert result.success
    
    def test_special_characters_in_name(self, temp_output_dir):
        """Nom de projet avec caractères spéciaux."""
        manifest = {
            "name": "my-special_project",
            "version": "1.0.0",
            "fractal": {
                "objects": {
                    "Item": {
                        "identity": {"id": "string"}
                    }
                }
            }
        }
        
        result = bootstrap_project(
            manifest=manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        assert result.success
        # Le package doit être en snake_case (tirets → underscores)
        assert (temp_output_dir / "src/my_special_project/__init__.py").exists()
    
    def test_complex_type_mapping(self, temp_output_dir):
        """Types complexes dans les identités."""
        manifest = {
            "name": "complex-types",
            "version": "1.0.0",
            "fractal": {
                "objects": {
                    "ComplexItem": {
                        "identity": {
                            "id": "string",
                            "tags": "list[string]",
                            "status": "enum[a, b, c]",
                            "data": "dict",
                            "score": "float"
                        }
                    }
                }
            }
        }
        
        result = bootstrap_project(
            manifest=manifest,
            output_dir=temp_output_dir,
            create_venv=False,
            run_initial_tests=False
        )
        
        assert result.success
        
        model_path = temp_output_dir / "src/complex_types/models/complex_item.py"
        content = model_path.read_text()
        
        assert "tags: List[str]" in content
        assert "score: float" in content


# ═══════════════════════════════════════════════════════════════════════════════
# EXÉCUTION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
