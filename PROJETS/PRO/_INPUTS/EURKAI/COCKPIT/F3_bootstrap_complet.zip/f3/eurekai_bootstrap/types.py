"""
F3/6 — Types de base pour le bootstrapping de projets EUREKAI.

Ce module définit toutes les structures de données utilisées
par le pipeline de bootstrapping.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Callable


# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════════════════════════

class BootstrapPhase(Enum):
    """Phases du pipeline de bootstrapping."""
    INIT = "init"                   # Initialisation
    READ_MANIFEST = "read_manifest" # Lecture du manifest
    VALIDATE = "validate"           # Validation du manifest
    GENERATE = "generate"           # Génération des modules
    WRITE = "write"                 # Écriture sur disque
    SETUP_ENV = "setup_env"         # Setup environnement (venv, deps)
    RUN_TESTS = "run_tests"         # Exécution des tests
    FINALIZE = "finalize"           # Finalisation


class BootstrapStatus(Enum):
    """Statut du bootstrapping."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    PARTIAL = "partial"     # Succès partiel (warnings)
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class EnvironmentType(Enum):
    """Type d'environnement cible."""
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"


class ProjectType(Enum):
    """Type de projet EUREKAI."""
    LIBRARY = "library"         # Package Python
    APPLICATION = "application" # Application standalone
    SERVICE = "service"         # Microservice
    FULLSTACK = "fullstack"     # Full-stack (backend + frontend)


# ═══════════════════════════════════════════════════════════════════════════════
# OPTIONS DE BOOTSTRAPPING
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class BootstrapOptions:
    """Options de configuration pour le bootstrapping."""
    
    # Chemins
    output_dir: Path = field(default_factory=lambda: Path("./project"))
    manifest_path: Optional[Path] = None
    
    # Environnement
    env_type: EnvironmentType = EnvironmentType.DEVELOPMENT
    project_type: ProjectType = ProjectType.APPLICATION
    python_version: str = "3.11"
    
    # Comportement
    create_venv: bool = True
    install_deps: bool = True
    run_initial_tests: bool = True
    init_git: bool = True
    
    # Génération (délégué à F2)
    generate_tests: bool = True
    generate_docs: bool = True
    
    # Sécurité
    dry_run: bool = False
    allow_overwrite: bool = False
    backup_existing: bool = True
    
    # Hooks
    pre_hooks: List[str] = field(default_factory=list)
    post_hooks: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        if isinstance(self.output_dir, str):
            self.output_dir = Path(self.output_dir)
        if isinstance(self.manifest_path, str):
            self.manifest_path = Path(self.manifest_path)


# ═══════════════════════════════════════════════════════════════════════════════
# LOGGING ET CHECKPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class LogEntry:
    """Entrée de log du bootstrapping."""
    timestamp: str
    phase: BootstrapPhase
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR"]
    message: str
    details: Optional[Dict[str, Any]] = None
    
    @classmethod
    def now(cls, phase: BootstrapPhase, level: str, message: str, **details) -> 'LogEntry':
        return cls(
            timestamp=datetime.now(timezone.utc).isoformat(),
            phase=phase,
            level=level,
            message=message,
            details=details if details else None
        )
    
    def to_dict(self) -> Dict:
        result = {
            "timestamp": self.timestamp,
            "phase": self.phase.value,
            "level": self.level,
            "message": self.message
        }
        if self.details:
            result["details"] = self.details
        return result


@dataclass
class Checkpoint:
    """Point de contrôle pour rollback."""
    id: str
    phase: BootstrapPhase
    timestamp: str
    state: Dict[str, Any]
    files_created: List[str] = field(default_factory=list)
    dirs_created: List[str] = field(default_factory=list)
    reversible: bool = True
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "phase": self.phase.value,
            "timestamp": self.timestamp,
            "state": self.state,
            "files_created": self.files_created,
            "dirs_created": self.dirs_created,
            "reversible": self.reversible
        }


@dataclass
class BootstrapLog:
    """Journal complet du bootstrapping."""
    entries: List[LogEntry] = field(default_factory=list)
    checkpoints: List[Checkpoint] = field(default_factory=list)
    
    def add(self, phase: BootstrapPhase, level: str, message: str, **details):
        self.entries.append(LogEntry.now(phase, level, message, **details))
    
    def info(self, phase: BootstrapPhase, message: str, **details):
        self.add(phase, "INFO", message, **details)
    
    def warning(self, phase: BootstrapPhase, message: str, **details):
        self.add(phase, "WARNING", message, **details)
    
    def error(self, phase: BootstrapPhase, message: str, **details):
        self.add(phase, "ERROR", message, **details)
    
    def checkpoint(self, id: str, phase: BootstrapPhase, state: Dict, **kwargs) -> Checkpoint:
        cp = Checkpoint(
            id=id,
            phase=phase,
            timestamp=datetime.now(timezone.utc).isoformat(),
            state=state,
            **kwargs
        )
        self.checkpoints.append(cp)
        return cp
    
    def get_errors(self) -> List[LogEntry]:
        return [e for e in self.entries if e.level == "ERROR"]
    
    def get_warnings(self) -> List[LogEntry]:
        return [e for e in self.entries if e.level == "WARNING"]
    
    def to_dict(self) -> Dict:
        return {
            "entries": [e.to_dict() for e in self.entries],
            "checkpoints": [c.to_dict() for c in self.checkpoints]
        }


# ═══════════════════════════════════════════════════════════════════════════════
# RÉSULTAT DU BOOTSTRAPPING
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class GeneratedFile:
    """Fichier généré durant le bootstrapping."""
    path: Path
    source_ref: Optional[str]
    checksum: str
    size: int
    is_config: bool = False
    is_test: bool = False


@dataclass
class BootstrapResult:
    """
    Résultat complet du bootstrapping.
    
    C'est le retour de bootstrapProject(manifest, options).
    """
    status: BootstrapStatus
    project_path: Path
    manifest_hash: str
    
    # Fichiers générés
    files: List[GeneratedFile] = field(default_factory=list)
    directories: List[Path] = field(default_factory=list)
    
    # Environnement
    venv_path: Optional[Path] = None
    installed_packages: List[str] = field(default_factory=list)
    
    # Tests
    tests_run: int = 0
    tests_passed: int = 0
    tests_failed: int = 0
    
    # Métriques
    duration_ms: int = 0
    started_at: str = ""
    completed_at: str = ""
    
    # Logs
    logs: BootstrapLog = field(default_factory=BootstrapLog)
    
    def __post_init__(self):
        if isinstance(self.project_path, str):
            self.project_path = Path(self.project_path)
    
    @property
    def success(self) -> bool:
        return self.status in (BootstrapStatus.SUCCESS, BootstrapStatus.PARTIAL)
    
    @property
    def file_count(self) -> int:
        return len(self.files)
    
    @property
    def errors(self) -> List[LogEntry]:
        return self.logs.get_errors()
    
    @property
    def warnings(self) -> List[LogEntry]:
        return self.logs.get_warnings()
    
    def to_dict(self) -> Dict:
        return {
            "status": self.status.value,
            "project_path": str(self.project_path),
            "manifest_hash": self.manifest_hash,
            "stats": {
                "files_generated": self.file_count,
                "directories_created": len(self.directories),
                "tests_run": self.tests_run,
                "tests_passed": self.tests_passed,
                "tests_failed": self.tests_failed,
                "duration_ms": self.duration_ms
            },
            "environment": {
                "venv_path": str(self.venv_path) if self.venv_path else None,
                "installed_packages": self.installed_packages
            },
            "timing": {
                "started_at": self.started_at,
                "completed_at": self.completed_at
            },
            "files": [
                {
                    "path": str(f.path),
                    "source_ref": f.source_ref,
                    "checksum": f.checksum,
                    "size": f.size
                }
                for f in self.files
            ],
            "logs": self.logs.to_dict()
        }


# ═══════════════════════════════════════════════════════════════════════════════
# MANIFEST DE PROJET
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ProjectDependency:
    """Dépendance du projet."""
    name: str
    version: str = "*"
    dev_only: bool = False
    optional: bool = False


@dataclass
class ProjectManifest:
    """
    Manifest de projet EUREKAI.
    
    Étend le manifest fractal (F1) avec des informations projet.
    """
    # Identité
    name: str
    version: str
    description: str = ""
    
    # Configuration projet
    project_type: ProjectType = ProjectType.APPLICATION
    python_version: str = ">=3.10"
    
    # Dépendances
    dependencies: List[ProjectDependency] = field(default_factory=list)
    dev_dependencies: List[ProjectDependency] = field(default_factory=list)
    
    # Manifest fractal embarqué (F1)
    fractal: Dict[str, Any] = field(default_factory=dict)
    
    # Configuration additionnelle
    config: Dict[str, Any] = field(default_factory=dict)
    
    # Métadonnées
    author: str = ""
    license: str = "MIT"
    repository: str = ""
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProjectManifest':
        deps = [
            ProjectDependency(**d) if isinstance(d, dict) else ProjectDependency(name=d)
            for d in data.get("dependencies", [])
        ]
        dev_deps = [
            ProjectDependency(**d) if isinstance(d, dict) else ProjectDependency(name=d)
            for d in data.get("dev_dependencies", [])
        ]
        
        return cls(
            name=data["name"],
            version=data.get("version", "0.1.0"),
            description=data.get("description", ""),
            project_type=ProjectType(data.get("project_type", "application")),
            python_version=data.get("python_version", ">=3.10"),
            dependencies=deps,
            dev_dependencies=dev_deps,
            fractal=data.get("fractal", {}),
            config=data.get("config", {}),
            author=data.get("author", ""),
            license=data.get("license", "MIT"),
            repository=data.get("repository", "")
        )
    
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "project_type": self.project_type.value,
            "python_version": self.python_version,
            "dependencies": [
                {"name": d.name, "version": d.version}
                for d in self.dependencies
            ],
            "dev_dependencies": [
                {"name": d.name, "version": d.version}
                for d in self.dev_dependencies
            ],
            "fractal": self.fractal,
            "config": self.config,
            "author": self.author,
            "license": self.license,
            "repository": self.repository
        }
