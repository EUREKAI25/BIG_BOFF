#!/usr/bin/env python3
"""
Démonstration du bootstrapping EUREKAI.

Ce script montre comment utiliser le bootstrapper pour créer
un projet complet à partir d'un manifest.
"""

import json
import sys
from pathlib import Path

# Ajouter le répertoire parent au path
sys.path.insert(0, str(Path(__file__).parent.parent))

from eurekai_bootstrap import (
    bootstrap_project,
    BootstrapOptions,
    ProjectType,
    EnvironmentType,
)


def demo_minimal_project():
    """
    Démonstration 1: Projet minimal.
    
    Crée un projet avec un seul objet.
    """
    print("\n" + "="*60)
    print("DEMO 1: Projet Minimal")
    print("="*60)
    
    manifest = {
        "name": "minimal-demo",
        "version": "0.1.0",
        "description": "A minimal EUREKAI project",
        "project_type": "library",
        "fractal": {
            "meta": {
                "name": "MinimalFractal",
                "version": "1.0.0"
            },
            "objects": {
                "Item": {
                    "identity": {
                        "id": "string",
                        "name": "string",
                        "value": "int"
                    },
                    "view": {
                        "methods": [
                            "validate() -> bool"
                        ]
                    }
                }
            },
            "scenarios": {}
        }
    }
    
    result = bootstrap_project(
        manifest=manifest,
        output_dir="./demo_output/minimal",
        create_venv=False,  # Skip venv for demo
        run_initial_tests=False,
        dry_run=False
    )
    
    print(f"Status: {result.status.value}")
    print(f"Files created: {result.file_count}")
    print(f"Duration: {result.duration_ms}ms")
    
    if result.success:
        print("\nGenerated files:")
        for f in result.files[:10]:
            print(f"  - {f.path}")
    
    return result


def demo_blog_project():
    """
    Démonstration 2: Projet Blog complet.
    
    Utilise le manifest blog_manifest.yaml.
    """
    print("\n" + "="*60)
    print("DEMO 2: Projet Blog")
    print("="*60)
    
    manifest_path = Path(__file__).parent / "blog_manifest.yaml"
    
    if not manifest_path.exists():
        print(f"Manifest not found: {manifest_path}")
        return None
    
    result = bootstrap_project(
        manifest=str(manifest_path),
        output_dir="./demo_output/blog",
        create_venv=False,
        run_initial_tests=False
    )
    
    print(f"Status: {result.status.value}")
    print(f"Files created: {result.file_count}")
    print(f"Duration: {result.duration_ms}ms")
    
    if result.errors:
        print("\nErrors:")
        for e in result.errors:
            print(f"  - {e.message}")
    
    return result


def demo_labo_project():
    """
    Démonstration 3: Projet Laboratoire.
    
    Utilise le manifest labo_manifest.yaml.
    """
    print("\n" + "="*60)
    print("DEMO 3: Projet Laboratoire")
    print("="*60)
    
    manifest_path = Path(__file__).parent / "labo_manifest.yaml"
    
    if not manifest_path.exists():
        print(f"Manifest not found: {manifest_path}")
        return None
    
    result = bootstrap_project(
        manifest=str(manifest_path),
        output_dir="./demo_output/labo",
        create_venv=False,
        run_initial_tests=False
    )
    
    print(f"Status: {result.status.value}")
    print(f"Files created: {result.file_count}")
    print(f"Duration: {result.duration_ms}ms")
    
    return result


def demo_dry_run():
    """
    Démonstration 4: Prévisualisation (dry-run).
    
    Montre les fichiers qui seraient générés sans écriture.
    """
    print("\n" + "="*60)
    print("DEMO 4: Dry Run (prévisualisation)")
    print("="*60)
    
    manifest = {
        "name": "preview-demo",
        "version": "1.0.0",
        "fractal": {
            "objects": {
                "Task": {
                    "identity": {
                        "id": "string",
                        "title": "string",
                        "done": "bool"
                    }
                }
            }
        }
    }
    
    result = bootstrap_project(
        manifest=manifest,
        output_dir="./demo_output/preview",
        dry_run=True
    )
    
    print(f"Status: {result.status.value}")
    print(f"Files that would be created: {result.file_count}")
    
    print("\nPreviewed structure:")
    for f in result.files:
        print(f"  - {f.path}")
    
    return result


def show_result_json(result):
    """Affiche le résultat complet en JSON."""
    print("\n" + "-"*60)
    print("RÉSULTAT COMPLET (JSON):")
    print("-"*60)
    print(json.dumps(result.to_dict(), indent=2, default=str))


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="EUREKAI Bootstrap Demo")
    parser.add_argument(
        "demo",
        nargs="?",
        choices=["minimal", "blog", "labo", "dry-run", "all"],
        default="minimal",
        help="Which demo to run"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Show full JSON result"
    )
    
    args = parser.parse_args()
    
    demos = {
        "minimal": demo_minimal_project,
        "blog": demo_blog_project,
        "labo": demo_labo_project,
        "dry-run": demo_dry_run,
    }
    
    if args.demo == "all":
        for name, func in demos.items():
            result = func()
            if args.json and result:
                show_result_json(result)
    else:
        result = demos[args.demo]()
        if args.json and result:
            show_result_json(result)
    
    print("\n" + "="*60)
    print("DEMO COMPLETE")
    print("="*60)
