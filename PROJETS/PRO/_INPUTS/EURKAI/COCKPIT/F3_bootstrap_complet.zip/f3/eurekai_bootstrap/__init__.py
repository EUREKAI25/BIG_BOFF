"""
EUREKAI F3/6 — Project Bootstrapper.

Pipeline de bootstrapping complet pour projets EUREKAI.

Usage:
    from eurekai_bootstrap import bootstrap_project
    
    result = bootstrap_project(
        manifest="project.yaml",
        output_dir="./my_project"
    )
"""

from .bootstrap import (
    ProjectBootstrapper,
    bootstrap_project,
    preview_bootstrap,
    ManifestReader,
    ProjectWriter,
    EnvironmentSetup,
    TestRunner,
    ConfigGenerator,
)

from .types import (
    BootstrapOptions,
    BootstrapResult,
    BootstrapStatus,
    BootstrapPhase,
    BootstrapLog,
    ProjectManifest,
    ProjectDependency,
    ProjectType,
    EnvironmentType,
    GeneratedFile,
)

__version__ = "1.0.0"
__all__ = [
    # Main API
    "bootstrap_project",
    "preview_bootstrap",
    "ProjectBootstrapper",
    
    # Components
    "ManifestReader",
    "ProjectWriter",
    "EnvironmentSetup",
    "TestRunner",
    "ConfigGenerator",
    
    # Types
    "BootstrapOptions",
    "BootstrapResult",
    "BootstrapStatus",
    "BootstrapPhase",
    "BootstrapLog",
    "ProjectManifest",
    "ProjectDependency",
    "ProjectType",
    "EnvironmentType",
    "GeneratedFile",
]
