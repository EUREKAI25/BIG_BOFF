# LIVRAISON C3/3 — MetaRelations & Optimisation Structurelle

## 📋 Résumé de Livraison

| Élément | Statut |
|---------|--------|
| **Module** | C3/3 - MetaRelations |
| **Version** | 1.0.0 |
| **Date** | 2025-12-01 |
| **Tests** | 12/12 ✅ |
| **Dépendances** | C2/2 MetaRules (structure compatible) |

## 🎯 Objectifs Accomplis

### Checklist du Prompt

- [x] **Cycles détectés et listés clairement**
  - Algorithme de Tarjan pour composantes fortement connexes
  - Détection des auto-références (self-loops)
  - Classification par sévérité (error, warning)

- [x] **Relations redondantes identifiées**
  - Redondances directes (A→C quand A→B→C existe)
  - Redondances transitives profondes
  - Explication du chemin alternatif

- [x] **Suggestions de simplification proposées**
  - Casser les cycles (avec identification du maillon faible)
  - Supprimer les redondances
  - Introduire des parents communs pour factorisation

- [x] **Exemples et cas de test fournis**
  - 12 tests unitaires couvrant tous les cas
  - 3 démonstrations interactives
  - Graphes de test variés (propres, cycliques, redondants)

## 📦 Fichiers Livrés

```
C3_metarelations/
├── metarelations_engine.py    # Moteur principal (650+ lignes)
├── test_metarelations.py      # Tests et exemples (710+ lignes)
├── MetaRelationsPanel.jsx     # Composant React cockpit (550+ lignes)
└── LIVRAISON.md               # Documentation
```

## 🔧 Architecture

### Classes Principales

```
RelationGraph          # Graphe orienté des relations
├── add_relation()     # Ajout de relation
├── has_path()         # Test d'accessibilité
├── find_path()        # Plus court chemin (BFS)
├── find_all_paths()   # Tous les chemins
└── from_fractal_store() # Import depuis store EUREKAI

CycleDetector          # Algorithme de Tarjan
├── detect_cycles()    # Détection SCC
└── _strongconnect()   # Fonction récursive Tarjan

RedundancyAnalyzer     # Analyse de redondance
├── find_redundancies()           # Redondances directes
└── find_transitive_redundancies() # Redondances transitives

RelationOptimizer      # Générateur de suggestions
├── generate_suggestions()     # Toutes suggestions
├── _suggest_cycle_breaks()    # Casser les cycles
├── _suggest_redundancy_removal() # Supprimer redondances
└── _suggest_common_parent()   # Factorisation

MetaRelationsEngine    # Orchestrateur
├── analyze()          # Analyse RelationGraph
└── analyze_store()    # Analyse store fractal
```

### Types de Données

```python
@dataclass
class Relation:
    source: str
    target: str
    relation_type: RelationType
    metadata: Optional[FrozenSet]

@dataclass
class Cycle:
    path: List[str]
    relation_types: List[RelationType]
    severity: str  # error, warning

@dataclass
class Redundancy:
    direct_relation: Relation
    alternative_path: List[str]
    reason: str

@dataclass
class Suggestion:
    suggestion_type: SuggestionType
    description: str
    affected_relations: List[Relation]
    proposed_action: Dict
    impact: str  # high, medium, low
```

## 🔌 API

### API Centrale

```python
def analyze_relations(
    graph_or_store: Union[RelationGraph, Dict[str, Any]],
    **options
) -> Dict:
    """
    Retourne:
    {
        "cycles": [...],
        "redundancies": [...],
        "suggestions": [...],
        "stats": {...},
        "summary": {
            "cyclesCount": int,
            "redundanciesCount": int,
            "suggestionsCount": int,
            "hasIssues": bool
        }
    }
    """
```

### API Rapide

```python
# Analyse directe depuis liste de relations
result = quick_analyze([
    {"source": "A", "target": "B", "type": "depends_on"},
    {"source": "B", "target": "C", "type": "depends_on"},
    {"source": "C", "target": "A", "type": "depends_on"}  # Cycle!
])
```

### Audit Console

```python
from metarelations_engine import audit_relations
audit_relations(fractal_store)  # Affichage formaté
```

## 📊 Algorithmes

### 1. Détection de Cycles (Tarjan)

**Complexité:** O(V + E)

L'algorithme de Tarjan trouve les composantes fortement connexes (SCC).
Toute SCC de taille > 1 représente un cycle.

```python
def _strongconnect(self, node: str):
    self._indices[node] = self._index
    self._lowlinks[node] = self._index
    self._index += 1
    self._stack.append(node)
    self._on_stack.add(node)
    
    for successor in self.graph.get_successors(node):
        if successor not in self._indices:
            self._strongconnect(successor)
            self._lowlinks[node] = min(
                self._lowlinks[node], 
                self._lowlinks[successor]
            )
        elif successor in self._on_stack:
            self._lowlinks[node] = min(
                self._lowlinks[node], 
                self._indices[successor]
            )
    
    # Si node est racine de SCC
    if self._lowlinks[node] == self._indices[node]:
        scc = []
        while True:
            w = self._stack.pop()
            self._on_stack.remove(w)
            scc.append(w)
            if w == node:
                break
        self._sccs.append(scc)
```

### 2. Détection de Redondances

**Principe:** Pour chaque relation directe A→B, chercher un chemin alternatif A→...→B de longueur > 1.

```python
def _find_alternative_path(self, relation: Relation) -> Optional[List[str]]:
    # BFS en excluant le lien direct
    visited = {source}
    queue = [(source, [source])]
    
    while queue:
        current, path = queue.pop(0)
        
        for successor, rel in self.graph.get_outgoing(current):
            # Ignorer la relation directe
            if current == source and successor == target and rel == relation:
                continue
            
            if successor == target and len(path) > 1:
                return path + [successor]  # Chemin alternatif trouvé!
```

### 3. Suggestions d'Optimisation

**Priorité des relations (pour casser un cycle):**
1. RELATED_TO (plus faible)
2. REFERENCES
3. TRIGGERS
4. EXTENDS
5. COMPOSED_OF
6. DEPENDS_ON
7. INHERITS_FROM (plus forte)

On suggère de supprimer le maillon le plus faible du cycle.

## 🧪 Tests

### Cas de Test Couverts

| Test | Description | Résultat |
|------|-------------|----------|
| 1 | Graphe propre (aucune anomalie) | ✅ |
| 2 | Cycle simple A→B→C→A | ✅ |
| 3 | Cycles complexes imbriqués | ✅ |
| 4 | Auto-référence (self-loop) | ✅ |
| 5 | Redondance directe | ✅ |
| 6 | Redondance transitive profonde | ✅ |
| 7 | Génération de suggestions | ✅ |
| 8 | Suggestion parent commun | ✅ |
| 9 | Intégration store fractal | ✅ |
| 10 | Store fractal avec cycle | ✅ |
| 11 | API rapide quick_analyze | ✅ |
| 12 | Sérialisation JSON | ✅ |

### Exécution des Tests

```bash
cd C3_metarelations
python test_metarelations.py
```

## 🖥️ Composant React

### MetaRelationsPanel

Composant principal pour le cockpit EUREKAI avec:
- Vue d'ensemble avec statistiques
- Visualisation SVG des cycles
- Liste interactive des cycles/redondances
- Suggestions avec détails d'action
- Export JSON

### Props

```jsx
<MetaRelationsPanel
  analysisResult={result}    // Résultat de analyze_relations()
  onRefresh={() => {...}}    // Callback rafraîchissement
  onExport={(format, data) => {...}} // Callback export
  loading={false}            // État de chargement
/>
```

### Composants Exportés

- `MetaRelationsPanel` - Panneau principal
- `CycleItem` - Affichage d'un cycle
- `RedundancyItem` - Affichage d'une redondance
- `SuggestionItem` - Affichage d'une suggestion
- `StatsPanel` - Panneau de statistiques
- `MiniGraph` - Visualisation SVG des cycles

## 📐 Exemples d'Utilisation

### Exemple 1: Analyse Rapide

```python
from metarelations_engine import quick_analyze

result = quick_analyze([
    {"source": "A", "target": "B", "type": "depends_on"},
    {"source": "B", "target": "C", "type": "depends_on"},
    {"source": "C", "target": "A", "type": "depends_on"}
])

print(f"Cycles: {result['summary']['cyclesCount']}")
# Output: Cycles: 1
```

### Exemple 2: Analyse de Store Fractal

```python
from metarelations_engine import analyze_relations

# Store EUREKAI avec objets ayant metadata.relations
store = {
    "core": FractalObject(
        id="core",
        metadata={"relations": {"depends_on": ["config"]}}
    ),
    "config": FractalObject(
        id="config",
        metadata={"relations": {"depends_on": ["env"]}}
    ),
    # ...
}

result = analyze_relations(store)
print(result['summary'])
```

### Exemple 3: Moteur Configurable

```python
from metarelations_engine import MetaRelationsEngine, RelationGraph

graph = RelationGraph()
# ... ajouter des relations ...

# Analyse partielle (cycles seulement)
engine = MetaRelationsEngine(
    detect_cycles=True,
    detect_redundancies=False,
    generate_suggestions=False
)
result = engine.analyze(graph)
```

## 🔄 Intégration C2/C3

Le module C3 s'intègre avec C2 via:

1. **Même structure de store**: Les deux modules utilisent le même format `Dict[str, FractalObject]`

2. **MetaRules de relation**: C2 peut vérifier l'existence des relations, C3 analyse leur structure

3. **Pipeline d'audit combiné**:
```python
from metarules_engine import check_metarules
from metarelations_engine import analyze_relations

# Audit structurel C2
metarules_result = check_metarules(store)

# Analyse relations C3
relations_result = analyze_relations(store)

# Rapport combiné
print(f"MetaRules: {'OK' if metarules_result['ok'] else 'FAILED'}")
print(f"Relations: {relations_result['summary']}")
```

## 🚀 Prochaines Étapes (G1/9)

Ce module prépare les optimisations PGCD/PPCM logiques de G1/9:

- **PGCD**: Factorisation des dépendances communes → suggestion `INTRODUCE_PARENT`
- **PPCM**: Couverture minimale des relations → détection de redondances

Les suggestions générées par C3 peuvent alimenter un module G1/9 de refactoring automatique.

## ⚠️ Contraintes Respectées

1. **Aucune modification automatique**: Le module analyse et suggère, mais ne modifie jamais la fractale
2. **Algorithmes compréhensibles**: Tarjan documenté, BFS pour chemins
3. **Efficacité raisonnable**: O(V+E) pour la détection de cycles
4. **Robustesse**: Gestion des graphes vides, auto-références, cas limites

## 📝 Notes Techniques

- Les `Relation` sont immutables (dataclass frozen) pour hashabilité
- Le graphe utilise des `defaultdict` pour éviter les KeyError
- La sérialisation JSON est complète et réversible
- Les tests sont autonomes (mock FractalObject inclus)
