/**
 * EUREKAI C3/3 — MetaRelations Analysis Panel
 * ============================================
 * Composant React pour visualiser l'analyse des relations
 * dans le cockpit EUREKAI.
 * 
 * Features:
 * - Affichage des cycles détectés avec graphe interactif
 * - Liste des relations redondantes
 * - Suggestions d'optimisation avec actions
 * - Export JSON/ERK des résultats
 */

import React, { useState, useMemo, useCallback } from 'react';

// =============================================================================
// TYPES
// =============================================================================

/**
 * @typedef {Object} Relation
 * @property {string} source
 * @property {string} target
 * @property {string} type
 * @property {Object} metadata
 */

/**
 * @typedef {Object} Cycle
 * @property {string[]} path
 * @property {string[]} relationTypes
 * @property {string} severity
 * @property {string} display
 */

/**
 * @typedef {Object} Redundancy
 * @property {Relation} directRelation
 * @property {string[]} alternativePath
 * @property {string} pathDisplay
 * @property {string} reason
 */

/**
 * @typedef {Object} Suggestion
 * @property {string} type
 * @property {string} description
 * @property {Relation[]} affectedRelations
 * @property {Object} proposedAction
 * @property {string} impact
 */

/**
 * @typedef {Object} AnalysisResult
 * @property {Cycle[]} cycles
 * @property {Redundancy[]} redundancies
 * @property {Suggestion[]} suggestions
 * @property {Object} stats
 * @property {Object} summary
 */

// =============================================================================
// COMPOSANTS UTILITAIRES
// =============================================================================

const Badge = ({ variant = 'default', children }) => {
  const variants = {
    default: 'bg-gray-100 text-gray-800',
    error: 'bg-red-100 text-red-800',
    warning: 'bg-yellow-100 text-yellow-800',
    info: 'bg-blue-100 text-blue-800',
    success: 'bg-green-100 text-green-800',
    high: 'bg-red-100 text-red-800 border border-red-300',
    medium: 'bg-orange-100 text-orange-800 border border-orange-300',
    low: 'bg-green-100 text-green-800 border border-green-300',
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${variants[variant] || variants.default}`}>
      {children}
    </span>
  );
};

const Card = ({ title, icon, children, className = '' }) => (
  <div className={`bg-white rounded-lg shadow-sm border border-gray-200 ${className}`}>
    {title && (
      <div className="px-4 py-3 border-b border-gray-200 flex items-center gap-2">
        {icon && <span className="text-lg">{icon}</span>}
        <h3 className="font-semibold text-gray-900">{title}</h3>
      </div>
    )}
    <div className="p-4">{children}</div>
  </div>
);

const EmptyState = ({ icon, message }) => (
  <div className="flex flex-col items-center justify-center py-8 text-gray-500">
    <span className="text-4xl mb-2">{icon}</span>
    <p className="text-sm">{message}</p>
  </div>
);

// =============================================================================
// COMPOSANT CYCLE
// =============================================================================

const CycleItem = ({ cycle, index }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className="text-lg">🔄</span>
          <div className="text-left">
            <div className="font-medium text-gray-900">
              Cycle #{index + 1}
            </div>
            <div className="text-sm text-gray-600 font-mono">
              {cycle.display}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={cycle.severity}>{cycle.severity}</Badge>
          <span className="text-gray-400">{expanded ? '▲' : '▼'}</span>
        </div>
      </button>
      
      {expanded && (
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200">
          <div className="space-y-2">
            <div>
              <span className="text-sm text-gray-600">Nœuds: </span>
              <span className="text-sm font-mono">
                {cycle.path.join(' → ')} → {cycle.path[0]}
              </span>
            </div>
            <div>
              <span className="text-sm text-gray-600">Types de relations: </span>
              <div className="flex flex-wrap gap-1 mt-1">
                {cycle.relationTypes.map((type, i) => (
                  <Badge key={i} variant="info">{type}</Badge>
                ))}
              </div>
            </div>
            <div>
              <span className="text-sm text-gray-600">Longueur: </span>
              <span className="text-sm">{cycle.path.length} nœuds</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// =============================================================================
// COMPOSANT REDONDANCE
// =============================================================================

const RedundancyItem = ({ redundancy, index }) => {
  const [expanded, setExpanded] = useState(false);
  const rel = redundancy.directRelation;

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className="text-lg">🔁</span>
          <div className="text-left">
            <div className="font-medium text-gray-900 font-mono">
              {rel.source} → {rel.target}
            </div>
            <div className="text-sm text-gray-600">
              Redondant via {redundancy.pathDisplay}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="warning">{rel.type}</Badge>
          <span className="text-gray-400">{expanded ? '▲' : '▼'}</span>
        </div>
      </button>
      
      {expanded && (
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200">
          <div className="space-y-2">
            <div>
              <span className="text-sm text-gray-600">Relation directe: </span>
              <code className="text-sm bg-white px-2 py-0.5 rounded border">
                {rel.source} --[{rel.type}]--&gt; {rel.target}
              </code>
            </div>
            <div>
              <span className="text-sm text-gray-600">Chemin alternatif: </span>
              <code className="text-sm bg-white px-2 py-0.5 rounded border">
                {redundancy.pathDisplay}
              </code>
            </div>
            <div className="text-sm text-gray-700 italic">
              💡 {redundancy.reason}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// =============================================================================
// COMPOSANT SUGGESTION
// =============================================================================

const SuggestionItem = ({ suggestion, index, onApply }) => {
  const [expanded, setExpanded] = useState(false);

  const impactColors = {
    high: 'border-l-red-500',
    medium: 'border-l-orange-500',
    low: 'border-l-green-500',
  };

  const typeIcons = {
    break_cycle: '🔨',
    remove_redundant: '🗑️',
    introduce_parent: '📦',
    merge_relations: '🔗',
    simplify_path: '✂️',
  };

  return (
    <div className={`border border-gray-200 rounded-lg overflow-hidden border-l-4 ${impactColors[suggestion.impact] || ''}`}>
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className="text-lg">{typeIcons[suggestion.type] || '💡'}</span>
          <div className="text-left">
            <div className="font-medium text-gray-900">
              {suggestion.description}
            </div>
            <div className="text-sm text-gray-600">
              Type: {suggestion.type.replace(/_/g, ' ')}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={suggestion.impact}>Impact: {suggestion.impact}</Badge>
          <span className="text-gray-400">{expanded ? '▲' : '▼'}</span>
        </div>
      </button>
      
      {expanded && (
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200">
          <div className="space-y-3">
            <div>
              <span className="text-sm font-medium text-gray-700">Action proposée:</span>
              <pre className="mt-1 p-2 bg-white rounded border text-xs overflow-auto">
                {JSON.stringify(suggestion.proposedAction, null, 2)}
              </pre>
            </div>
            
            {suggestion.affectedRelations.length > 0 && (
              <div>
                <span className="text-sm font-medium text-gray-700">
                  Relations affectées ({suggestion.affectedRelations.length}):
                </span>
                <ul className="mt-1 space-y-1">
                  {suggestion.affectedRelations.slice(0, 5).map((rel, i) => (
                    <li key={i} className="text-sm font-mono text-gray-600">
                      • {rel.source} → {rel.target}
                    </li>
                  ))}
                  {suggestion.affectedRelations.length > 5 && (
                    <li className="text-sm text-gray-500 italic">
                      ... et {suggestion.affectedRelations.length - 5} autres
                    </li>
                  )}
                </ul>
              </div>
            )}

            {onApply && (
              <div className="pt-2 border-t border-gray-200">
                <button
                  onClick={() => onApply(suggestion)}
                  className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors"
                >
                  Voir les détails
                </button>
                <span className="ml-2 text-xs text-gray-500">
                  (Modifications manuelles requises)
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// =============================================================================
// COMPOSANT MINI GRAPHE SVG
// =============================================================================

const MiniGraph = ({ cycles, maxNodes = 10 }) => {
  const graphData = useMemo(() => {
    if (!cycles || cycles.length === 0) return null;

    // Collecter les nœuds uniques des cycles
    const nodes = new Set();
    const edges = [];

    cycles.forEach(cycle => {
      cycle.path.forEach((node, i) => {
        nodes.add(node);
        const nextNode = cycle.path[(i + 1) % cycle.path.length];
        edges.push({ from: node, to: nextNode, type: cycle.relationTypes[i] });
      });
    });

    // Limiter le nombre de nœuds
    const nodeList = Array.from(nodes).slice(0, maxNodes);
    const filteredEdges = edges.filter(
      e => nodeList.includes(e.from) && nodeList.includes(e.to)
    );

    // Calculer les positions en cercle
    const positions = {};
    const centerX = 150;
    const centerY = 100;
    const radius = 70;

    nodeList.forEach((node, i) => {
      const angle = (2 * Math.PI * i) / nodeList.length - Math.PI / 2;
      positions[node] = {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      };
    });

    return { nodes: nodeList, edges: filteredEdges, positions };
  }, [cycles, maxNodes]);

  if (!graphData) {
    return (
      <div className="flex items-center justify-center h-48 text-gray-400">
        Pas de cycles à visualiser
      </div>
    );
  }

  return (
    <svg viewBox="0 0 300 200" className="w-full h-48">
      <defs>
        <marker
          id="arrowhead"
          markerWidth="10"
          markerHeight="7"
          refX="9"
          refY="3.5"
          orient="auto"
        >
          <polygon points="0 0, 10 3.5, 0 7" fill="#ef4444" />
        </marker>
      </defs>

      {/* Edges */}
      {graphData.edges.map((edge, i) => {
        const from = graphData.positions[edge.from];
        const to = graphData.positions[edge.to];
        if (!from || !to) return null;

        // Calculer le point d'arrivée sur le bord du cercle
        const dx = to.x - from.x;
        const dy = to.y - from.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const nodeRadius = 20;
        const endX = to.x - (dx / dist) * nodeRadius;
        const endY = to.y - (dy / dist) * nodeRadius;
        const startX = from.x + (dx / dist) * nodeRadius;
        const startY = from.y + (dy / dist) * nodeRadius;

        return (
          <line
            key={i}
            x1={startX}
            y1={startY}
            x2={endX}
            y2={endY}
            stroke="#ef4444"
            strokeWidth="2"
            markerEnd="url(#arrowhead)"
          />
        );
      })}

      {/* Nodes */}
      {graphData.nodes.map((node, i) => {
        const pos = graphData.positions[node];
        return (
          <g key={node}>
            <circle
              cx={pos.x}
              cy={pos.y}
              r="20"
              fill="#fee2e2"
              stroke="#ef4444"
              strokeWidth="2"
            />
            <text
              x={pos.x}
              y={pos.y}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-xs font-medium"
              fill="#991b1b"
            >
              {node.length > 4 ? node.slice(0, 4) + '…' : node}
            </text>
          </g>
        );
      })}
    </svg>
  );
};

// =============================================================================
// COMPOSANT STATISTIQUES
// =============================================================================

const StatsPanel = ({ stats, summary }) => {
  const items = [
    { label: 'Relations', value: stats?.total_relations || 0, icon: '🔗' },
    { label: 'Objets', value: stats?.unique_objects || 0, icon: '📦' },
    { label: 'Cycles', value: summary?.cyclesCount || 0, icon: '🔄', alert: summary?.cyclesCount > 0 },
    { label: 'Redondances', value: summary?.redundanciesCount || 0, icon: '🔁', alert: summary?.redundanciesCount > 0 },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {items.map((item, i) => (
        <div
          key={i}
          className={`p-3 rounded-lg border ${
            item.alert ? 'bg-red-50 border-red-200' : 'bg-gray-50 border-gray-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <span className="text-xl">{item.icon}</span>
            <div>
              <div className={`text-2xl font-bold ${item.alert ? 'text-red-600' : 'text-gray-900'}`}>
                {item.value}
              </div>
              <div className="text-xs text-gray-600">{item.label}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

// =============================================================================
// COMPOSANT PRINCIPAL
// =============================================================================

/**
 * MetaRelationsPanel
 * 
 * @param {Object} props
 * @param {AnalysisResult} props.analysisResult - Résultat de l'analyse
 * @param {Function} props.onRefresh - Callback pour relancer l'analyse
 * @param {Function} props.onExport - Callback pour exporter les résultats
 */
const MetaRelationsPanel = ({ 
  analysisResult = null,
  onRefresh = null,
  onExport = null,
  loading = false,
}) => {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: '📊' },
    { id: 'cycles', label: 'Cycles', icon: '🔄', count: analysisResult?.cycles?.length },
    { id: 'redundancies', label: 'Redondances', icon: '🔁', count: analysisResult?.redundancies?.length },
    { id: 'suggestions', label: 'Suggestions', icon: '💡', count: analysisResult?.suggestions?.length },
  ];

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport(format, analysisResult);
    } else {
      // Export par défaut en JSON
      const blob = new Blob([JSON.stringify(analysisResult, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `metarelations-analysis-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    }
  }, [analysisResult, onExport]);

  if (loading) {
    return (
      <Card title="Analyse MetaRelations" icon="🔍">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Analyse en cours...</span>
        </div>
      </Card>
    );
  }

  if (!analysisResult) {
    return (
      <Card title="Analyse MetaRelations" icon="🔍">
        <EmptyState
          icon="📭"
          message="Aucune analyse disponible. Lancez une analyse pour voir les résultats."
        />
        {onRefresh && (
          <div className="mt-4 text-center">
            <button
              onClick={onRefresh}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Lancer l'analyse
            </button>
          </div>
        )}
      </Card>
    );
  }

  const hasIssues = analysisResult.summary?.hasIssues;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{hasIssues ? '⚠️' : '✅'}</span>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              Analyse MetaRelations
            </h2>
            <p className="text-sm text-gray-600">
              {analysisResult.timestamp ? 
                `Dernière analyse: ${new Date(analysisResult.timestamp).toLocaleString('fr-FR')}` :
                'Résultats de l\'analyse'
              }
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          {onRefresh && (
            <button
              onClick={onRefresh}
              className="px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              🔄 Actualiser
            </button>
          )}
          <button
            onClick={() => handleExport('json')}
            className="px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            📥 Exporter JSON
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex gap-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
                activeTab === tab.id
                  ? 'bg-white border border-b-white border-gray-200 text-blue-600 -mb-px'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <span className="mr-1">{tab.icon}</span>
              {tab.label}
              {tab.count !== undefined && tab.count > 0 && (
                <span className="ml-1.5 px-1.5 py-0.5 text-xs bg-red-100 text-red-700 rounded-full">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Content */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <StatsPanel stats={analysisResult.stats} summary={analysisResult.summary} />
            
            {analysisResult.cycles?.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">
                  Visualisation des cycles
                </h4>
                <div className="bg-gray-50 rounded-lg p-2">
                  <MiniGraph cycles={analysisResult.cycles} />
                </div>
              </div>
            )}

            {!hasIssues && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                <span className="text-2xl">🎉</span>
                <p className="text-green-800 font-medium mt-2">
                  Aucune anomalie détectée
                </p>
                <p className="text-sm text-green-600">
                  Le graphe de relations est propre et optimisé.
                </p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'cycles' && (
          <div className="space-y-3">
            {analysisResult.cycles?.length > 0 ? (
              analysisResult.cycles.map((cycle, i) => (
                <CycleItem key={i} cycle={cycle} index={i} />
              ))
            ) : (
              <EmptyState icon="✅" message="Aucun cycle détecté dans le graphe" />
            )}
          </div>
        )}

        {activeTab === 'redundancies' && (
          <div className="space-y-3">
            {analysisResult.redundancies?.length > 0 ? (
              analysisResult.redundancies.map((red, i) => (
                <RedundancyItem key={i} redundancy={red} index={i} />
              ))
            ) : (
              <EmptyState icon="✅" message="Aucune relation redondante détectée" />
            )}
          </div>
        )}

        {activeTab === 'suggestions' && (
          <div className="space-y-3">
            {analysisResult.suggestions?.length > 0 ? (
              <>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-800">
                  ⚠️ Ces suggestions sont indicatives. Aucune modification n'est appliquée automatiquement.
                </div>
                {analysisResult.suggestions.map((sug, i) => (
                  <SuggestionItem key={i} suggestion={sug} index={i} />
                ))}
              </>
            ) : (
              <EmptyState icon="✅" message="Aucune optimisation suggérée" />
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default MetaRelationsPanel;
export { 
  CycleItem, 
  RedundancyItem, 
  SuggestionItem, 
  StatsPanel, 
  MiniGraph,
  Badge,
  Card,
  EmptyState 
};
