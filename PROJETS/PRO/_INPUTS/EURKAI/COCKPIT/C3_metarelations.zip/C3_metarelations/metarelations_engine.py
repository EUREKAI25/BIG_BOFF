"""
EUREKAI C3/3 — MetaRelations & Optimisation Structurelle
=========================================================
Analyse du réseau de relations entre objets fractals :
- Détection de cycles indésirables
- Identification de relations redondantes
- Propositions de simplification

Architecture:
- RelationGraph: Graphe orienté des relations
- CycleDetector: Algorithme de Tarjan pour cycles
- RedundancyAnalyzer: Détection de chemins redondants
- RelationOptimizer: Suggestions de simplification
- MetaRelationsEngine: Orchestrateur central

Prépare les optimisations PGCD/PPCM logiques de G1/9.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import (
    List, Dict, Optional, Tuple, Set, 
    Any, FrozenSet, Iterator, Union
)
from enum import Enum
from datetime import datetime
from collections import defaultdict
import json


# =============================================================================
# ÉNUMÉRATIONS ET TYPES
# =============================================================================

class RelationType(Enum):
    """Types de relations entre objets fractals."""
    DEPENDS_ON = "depends_on"       # Dépendance fonctionnelle
    INHERITS_FROM = "inherits_from" # Héritage de structure
    RELATED_TO = "related_to"       # Association générique
    COMPOSED_OF = "composed_of"     # Composition/agrégation
    TRIGGERS = "triggers"           # Déclenchement
    REFERENCES = "references"       # Référence simple
    EXTENDS = "extends"             # Extension de fonctionnalité


class AnomalyType(Enum):
    """Types d'anomalies détectées."""
    CYCLE = "cycle"                 # Cycle dans le graphe
    REDUNDANT_DIRECT = "redundant_direct"   # Relation directe redondante
    REDUNDANT_TRANSITIVE = "redundant_transitive"  # Redondance transitive
    ORPHAN_RELATION = "orphan_relation"     # Relation vers objet inexistant
    SELF_REFERENCE = "self_reference"       # Auto-référence
    UNUSED_RELATION = "unused_relation"     # Relation jamais utilisée


class SuggestionType(Enum):
    """Types de suggestions d'optimisation."""
    REMOVE_REDUNDANT = "remove_redundant"
    INTRODUCE_PARENT = "introduce_parent"
    MERGE_RELATIONS = "merge_relations"
    BREAK_CYCLE = "break_cycle"
    SIMPLIFY_PATH = "simplify_path"


# =============================================================================
# STRUCTURES DE DONNÉES
# =============================================================================

@dataclass(frozen=True)
class Relation:
    """
    Représente une relation entre deux objets.
    
    Attributes:
        source: ID de l'objet source
        target: ID de l'objet cible
        relation_type: Type de relation
        metadata: Données additionnelles
    """
    source: str
    target: str
    relation_type: RelationType = RelationType.RELATED_TO
    metadata: Optional[FrozenSet[Tuple[str, Any]]] = None
    
    def to_dict(self) -> Dict:
        return {
            "source": self.source,
            "target": self.target,
            "type": self.relation_type.value,
            "metadata": dict(self.metadata) if self.metadata else {}
        }
    
    def __str__(self) -> str:
        return f"{self.source} --[{self.relation_type.value}]--> {self.target}"
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Relation':
        """Crée une Relation depuis un dictionnaire."""
        metadata = None
        if data.get("metadata"):
            metadata = frozenset(data["metadata"].items())
        return cls(
            source=data["source"],
            target=data["target"],
            relation_type=RelationType(data.get("type", "related_to")),
            metadata=metadata
        )


@dataclass
class Cycle:
    """
    Représente un cycle détecté dans le graphe.
    
    Attributes:
        path: Liste ordonnée des IDs formant le cycle
        relation_types: Types de relations dans le cycle
        severity: Gravité (certains cycles sont acceptables)
    """
    path: List[str]
    relation_types: List[RelationType]
    severity: str = "error"  # error, warning, info
    
    def to_dict(self) -> Dict:
        return {
            "path": self.path,
            "relationTypes": [rt.value for rt in self.relation_types],
            "severity": self.severity,
            "display": self.display()
        }
    
    def display(self) -> str:
        """Affichage lisible du cycle."""
        if not self.path:
            return "Cycle vide"
        cycle_str = " → ".join(self.path)
        return f"{cycle_str} → {self.path[0]}"
    
    def __len__(self) -> int:
        return len(self.path)
    
    def __hash__(self) -> int:
        # Normaliser le cycle pour comparaison
        if not self.path:
            return hash(())
        min_idx = self.path.index(min(self.path))
        normalized = tuple(self.path[min_idx:] + self.path[:min_idx])
        return hash(normalized)
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, Cycle):
            return False
        return hash(self) == hash(other)


@dataclass
class Redundancy:
    """
    Représente une relation redondante.
    
    Attributes:
        direct_relation: La relation directe redondante
        alternative_path: Le chemin alternatif qui la rend redondante
        reason: Explication de la redondance
    """
    direct_relation: Relation
    alternative_path: List[str]
    reason: str
    
    def to_dict(self) -> Dict:
        return {
            "directRelation": self.direct_relation.to_dict(),
            "alternativePath": self.alternative_path,
            "pathDisplay": " → ".join(self.alternative_path),
            "reason": self.reason
        }


@dataclass
class Suggestion:
    """
    Suggestion d'optimisation.
    
    Attributes:
        suggestion_type: Type de suggestion
        description: Description humaine
        affected_relations: Relations concernées
        proposed_action: Action proposée (JSON-like)
        impact: Estimation de l'impact
    """
    suggestion_type: SuggestionType
    description: str
    affected_relations: List[Relation]
    proposed_action: Dict[str, Any]
    impact: str = "low"  # low, medium, high
    
    def to_dict(self) -> Dict:
        return {
            "type": self.suggestion_type.value,
            "description": self.description,
            "affectedRelations": [r.to_dict() for r in self.affected_relations],
            "proposedAction": self.proposed_action,
            "impact": self.impact
        }


@dataclass
class AnalysisResult:
    """
    Résultat complet de l'analyse des relations.
    
    Format de sortie API centrale.
    """
    cycles: List[Cycle]
    redundancies: List[Redundancy]
    suggestions: List[Suggestion]
    stats: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        return {
            "cycles": [c.to_dict() for c in self.cycles],
            "redundancies": [r.to_dict() for r in self.redundancies],
            "suggestions": [s.to_dict() for s in self.suggestions],
            "stats": self.stats,
            "timestamp": self.timestamp.isoformat(),
            "summary": self.summary()
        }
    
    def summary(self) -> Dict:
        """Résumé de l'analyse."""
        return {
            "cyclesCount": len(self.cycles),
            "redundanciesCount": len(self.redundancies),
            "suggestionsCount": len(self.suggestions),
            "hasIssues": len(self.cycles) > 0 or len(self.redundancies) > 0
        }
    
    def display(self) -> str:
        """Affichage formaté du résultat."""
        lines = [
            "═" * 60,
            "  ANALYSE METARELATIONS",
            "═" * 60,
            f"  Timestamp: {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            f"  Relations analysées: {self.stats.get('total_relations', 0)}",
            f"  Objets uniques: {self.stats.get('unique_objects', 0)}",
            ""
        ]
        
        # Cycles
        lines.append(f"🔄 CYCLES DÉTECTÉS: {len(self.cycles)}")
        if self.cycles:
            for i, cycle in enumerate(self.cycles, 1):
                lines.append(f"   {i}. {cycle.display()}")
        else:
            lines.append("   ✓ Aucun cycle détecté")
        
        lines.append("")
        
        # Redondances
        lines.append(f"🔁 RELATIONS REDONDANTES: {len(self.redundancies)}")
        if self.redundancies:
            for i, red in enumerate(self.redundancies, 1):
                lines.append(f"   {i}. {red.direct_relation}")
                lines.append(f"      Via: {' → '.join(red.alternative_path)}")
        else:
            lines.append("   ✓ Aucune redondance détectée")
        
        lines.append("")
        
        # Suggestions
        lines.append(f"💡 SUGGESTIONS: {len(self.suggestions)}")
        if self.suggestions:
            for i, sug in enumerate(self.suggestions, 1):
                lines.append(f"   {i}. [{sug.suggestion_type.value}] {sug.description}")
                lines.append(f"      Impact: {sug.impact}")
        else:
            lines.append("   ✓ Aucune optimisation suggérée")
        
        lines.append("")
        lines.append("═" * 60)
        
        return "\n".join(lines)


# =============================================================================
# GRAPHE DE RELATIONS
# =============================================================================

class RelationGraph:
    """
    Graphe orienté des relations entre objets.
    
    Structure optimisée pour:
    - Détection de cycles (Tarjan)
    - Parcours de chemins (BFS/DFS)
    - Recherche de redondances
    """
    
    def __init__(self):
        # Adjacences: source → [(target, relation)]
        self._adj: Dict[str, List[Tuple[str, Relation]]] = defaultdict(list)
        # Adjacences inverses pour parcours inverse
        self._adj_inv: Dict[str, List[Tuple[str, Relation]]] = defaultdict(list)
        # Ensemble des relations
        self._relations: Set[Relation] = set()
        # Cache des nœuds
        self._nodes: Set[str] = set()
    
    def add_relation(self, relation: Relation) -> None:
        """Ajoute une relation au graphe."""
        if relation in self._relations:
            return
        
        self._relations.add(relation)
        self._adj[relation.source].append((relation.target, relation))
        self._adj_inv[relation.target].append((relation.source, relation))
        self._nodes.add(relation.source)
        self._nodes.add(relation.target)
    
    def add_relations(self, relations: List[Relation]) -> None:
        """Ajoute plusieurs relations."""
        for rel in relations:
            self.add_relation(rel)
    
    def get_outgoing(self, node: str) -> List[Tuple[str, Relation]]:
        """Retourne les arêtes sortantes d'un nœud."""
        return self._adj.get(node, [])
    
    def get_incoming(self, node: str) -> List[Tuple[str, Relation]]:
        """Retourne les arêtes entrantes d'un nœud."""
        return self._adj_inv.get(node, [])
    
    def get_successors(self, node: str) -> Set[str]:
        """Retourne les successeurs directs d'un nœud."""
        return {target for target, _ in self._adj.get(node, [])}
    
    def get_predecessors(self, node: str) -> Set[str]:
        """Retourne les prédécesseurs directs d'un nœud."""
        return {source for source, _ in self._adj_inv.get(node, [])}
    
    @property
    def nodes(self) -> Set[str]:
        """Ensemble des nœuds du graphe."""
        return self._nodes.copy()
    
    @property
    def relations(self) -> Set[Relation]:
        """Ensemble des relations."""
        return self._relations.copy()
    
    def has_path(self, source: str, target: str, excluded: Optional[Set[str]] = None) -> bool:
        """
        Vérifie s'il existe un chemin de source vers target.
        
        Args:
            source: Nœud de départ
            target: Nœud d'arrivée
            excluded: Nœuds à exclure du parcours
        """
        if source == target:
            return True
        
        excluded = excluded or set()
        visited = set()
        stack = [source]
        
        while stack:
            current = stack.pop()
            if current == target:
                return True
            
            if current in visited or current in excluded:
                continue
            
            visited.add(current)
            stack.extend(self.get_successors(current))
        
        return False
    
    def find_path(self, source: str, target: str) -> Optional[List[str]]:
        """
        Trouve un chemin de source vers target (BFS pour plus court).
        
        Returns:
            Liste des nœuds du chemin, ou None si pas de chemin
        """
        if source == target:
            return [source]
        
        visited = {source}
        queue = [(source, [source])]
        
        while queue:
            current, path = queue.pop(0)
            
            for successor in self.get_successors(current):
                if successor == target:
                    return path + [successor]
                
                if successor not in visited:
                    visited.add(successor)
                    queue.append((successor, path + [successor]))
        
        return None
    
    def find_all_paths(
        self, 
        source: str, 
        target: str, 
        max_depth: int = 10
    ) -> List[List[str]]:
        """
        Trouve tous les chemins de source vers target.
        
        Args:
            source: Nœud de départ
            target: Nœud d'arrivée
            max_depth: Profondeur maximale de recherche
        
        Returns:
            Liste de tous les chemins trouvés
        """
        paths = []
        
        def dfs(current: str, path: List[str], depth: int):
            if depth > max_depth:
                return
            
            if current == target:
                paths.append(path.copy())
                return
            
            for successor in self.get_successors(current):
                if successor not in path:  # Éviter les cycles
                    path.append(successor)
                    dfs(successor, path, depth + 1)
                    path.pop()
        
        dfs(source, [source], 0)
        return paths
    
    def get_relation_between(
        self, 
        source: str, 
        target: str
    ) -> Optional[Relation]:
        """Retourne la relation directe entre source et target."""
        for t, rel in self._adj.get(source, []):
            if t == target:
                return rel
        return None
    
    def to_dict(self) -> Dict:
        """Sérialisation du graphe."""
        return {
            "nodes": list(self._nodes),
            "relations": [r.to_dict() for r in self._relations],
            "stats": {
                "nodeCount": len(self._nodes),
                "relationCount": len(self._relations)
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'RelationGraph':
        """Désérialisation."""
        graph = cls()
        for rel_data in data.get("relations", []):
            graph.add_relation(Relation.from_dict(rel_data))
        return graph
    
    @classmethod
    def from_fractal_store(
        cls, 
        store: Dict[str, Any],
        relation_key: str = "relations"
    ) -> 'RelationGraph':
        """
        Crée un graphe depuis un store fractal.
        
        Args:
            store: Store fractal {id → FractalObject}
            relation_key: Clé dans metadata contenant les relations
        """
        graph = cls()
        
        for obj_id, obj in store.items():
            # Extraire les relations du metadata
            if hasattr(obj, 'metadata') and obj.metadata:
                relations_data = obj.metadata.get(relation_key, {})
                
                for rel_type_str, targets in relations_data.items():
                    try:
                        rel_type = RelationType(rel_type_str)
                    except ValueError:
                        rel_type = RelationType.RELATED_TO
                    
                    # targets peut être une liste ou un dict
                    if isinstance(targets, list):
                        for target in targets:
                            graph.add_relation(Relation(
                                source=obj_id,
                                target=target,
                                relation_type=rel_type
                            ))
                    elif isinstance(targets, dict):
                        for target, meta in targets.items():
                            metadata = frozenset(meta.items()) if meta else None
                            graph.add_relation(Relation(
                                source=obj_id,
                                target=target,
                                relation_type=rel_type,
                                metadata=metadata
                            ))
        
        return graph


# =============================================================================
# DÉTECTEUR DE CYCLES (TARJAN)
# =============================================================================

class CycleDetector:
    """
    Détection de cycles avec l'algorithme de Tarjan.
    
    Détecte les composantes fortement connexes (SCC) qui
    correspondent aux cycles dans un graphe orienté.
    """
    
    def __init__(self, graph: RelationGraph):
        self.graph = graph
        self._index = 0
        self._stack: List[str] = []
        self._on_stack: Set[str] = set()
        self._indices: Dict[str, int] = {}
        self._lowlinks: Dict[str, int] = {}
        self._sccs: List[List[str]] = []
    
    def detect_cycles(self) -> List[Cycle]:
        """
        Détecte tous les cycles dans le graphe.
        
        Returns:
            Liste de cycles détectés
        """
        self._reset()
        
        # Tarjan sur tous les nœuds
        for node in self.graph.nodes:
            if node not in self._indices:
                self._strongconnect(node)
        
        # Convertir les SCC en cycles
        cycles = []
        for scc in self._sccs:
            if len(scc) > 1 or self._has_self_loop(scc[0]):
                cycle = self._scc_to_cycle(scc)
                if cycle:
                    cycles.append(cycle)
        
        return cycles
    
    def _reset(self):
        """Réinitialise l'état du détecteur."""
        self._index = 0
        self._stack = []
        self._on_stack = set()
        self._indices = {}
        self._lowlinks = {}
        self._sccs = []
    
    def _strongconnect(self, node: str):
        """Fonction récursive de Tarjan."""
        self._indices[node] = self._index
        self._lowlinks[node] = self._index
        self._index += 1
        self._stack.append(node)
        self._on_stack.add(node)
        
        for successor in self.graph.get_successors(node):
            if successor not in self._indices:
                self._strongconnect(successor)
                self._lowlinks[node] = min(
                    self._lowlinks[node], 
                    self._lowlinks[successor]
                )
            elif successor in self._on_stack:
                self._lowlinks[node] = min(
                    self._lowlinks[node], 
                    self._indices[successor]
                )
        
        # Si node est une racine de SCC
        if self._lowlinks[node] == self._indices[node]:
            scc = []
            while True:
                w = self._stack.pop()
                self._on_stack.remove(w)
                scc.append(w)
                if w == node:
                    break
            self._sccs.append(scc)
    
    def _has_self_loop(self, node: str) -> bool:
        """Vérifie si un nœud a une auto-référence."""
        return node in self.graph.get_successors(node)
    
    def _scc_to_cycle(self, scc: List[str]) -> Optional[Cycle]:
        """Convertit une SCC en objet Cycle avec le chemin ordonné."""
        if len(scc) == 1 and self._has_self_loop(scc[0]):
            # Auto-référence
            rel = self.graph.get_relation_between(scc[0], scc[0])
            return Cycle(
                path=[scc[0]],
                relation_types=[rel.relation_type] if rel else [RelationType.RELATED_TO],
                severity="warning"  # Auto-ref moins grave
            )
        
        # Reconstruire un chemin valide dans la SCC
        path = self._find_cycle_path(scc)
        if not path:
            return None
        
        # Extraire les types de relations
        relation_types = []
        for i in range(len(path)):
            source = path[i]
            target = path[(i + 1) % len(path)]
            rel = self.graph.get_relation_between(source, target)
            if rel:
                relation_types.append(rel.relation_type)
            else:
                relation_types.append(RelationType.RELATED_TO)
        
        # Déterminer la sévérité
        severity = self._determine_severity(relation_types)
        
        return Cycle(path=path, relation_types=relation_types, severity=severity)
    
    def _find_cycle_path(self, scc: List[str]) -> Optional[List[str]]:
        """Trouve un chemin cyclique dans une SCC."""
        if len(scc) < 2:
            return scc
        
        scc_set = set(scc)
        start = scc[0]
        
        # DFS pour trouver un chemin qui revient au départ
        def dfs(current: str, path: List[str]) -> Optional[List[str]]:
            for successor in self.graph.get_successors(current):
                if successor == start and len(path) > 1:
                    return path
                if successor in scc_set and successor not in path:
                    result = dfs(successor, path + [successor])
                    if result:
                        return result
            return None
        
        return dfs(start, [start])
    
    def _determine_severity(self, relation_types: List[RelationType]) -> str:
        """Détermine la sévérité d'un cycle selon ses types de relations."""
        # Cycles DEPENDS_ON sont critiques
        if RelationType.DEPENDS_ON in relation_types:
            return "error"
        
        # Cycles INHERITS_FROM sont problématiques
        if RelationType.INHERITS_FROM in relation_types:
            return "error"
        
        # Autres cycles sont des warnings
        return "warning"


# =============================================================================
# ANALYSEUR DE REDONDANCES
# =============================================================================

class RedundancyAnalyzer:
    """
    Analyse les relations redondantes dans le graphe.
    
    Une relation est redondante si elle existe directement
    mais aussi via un chemin indirect plus long.
    """
    
    def __init__(self, graph: RelationGraph):
        self.graph = graph
    
    def find_redundancies(self) -> List[Redundancy]:
        """
        Trouve toutes les relations redondantes.
        
        Returns:
            Liste des redondances détectées
        """
        redundancies = []
        
        for relation in self.graph.relations:
            # Chercher un chemin alternatif de source vers target
            # en excluant la relation directe
            alternative = self._find_alternative_path(relation)
            
            if alternative:
                redundancies.append(Redundancy(
                    direct_relation=relation,
                    alternative_path=alternative,
                    reason=self._explain_redundancy(relation, alternative)
                ))
        
        return redundancies
    
    def _find_alternative_path(self, relation: Relation) -> Optional[List[str]]:
        """
        Trouve un chemin alternatif pour une relation.
        
        Returns:
            Le chemin alternatif ou None
        """
        source = relation.source
        target = relation.target
        
        # BFS en excluant le lien direct
        visited = {source}
        queue = [(source, [source])]
        
        while queue:
            current, path = queue.pop(0)
            
            for successor, rel in self.graph.get_outgoing(current):
                # Ignorer la relation directe
                if current == source and successor == target and rel == relation:
                    continue
                
                if successor == target and len(path) > 1:
                    return path + [successor]
                
                if successor not in visited:
                    visited.add(successor)
                    queue.append((successor, path + [successor]))
        
        return None
    
    def _explain_redundancy(
        self, 
        relation: Relation, 
        alternative: List[str]
    ) -> str:
        """Génère une explication de la redondance."""
        if len(alternative) == 3:
            return (
                f"La relation {relation.source} → {relation.target} "
                f"est redondante car elle existe via {alternative[1]}"
            )
        else:
            via = " → ".join(alternative[1:-1])
            return (
                f"La relation directe est redondante avec le chemin "
                f"via {via} (profondeur {len(alternative) - 1})"
            )
    
    def find_transitive_redundancies(
        self, 
        relation_types: Optional[List[RelationType]] = None
    ) -> List[Redundancy]:
        """
        Trouve les redondances transitives pour certains types.
        
        Pour DEPENDS_ON et INHERITS_FROM, la transitivité est attendue:
        Si A depends_on B et B depends_on C, alors A depends_on C est redondant.
        """
        if relation_types is None:
            relation_types = [RelationType.DEPENDS_ON, RelationType.INHERITS_FROM]
        
        redundancies = []
        
        # Filtrer les relations par type
        typed_relations = [
            r for r in self.graph.relations 
            if r.relation_type in relation_types
        ]
        
        # Construire la fermeture transitive
        transitive_closure = self._compute_transitive_closure(typed_relations)
        
        # Identifier les relations directes qui sont déjà dans la fermeture
        for relation in typed_relations:
            indirect_sources = transitive_closure.get(relation.target, set())
            
            if relation.source in indirect_sources:
                # Trouver le chemin intermédiaire
                path = self._find_transitive_path(
                    relation.source, 
                    relation.target, 
                    typed_relations
                )
                if path and len(path) > 2:
                    redundancies.append(Redundancy(
                        direct_relation=relation,
                        alternative_path=path,
                        reason=f"Transitivité {relation.relation_type.value}: "
                               f"implicite via {' → '.join(path[1:-1])}"
                    ))
        
        return redundancies
    
    def _compute_transitive_closure(
        self, 
        relations: List[Relation]
    ) -> Dict[str, Set[str]]:
        """Calcule la fermeture transitive des relations."""
        # Adjacence simple
        adj = defaultdict(set)
        for rel in relations:
            adj[rel.source].add(rel.target)
        
        # Floyd-Warshall simplifié pour la fermeture transitive
        nodes = set()
        for rel in relations:
            nodes.add(rel.source)
            nodes.add(rel.target)
        
        closure = {n: adj[n].copy() for n in nodes}
        
        for k in nodes:
            for i in nodes:
                if k in closure[i]:
                    closure[i] |= closure[k]
        
        return closure
    
    def _find_transitive_path(
        self, 
        source: str, 
        target: str, 
        relations: List[Relation]
    ) -> Optional[List[str]]:
        """Trouve le chemin transitif entre source et target."""
        # Construire sous-graphe
        adj = defaultdict(list)
        for rel in relations:
            adj[rel.source].append(rel.target)
        
        # BFS pour plus court chemin
        visited = {source}
        queue = [(source, [source])]
        
        while queue:
            current, path = queue.pop(0)
            
            for successor in adj[current]:
                if successor == target:
                    return path + [successor]
                if successor not in visited:
                    visited.add(successor)
                    queue.append((successor, path + [successor]))
        
        return None


# =============================================================================
# OPTIMISEUR DE RELATIONS
# =============================================================================

class RelationOptimizer:
    """
    Génère des suggestions d'optimisation du graphe.
    """
    
    def __init__(
        self, 
        graph: RelationGraph,
        cycles: List[Cycle],
        redundancies: List[Redundancy]
    ):
        self.graph = graph
        self.cycles = cycles
        self.redundancies = redundancies
    
    def generate_suggestions(self) -> List[Suggestion]:
        """
        Génère toutes les suggestions d'optimisation.
        
        Returns:
            Liste de suggestions priorisées
        """
        suggestions = []
        
        # Suggestions pour les cycles
        suggestions.extend(self._suggest_cycle_breaks())
        
        # Suggestions pour les redondances
        suggestions.extend(self._suggest_redundancy_removal())
        
        # Suggestions de factorisation
        suggestions.extend(self._suggest_common_parent())
        
        # Trier par impact
        suggestions.sort(key=lambda s: {"high": 0, "medium": 1, "low": 2}[s.impact])
        
        return suggestions
    
    def _suggest_cycle_breaks(self) -> List[Suggestion]:
        """Suggestions pour casser les cycles."""
        suggestions = []
        
        for cycle in self.cycles:
            if cycle.severity == "error":
                # Trouver la relation la moins critique à supprimer
                weakest = self._find_weakest_link(cycle)
                
                suggestions.append(Suggestion(
                    suggestion_type=SuggestionType.BREAK_CYCLE,
                    description=f"Supprimer la relation {weakest} pour casser le cycle",
                    affected_relations=[weakest] if weakest else [],
                    proposed_action={
                        "action": "remove_relation",
                        "relation": weakest.to_dict() if weakest else None,
                        "cycle": cycle.to_dict()
                    },
                    impact="high"
                ))
        
        return suggestions
    
    def _find_weakest_link(self, cycle: Cycle) -> Optional[Relation]:
        """Trouve le maillon le plus faible d'un cycle."""
        if not cycle.path:
            return None
        
        # Priorité: RELATED_TO < REFERENCES < autres
        priority = {
            RelationType.RELATED_TO: 0,
            RelationType.REFERENCES: 1,
            RelationType.TRIGGERS: 2,
            RelationType.EXTENDS: 3,
            RelationType.COMPOSED_OF: 4,
            RelationType.DEPENDS_ON: 5,
            RelationType.INHERITS_FROM: 6
        }
        
        weakest = None
        weakest_priority = 100
        
        for i in range(len(cycle.path)):
            source = cycle.path[i]
            target = cycle.path[(i + 1) % len(cycle.path)]
            rel = self.graph.get_relation_between(source, target)
            
            if rel and priority.get(rel.relation_type, 3) < weakest_priority:
                weakest = rel
                weakest_priority = priority.get(rel.relation_type, 3)
        
        return weakest
    
    def _suggest_redundancy_removal(self) -> List[Suggestion]:
        """Suggestions pour supprimer les relations redondantes."""
        suggestions = []
        
        for redundancy in self.redundancies:
            rel = redundancy.direct_relation
            
            suggestions.append(Suggestion(
                suggestion_type=SuggestionType.REMOVE_REDUNDANT,
                description=(
                    f"Supprimer {rel.source} → {rel.target} "
                    f"(redondant via {' → '.join(redundancy.alternative_path)})"
                ),
                affected_relations=[rel],
                proposed_action={
                    "action": "remove_relation",
                    "relation": rel.to_dict(),
                    "reason": redundancy.reason
                },
                impact="low"
            ))
        
        return suggestions
    
    def _suggest_common_parent(self) -> List[Suggestion]:
        """
        Suggère l'introduction de parents communs.
        
        Si plusieurs objets ont les mêmes dépendances, un parent
        commun peut factoriser ces relations.
        """
        suggestions = []
        
        # Grouper les objets par leurs dépendances
        deps_signature: Dict[FrozenSet[str], List[str]] = defaultdict(list)
        
        for node in self.graph.nodes:
            deps = frozenset(self.graph.get_successors(node))
            if len(deps) >= 2:  # Au moins 2 dépendances
                deps_signature[deps].append(node)
        
        # Chercher les groupes avec plusieurs objets
        for deps, objects in deps_signature.items():
            if len(objects) >= 2:
                common_deps = list(deps)
                
                suggestions.append(Suggestion(
                    suggestion_type=SuggestionType.INTRODUCE_PARENT,
                    description=(
                        f"Introduire un parent commun pour {', '.join(objects[:3])}"
                        f"{' et autres' if len(objects) > 3 else ''} "
                        f"qui partagent les dépendances: {', '.join(common_deps[:3])}"
                    ),
                    affected_relations=[
                        rel for rel in self.graph.relations 
                        if rel.source in objects
                    ],
                    proposed_action={
                        "action": "introduce_parent",
                        "children": objects,
                        "shared_dependencies": common_deps
                    },
                    impact="medium"
                ))
        
        return suggestions


# =============================================================================
# MOTEUR PRINCIPAL
# =============================================================================

class MetaRelationsEngine:
    """
    Orchestrateur principal de l'analyse MetaRelations.
    
    Usage:
        engine = MetaRelationsEngine()
        result = engine.analyze(graph)
        # ou
        result = engine.analyze_store(fractal_store)
    """
    
    def __init__(
        self,
        detect_cycles: bool = True,
        detect_redundancies: bool = True,
        detect_transitive: bool = True,
        generate_suggestions: bool = True
    ):
        self.detect_cycles = detect_cycles
        self.detect_redundancies = detect_redundancies
        self.detect_transitive = detect_transitive
        self.generate_suggestions = generate_suggestions
    
    def analyze(self, graph: RelationGraph) -> AnalysisResult:
        """
        Analyse complète d'un graphe de relations.
        
        Args:
            graph: Le graphe à analyser
        
        Returns:
            AnalysisResult avec cycles, redondances et suggestions
        """
        cycles = []
        redundancies = []
        suggestions = []
        
        # Détection de cycles
        if self.detect_cycles:
            detector = CycleDetector(graph)
            cycles = detector.detect_cycles()
        
        # Détection de redondances
        if self.detect_redundancies:
            analyzer = RedundancyAnalyzer(graph)
            redundancies = analyzer.find_redundancies()
            
            if self.detect_transitive:
                transitive = analyzer.find_transitive_redundancies()
                redundancies.extend(transitive)
        
        # Génération de suggestions
        if self.generate_suggestions:
            optimizer = RelationOptimizer(graph, cycles, redundancies)
            suggestions = optimizer.generate_suggestions()
        
        # Statistiques
        stats = {
            "total_relations": len(graph.relations),
            "unique_objects": len(graph.nodes),
            "cycles_detected": len(cycles),
            "redundancies_detected": len(redundancies),
            "suggestions_generated": len(suggestions)
        }
        
        return AnalysisResult(
            cycles=cycles,
            redundancies=redundancies,
            suggestions=suggestions,
            stats=stats
        )
    
    def analyze_store(
        self, 
        store: Dict[str, Any],
        relation_key: str = "relations"
    ) -> AnalysisResult:
        """
        Analyse directe d'un store fractal.
        
        Args:
            store: Store fractal {id → FractalObject}
            relation_key: Clé des relations dans metadata
        
        Returns:
            AnalysisResult
        """
        graph = RelationGraph.from_fractal_store(store, relation_key)
        return self.analyze(graph)


# =============================================================================
# API SIMPLIFIÉE
# =============================================================================

def analyze_relations(
    graph_or_store: Union[RelationGraph, Dict[str, Any]],
    **options
) -> Dict:
    """
    API centrale pour l'analyse des relations.
    
    Args:
        graph_or_store: RelationGraph ou store fractal
        **options: Options de configuration
    
    Returns:
        Dict avec cycles[], redundancies[], suggestions[]
    """
    engine = MetaRelationsEngine(**options)
    
    if isinstance(graph_or_store, RelationGraph):
        result = engine.analyze(graph_or_store)
    else:
        result = engine.analyze_store(graph_or_store)
    
    return result.to_dict()


def create_graph_from_relations(relations_data: List[Dict]) -> RelationGraph:
    """
    Crée un graphe depuis une liste de relations.
    
    Args:
        relations_data: Liste de dicts {source, target, type?}
    
    Returns:
        RelationGraph
    """
    graph = RelationGraph()
    for data in relations_data:
        graph.add_relation(Relation.from_dict(data))
    return graph


def quick_analyze(relations_data: List[Dict]) -> Dict:
    """
    Analyse rapide depuis une liste de relations.
    
    Example:
        result = quick_analyze([
            {"source": "A", "target": "B", "type": "depends_on"},
            {"source": "B", "target": "C", "type": "depends_on"},
            {"source": "C", "target": "A", "type": "depends_on"}  # Cycle!
        ])
    """
    graph = create_graph_from_relations(relations_data)
    return analyze_relations(graph)


def audit_relations(graph_or_store: Union[RelationGraph, Dict[str, Any]]) -> None:
    """
    Lance un audit et affiche les résultats.
    """
    engine = MetaRelationsEngine()
    
    if isinstance(graph_or_store, RelationGraph):
        result = engine.analyze(graph_or_store)
    else:
        result = engine.analyze_store(graph_or_store)
    
    print(result.display())
