"""
EUREKAI C3/3 — Tests et Exemples MetaRelations
===============================================
Démonstration et validation de l'analyse des relations.

Tests couverts:
- Graphe sans anomalies
- Graphe avec cycles (simples, complexes, auto-référence)
- Graphe avec redondances (directes, transitives)
- Suggestions d'optimisation
- Intégration avec store fractal
"""

import sys
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum

# Import du module
from metarelations_engine import (
    # Classes principales
    RelationGraph, Relation, RelationType,
    Cycle, Redundancy, Suggestion,
    AnalysisResult, AnomalyType, SuggestionType,
    # Analyseurs
    CycleDetector, RedundancyAnalyzer, RelationOptimizer,
    MetaRelationsEngine,
    # API
    analyze_relations, quick_analyze, audit_relations,
    create_graph_from_relations
)


# =============================================================================
# MOCK FRACTAL OBJECT (Simulation C1)
# =============================================================================

class ObjectType(Enum):
    IDENTITY = "I"
    VIEW = "V"
    CONTEXT = "C"
    DEFINITION = "D"
    RULE = "R"
    OPTION = "O"
    UNKNOWN = "?"


@dataclass
class FractalObject:
    """Mock FractalObject pour tests standalone."""
    id: str
    name: str
    lineage: str = ""
    parent_id: Optional[str] = None
    depth: int = 1
    object_type: ObjectType = ObjectType.UNKNOWN
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# GRAPHES DE TEST
# =============================================================================

def create_clean_graph() -> RelationGraph:
    """
    Graphe sans anomalies (acyclique, sans redondances).
    
    Structure:
        A → B → D
        ↓   ↓
        C   E
    """
    graph = RelationGraph()
    
    relations = [
        Relation("A", "B", RelationType.DEPENDS_ON),
        Relation("A", "C", RelationType.DEPENDS_ON),
        Relation("B", "D", RelationType.DEPENDS_ON),
        Relation("B", "E", RelationType.RELATED_TO),
    ]
    
    graph.add_relations(relations)
    return graph


def create_simple_cycle_graph() -> RelationGraph:
    """
    Graphe avec un cycle simple A → B → C → A.
    
    Structure:
        A → B
        ↑   ↓
        C ←─┘
    """
    graph = RelationGraph()
    
    relations = [
        Relation("A", "B", RelationType.DEPENDS_ON),
        Relation("B", "C", RelationType.DEPENDS_ON),
        Relation("C", "A", RelationType.DEPENDS_ON),  # Cycle!
    ]
    
    graph.add_relations(relations)
    return graph


def create_complex_cycle_graph() -> RelationGraph:
    """
    Graphe avec plusieurs cycles imbriqués.
    
    Structure:
        A → B → C
        ↓   ↓   ↓
        D → E → F
        ↑       ↓
        └───────┘
        
    Cycles: B→C→F→E→B, D→E→F→D (via les liens)
    """
    graph = RelationGraph()
    
    relations = [
        # Cycle 1: A→B→E→D→A (si on ajoute D→A)
        Relation("A", "B", RelationType.DEPENDS_ON),
        Relation("A", "D", RelationType.RELATED_TO),
        Relation("B", "C", RelationType.DEPENDS_ON),
        Relation("B", "E", RelationType.DEPENDS_ON),
        Relation("C", "F", RelationType.TRIGGERS),
        Relation("D", "E", RelationType.DEPENDS_ON),
        Relation("E", "F", RelationType.DEPENDS_ON),
        Relation("F", "D", RelationType.DEPENDS_ON),  # Crée le cycle D→E→F→D
    ]
    
    graph.add_relations(relations)
    return graph


def create_self_loop_graph() -> RelationGraph:
    """
    Graphe avec une auto-référence.
    
    Structure:
        A → B
        ↓   ↺ (B se référence lui-même)
        C
    """
    graph = RelationGraph()
    
    relations = [
        Relation("A", "B", RelationType.DEPENDS_ON),
        Relation("A", "C", RelationType.DEPENDS_ON),
        Relation("B", "B", RelationType.REFERENCES),  # Auto-ref!
    ]
    
    graph.add_relations(relations)
    return graph


def create_redundant_graph() -> RelationGraph:
    """
    Graphe avec relation redondante directe.
    
    Structure:
        A → B → C
        └───────┘ (redondant)
    """
    graph = RelationGraph()
    
    relations = [
        Relation("A", "B", RelationType.DEPENDS_ON),
        Relation("B", "C", RelationType.DEPENDS_ON),
        Relation("A", "C", RelationType.DEPENDS_ON),  # Redondant!
    ]
    
    graph.add_relations(relations)
    return graph


def create_transitive_redundant_graph() -> RelationGraph:
    """
    Graphe avec redondance transitive profonde.
    
    Structure:
        A → B → C → D
        └─────────────┘ (redondant via B→C→D)
    """
    graph = RelationGraph()
    
    relations = [
        Relation("A", "B", RelationType.DEPENDS_ON),
        Relation("B", "C", RelationType.DEPENDS_ON),
        Relation("C", "D", RelationType.DEPENDS_ON),
        Relation("A", "D", RelationType.DEPENDS_ON),  # Redondant!
    ]
    
    graph.add_relations(relations)
    return graph


def create_common_deps_graph() -> RelationGraph:
    """
    Graphe avec plusieurs objets partageant les mêmes dépendances.
    
    Structure:
        A → X    B → X    C → X
        ↓   ↓    ↓   ↓    ↓   ↓
        └→ Y ←───┴→ Y ←───┴→ Y
        
    A, B, C partagent X et Y comme dépendances.
    """
    graph = RelationGraph()
    
    relations = [
        Relation("A", "X", RelationType.DEPENDS_ON),
        Relation("A", "Y", RelationType.DEPENDS_ON),
        Relation("B", "X", RelationType.DEPENDS_ON),
        Relation("B", "Y", RelationType.DEPENDS_ON),
        Relation("C", "X", RelationType.DEPENDS_ON),
        Relation("C", "Y", RelationType.DEPENDS_ON),
    ]
    
    graph.add_relations(relations)
    return graph


def create_mixed_issues_graph() -> RelationGraph:
    """
    Graphe avec cycle ET redondance.
    
    Structure:
        A → B → C → A (cycle)
        │       ↑
        └───────┘ (redondant)
    """
    graph = RelationGraph()
    
    relations = [
        Relation("A", "B", RelationType.DEPENDS_ON),
        Relation("B", "C", RelationType.DEPENDS_ON),
        Relation("C", "A", RelationType.TRIGGERS),    # Cycle
        Relation("A", "C", RelationType.RELATED_TO),  # Aussi redondant
    ]
    
    graph.add_relations(relations)
    return graph


# =============================================================================
# STORE FRACTAL DE TEST
# =============================================================================

def create_fractal_store() -> Dict[str, FractalObject]:
    """
    Crée un store fractal avec des relations dans metadata.
    """
    objects = [
        FractalObject(
            id="core",
            name="Core",
            lineage="Core",
            object_type=ObjectType.IDENTITY,
            metadata={
                "relations": {
                    "depends_on": ["config"],
                    "related_to": ["agency"]
                }
            }
        ),
        FractalObject(
            id="config",
            name="Config",
            lineage="Core:Config",
            parent_id="core",
            object_type=ObjectType.OPTION,
            metadata={
                "relations": {
                    "depends_on": ["env"]
                }
            }
        ),
        FractalObject(
            id="env",
            name="Environment",
            lineage="Core:Config:Env",
            parent_id="config",
            object_type=ObjectType.OPTION,
            metadata={}
        ),
        FractalObject(
            id="agency",
            name="Agency",
            lineage="Agency",
            object_type=ObjectType.CONTEXT,
            metadata={
                "relations": {
                    "depends_on": ["config", "env"],  # env est redondant
                }
            }
        ),
        FractalObject(
            id="agent",
            name="Agent",
            lineage="Core:Agent",
            parent_id="core",
            object_type=ObjectType.IDENTITY,
            metadata={
                "relations": {
                    "depends_on": ["config"],
                    "triggers": ["agency"]
                }
            }
        ),
    ]
    
    return {obj.id: obj for obj in objects}


def create_cyclic_fractal_store() -> Dict[str, FractalObject]:
    """Store avec un cycle dans les relations."""
    objects = [
        FractalObject(
            id="module_a",
            name="Module A",
            lineage="Modules:A",
            metadata={
                "relations": {"depends_on": ["module_b"]}
            }
        ),
        FractalObject(
            id="module_b",
            name="Module B",
            lineage="Modules:B",
            metadata={
                "relations": {"depends_on": ["module_c"]}
            }
        ),
        FractalObject(
            id="module_c",
            name="Module C",
            lineage="Modules:C",
            metadata={
                "relations": {"depends_on": ["module_a"]}  # Cycle!
            }
        ),
    ]
    
    return {obj.id: obj for obj in objects}


# =============================================================================
# TESTS UNITAIRES
# =============================================================================

def test_clean_graph():
    """
    TEST 1: Graphe Sans Anomalies
    -----------------------------
    Un graphe bien formé ne doit générer aucune anomalie.
    """
    print("\n" + "="*60)
    print("TEST 1: Graphe propre (aucune anomalie attendue)")
    print("="*60)
    
    graph = create_clean_graph()
    engine = MetaRelationsEngine()
    result = engine.analyze(graph)
    
    print(f"\nRelations: {len(graph.relations)}")
    print(f"Nœuds: {len(graph.nodes)}")
    print(f"Cycles: {len(result.cycles)}")
    print(f"Redondances: {len(result.redundancies)}")
    
    # Vérifications
    assert len(result.cycles) == 0, "Ne devrait pas avoir de cycles"
    assert len(result.redundancies) == 0, "Ne devrait pas avoir de redondances"
    
    print("\n✅ TEST 1 VALIDÉ: Graphe propre analysé correctement")
    return True


def test_simple_cycle():
    """
    TEST 2: Détection de Cycle Simple
    ---------------------------------
    Cycle A → B → C → A
    """
    print("\n" + "="*60)
    print("TEST 2: Cycle simple A → B → C → A")
    print("="*60)
    
    graph = create_simple_cycle_graph()
    detector = CycleDetector(graph)
    cycles = detector.detect_cycles()
    
    print(f"\nCycles détectés: {len(cycles)}")
    for cycle in cycles:
        print(f"  • {cycle.display()}")
        print(f"    Sévérité: {cycle.severity}")
    
    # Vérification
    assert len(cycles) == 1, "Devrait détecter exactement 1 cycle"
    assert set(cycles[0].path) == {"A", "B", "C"}, "Le cycle devrait contenir A, B, C"
    
    print("\n✅ TEST 2 VALIDÉ: Cycle simple détecté")
    return True


def test_complex_cycles():
    """
    TEST 3: Détection de Cycles Complexes
    -------------------------------------
    Plusieurs cycles imbriqués.
    """
    print("\n" + "="*60)
    print("TEST 3: Cycles complexes imbriqués")
    print("="*60)
    
    graph = create_complex_cycle_graph()
    detector = CycleDetector(graph)
    cycles = detector.detect_cycles()
    
    print(f"\nCycles détectés: {len(cycles)}")
    for i, cycle in enumerate(cycles, 1):
        print(f"  {i}. {cycle.display()}")
        print(f"     Types: {[rt.value for rt in cycle.relation_types]}")
    
    # Au moins le cycle D→E→F→D devrait être détecté
    assert len(cycles) >= 1, "Devrait détecter au moins 1 cycle"
    
    print("\n✅ TEST 3 VALIDÉ: Cycles complexes détectés")
    return True


def test_self_loop():
    """
    TEST 4: Détection d'Auto-Référence
    ----------------------------------
    B → B (self-loop)
    """
    print("\n" + "="*60)
    print("TEST 4: Auto-référence (self-loop)")
    print("="*60)
    
    graph = create_self_loop_graph()
    detector = CycleDetector(graph)
    cycles = detector.detect_cycles()
    
    print(f"\nCycles détectés: {len(cycles)}")
    for cycle in cycles:
        print(f"  • {cycle.display()}")
        print(f"    Sévérité: {cycle.severity}")
    
    # Vérification
    assert len(cycles) == 1, "Devrait détecter l'auto-référence"
    assert len(cycles[0].path) == 1, "Auto-ref = cycle de longueur 1"
    assert cycles[0].path[0] == "B", "L'auto-ref est sur B"
    
    print("\n✅ TEST 4 VALIDÉ: Auto-référence détectée")
    return True


def test_direct_redundancy():
    """
    TEST 5: Détection de Redondance Directe
    ---------------------------------------
    A → C directement alors que A → B → C existe
    """
    print("\n" + "="*60)
    print("TEST 5: Redondance directe A → C (via A → B → C)")
    print("="*60)
    
    graph = create_redundant_graph()
    analyzer = RedundancyAnalyzer(graph)
    redundancies = analyzer.find_redundancies()
    
    print(f"\nRedondances détectées: {len(redundancies)}")
    for red in redundancies:
        print(f"  • {red.direct_relation}")
        print(f"    Alternative: {' → '.join(red.alternative_path)}")
        print(f"    Raison: {red.reason}")
    
    # Vérification
    assert len(redundancies) == 1, "Devrait détecter 1 redondance"
    assert redundancies[0].direct_relation.target == "C"
    
    print("\n✅ TEST 5 VALIDÉ: Redondance directe détectée")
    return True


def test_transitive_redundancy():
    """
    TEST 6: Redondance Transitive Profonde
    --------------------------------------
    A → D directement alors que A → B → C → D existe
    """
    print("\n" + "="*60)
    print("TEST 6: Redondance transitive profonde")
    print("="*60)
    
    graph = create_transitive_redundant_graph()
    analyzer = RedundancyAnalyzer(graph)
    
    # Redondances directes
    redundancies = analyzer.find_redundancies()
    print(f"\nRedondances directes: {len(redundancies)}")
    for red in redundancies:
        print(f"  • {red.direct_relation}")
        print(f"    Via: {' → '.join(red.alternative_path)}")
    
    # Redondances transitives
    transitive = analyzer.find_transitive_redundancies()
    print(f"\nRedondances transitives: {len(transitive)}")
    for red in transitive:
        print(f"  • {red.direct_relation}")
        print(f"    Raison: {red.reason}")
    
    # Vérification
    assert len(redundancies) >= 1, "Devrait détecter au moins 1 redondance"
    
    print("\n✅ TEST 6 VALIDÉ: Redondances transitives détectées")
    return True


def test_suggestions():
    """
    TEST 7: Génération de Suggestions
    ---------------------------------
    Vérifier les suggestions pour cycles et redondances.
    """
    print("\n" + "="*60)
    print("TEST 7: Génération de suggestions")
    print("="*60)
    
    graph = create_mixed_issues_graph()
    engine = MetaRelationsEngine()
    result = engine.analyze(graph)
    
    print(f"\nCycles: {len(result.cycles)}")
    print(f"Redondances: {len(result.redundancies)}")
    print(f"Suggestions: {len(result.suggestions)}")
    
    print("\nSuggestions générées:")
    for i, sug in enumerate(result.suggestions, 1):
        print(f"  {i}. [{sug.suggestion_type.value}]")
        print(f"     {sug.description}")
        print(f"     Impact: {sug.impact}")
    
    # Vérification
    assert len(result.suggestions) >= 1, "Devrait avoir au moins 1 suggestion"
    
    # Vérifier qu'on a une suggestion pour le cycle
    cycle_suggestions = [
        s for s in result.suggestions 
        if s.suggestion_type == SuggestionType.BREAK_CYCLE
    ]
    assert len(cycle_suggestions) >= 1, "Devrait suggérer de casser le cycle"
    
    print("\n✅ TEST 7 VALIDÉ: Suggestions générées correctement")
    return True


def test_common_parent_suggestion():
    """
    TEST 8: Suggestion de Parent Commun
    -----------------------------------
    A, B, C partagent X et Y → suggérer un parent commun
    """
    print("\n" + "="*60)
    print("TEST 8: Suggestion de parent commun")
    print("="*60)
    
    graph = create_common_deps_graph()
    engine = MetaRelationsEngine()
    result = engine.analyze(graph)
    
    print(f"\nRelations: {len(graph.relations)}")
    print(f"Suggestions: {len(result.suggestions)}")
    
    # Chercher la suggestion de parent commun
    parent_suggestions = [
        s for s in result.suggestions 
        if s.suggestion_type == SuggestionType.INTRODUCE_PARENT
    ]
    
    print("\nSuggestions de factorisation:")
    for sug in parent_suggestions:
        print(f"  • {sug.description}")
        print(f"    Enfants: {sug.proposed_action.get('children', [])}")
        print(f"    Dépendances communes: {sug.proposed_action.get('shared_dependencies', [])}")
    
    assert len(parent_suggestions) >= 1, "Devrait suggérer un parent commun"
    
    print("\n✅ TEST 8 VALIDÉ: Suggestion de parent commun générée")
    return True


def test_fractal_store_integration():
    """
    TEST 9: Intégration Store Fractal
    ---------------------------------
    Analyse directe depuis un store EUREKAI.
    """
    print("\n" + "="*60)
    print("TEST 9: Intégration avec store fractal")
    print("="*60)
    
    store = create_fractal_store()
    engine = MetaRelationsEngine()
    result = engine.analyze_store(store)
    
    print(f"\nObjets dans le store: {len(store)}")
    print(f"Relations extraites: {result.stats.get('total_relations', 0)}")
    print(f"Cycles: {len(result.cycles)}")
    print(f"Redondances: {len(result.redundancies)}")
    
    # Afficher les issues trouvées
    if result.cycles:
        print("\nCycles:")
        for c in result.cycles:
            print(f"  • {c.display()}")
    
    if result.redundancies:
        print("\nRedondances:")
        for r in result.redundancies:
            print(f"  • {r.direct_relation}")
    
    # Vérification: le store de test a une redondance agency → env
    assert result.stats['total_relations'] > 0, "Devrait extraire des relations"
    
    print("\n✅ TEST 9 VALIDÉ: Intégration store fractal OK")
    return True


def test_cyclic_store():
    """
    TEST 10: Store Fractal avec Cycle
    ---------------------------------
    module_a → module_b → module_c → module_a
    """
    print("\n" + "="*60)
    print("TEST 10: Store fractal avec cycle")
    print("="*60)
    
    store = create_cyclic_fractal_store()
    result = analyze_relations(store)
    
    print(f"\nCycles détectés: {len(result['cycles'])}")
    for cycle in result['cycles']:
        print(f"  • {cycle['display']}")
    
    # Vérification
    assert len(result['cycles']) == 1, "Devrait détecter le cycle"
    
    print("\n✅ TEST 10 VALIDÉ: Cycle détecté dans store fractal")
    return True


def test_quick_api():
    """
    TEST 11: API Rapide
    -------------------
    Test de quick_analyze() pour usage simplifié.
    """
    print("\n" + "="*60)
    print("TEST 11: API quick_analyze")
    print("="*60)
    
    # Cycle simple via API rapide
    result = quick_analyze([
        {"source": "X", "target": "Y", "type": "depends_on"},
        {"source": "Y", "target": "Z", "type": "depends_on"},
        {"source": "Z", "target": "X", "type": "depends_on"}
    ])
    
    print(f"\nRésultat API rapide:")
    print(f"  Cycles: {result['summary']['cyclesCount']}")
    print(f"  Redondances: {result['summary']['redundanciesCount']}")
    print(f"  A des problèmes: {result['summary']['hasIssues']}")
    
    assert result['summary']['cyclesCount'] == 1
    assert result['summary']['hasIssues'] == True
    
    print("\n✅ TEST 11 VALIDÉ: API rapide fonctionne")
    return True


def test_json_serialization():
    """
    TEST 12: Sérialisation JSON
    ---------------------------
    Vérifier que tout est sérialisable.
    """
    print("\n" + "="*60)
    print("TEST 12: Sérialisation JSON")
    print("="*60)
    
    graph = create_mixed_issues_graph()
    engine = MetaRelationsEngine()
    result = engine.analyze(graph)
    
    # Tenter la sérialisation
    try:
        json_str = json.dumps(result.to_dict(), indent=2)
        print(f"\nJSON généré: {len(json_str)} caractères")
        print("\nExtrait:")
        print(json_str[:500] + "...")
        
        # Vérifier qu'on peut relire
        reloaded = json.loads(json_str)
        assert 'cycles' in reloaded
        assert 'redundancies' in reloaded
        assert 'suggestions' in reloaded
        
        print("\n✅ TEST 12 VALIDÉ: Sérialisation JSON OK")
        return True
    except Exception as e:
        print(f"\n❌ Erreur de sérialisation: {e}")
        return False


# =============================================================================
# DÉMONSTRATIONS
# =============================================================================

def demo_complete_analysis():
    """
    Démonstration complète avec affichage formaté.
    """
    print("\n" + "🔷"*30)
    print("  DÉMONSTRATION ANALYSE COMPLÈTE")
    print("🔷"*30)
    
    # Créer un graphe avec problèmes multiples
    graph = RelationGraph()
    
    # Structure avec cycle et redondances
    relations = [
        # Branche principale
        Relation("Core", "Config", RelationType.DEPENDS_ON),
        Relation("Config", "Env", RelationType.DEPENDS_ON),
        Relation("Config", "Secrets", RelationType.DEPENDS_ON),
        
        # Branche Agency avec redondance
        Relation("Agency", "Config", RelationType.DEPENDS_ON),
        Relation("Agency", "Env", RelationType.DEPENDS_ON),  # Redondant!
        Relation("Agency", "Worker", RelationType.COMPOSED_OF),
        
        # Cycle dans Worker
        Relation("Worker", "Task", RelationType.TRIGGERS),
        Relation("Task", "Result", RelationType.DEPENDS_ON),
        Relation("Result", "Worker", RelationType.TRIGGERS),  # Cycle!
        
        # Objets partagés
        Relation("API", "Config", RelationType.DEPENDS_ON),
        Relation("API", "Secrets", RelationType.DEPENDS_ON),
        Relation("UI", "Config", RelationType.DEPENDS_ON),
        Relation("UI", "Secrets", RelationType.DEPENDS_ON),
    ]
    
    graph.add_relations(relations)
    
    # Lancer l'analyse
    print("\n📊 Analyse du graphe...")
    audit_relations(graph)
    
    # Export JSON
    result = analyze_relations(graph)
    print("\n📋 Export JSON disponible:")
    print(f"   Taille: {len(json.dumps(result))} caractères")


def demo_store_audit():
    """
    Démonstration d'audit d'un store fractal.
    """
    print("\n" + "🔷"*30)
    print("  DÉMONSTRATION AUDIT STORE FRACTAL")
    print("🔷"*30)
    
    store = create_fractal_store()
    
    print("\n📦 Objets du store:")
    for obj_id, obj in store.items():
        relations = obj.metadata.get('relations', {})
        print(f"   {obj_id}: {obj.name}")
        if relations:
            for rel_type, targets in relations.items():
                print(f"      {rel_type}: {targets}")
    
    print("\n📊 Analyse...")
    audit_relations(store)


def demo_api_usage():
    """
    Démonstration des différentes API.
    """
    print("\n" + "🔷"*30)
    print("  DÉMONSTRATION API")
    print("🔷"*30)
    
    print("\n1️⃣ API quick_analyze (relations en dict):")
    print("-" * 40)
    
    result = quick_analyze([
        {"source": "A", "target": "B", "type": "depends_on"},
        {"source": "B", "target": "C", "type": "depends_on"},
        {"source": "A", "target": "C", "type": "depends_on"}  # Redondant
    ])
    print(f"   Redondances: {result['summary']['redundanciesCount']}")
    
    print("\n2️⃣ API avec RelationGraph:")
    print("-" * 40)
    
    graph = create_graph_from_relations([
        {"source": "X", "target": "Y"},
        {"source": "Y", "target": "Z"},
        {"source": "Z", "target": "X"}  # Cycle
    ])
    result = analyze_relations(graph)
    print(f"   Cycles: {result['summary']['cyclesCount']}")
    
    print("\n3️⃣ API avec store fractal:")
    print("-" * 40)
    
    store = create_fractal_store()
    result = analyze_relations(store)
    print(f"   Relations: {result['stats']['total_relations']}")
    print(f"   Objets: {result['stats']['unique_objects']}")


# =============================================================================
# EXÉCUTION
# =============================================================================

if __name__ == "__main__":
    print("\n" + "🔶"*30)
    print("  EUREKAI C3/3 — METARELATIONS — TESTS")
    print("🔶"*30)
    
    # Exécuter tous les tests
    results = []
    
    results.append(("Test 1: Graphe propre", test_clean_graph()))
    results.append(("Test 2: Cycle simple", test_simple_cycle()))
    results.append(("Test 3: Cycles complexes", test_complex_cycles()))
    results.append(("Test 4: Auto-référence", test_self_loop()))
    results.append(("Test 5: Redondance directe", test_direct_redundancy()))
    results.append(("Test 6: Redondance transitive", test_transitive_redundancy()))
    results.append(("Test 7: Suggestions", test_suggestions()))
    results.append(("Test 8: Parent commun", test_common_parent_suggestion()))
    results.append(("Test 9: Store fractal", test_fractal_store_integration()))
    results.append(("Test 10: Store cyclique", test_cyclic_store()))
    results.append(("Test 11: API rapide", test_quick_api()))
    results.append(("Test 12: JSON", test_json_serialization()))
    
    # Démos
    demo_api_usage()
    demo_store_audit()
    demo_complete_analysis()
    
    # Résumé
    print("\n" + "="*60)
    print("RÉSUMÉ DES TESTS")
    print("="*60)
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "✅" if result else "❌"
        print(f"  {status} {name}")
    
    print(f"\n  Total: {passed}/{total} tests passés")
    
    if passed == total:
        print("\n  🎉 TOUS LES TESTS PASSENT!")
    
    print("="*60)
