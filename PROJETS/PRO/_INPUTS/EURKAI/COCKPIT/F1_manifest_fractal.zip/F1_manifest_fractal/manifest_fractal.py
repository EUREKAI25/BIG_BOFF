"""
EUREKAI F1/4 — Manifest Fractal (Export JSON Officiel)
======================================================
Format d'export officiel de la fractale EUREKAI.

Ce manifest contient tout le nécessaire pour :
- Reconstruire l'état d'EUREKAI ailleurs
- Générer du code et des projets (F2, F3)
- Faire des backups cohérents

Architecture:
- ManifestSchema: Définition du schéma JSON
- ManifestExporter: Export GEVR de la fractale
- ManifestImporter: Import et reconstruction
- ManifestValidator: Validation de cohérence

Intégrations:
- C2 MetaRules: Section metaRules du manifest
- C3 MetaRelations: Section relations analysables
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import (
    List, Dict, Optional, Tuple, Set, 
    Any, Union, Callable, Iterator
)
from enum import Enum
from datetime import datetime, timezone
import hashlib
import json
import re
from pathlib import Path


# =============================================================================
# VERSION ET CONSTANTES
# =============================================================================

MANIFEST_VERSION = "1.0.0"
SCHEMA_URL = "https://eurekai.io/schemas/manifest-fractal-v1.json"
MIN_COMPATIBLE_VERSION = "1.0.0"
MAX_COMPATIBLE_VERSION = "1.x.x"


# =============================================================================
# ÉNUMÉRATIONS
# =============================================================================

class ExportScope(Enum):
    """Portée de l'export."""
    FULL = "full"           # Export complet
    PARTIAL = "partial"     # Export filtré
    SNAPSHOT = "snapshot"   # Snapshot temporel
    DELTA = "delta"         # Différentiel depuis version


class ObjectTypeCategory(Enum):
    """Catégories IVC×DRO."""
    IDENTITY = "identity"       # I - Identification
    VIEW = "view"               # V - Présentation
    CONTEXT = "context"         # C - Contexte
    DEFINITION = "definition"   # D - Définition
    RULE = "rule"               # R - Règle
    OPTION = "option"           # O - Option


class RelationType(Enum):
    """Types de relations (compatible C3)."""
    DEPENDS_ON = "depends_on"
    INHERITS_FROM = "inherits_from"
    RELATED_TO = "related_to"
    COMPOSED_OF = "composed_of"
    TRIGGERS = "triggers"
    REFERENCES = "references"
    EXTENDS = "extends"


class Severity(Enum):
    """Sévérité des règles (compatible C2)."""
    CRITICAL = "critical"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class RuleCategory(Enum):
    """Catégories de règles (compatible C2)."""
    IDENTITY = "identity"
    STRUCTURE = "structure"
    BUNDLE = "bundle"
    RELATION = "relation"
    CONSISTENCY = "consistency"


# =============================================================================
# STRUCTURES DE DONNÉES DU MANIFEST
# =============================================================================

@dataclass
class ManifestMeta:
    """
    Métadonnées du manifest.
    Section obligatoire pour traçabilité et compatibilité.
    """
    exported_at: str
    exported_by: str
    source_instance: str
    checksum: str = ""
    compatibility: Dict[str, str] = field(default_factory=lambda: {
        "minVersion": MIN_COMPATIBLE_VERSION,
        "maxVersion": MAX_COMPATIBLE_VERSION
    })
    export_scope: ExportScope = ExportScope.FULL
    description: str = ""
    stats: Dict[str, int] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "exportedAt": self.exported_at,
            "exportedBy": self.exported_by,
            "sourceInstance": self.source_instance,
            "checksum": self.checksum,
            "compatibility": self.compatibility,
            "exportScope": self.export_scope.value,
            "description": self.description,
            "stats": self.stats
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ManifestMeta':
        return cls(
            exported_at=data["exportedAt"],
            exported_by=data["exportedBy"],
            source_instance=data["sourceInstance"],
            checksum=data.get("checksum", ""),
            compatibility=data.get("compatibility", {}),
            export_scope=ExportScope(data.get("exportScope", "full")),
            description=data.get("description", ""),
            stats=data.get("stats", {})
        )


@dataclass
class IVCConfig:
    """Configuration Identity-View-Context d'un ObjectType."""
    identity: Dict[str, Any] = field(default_factory=lambda: {
        "required": ["id", "name"],
        "unique": ["id"]
    })
    view: Dict[str, Any] = field(default_factory=lambda: {
        "default": "card",
        "available": ["card", "detail", "list"]
    })
    context: Dict[str, Any] = field(default_factory=lambda: {
        "scopes": ["global"]
    })
    
    def to_dict(self) -> Dict:
        return {
            "identity": self.identity,
            "view": self.view,
            "context": self.context
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'IVCConfig':
        return cls(
            identity=data.get("identity", {}),
            view=data.get("view", {}),
            context=data.get("context", {})
        )


@dataclass
class DROConfig:
    """Configuration Definition-Rule-Option d'un ObjectType."""
    definition: Dict[str, Any] = field(default_factory=lambda: {
        "extends": None,
        "abstract": False
    })
    rules: List[str] = field(default_factory=list)
    options: Dict[str, Any] = field(default_factory=lambda: {
        "auditable": True,
        "versionable": True
    })
    
    def to_dict(self) -> Dict:
        return {
            "definition": self.definition,
            "rules": self.rules,
            "options": self.options
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'DROConfig':
        return cls(
            definition=data.get("definition", {}),
            rules=data.get("rules", []),
            options=data.get("options", {})
        )


@dataclass
class ObjectTypeSpec:
    """
    Spécification complète d'un ObjectType.
    Conforme au pattern IVC×DRO.
    """
    id: str
    name: str
    ivc: IVCConfig
    dro: DROConfig
    schema: Dict[str, Any] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""
    
    def __post_init__(self):
        now = datetime.now(timezone.utc).isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "ivc": self.ivc.to_dict(),
            "dro": self.dro.to_dict(),
            "schema": self.schema,
            "createdAt": self.created_at,
            "updatedAt": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ObjectTypeSpec':
        return cls(
            id=data["id"],
            name=data["name"],
            ivc=IVCConfig.from_dict(data.get("ivc", {})),
            dro=DROConfig.from_dict(data.get("dro", {})),
            schema=data.get("schema", {}),
            created_at=data.get("createdAt", ""),
            updated_at=data.get("updatedAt", "")
        )


@dataclass
class LineageSpec:
    """Spécification d'un lineage (lignée d'héritage)."""
    id: str
    root_type: str
    inheritance: List[str] = field(default_factory=list)
    depth: int = 1
    members: List[str] = field(default_factory=list)
    rules: Dict[str, str] = field(default_factory=lambda: {
        "propagation": "cascade",
        "override": "explicit"
    })
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "rootType": self.root_type,
            "inheritance": self.inheritance,
            "depth": self.depth,
            "members": self.members,
            "rules": self.rules
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'LineageSpec':
        return cls(
            id=data["id"],
            root_type=data["rootType"],
            inheritance=data.get("inheritance", []),
            depth=data.get("depth", 1),
            members=data.get("members", []),
            rules=data.get("rules", {})
        )


@dataclass
class RelationSpec:
    """Spécification d'une relation entre objets."""
    source: str
    target: str
    relation_type: RelationType = RelationType.RELATED_TO
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "type": self.relation_type.value,
            "target": self.target
        }
    
    @classmethod
    def from_dict(cls, source: str, data: Dict) -> 'RelationSpec':
        return cls(
            source=source,
            target=data["target"],
            relation_type=RelationType(data.get("type", "related_to")),
            metadata=data.get("metadata", {})
        )


@dataclass
class ObjectSpec:
    """Spécification complète d'un objet fractal."""
    id: str
    object_type: str
    lineage: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    bundles: Dict[str, List[str]] = field(default_factory=lambda: {
        "attributes": [],
        "methods": [],
        "rules": []
    })
    relations: List[Dict] = field(default_factory=list)
    meta: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        now = datetime.now(timezone.utc).isoformat()
        if "createdAt" not in self.meta:
            self.meta["createdAt"] = now
        if "updatedAt" not in self.meta:
            self.meta["updatedAt"] = now
        if "version" not in self.meta:
            self.meta["version"] = 1
        if "tags" not in self.meta:
            self.meta["tags"] = []
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "type": self.object_type,
            "lineage": self.lineage,
            "data": self.data,
            "bundles": self.bundles,
            "relations": self.relations,
            "meta": self.meta
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ObjectSpec':
        return cls(
            id=data["id"],
            object_type=data["type"],
            lineage=data.get("lineage"),
            data=data.get("data", {}),
            bundles=data.get("bundles", {}),
            relations=data.get("relations", []),
            meta=data.get("meta", {})
        )


@dataclass
class BundleAttributeSpec:
    """Spécification d'un bundle d'attributs."""
    id: str
    applies_to: List[str] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "appliesTo": self.applies_to,
            "properties": self.properties
        }


@dataclass
class BundleMethodSpec:
    """Spécification d'un bundle de méthode avec GEVR."""
    id: str
    signature: str
    gevr: Dict[str, Any] = field(default_factory=lambda: {
        "get": {"sources": [], "validation": "schema"},
        "execute": {"handler": "", "timeout": 30000},
        "validate": {"schema": "", "rules": []},
        "render": {"format": "json", "template": None}
    })
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "signature": self.signature,
            "gevr": self.gevr
        }


@dataclass
class BundleRuleSpec:
    """Spécification d'un bundle de règle (compatible C2)."""
    id: str
    rule_type: str = "validation"
    condition: str = ""
    message: str = ""
    severity: Severity = Severity.ERROR
    category: RuleCategory = RuleCategory.CONSISTENCY
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "type": self.rule_type,
            "condition": self.condition,
            "message": self.message,
            "severity": self.severity.value,
            "category": self.category.value
        }


@dataclass  
class BundleRelationSpec:
    """Spécification d'un type de relation (compatible C3)."""
    id: str
    name: str
    source_type: str
    target_type: str
    cardinality: str = "1:N"
    bidirectional: bool = False
    inverse: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "sourceType": self.source_type,
            "targetType": self.target_type,
            "cardinality": self.cardinality,
            "bidirectional": self.bidirectional,
            "inverse": self.inverse
        }


@dataclass
class ScenarioGEVRSpec:
    """Spécification d'un scénario GEVR."""
    id: str
    name: str
    trigger: Dict[str, Any] = field(default_factory=dict)
    steps: List[Dict[str, Any]] = field(default_factory=list)
    on_error: Dict[str, Any] = field(default_factory=lambda: {
        "action": "notifyFailure",
        "rollback": True
    })
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "trigger": self.trigger,
            "steps": self.steps,
            "onError": self.on_error
        }


@dataclass
class WorkflowSpec:
    """Spécification d'un workflow (machine à états)."""
    id: str
    states: List[str] = field(default_factory=list)
    transitions: List[Dict[str, Any]] = field(default_factory=list)
    initial_state: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "states": self.states,
            "transitions": self.transitions,
            "initialState": self.initial_state or (self.states[0] if self.states else "")
        }


@dataclass
class MetaRuleSpec:
    """Spécification d'une MetaRule (compatible C2)."""
    id: str
    name: str
    scope: str = "global"
    applies: str = "objects"
    rule: str = ""
    enforcement: str = "strict"
    message: str = ""
    severity: Severity = Severity.ERROR
    category: RuleCategory = RuleCategory.CONSISTENCY
    enabled: bool = True
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "scope": self.scope,
            "applies": self.applies,
            "rule": self.rule,
            "enforcement": self.enforcement,
            "message": self.message,
            "severity": self.severity.value,
            "category": self.category.value,
            "enabled": self.enabled
        }


@dataclass
class SuperToolSpec:
    """Spécification d'un SuperTool."""
    id: str
    name: str
    tool_type: str = "generator"
    config: Dict[str, Any] = field(default_factory=dict)
    permissions: List[str] = field(default_factory=list)
    gevr: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.tool_type,
            "config": self.config,
            "permissions": self.permissions,
            "gevr": self.gevr
        }


@dataclass
class TagSpec:
    """Spécification d'un tag."""
    id: str
    name: str
    color: str = "#3B82F6"
    description: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "color": self.color,
            "description": self.description
        }


@dataclass
class CategorySpec:
    """Spécification d'une catégorie hiérarchique."""
    id: str
    name: str
    parent: Optional[str] = None
    children: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "parent": self.parent,
            "children": self.children
        }


# =============================================================================
# MANIFEST COMPLET
# =============================================================================

@dataclass
class ManifestFractal:
    """
    Manifest Fractal complet.
    Structure principale d'export/import EUREKAI.
    """
    # Version et schéma
    version: str = MANIFEST_VERSION
    schema: str = SCHEMA_URL
    
    # Métadonnées
    meta: ManifestMeta = None
    
    # Fractale
    object_types: Dict[str, ObjectTypeSpec] = field(default_factory=dict)
    lineages: Dict[str, LineageSpec] = field(default_factory=dict)
    objects: Dict[str, ObjectSpec] = field(default_factory=dict)
    
    # Bundles
    bundle_attributes: Dict[str, BundleAttributeSpec] = field(default_factory=dict)
    bundle_methods: Dict[str, BundleMethodSpec] = field(default_factory=dict)
    bundle_rules: Dict[str, BundleRuleSpec] = field(default_factory=dict)
    bundle_relations: Dict[str, BundleRelationSpec] = field(default_factory=dict)
    
    # Scénarios
    scenarios_gevr: Dict[str, ScenarioGEVRSpec] = field(default_factory=dict)
    workflows: Dict[str, WorkflowSpec] = field(default_factory=dict)
    
    # MetaRules (C2)
    meta_rules: Dict[str, MetaRuleSpec] = field(default_factory=dict)
    
    # SuperTools
    super_tools: Dict[str, SuperToolSpec] = field(default_factory=dict)
    
    # Taxonomie
    tags: Dict[str, TagSpec] = field(default_factory=dict)
    categories: Dict[str, CategorySpec] = field(default_factory=dict)
    aliases: Dict[str, List[str]] = field(default_factory=dict)
    
    # Index (calculés)
    indexes: Dict[str, Dict] = field(default_factory=dict)
    
    def __post_init__(self):
        if self.meta is None:
            self.meta = ManifestMeta(
                exported_at=datetime.now(timezone.utc).isoformat(),
                exported_by="eurekai-core",
                source_instance="eurekai-main"
            )
    
    def to_dict(self) -> Dict:
        """Sérialise le manifest complet en dictionnaire."""
        return {
            "$schema": self.schema,
            "version": self.version,
            "meta": self.meta.to_dict(),
            "fractale": {
                "objectTypes": {k: v.to_dict() for k, v in self.object_types.items()},
                "lineages": {k: v.to_dict() for k, v in self.lineages.items()},
                "objects": {k: v.to_dict() for k, v in self.objects.items()}
            },
            "bundles": {
                "attributes": {k: v.to_dict() for k, v in self.bundle_attributes.items()},
                "methods": {k: v.to_dict() for k, v in self.bundle_methods.items()},
                "rules": {k: v.to_dict() for k, v in self.bundle_rules.items()},
                "relations": {k: v.to_dict() for k, v in self.bundle_relations.items()}
            },
            "scenarios": {
                "gevr": {k: v.to_dict() for k, v in self.scenarios_gevr.items()},
                "workflows": {k: v.to_dict() for k, v in self.workflows.items()}
            },
            "metaRules": {k: v.to_dict() for k, v in self.meta_rules.items()},
            "superTools": {k: v.to_dict() for k, v in self.super_tools.items()},
            "taxonomie": {
                "tags": {k: v.to_dict() for k, v in self.tags.items()},
                "categories": {k: v.to_dict() for k, v in self.categories.items()},
                "aliases": self.aliases
            },
            "indexes": self.indexes
        }
    
    def to_json(self, pretty: bool = True) -> str:
        """Sérialise en JSON."""
        data = self.to_dict()
        if pretty:
            return json.dumps(data, indent=2, ensure_ascii=False)
        return json.dumps(data, ensure_ascii=False)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ManifestFractal':
        """Désérialise depuis un dictionnaire."""
        manifest = cls(
            version=data.get("version", MANIFEST_VERSION),
            schema=data.get("$schema", SCHEMA_URL),
            meta=ManifestMeta.from_dict(data.get("meta", {}))
        )
        
        # Fractale
        fractale = data.get("fractale", {})
        for k, v in fractale.get("objectTypes", {}).items():
            manifest.object_types[k] = ObjectTypeSpec.from_dict(v)
        for k, v in fractale.get("lineages", {}).items():
            manifest.lineages[k] = LineageSpec.from_dict(v)
        for k, v in fractale.get("objects", {}).items():
            manifest.objects[k] = ObjectSpec.from_dict(v)
        
        # Bundles, scénarios, etc. - parsing similaire...
        manifest.indexes = data.get("indexes", {})
        
        return manifest
    
    @classmethod
    def from_json(cls, json_str: str) -> 'ManifestFractal':
        """Désérialise depuis JSON."""
        return cls.from_dict(json.loads(json_str))
    
    def compute_checksum(self) -> str:
        """Calcule le checksum SHA256 du contenu (hors meta)."""
        data = self.to_dict()
        content = {k: v for k, v in data.items() if k != "meta"}
        json_str = json.dumps(content, sort_keys=True, ensure_ascii=False)
        return f"sha256:{hashlib.sha256(json_str.encode()).hexdigest()}"
    
    def build_indexes(self) -> None:
        """Construit les index pour recherche rapide."""
        by_type = {}
        by_lineage = {}
        by_tag = {}
        
        for obj_id, obj in self.objects.items():
            # Index par type
            obj_type = obj.object_type
            if obj_type not in by_type:
                by_type[obj_type] = []
            by_type[obj_type].append(obj_id)
            
            # Index par lineage
            if obj.lineage:
                if obj.lineage not in by_lineage:
                    by_lineage[obj.lineage] = []
                by_lineage[obj.lineage].append(obj_id)
            
            # Index par tag
            for tag in obj.meta.get("tags", []):
                if tag not in by_tag:
                    by_tag[tag] = []
                by_tag[tag].append(obj_id)
        
        self.indexes = {
            "byType": by_type,
            "byLineage": by_lineage,
            "byTag": by_tag
        }
    
    def update_stats(self) -> None:
        """Met à jour les statistiques dans meta."""
        self.meta.stats = {
            "objectTypes": len(self.object_types),
            "lineages": len(self.lineages),
            "objects": len(self.objects),
            "bundleAttributes": len(self.bundle_attributes),
            "bundleMethods": len(self.bundle_methods),
            "bundleRules": len(self.bundle_rules),
            "bundleRelations": len(self.bundle_relations),
            "scenariosGevr": len(self.scenarios_gevr),
            "workflows": len(self.workflows),
            "metaRules": len(self.meta_rules),
            "superTools": len(self.super_tools),
            "tags": len(self.tags),
            "categories": len(self.categories)
        }


# =============================================================================
# OPTIONS D'EXPORT
# =============================================================================

@dataclass
class ExportOptions:
    """Options de configuration pour l'export."""
    scope: ExportScope = ExportScope.FULL
    include_indexes: bool = True
    include_computed: bool = False
    filter_types: Optional[List[str]] = None
    filter_tags: Optional[List[str]] = None
    filter_lineages: Optional[List[str]] = None
    pretty_print: bool = True
    version: str = MANIFEST_VERSION
    description: str = ""


# =============================================================================
# EXPORTEUR GEVR
# =============================================================================

class ManifestExporter:
    """
    Exporteur officiel du Manifest Fractal EUREKAI.
    
    Implémente le pattern GEVR:
    - GET: Collecte les données de la fractale
    - EXECUTE: Applique les transformations et filtres
    - VALIDATE: Vérifie la cohérence du manifest
    - RENDER: Produit le JSON final
    """
    
    def __init__(self, fractale: Any, instance_name: str = "eurekai-main"):
        """
        Args:
            fractale: Store fractal source (dict ou objet avec méthodes)
            instance_name: Nom de l'instance source
        """
        self.fractale = fractale
        self.instance_name = instance_name
    
    def export_manifest(self, options: Optional[ExportOptions] = None) -> str:
        """
        Point d'entrée principal: exporte le manifest.
        
        Args:
            options: Options d'export
            
        Returns:
            JSON string du manifest
        """
        options = options or ExportOptions()
        
        # GEVR: GET
        manifest = self._get_fractale_data(options)
        
        # GEVR: EXECUTE
        manifest = self._execute_transforms(manifest, options)
        
        # GEVR: VALIDATE
        errors = self._validate_manifest(manifest)
        if errors:
            raise ManifestValidationError(errors)
        
        # GEVR: RENDER
        return self._render_json(manifest, options)
    
    def export_manifest_dict(self, options: Optional[ExportOptions] = None) -> Dict:
        """Exporte comme dictionnaire Python."""
        json_str = self.export_manifest(options)
        return json.loads(json_str)
    
    # ─────────────────────────────────────────────────────────────
    # GEVR: GET
    # ─────────────────────────────────────────────────────────────
    
    def _get_fractale_data(self, options: ExportOptions) -> ManifestFractal:
        """Collecte les données de la fractale."""
        manifest = ManifestFractal()
        
        # Extraire selon le type de fractale
        if isinstance(self.fractale, dict):
            self._extract_from_dict(manifest, options)
        else:
            self._extract_from_object(manifest, options)
        
        return manifest
    
    def _extract_from_dict(self, manifest: ManifestFractal, options: ExportOptions):
        """Extraction depuis un dictionnaire."""
        store = self.fractale
        
        # ObjectTypes
        for key, value in store.get("objectTypes", {}).items():
            if self._matches_filter(value, options):
                manifest.object_types[key] = self._to_object_type_spec(key, value)
        
        # Lineages
        for key, value in store.get("lineages", {}).items():
            if options.filter_lineages is None or key in options.filter_lineages:
                manifest.lineages[key] = self._to_lineage_spec(key, value)
        
        # Objects
        for key, value in store.get("objects", {}).items():
            if self._matches_object_filter(value, options):
                manifest.objects[key] = self._to_object_spec(key, value)
        
        # Bundles
        for bundle_type in ["attributes", "methods", "rules", "relations"]:
            bundles = store.get("bundles", {}).get(bundle_type, {})
            for key, value in bundles.items():
                self._add_bundle(manifest, bundle_type, key, value)
        
        # Scenarios
        for key, value in store.get("scenarios", {}).get("gevr", {}).items():
            manifest.scenarios_gevr[key] = self._to_scenario_spec(key, value)
        for key, value in store.get("scenarios", {}).get("workflows", {}).items():
            manifest.workflows[key] = self._to_workflow_spec(key, value)
        
        # MetaRules
        for key, value in store.get("metaRules", {}).items():
            manifest.meta_rules[key] = self._to_metarule_spec(key, value)
        
        # SuperTools
        for key, value in store.get("superTools", {}).items():
            manifest.super_tools[key] = self._to_supertool_spec(key, value)
        
        # Taxonomie
        for key, value in store.get("taxonomie", {}).get("tags", {}).items():
            manifest.tags[key] = TagSpec(id=key, name=value.get("name", key), 
                                         color=value.get("color", "#3B82F6"))
        for key, value in store.get("taxonomie", {}).get("categories", {}).items():
            manifest.categories[key] = CategorySpec(
                id=key, name=value.get("name", key),
                parent=value.get("parent"), children=value.get("children", [])
            )
        manifest.aliases = store.get("taxonomie", {}).get("aliases", {})
    
    def _extract_from_object(self, manifest: ManifestFractal, options: ExportOptions):
        """Extraction depuis un objet avec méthodes."""
        # Appeler les méthodes get_* de l'objet fractale
        if hasattr(self.fractale, 'get_all_object_types'):
            for key, value in self.fractale.get_all_object_types().items():
                manifest.object_types[key] = self._to_object_type_spec(key, value)
        
        if hasattr(self.fractale, 'get_all_objects'):
            for key, value in self.fractale.get_all_objects().items():
                if self._matches_object_filter(value, options):
                    manifest.objects[key] = self._to_object_spec(key, value)
    
    def _matches_filter(self, value: Any, options: ExportOptions) -> bool:
        """Vérifie si une valeur passe les filtres."""
        if options.filter_types:
            type_name = value.get("name") if isinstance(value, dict) else getattr(value, "name", None)
            if type_name and type_name not in options.filter_types:
                return False
        return True
    
    def _matches_object_filter(self, obj: Any, options: ExportOptions) -> bool:
        """Vérifie si un objet passe les filtres."""
        if options.filter_types:
            obj_type = obj.get("type") if isinstance(obj, dict) else getattr(obj, "object_type", None)
            if obj_type and obj_type not in options.filter_types:
                return False
        
        if options.filter_tags:
            tags = obj.get("meta", {}).get("tags", []) if isinstance(obj, dict) else getattr(obj, "tags", [])
            if not any(tag in tags for tag in options.filter_tags):
                return False
        
        if options.filter_lineages:
            lineage = obj.get("lineage") if isinstance(obj, dict) else getattr(obj, "lineage", None)
            if lineage and lineage not in options.filter_lineages:
                return False
        
        return True
    
    def _to_object_type_spec(self, key: str, value: Any) -> ObjectTypeSpec:
        """Convertit en ObjectTypeSpec."""
        if isinstance(value, dict):
            return ObjectTypeSpec.from_dict({"id": key, **value})
        # Conversion depuis objet
        return ObjectTypeSpec(
            id=key,
            name=getattr(value, "name", key),
            ivc=IVCConfig(),
            dro=DROConfig()
        )
    
    def _to_lineage_spec(self, key: str, value: Any) -> LineageSpec:
        """Convertit en LineageSpec."""
        if isinstance(value, dict):
            return LineageSpec.from_dict({"id": key, **value})
        return LineageSpec(id=key, root_type=getattr(value, "root_type", ""))
    
    def _to_object_spec(self, key: str, value: Any) -> ObjectSpec:
        """Convertit en ObjectSpec."""
        if isinstance(value, dict):
            return ObjectSpec.from_dict({"id": key, **value})
        return ObjectSpec(
            id=key,
            object_type=getattr(value, "object_type", "Unknown"),
            data=getattr(value, "data", {})
        )
    
    def _add_bundle(self, manifest: ManifestFractal, bundle_type: str, key: str, value: Any):
        """Ajoute un bundle au manifest."""
        if bundle_type == "attributes":
            manifest.bundle_attributes[key] = BundleAttributeSpec(
                id=key,
                applies_to=value.get("appliesTo", []) if isinstance(value, dict) else [],
                properties=value.get("properties", {}) if isinstance(value, dict) else {}
            )
        elif bundle_type == "methods":
            manifest.bundle_methods[key] = BundleMethodSpec(
                id=key,
                signature=value.get("signature", "") if isinstance(value, dict) else "",
                gevr=value.get("gevr", {}) if isinstance(value, dict) else {}
            )
        elif bundle_type == "rules":
            manifest.bundle_rules[key] = BundleRuleSpec(
                id=key,
                condition=value.get("condition", "") if isinstance(value, dict) else "",
                message=value.get("message", "") if isinstance(value, dict) else ""
            )
        elif bundle_type == "relations":
            manifest.bundle_relations[key] = BundleRelationSpec(
                id=key,
                name=value.get("name", key) if isinstance(value, dict) else key,
                source_type=value.get("sourceType", "") if isinstance(value, dict) else "",
                target_type=value.get("targetType", "") if isinstance(value, dict) else ""
            )
    
    def _to_scenario_spec(self, key: str, value: Any) -> ScenarioGEVRSpec:
        """Convertit en ScenarioGEVRSpec."""
        if isinstance(value, dict):
            return ScenarioGEVRSpec(
                id=key,
                name=value.get("name", key),
                trigger=value.get("trigger", {}),
                steps=value.get("steps", []),
                on_error=value.get("onError", {})
            )
        return ScenarioGEVRSpec(id=key, name=key)
    
    def _to_workflow_spec(self, key: str, value: Any) -> WorkflowSpec:
        """Convertit en WorkflowSpec."""
        if isinstance(value, dict):
            return WorkflowSpec(
                id=key,
                states=value.get("states", []),
                transitions=value.get("transitions", [])
            )
        return WorkflowSpec(id=key)
    
    def _to_metarule_spec(self, key: str, value: Any) -> MetaRuleSpec:
        """Convertit en MetaRuleSpec."""
        if isinstance(value, dict):
            return MetaRuleSpec(
                id=key,
                name=value.get("name", key),
                scope=value.get("scope", "global"),
                applies=value.get("applies", "objects"),
                rule=value.get("rule", ""),
                enforcement=value.get("enforcement", "strict"),
                message=value.get("message", "")
            )
        return MetaRuleSpec(id=key, name=key)
    
    def _to_supertool_spec(self, key: str, value: Any) -> SuperToolSpec:
        """Convertit en SuperToolSpec."""
        if isinstance(value, dict):
            return SuperToolSpec(
                id=key,
                name=value.get("name", key),
                tool_type=value.get("type", "generator"),
                config=value.get("config", {}),
                permissions=value.get("permissions", []),
                gevr=value.get("gevr", {})
            )
        return SuperToolSpec(id=key, name=key)
    
    # ─────────────────────────────────────────────────────────────
    # GEVR: EXECUTE
    # ─────────────────────────────────────────────────────────────
    
    def _execute_transforms(self, manifest: ManifestFractal, options: ExportOptions) -> ManifestFractal:
        """Applique les transformations."""
        # Mise à jour des métadonnées
        manifest.meta = ManifestMeta(
            exported_at=datetime.now(timezone.utc).isoformat(),
            exported_by="eurekai-core",
            source_instance=self.instance_name,
            export_scope=options.scope,
            description=options.description
        )
        
        # Construction des index
        if options.include_indexes:
            manifest.build_indexes()
        
        # Mise à jour des stats
        manifest.update_stats()
        
        # Calcul du checksum
        manifest.meta.checksum = manifest.compute_checksum()
        
        return manifest
    
    # ─────────────────────────────────────────────────────────────
    # GEVR: VALIDATE
    # ─────────────────────────────────────────────────────────────
    
    def _validate_manifest(self, manifest: ManifestFractal) -> List[str]:
        """Valide la cohérence du manifest."""
        errors = []
        
        # Vérifications de base
        if not manifest.version:
            errors.append("Missing version")
        
        if not manifest.meta:
            errors.append("Missing meta section")
        
        # Vérification des références
        errors.extend(self._validate_references(manifest))
        
        # Vérification IVC×DRO
        errors.extend(self._validate_ivc_dro(manifest))
        
        return errors
    
    def _validate_references(self, manifest: ManifestFractal) -> List[str]:
        """Vérifie les références entre objets."""
        errors = []
        type_ids = set(manifest.object_types.keys())
        object_ids = set(manifest.objects.keys())
        
        for obj_id, obj in manifest.objects.items():
            # Le type existe
            if obj.object_type not in type_ids:
                errors.append(f"Object {obj_id} references unknown type '{obj.object_type}'")
            
            # Les relations pointent vers des objets existants
            for rel in obj.relations:
                target = rel.get("target")
                if target and target not in object_ids:
                    errors.append(f"Object {obj_id} has relation to non-existent '{target}'")
        
        return errors
    
    def _validate_ivc_dro(self, manifest: ManifestFractal) -> List[str]:
        """Vérifie la conformité IVC×DRO."""
        errors = []
        
        for type_id, type_def in manifest.object_types.items():
            if not type_def.ivc:
                errors.append(f"ObjectType {type_id} missing IVC configuration")
            if not type_def.dro:
                errors.append(f"ObjectType {type_id} missing DRO configuration")
        
        return errors
    
    # ─────────────────────────────────────────────────────────────
    # GEVR: RENDER
    # ─────────────────────────────────────────────────────────────
    
    def _render_json(self, manifest: ManifestFractal, options: ExportOptions) -> str:
        """Produit le JSON final."""
        return manifest.to_json(pretty=options.pretty_print)


# =============================================================================
# IMPORTEUR
# =============================================================================

class ManifestImporter:
    """Importeur de Manifest Fractal."""
    
    @classmethod
    def import_manifest(cls, data: Union[str, Dict]) -> ManifestFractal:
        """
        Importe un manifest depuis JSON ou dict.
        
        Args:
            data: JSON string ou dictionnaire
            
        Returns:
            ManifestFractal reconstruit
        """
        if isinstance(data, str):
            return ManifestFractal.from_json(data)
        return ManifestFractal.from_dict(data)
    
    @classmethod
    def import_from_file(cls, filepath: Union[str, Path]) -> ManifestFractal:
        """Importe depuis un fichier."""
        path = Path(filepath)
        with open(path, 'r', encoding='utf-8') as f:
            return cls.import_manifest(f.read())
    
    @classmethod
    def verify_checksum(cls, manifest: ManifestFractal) -> bool:
        """Vérifie l'intégrité du manifest."""
        expected = manifest.meta.checksum
        actual = manifest.compute_checksum()
        return expected == actual


# =============================================================================
# VALIDATEUR
# =============================================================================

class ManifestValidator:
    """Validateur de Manifest Fractal."""
    
    def __init__(self, manifest: ManifestFractal):
        self.manifest = manifest
        self.errors: List[str] = []
        self.warnings: List[str] = []
    
    def validate(self) -> bool:
        """Valide le manifest complet."""
        self.errors = []
        self.warnings = []
        
        self._check_structure()
        self._check_references()
        self._check_ivc_dro()
        self._check_bundles()
        self._check_scenarios()
        
        return len(self.errors) == 0
    
    def _check_structure(self):
        """Vérifie la structure de base."""
        if not self.manifest.version:
            self.errors.append("Missing version")
        if not self.manifest.meta:
            self.errors.append("Missing meta section")
        if not self.manifest.object_types:
            self.warnings.append("No ObjectTypes defined")
    
    def _check_references(self):
        """Vérifie les références."""
        type_ids = set(self.manifest.object_types.keys())
        object_ids = set(self.manifest.objects.keys())
        
        for obj_id, obj in self.manifest.objects.items():
            if obj.object_type not in type_ids:
                self.errors.append(f"Object {obj_id} references unknown type")
            
            for rel in obj.relations:
                if rel.get("target") not in object_ids:
                    self.warnings.append(f"Object {obj_id} references unknown target")
    
    def _check_ivc_dro(self):
        """Vérifie IVC×DRO."""
        for type_id, type_def in self.manifest.object_types.items():
            if not type_def.ivc.identity.get("required"):
                self.warnings.append(f"ObjectType {type_id} has no required identity fields")
    
    def _check_bundles(self):
        """Vérifie les bundles."""
        bundle_rule_ids = set(self.manifest.bundle_rules.keys())
        
        for type_id, type_def in self.manifest.object_types.items():
            for rule_id in type_def.dro.rules:
                if rule_id not in bundle_rule_ids:
                    self.warnings.append(f"ObjectType {type_id} references unknown rule {rule_id}")
    
    def _check_scenarios(self):
        """Vérifie les scénarios."""
        for scn_id, scenario in self.manifest.scenarios_gevr.items():
            if not scenario.steps:
                self.warnings.append(f"Scenario {scn_id} has no steps")
    
    def report(self) -> Dict:
        """Génère un rapport de validation."""
        return {
            "valid": len(self.errors) == 0,
            "errors": self.errors,
            "warnings": self.warnings,
            "stats": {
                "errorCount": len(self.errors),
                "warningCount": len(self.warnings)
            }
        }


# =============================================================================
# EXCEPTIONS
# =============================================================================

class ManifestValidationError(Exception):
    """Erreur de validation du manifest."""
    
    def __init__(self, errors: List[str]):
        self.errors = errors
        super().__init__(f"Manifest validation failed: {errors}")


# =============================================================================
# FONCTIONS UTILITAIRES
# =============================================================================

def export_manifest(fractale: Any, **kwargs) -> str:
    """
    Fonction helper pour export rapide.
    
    Args:
        fractale: Store ou objet fractale
        **kwargs: Options d'export
        
    Returns:
        JSON du manifest
    """
    options = ExportOptions(**kwargs)
    exporter = ManifestExporter(fractale)
    return exporter.export_manifest(options)


def export_manifest_to_file(fractale: Any, filepath: str, **kwargs) -> None:
    """Exporte directement vers un fichier."""
    manifest_json = export_manifest(fractale, **kwargs)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(manifest_json)


def import_manifest(source: Union[str, Dict, Path]) -> ManifestFractal:
    """
    Fonction helper pour import rapide.
    
    Args:
        source: JSON string, dict, ou Path
        
    Returns:
        ManifestFractal
    """
    if isinstance(source, Path):
        return ManifestImporter.import_from_file(source)
    return ManifestImporter.import_manifest(source)


def validate_manifest(manifest: ManifestFractal) -> Dict:
    """Valide un manifest et retourne le rapport."""
    validator = ManifestValidator(manifest)
    validator.validate()
    return validator.report()


def create_minimal_manifest() -> ManifestFractal:
    """Crée un manifest minimal valide."""
    manifest = ManifestFractal()
    
    # ObjectType minimal
    manifest.object_types["BaseObject"] = ObjectTypeSpec(
        id="ot_base_object",
        name="BaseObject",
        ivc=IVCConfig(),
        dro=DROConfig()
    )
    
    manifest.update_stats()
    manifest.meta.checksum = manifest.compute_checksum()
    
    return manifest


# =============================================================================
# POINT D'ENTRÉE CLI
# =============================================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python manifest_fractal.py <command> [args]")
        print("Commands:")
        print("  validate <file.json>  - Validate a manifest file")
        print("  minimal               - Generate minimal manifest")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "validate" and len(sys.argv) > 2:
        filepath = sys.argv[2]
        manifest = import_manifest(Path(filepath))
        report = validate_manifest(manifest)
        print(json.dumps(report, indent=2))
        sys.exit(0 if report["valid"] else 1)
    
    elif command == "minimal":
        manifest = create_minimal_manifest()
        print(manifest.to_json())
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
