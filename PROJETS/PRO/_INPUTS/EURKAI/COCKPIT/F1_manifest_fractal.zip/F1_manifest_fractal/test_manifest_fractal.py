"""
EUREKAI F1/4 — Tests du Manifest Fractal
========================================
Tests unitaires et d'intégration pour le format d'export.

Couvre:
- Structure du manifest
- Export/Import (roundtrip)
- Validation de cohérence
- Filtrage et options
- Compatibilité C2/C3
"""

import pytest
import json
from datetime import datetime, timezone
from pathlib import Path

from manifest_fractal import (
    # Classes principales
    ManifestFractal, ManifestMeta, ManifestExporter, ManifestImporter,
    ManifestValidator, ManifestValidationError,
    
    # Specs
    ObjectTypeSpec, LineageSpec, ObjectSpec, IVCConfig, DROConfig,
    BundleAttributeSpec, BundleMethodSpec, BundleRuleSpec, BundleRelationSpec,
    ScenarioGEVRSpec, WorkflowSpec, MetaRuleSpec, SuperToolSpec,
    TagSpec, CategorySpec,
    
    # Options et enums
    ExportOptions, ExportScope, RelationType, Severity, RuleCategory,
    
    # Helpers
    export_manifest, import_manifest, validate_manifest, create_minimal_manifest,
    
    # Constantes
    MANIFEST_VERSION, SCHEMA_URL
)


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture
def minimal_manifest():
    """Manifest minimal valide."""
    return create_minimal_manifest()


@pytest.fixture
def complete_manifest():
    """Manifest complet avec tous les éléments."""
    manifest = ManifestFractal()
    
    # ObjectTypes
    manifest.object_types["Agent"] = ObjectTypeSpec(
        id="ot_agent",
        name="Agent",
        ivc=IVCConfig(
            identity={"required": ["name", "role"], "unique": ["id"]},
            view={"default": "card", "available": ["card", "detail", "graph"]},
            context={"scopes": ["global", "project"]}
        ),
        dro=DROConfig(
            definition={"extends": "BaseEntity", "abstract": False},
            rules=["rule_agent_status"],
            options={"auditable": True, "versionable": True}
        ),
        schema={
            "properties": {
                "name": {"type": "string"},
                "role": {"type": "string", "enum": ["analyzer", "executor", "validator"]},
                "status": {"type": "string", "enum": ["active", "paused", "retired"]}
            },
            "required": ["name", "role"]
        }
    )
    
    manifest.object_types["Task"] = ObjectTypeSpec(
        id="ot_task",
        name="Task",
        ivc=IVCConfig(
            identity={"required": ["title"], "unique": ["id"]},
            view={"default": "list"},
            context={"scopes": ["project", "task"]}
        ),
        dro=DROConfig(
            definition={"extends": None},
            rules=["rule_task_status"],
            options={"auditable": True}
        )
    )
    
    # Lineages
    manifest.lineages["lin_agent_hierarchy"] = LineageSpec(
        id="lin_agent_hierarchy",
        root_type="Agent",
        inheritance=["BaseEntity", "Auditable"],
        depth=3,
        members=["Agent", "Supervisor", "Orchestrator"],
        rules={"propagation": "cascade", "override": "explicit"}
    )
    
    # Objects
    manifest.objects["agent_alpha"] = ObjectSpec(
        id="agent_alpha",
        object_type="Agent",
        lineage="lin_agent_hierarchy",
        data={
            "name": "Agent Alpha",
            "role": "analyzer",
            "status": "active"
        },
        bundles={
            "attributes": ["attr_agent_core"],
            "methods": ["meth_analyze"],
            "rules": ["rule_agent_status"]
        },
        relations=[
            {"type": "supervises", "target": "agent_beta"}
        ],
        meta={
            "createdAt": "2025-02-01T09:00:00Z",
            "updatedAt": "2025-05-20T14:30:00Z",
            "version": 5,
            "tags": ["core", "production"]
        }
    )
    
    manifest.objects["agent_beta"] = ObjectSpec(
        id="agent_beta",
        object_type="Agent",
        lineage="lin_agent_hierarchy",
        data={
            "name": "Agent Beta",
            "role": "executor",
            "status": "active"
        },
        relations=[
            {"type": "supervisedBy", "target": "agent_alpha"}
        ],
        meta={
            "createdAt": "2025-02-15T10:00:00Z",
            "updatedAt": "2025-05-18T11:00:00Z",
            "version": 3,
            "tags": ["executor"]
        }
    )
    
    manifest.objects["task_1"] = ObjectSpec(
        id="task_1",
        object_type="Task",
        data={"title": "Analyze code", "status": "todo"},
        relations=[
            {"type": "assignedTo", "target": "agent_alpha"}
        ],
        meta={"tags": ["urgent"]}
    )
    
    # Bundle Attributes
    manifest.bundle_attributes["attr_agent_core"] = BundleAttributeSpec(
        id="attr_agent_core",
        applies_to=["Agent"],
        properties={
            "capabilities": {"type": "array", "items": "string"},
            "maxConcurrency": {"type": "integer", "default": 5}
        }
    )
    
    # Bundle Methods
    manifest.bundle_methods["meth_analyze"] = BundleMethodSpec(
        id="meth_analyze",
        signature="analyze(input: Object) -> AnalysisResult",
        gevr={
            "get": {"sources": ["input"], "validation": "schema"},
            "execute": {"handler": "analyze_handler", "timeout": 30000},
            "validate": {"schema": "AnalysisResult", "rules": ["non_empty"]},
            "render": {"format": "json"}
        }
    )
    
    # Bundle Rules
    manifest.bundle_rules["rule_agent_status"] = BundleRuleSpec(
        id="rule_agent_status",
        rule_type="validation",
        condition="object.status in ['active', 'paused', 'retired']",
        message="Invalid agent status",
        severity=Severity.ERROR,
        category=RuleCategory.CONSISTENCY
    )
    
    manifest.bundle_rules["rule_task_status"] = BundleRuleSpec(
        id="rule_task_status",
        rule_type="validation",
        condition="object.status in ['todo', 'doing', 'done']",
        message="Invalid task status",
        severity=Severity.ERROR
    )
    
    # Bundle Relations
    manifest.bundle_relations["rel_supervises"] = BundleRelationSpec(
        id="rel_supervises",
        name="supervises",
        source_type="Agent",
        target_type="Agent",
        cardinality="1:N",
        bidirectional=True,
        inverse="supervisedBy"
    )
    
    # Scenarios GEVR
    manifest.scenarios_gevr["scn_task_execution"] = ScenarioGEVRSpec(
        id="scn_task_execution",
        name="Task Execution Pipeline",
        trigger={"event": "task.created", "condition": "task.auto_execute"},
        steps=[
            {"phase": "get", "action": "fetchTaskDependencies", "timeout": 5000},
            {"phase": "execute", "action": "runTaskHandler", "retry": {"attempts": 3}},
            {"phase": "validate", "action": "validateOutput", "schema": "TaskResult"},
            {"phase": "render", "action": "formatResult", "output": ["log", "notification"]}
        ],
        on_error={"action": "notifyFailure", "rollback": True}
    )
    
    # Workflows
    manifest.workflows["wf_deployment"] = WorkflowSpec(
        id="wf_deployment",
        states=["draft", "review", "approved", "deployed"],
        transitions=[
            {"from": "draft", "to": "review", "action": "submitForReview"},
            {"from": "review", "to": "approved", "action": "approve"},
            {"from": "approved", "to": "deployed", "action": "deploy"}
        ]
    )
    
    # MetaRules (C2)
    manifest.meta_rules["mr_naming_convention"] = MetaRuleSpec(
        id="mr_naming_convention",
        name="Naming Convention",
        scope="global",
        applies="objectTypes",
        rule="name must match /^[A-Z][a-zA-Z0-9]*$/",
        enforcement="strict",
        message="ObjectType names must be PascalCase"
    )
    
    manifest.meta_rules["mr_mandatory_audit"] = MetaRuleSpec(
        id="mr_mandatory_audit",
        name="Mandatory Audit",
        scope="lineage:auditable",
        applies="objects",
        rule="must have createdAt and updatedAt",
        enforcement="strict"
    )
    
    # SuperTools
    manifest.super_tools["st_code_generator"] = SuperToolSpec(
        id="st_code_generator",
        name="Code Generator",
        tool_type="generator",
        config={"templates": ["python", "typescript"], "outputDir": "./generated"},
        permissions=["read:objects", "write:files"],
        gevr={
            "get": {"input": "GenerationRequest"},
            "execute": {"handler": "code_gen_handler"},
            "validate": {"lint": True},
            "render": {"format": "files"}
        }
    )
    
    # Tags
    manifest.tags["tag_core"] = TagSpec(id="tag_core", name="core", color="#3B82F6")
    manifest.tags["tag_production"] = TagSpec(id="tag_production", name="production", color="#10B981")
    manifest.tags["tag_urgent"] = TagSpec(id="tag_urgent", name="urgent", color="#EF4444")
    
    # Categories
    manifest.categories["cat_agents"] = CategorySpec(
        id="cat_agents",
        name="Agents",
        parent=None,
        children=["cat_analyzers", "cat_executors"]
    )
    
    # Aliases
    manifest.aliases = {
        "Agent": ["IA", "Bot", "Worker"],
        "Task": ["Job", "Work", "Assignment"]
    }
    
    # Finalize
    manifest.build_indexes()
    manifest.update_stats()
    manifest.meta.checksum = manifest.compute_checksum()
    
    return manifest


@pytest.fixture
def sample_store():
    """Store fractal en format dictionnaire."""
    return {
        "objectTypes": {
            "Agent": {
                "name": "Agent",
                "ivc": {
                    "identity": {"required": ["name"], "unique": ["id"]},
                    "view": {"default": "card"},
                    "context": {"scopes": ["global"]}
                },
                "dro": {
                    "definition": {"extends": None},
                    "rules": [],
                    "options": {}
                },
                "schema": {}
            }
        },
        "lineages": {},
        "objects": {
            "agent_1": {
                "type": "Agent",
                "data": {"name": "Agent One"},
                "relations": [],
                "meta": {"tags": ["test"]}
            }
        },
        "bundles": {
            "attributes": {},
            "methods": {},
            "rules": {},
            "relations": {}
        },
        "scenarios": {"gevr": {}, "workflows": {}},
        "metaRules": {},
        "superTools": {},
        "taxonomie": {"tags": {}, "categories": {}, "aliases": {}}
    }


# =============================================================================
# TESTS DE STRUCTURE
# =============================================================================

class TestManifestStructure:
    """Tests de la structure du manifest."""
    
    def test_minimal_manifest_has_required_fields(self, minimal_manifest):
        """Un manifest minimal a tous les champs obligatoires."""
        data = minimal_manifest.to_dict()
        
        assert "$schema" in data
        assert "version" in data
        assert "meta" in data
        assert "fractale" in data
        assert "bundles" in data
        assert "scenarios" in data
    
    def test_manifest_version_is_set(self, minimal_manifest):
        """La version est correctement définie."""
        assert minimal_manifest.version == MANIFEST_VERSION
    
    def test_manifest_schema_url(self, minimal_manifest):
        """Le schéma URL est correct."""
        assert minimal_manifest.schema == SCHEMA_URL
    
    def test_meta_has_required_fields(self, minimal_manifest):
        """Les métadonnées ont tous les champs requis."""
        meta = minimal_manifest.meta
        
        assert meta.exported_at is not None
        assert meta.exported_by is not None
        assert meta.source_instance is not None
        assert meta.checksum is not None
    
    def test_complete_manifest_structure(self, complete_manifest):
        """Un manifest complet a toutes les sections."""
        data = complete_manifest.to_dict()
        
        # Sections principales
        assert len(data["fractale"]["objectTypes"]) > 0
        assert len(data["fractale"]["objects"]) > 0
        
        # Bundles
        assert "attributes" in data["bundles"]
        assert "methods" in data["bundles"]
        assert "rules" in data["bundles"]
        assert "relations" in data["bundles"]
        
        # Autres
        assert "metaRules" in data
        assert "superTools" in data
        assert "taxonomie" in data
        assert "indexes" in data


class TestObjectTypeSpec:
    """Tests des ObjectTypes."""
    
    def test_object_type_has_ivc(self, complete_manifest):
        """Chaque ObjectType a une config IVC."""
        for type_id, type_def in complete_manifest.object_types.items():
            assert type_def.ivc is not None
            assert "identity" in type_def.ivc.to_dict()
            assert "view" in type_def.ivc.to_dict()
            assert "context" in type_def.ivc.to_dict()
    
    def test_object_type_has_dro(self, complete_manifest):
        """Chaque ObjectType a une config DRO."""
        for type_id, type_def in complete_manifest.object_types.items():
            assert type_def.dro is not None
            assert "definition" in type_def.dro.to_dict()
            assert "rules" in type_def.dro.to_dict()
            assert "options" in type_def.dro.to_dict()
    
    def test_object_type_serialization(self):
        """Sérialisation correcte d'un ObjectType."""
        spec = ObjectTypeSpec(
            id="ot_test",
            name="TestType",
            ivc=IVCConfig(),
            dro=DROConfig()
        )
        
        data = spec.to_dict()
        assert data["id"] == "ot_test"
        assert data["name"] == "TestType"
        assert "ivc" in data
        assert "dro" in data
    
    def test_object_type_from_dict(self):
        """Désérialisation d'un ObjectType."""
        data = {
            "id": "ot_test",
            "name": "TestType",
            "ivc": {"identity": {"required": ["id"]}},
            "dro": {"definition": {"extends": None}},
            "schema": {"type": "object"}
        }
        
        spec = ObjectTypeSpec.from_dict(data)
        assert spec.id == "ot_test"
        assert spec.name == "TestType"


# =============================================================================
# TESTS D'EXPORT
# =============================================================================

class TestManifestExport:
    """Tests d'export du manifest."""
    
    def test_export_from_dict_store(self, sample_store):
        """Export depuis un store dictionnaire."""
        exporter = ManifestExporter(sample_store)
        json_str = exporter.export_manifest()
        
        data = json.loads(json_str)
        assert "$schema" in data
        assert "version" in data
        assert "Agent" in data["fractale"]["objectTypes"]
    
    def test_export_with_pretty_print(self, sample_store):
        """Export avec formatage pretty."""
        options = ExportOptions(pretty_print=True)
        exporter = ManifestExporter(sample_store)
        json_str = exporter.export_manifest(options)
        
        # Doit contenir des indentations
        assert "\n  " in json_str
    
    def test_export_without_pretty_print(self, sample_store):
        """Export sans formatage."""
        options = ExportOptions(pretty_print=False)
        exporter = ManifestExporter(sample_store)
        json_str = exporter.export_manifest(options)
        
        # Une seule ligne
        assert json_str.count("\n") == 0
    
    def test_export_with_type_filter(self, sample_store):
        """Export filtré par type."""
        # Ajouter un autre type
        sample_store["objectTypes"]["Task"] = {
            "name": "Task",
            "ivc": {},
            "dro": {},
            "schema": {}
        }
        sample_store["objects"]["task_1"] = {
            "type": "Task",
            "data": {},
            "meta": {}
        }
        
        options = ExportOptions(filter_types=["Agent"])
        exporter = ManifestExporter(sample_store)
        result = exporter.export_manifest_dict(options)
        
        # Seul Agent doit être présent
        assert "Agent" in result["fractale"]["objectTypes"]
        # Task ne doit pas être là si le filtre fonctionne sur les types
    
    def test_export_with_tag_filter(self, complete_manifest):
        """Export filtré par tag."""
        # Ce test vérifie la logique de filtrage
        options = ExportOptions(filter_tags=["production"])
        
        # Les objets avec tag "production" doivent être inclus
        filtered_objects = {
            k: v for k, v in complete_manifest.objects.items()
            if "production" in v.meta.get("tags", [])
        }
        
        assert len(filtered_objects) > 0
    
    def test_export_includes_checksum(self, sample_store):
        """Le checksum est inclus dans l'export."""
        exporter = ManifestExporter(sample_store)
        result = exporter.export_manifest_dict()
        
        assert result["meta"]["checksum"].startswith("sha256:")
    
    def test_export_includes_stats(self, complete_manifest):
        """Les statistiques sont incluses."""
        complete_manifest.update_stats()
        data = complete_manifest.to_dict()
        
        stats = data["meta"]["stats"]
        assert stats["objectTypes"] == 2
        assert stats["objects"] == 3
    
    def test_export_builds_indexes(self, complete_manifest):
        """Les index sont construits."""
        data = complete_manifest.to_dict()
        
        assert "byType" in data["indexes"]
        assert "byLineage" in data["indexes"]
        assert "byTag" in data["indexes"]
        
        # Index byType contient les bons objets
        assert "Agent" in data["indexes"]["byType"]
        assert "agent_alpha" in data["indexes"]["byType"]["Agent"]


# =============================================================================
# TESTS D'IMPORT
# =============================================================================

class TestManifestImport:
    """Tests d'import du manifest."""
    
    def test_import_from_json_string(self, complete_manifest):
        """Import depuis JSON string."""
        json_str = complete_manifest.to_json()
        imported = ManifestImporter.import_manifest(json_str)
        
        assert imported.version == complete_manifest.version
        assert len(imported.object_types) == len(complete_manifest.object_types)
    
    def test_import_from_dict(self, complete_manifest):
        """Import depuis dictionnaire."""
        data = complete_manifest.to_dict()
        imported = ManifestImporter.import_manifest(data)
        
        assert imported.version == complete_manifest.version
    
    def test_roundtrip_preserves_data(self, complete_manifest):
        """Export → Import préserve les données."""
        json_str = complete_manifest.to_json()
        imported = ManifestImporter.import_manifest(json_str)
        
        # Re-export
        json_str2 = imported.to_json()
        
        # Les deux doivent être identiques (hors meta qui change)
        data1 = json.loads(json_str)
        data2 = json.loads(json_str2)
        
        # Comparer les sections stables
        assert data1["fractale"]["objectTypes"] == data2["fractale"]["objectTypes"]
        assert data1["fractale"]["objects"] == data2["fractale"]["objects"]
    
    def test_verify_checksum_valid(self, complete_manifest):
        """Vérification de checksum valide."""
        is_valid = ManifestImporter.verify_checksum(complete_manifest)
        assert is_valid
    
    def test_verify_checksum_invalid_after_modification(self, complete_manifest):
        """Checksum invalide après modification."""
        # Modifier sans recalculer
        complete_manifest.objects["new_obj"] = ObjectSpec(
            id="new_obj",
            object_type="Agent",
            data={"name": "New"}
        )
        
        # Le checksum ne correspond plus
        is_valid = ManifestImporter.verify_checksum(complete_manifest)
        assert not is_valid


# =============================================================================
# TESTS DE VALIDATION
# =============================================================================

class TestManifestValidation:
    """Tests de validation du manifest."""
    
    def test_minimal_manifest_is_valid(self, minimal_manifest):
        """Un manifest minimal est valide."""
        validator = ManifestValidator(minimal_manifest)
        is_valid = validator.validate()
        
        assert is_valid
        assert len(validator.errors) == 0
    
    def test_complete_manifest_is_valid(self, complete_manifest):
        """Un manifest complet est valide."""
        validator = ManifestValidator(complete_manifest)
        is_valid = validator.validate()
        
        assert is_valid
        assert len(validator.errors) == 0
    
    def test_validate_detects_missing_type_reference(self):
        """Détection de référence à un type inexistant."""
        manifest = create_minimal_manifest()
        
        # Ajouter un objet avec type inexistant
        manifest.objects["bad_obj"] = ObjectSpec(
            id="bad_obj",
            object_type="NonExistentType",
            data={}
        )
        
        validator = ManifestValidator(manifest)
        validator.validate()
        
        assert len(validator.errors) > 0
        assert any("unknown type" in e for e in validator.errors)
    
    def test_validate_warns_on_unknown_relation_target(self):
        """Warning sur cible de relation inconnue."""
        manifest = create_minimal_manifest()
        
        manifest.objects["obj1"] = ObjectSpec(
            id="obj1",
            object_type="BaseObject",
            relations=[{"type": "related", "target": "non_existent"}]
        )
        
        validator = ManifestValidator(manifest)
        validator.validate()
        
        assert len(validator.warnings) > 0
    
    def test_validate_report_format(self, complete_manifest):
        """Format du rapport de validation."""
        report = validate_manifest(complete_manifest)
        
        assert "valid" in report
        assert "errors" in report
        assert "warnings" in report
        assert "stats" in report


# =============================================================================
# TESTS DE COMPATIBILITÉ C2/C3
# =============================================================================

class TestC2Compatibility:
    """Tests de compatibilité avec C2 MetaRules."""
    
    def test_metarules_structure(self, complete_manifest):
        """Les MetaRules ont la bonne structure."""
        for mr_id, mr in complete_manifest.meta_rules.items():
            data = mr.to_dict()
            
            assert "id" in data
            assert "name" in data
            assert "scope" in data
            assert "applies" in data
            assert "rule" in data
            assert "enforcement" in data
            assert "severity" in data
    
    def test_metarule_severity_values(self, complete_manifest):
        """Les sévérités sont valides."""
        valid_severities = {s.value for s in Severity}
        
        for mr in complete_manifest.meta_rules.values():
            assert mr.severity.value in valid_severities
    
    def test_metarule_category_values(self, complete_manifest):
        """Les catégories sont valides."""
        valid_categories = {c.value for c in RuleCategory}
        
        for mr in complete_manifest.meta_rules.values():
            assert mr.category.value in valid_categories


class TestC3Compatibility:
    """Tests de compatibilité avec C3 MetaRelations."""
    
    def test_relation_types_structure(self, complete_manifest):
        """Les types de relation ont la bonne structure."""
        for rel_id, rel in complete_manifest.bundle_relations.items():
            data = rel.to_dict()
            
            assert "id" in data
            assert "name" in data
            assert "sourceType" in data
            assert "targetType" in data
            assert "cardinality" in data
    
    def test_object_relations_format(self, complete_manifest):
        """Les relations d'objets ont le bon format."""
        for obj in complete_manifest.objects.values():
            for rel in obj.relations:
                assert "type" in rel
                assert "target" in rel
    
    def test_relation_type_values(self):
        """Les types de relation sont conformes à C3."""
        expected_types = {
            "depends_on", "inherits_from", "related_to",
            "composed_of", "triggers", "references", "extends"
        }
        
        actual_types = {rt.value for rt in RelationType}
        assert expected_types == actual_types


# =============================================================================
# TESTS GEVR
# =============================================================================

class TestGEVRCompliance:
    """Tests de conformité au pattern GEVR."""
    
    def test_bundle_methods_have_gevr(self, complete_manifest):
        """Les méthodes ont une config GEVR."""
        for method in complete_manifest.bundle_methods.values():
            gevr = method.gevr
            
            assert "get" in gevr
            assert "execute" in gevr
            assert "validate" in gevr
            assert "render" in gevr
    
    def test_scenarios_have_gevr_steps(self, complete_manifest):
        """Les scénarios ont des steps GEVR."""
        for scenario in complete_manifest.scenarios_gevr.values():
            phases_found = set()
            
            for step in scenario.steps:
                if "phase" in step:
                    phases_found.add(step["phase"])
            
            # Doit avoir au moins get et execute
            assert "get" in phases_found or "execute" in phases_found
    
    def test_supertools_have_gevr(self, complete_manifest):
        """Les SuperTools ont une config GEVR."""
        for tool in complete_manifest.super_tools.values():
            if tool.gevr:
                assert "get" in tool.gevr or "execute" in tool.gevr


# =============================================================================
# TESTS D'INDEXES
# =============================================================================

class TestIndexes:
    """Tests des index."""
    
    def test_index_by_type_accuracy(self, complete_manifest):
        """L'index byType est correct."""
        indexes = complete_manifest.indexes
        
        # Compter manuellement
        agents = [obj_id for obj_id, obj in complete_manifest.objects.items()
                  if obj.object_type == "Agent"]
        
        assert set(indexes["byType"].get("Agent", [])) == set(agents)
    
    def test_index_by_tag_accuracy(self, complete_manifest):
        """L'index byTag est correct."""
        indexes = complete_manifest.indexes
        
        # Objets avec tag "core"
        core_objects = [
            obj_id for obj_id, obj in complete_manifest.objects.items()
            if "core" in obj.meta.get("tags", [])
        ]
        
        assert set(indexes["byTag"].get("core", [])) == set(core_objects)
    
    def test_index_by_lineage_accuracy(self, complete_manifest):
        """L'index byLineage est correct."""
        indexes = complete_manifest.indexes
        
        # Objets dans lineage agent_hierarchy
        lineage_objects = [
            obj_id for obj_id, obj in complete_manifest.objects.items()
            if obj.lineage == "lin_agent_hierarchy"
        ]
        
        assert set(indexes["byLineage"].get("lin_agent_hierarchy", [])) == set(lineage_objects)


# =============================================================================
# TESTS HELPERS
# =============================================================================

class TestHelperFunctions:
    """Tests des fonctions utilitaires."""
    
    def test_export_manifest_helper(self, sample_store):
        """Helper export_manifest fonctionne."""
        json_str = export_manifest(sample_store)
        data = json.loads(json_str)
        
        assert "$schema" in data
    
    def test_import_manifest_helper(self, complete_manifest):
        """Helper import_manifest fonctionne."""
        json_str = complete_manifest.to_json()
        imported = import_manifest(json_str)
        
        assert imported.version == complete_manifest.version
    
    def test_validate_manifest_helper(self, complete_manifest):
        """Helper validate_manifest fonctionne."""
        report = validate_manifest(complete_manifest)
        
        assert report["valid"] is True
    
    def test_create_minimal_manifest_helper(self):
        """Helper create_minimal_manifest fonctionne."""
        manifest = create_minimal_manifest()
        
        assert manifest.version == MANIFEST_VERSION
        assert len(manifest.object_types) > 0


# =============================================================================
# TESTS DE SÉRIALISATION JSON
# =============================================================================

class TestJsonSerialization:
    """Tests de sérialisation JSON."""
    
    def test_to_json_is_valid_json(self, complete_manifest):
        """to_json produit du JSON valide."""
        json_str = complete_manifest.to_json()
        
        # Ne doit pas lever d'exception
        data = json.loads(json_str)
        assert isinstance(data, dict)
    
    def test_from_json_reconstructs_manifest(self, complete_manifest):
        """from_json reconstruit correctement."""
        json_str = complete_manifest.to_json()
        reconstructed = ManifestFractal.from_json(json_str)
        
        assert reconstructed.version == complete_manifest.version
        assert len(reconstructed.object_types) == len(complete_manifest.object_types)
    
    def test_json_encoding_utf8(self):
        """L'encodage UTF-8 fonctionne."""
        manifest = create_minimal_manifest()
        manifest.objects["test"] = ObjectSpec(
            id="test",
            object_type="BaseObject",
            data={"name": "Tâche avec accénts éè"}
        )
        
        json_str = manifest.to_json()
        assert "Tâche avec accénts éè" in json_str


# =============================================================================
# DÉMONSTRATIONS
# =============================================================================

def demo_export_complete():
    """Démonstration d'export complet."""
    print("\n" + "=" * 60)
    print("  DÉMONSTRATION: Export Manifest Complet")
    print("=" * 60)
    
    # Créer store
    store = {
        "objectTypes": {
            "Agent": {
                "name": "Agent",
                "ivc": {"identity": {"required": ["name"]}},
                "dro": {"definition": {}, "rules": [], "options": {}},
                "schema": {}
            }
        },
        "objects": {
            "agent_1": {
                "type": "Agent",
                "data": {"name": "Test Agent"},
                "meta": {"tags": ["demo"]}
            }
        },
        "bundles": {"attributes": {}, "methods": {}, "rules": {}, "relations": {}},
        "scenarios": {"gevr": {}, "workflows": {}},
        "metaRules": {},
        "superTools": {},
        "taxonomie": {"tags": {}, "categories": {}, "aliases": {}}
    }
    
    # Export
    exporter = ManifestExporter(store, instance_name="demo-instance")
    json_str = exporter.export_manifest()
    
    print("\nManifest exporté:")
    print(json_str[:500] + "...")
    print("\n✅ Export réussi!")


def demo_validation():
    """Démonstration de validation."""
    print("\n" + "=" * 60)
    print("  DÉMONSTRATION: Validation de Manifest")
    print("=" * 60)
    
    # Manifest valide
    manifest = create_minimal_manifest()
    report = validate_manifest(manifest)
    print(f"\nManifest minimal: {'✅ Valide' if report['valid'] else '❌ Invalide'}")
    
    # Manifest avec erreur
    manifest.objects["bad"] = ObjectSpec(
        id="bad",
        object_type="UnknownType",
        data={}
    )
    
    report = validate_manifest(manifest)
    print(f"Après ajout objet invalide: {'✅ Valide' if report['valid'] else '❌ Invalide'}")
    print(f"  Erreurs: {report['errors']}")


def demo_roundtrip():
    """Démonstration roundtrip export/import."""
    print("\n" + "=" * 60)
    print("  DÉMONSTRATION: Roundtrip Export/Import")
    print("=" * 60)
    
    # Créer manifest original
    original = create_minimal_manifest()
    original.objects["test"] = ObjectSpec(
        id="test",
        object_type="BaseObject",
        data={"value": 42}
    )
    original.build_indexes()
    original.update_stats()
    
    # Export
    json_str = original.to_json()
    print(f"\nOriginal: {len(original.objects)} objets")
    
    # Import
    imported = import_manifest(json_str)
    print(f"Importé: {len(imported.objects)} objets")
    
    # Vérifier intégrité
    checksum_valid = ManifestImporter.verify_checksum(original)
    print(f"Checksum valide: {'✅' if checksum_valid else '❌'}")
    
    print("\n✅ Roundtrip réussi!")


if __name__ == "__main__":
    # Exécuter les démos
    demo_export_complete()
    demo_validation()
    demo_roundtrip()
    
    # Exécuter les tests avec pytest
    print("\n" + "=" * 60)
    print("  EXÉCUTION DES TESTS")
    print("=" * 60)
    pytest.main([__file__, "-v", "--tb=short"])
