"""
EUREKAI D2/5 — Générateurs de structure projet
===============================================

Ce module génère les structures EURKAI à partir de l'analyse:
- ObjectGenerator: Génère les objets du projet
- RelationGenerator: Génère les relations entre objets
- ScenarioGenerator: Génère les scénarios associés
- ProjectGenerator: Orchestre la génération complète

Version: D2/5 - MetaScénario "Projet EURKAI"
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import uuid
import re

from .analyzers import AnalysisResult, ProjectDomain, InputType


# =============================================================================
# SCHÉMA DU PROJET EURKAI
# =============================================================================

@dataclass
class EURKAIObject:
    """Représente un objet dans la fractale EURKAI."""
    id: str
    type: str
    name: str
    bundles: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "bundles": self.bundles,
            "metadata": self.metadata
        }


@dataclass
class EURKAIRelation:
    """Représente une relation entre objets."""
    source: str
    target: str
    type: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "source": self.source,
            "target": self.target,
            "type": self.type,
            "metadata": self.metadata
        }


@dataclass
class EURKAIScenario:
    """Représente un scénario associé au projet."""
    id: str
    name: str
    description: str = ""
    type: str = "custom"  # core, analysis, build, deploy, custom
    steps_hint: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "type": self.type,
            "steps_hint": self.steps_hint
        }


@dataclass
class EURKAIProject:
    """Structure complète d'un projet EURKAI."""
    project_id: str
    name: str
    description: str = ""
    domain: str = "generic"
    
    objects: List[EURKAIObject] = field(default_factory=list)
    relations: List[EURKAIRelation] = field(default_factory=list)
    scenarios: List[EURKAIScenario] = field(default_factory=list)
    
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    version: str = "1.0.0"
    
    def to_dict(self) -> Dict:
        """Convertit en dictionnaire (format de sortie standard)."""
        return {
            "projectId": self.project_id,
            "name": self.name,
            "description": self.description,
            "domain": self.domain,
            "objects": [o.to_dict() for o in self.objects],
            "relations": [r.to_dict() for r in self.relations],
            "scenarios": [s.to_dict() for s in self.scenarios],
            "tags": self.tags,
            "metadata": {
                **self.metadata,
                "created_at": self.created_at,
                "version": self.version,
                "object_count": len(self.objects),
                "relation_count": len(self.relations),
                "scenario_count": len(self.scenarios)
            }
        }


# Schéma JSON de sortie standard
PROJET_EURKAI_OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "projectId": {"type": "string", "pattern": "^Project\\.[A-Za-z0-9_]+$"},
        "name": {"type": "string"},
        "description": {"type": "string"},
        "domain": {"type": "string", "enum": [d.value for d in ProjectDomain]},
        "objects": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "type": {"type": "string"},
                    "name": {"type": "string"},
                    "bundles": {"type": "array", "items": {"type": "string"}},
                    "metadata": {"type": "object"}
                },
                "required": ["id", "type", "name"]
            }
        },
        "relations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source": {"type": "string"},
                    "target": {"type": "string"},
                    "type": {"type": "string"}
                },
                "required": ["source", "target", "type"]
            }
        },
        "scenarios": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"},
                    "type": {"type": "string"}
                }
            }
        },
        "tags": {"type": "array", "items": {"type": "string"}},
        "metadata": {"type": "object"}
    },
    "required": ["projectId", "name", "objects"]
}


# =============================================================================
# TEMPLATES PAR DOMAINE
# =============================================================================

DOMAIN_TEMPLATES = {
    ProjectDomain.WEB: {
        "base_objects": [
            {"type": "Agent", "name": "WebAgent", "bundles": ["core", "prompt", "web"]},
            {"type": "View", "name": "MainView", "bundles": ["core", "render"]},
            {"type": "Service", "name": "ContentService", "bundles": ["core"]},
            {"type": "Config", "name": "WebConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "WebAgent", "to": "MainView", "type": "renders"},
            {"from": "WebAgent", "to": "ContentService", "type": "depends_on"},
            {"from": "WebAgent", "to": "WebConfig", "type": "references"}
        ],
        "base_scenarios": [
            {"id": "Build", "name": "Build Web", "type": "build"},
            {"id": "Deploy", "name": "Deploy Static", "type": "deploy"}
        ]
    },
    ProjectDomain.API: {
        "base_objects": [
            {"type": "Agent", "name": "APIAgent", "bundles": ["core", "prompt", "api"]},
            {"type": "Service", "name": "MainService", "bundles": ["core", "api"]},
            {"type": "Service", "name": "DataService", "bundles": ["core", "data"]},
            {"type": "Config", "name": "APIConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "APIAgent", "to": "MainService", "type": "orchestrates"},
            {"from": "MainService", "to": "DataService", "type": "depends_on"},
            {"from": "APIAgent", "to": "APIConfig", "type": "references"}
        ],
        "base_scenarios": [
            {"id": "Build", "name": "Build API", "type": "build"},
            {"id": "Test", "name": "Test Endpoints", "type": "analysis"},
            {"id": "Deploy", "name": "Deploy Service", "type": "deploy"}
        ]
    },
    ProjectDomain.SAAS: {
        "base_objects": [
            {"type": "Agent", "name": "AppAgent", "bundles": ["core", "prompt", "saas"]},
            {"type": "View", "name": "Dashboard", "bundles": ["core", "render"]},
            {"type": "View", "name": "UserProfile", "bundles": ["core", "render"]},
            {"type": "Service", "name": "AuthService", "bundles": ["core", "auth"]},
            {"type": "Service", "name": "CoreService", "bundles": ["core"]},
            {"type": "Data", "name": "UserModel", "bundles": ["data"]},
            {"type": "Config", "name": "AppConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "AppAgent", "to": "Dashboard", "type": "renders"},
            {"from": "AppAgent", "to": "AuthService", "type": "depends_on"},
            {"from": "AppAgent", "to": "CoreService", "type": "depends_on"},
            {"from": "CoreService", "to": "UserModel", "type": "uses"},
            {"from": "AuthService", "to": "UserModel", "type": "uses"}
        ],
        "base_scenarios": [
            {"id": "Build", "name": "Build App", "type": "build"},
            {"id": "Test", "name": "Integration Tests", "type": "analysis"},
            {"id": "Deploy", "name": "Deploy Cloud", "type": "deploy"}
        ]
    },
    ProjectDomain.AGENT: {
        "base_objects": [
            {"type": "Agent", "name": "OrchestratorAgent", "bundles": ["core", "prompt", "orchestration"]},
            {"type": "Agent", "name": "WorkerAgent", "bundles": ["core", "prompt"]},
            {"type": "Service", "name": "PromptService", "bundles": ["core", "prompt"]},
            {"type": "Service", "name": "MemoryService", "bundles": ["core", "memory"]},
            {"type": "Config", "name": "AgentConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "OrchestratorAgent", "to": "WorkerAgent", "type": "orchestrates"},
            {"from": "OrchestratorAgent", "to": "PromptService", "type": "depends_on"},
            {"from": "WorkerAgent", "to": "MemoryService", "type": "depends_on"}
        ],
        "base_scenarios": [
            {"id": "Analyze", "name": "Analyze Agents", "type": "analysis"},
            {"id": "Build", "name": "Build Agents", "type": "build"},
            {"id": "Run", "name": "Run Orchestration", "type": "custom"}
        ]
    },
    ProjectDomain.DATA: {
        "base_objects": [
            {"type": "Agent", "name": "DataAgent", "bundles": ["core", "prompt", "data"]},
            {"type": "Service", "name": "ExtractService", "bundles": ["core", "etl"]},
            {"type": "Service", "name": "TransformService", "bundles": ["core", "etl"]},
            {"type": "Service", "name": "LoadService", "bundles": ["core", "etl"]},
            {"type": "Data", "name": "DataModel", "bundles": ["data", "schema"]},
            {"type": "Config", "name": "PipelineConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "DataAgent", "to": "ExtractService", "type": "orchestrates"},
            {"from": "ExtractService", "to": "TransformService", "type": "pipes_to"},
            {"from": "TransformService", "to": "LoadService", "type": "pipes_to"},
            {"from": "LoadService", "to": "DataModel", "type": "writes_to"}
        ],
        "base_scenarios": [
            {"id": "Build", "name": "Build Pipeline", "type": "build"},
            {"id": "Run", "name": "Run ETL", "type": "custom"},
            {"id": "Validate", "name": "Validate Data", "type": "analysis"}
        ]
    },
    ProjectDomain.LABO: {
        "base_objects": [
            {"type": "Agent", "name": "ExperimentAgent", "bundles": ["core", "prompt", "experiment"]},
            {"type": "Service", "name": "ExperimentService", "bundles": ["core"]},
            {"type": "Data", "name": "ResultsModel", "bundles": ["data"]},
            {"type": "Config", "name": "LabConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "ExperimentAgent", "to": "ExperimentService", "type": "runs"},
            {"from": "ExperimentService", "to": "ResultsModel", "type": "produces"}
        ],
        "base_scenarios": [
            {"id": "Setup", "name": "Setup Experiment", "type": "build"},
            {"id": "Run", "name": "Run Experiment", "type": "custom"},
            {"id": "Analyze", "name": "Analyze Results", "type": "analysis"}
        ]
    },
    ProjectDomain.TOOL: {
        "base_objects": [
            {"type": "Agent", "name": "ToolAgent", "bundles": ["core", "prompt"]},
            {"type": "Service", "name": "MainService", "bundles": ["core"]},
            {"type": "Config", "name": "ToolConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "ToolAgent", "to": "MainService", "type": "uses"},
            {"from": "ToolAgent", "to": "ToolConfig", "type": "references"}
        ],
        "base_scenarios": [
            {"id": "Build", "name": "Build Tool", "type": "build"},
            {"id": "Test", "name": "Test Tool", "type": "analysis"}
        ]
    },
    ProjectDomain.GAME: {
        "base_objects": [
            {"type": "Agent", "name": "GameAgent", "bundles": ["core", "prompt", "game"]},
            {"type": "View", "name": "GameView", "bundles": ["core", "render"]},
            {"type": "Service", "name": "GameEngine", "bundles": ["core", "game"]},
            {"type": "Data", "name": "GameState", "bundles": ["data"]},
            {"type": "Config", "name": "GameConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "GameAgent", "to": "GameView", "type": "renders"},
            {"from": "GameAgent", "to": "GameEngine", "type": "orchestrates"},
            {"from": "GameEngine", "to": "GameState", "type": "manages"}
        ],
        "base_scenarios": [
            {"id": "Build", "name": "Build Game", "type": "build"},
            {"id": "Run", "name": "Run Game", "type": "custom"}
        ]
    },
    ProjectDomain.GENERIC: {
        "base_objects": [
            {"type": "Agent", "name": "MainAgent", "bundles": ["core", "prompt"]},
            {"type": "Service", "name": "MainService", "bundles": ["core"]},
            {"type": "Config", "name": "ProjectConfig", "bundles": ["config"]}
        ],
        "base_relations": [
            {"from": "MainAgent", "to": "MainService", "type": "depends_on"},
            {"from": "MainAgent", "to": "ProjectConfig", "type": "references"}
        ],
        "base_scenarios": [
            {"id": "Build", "name": "Build Project", "type": "build"},
            {"id": "Analyze", "name": "Analyze Project", "type": "analysis"}
        ]
    }
}


# =============================================================================
# GÉNÉRATEUR D'OBJETS
# =============================================================================

class ObjectGenerator:
    """Génère les objets EURKAI à partir de l'analyse."""
    
    def __init__(self, project_name: str, domain: ProjectDomain):
        self.project_name = project_name
        self.project_id = f"Project.{self._sanitize_name(project_name)}"
        self.domain = domain
        self.logs: List[str] = []
    
    def generate(self, analysis: AnalysisResult) -> List[EURKAIObject]:
        """
        Génère les objets du projet.
        
        Combine:
        - Objets de base du template de domaine
        - Objets déduits des hints d'analyse
        - Objets du schéma partiel (si fourni)
        """
        objects = []
        
        # 1. Objets de base du domaine
        template = DOMAIN_TEMPLATES.get(self.domain, DOMAIN_TEMPLATES[ProjectDomain.GENERIC])
        for base_obj in template["base_objects"]:
            obj = self._create_object(
                obj_type=base_obj["type"],
                name=base_obj["name"],
                bundles=base_obj.get("bundles", ["core"]),
                source="template"
            )
            objects.append(obj)
            self._log(f"Objet template créé: {obj.id}")
        
        # 2. Objets depuis les hints d'analyse
        for hint in analysis.object_hints:
            # Vérifier si un objet similaire existe déjà
            if not self._object_exists(objects, hint.get("type"), hint.get("name_hint")):
                obj = self._create_object(
                    obj_type=hint.get("type", "Object"),
                    name=hint.get("name_hint", "Custom"),
                    bundles=hint.get("bundles", ["core"]),
                    source="analysis"
                )
                objects.append(obj)
                self._log(f"Objet depuis analyse créé: {obj.id}")
        
        # 3. Objets depuis le schéma partiel
        if analysis.partial_schema:
            for schema_obj in analysis.partial_schema.get("objects", []):
                existing = self._find_object_by_name(objects, schema_obj.get("name"))
                if existing:
                    # Fusionner les bundles
                    existing.bundles = list(set(existing.bundles + schema_obj.get("bundles", [])))
                    existing.metadata.update(schema_obj.get("metadata", {}))
                else:
                    obj = self._create_object(
                        obj_type=schema_obj.get("type", "Object"),
                        name=schema_obj.get("name", "Imported"),
                        bundles=schema_obj.get("bundles", ["core"]),
                        source="schema"
                    )
                    obj.metadata = schema_obj.get("metadata", {})
                    objects.append(obj)
                    self._log(f"Objet depuis schéma créé: {obj.id}")
        
        return objects
    
    def _create_object(
        self,
        obj_type: str,
        name: str,
        bundles: List[str],
        source: str = "generated"
    ) -> EURKAIObject:
        """Crée un objet EURKAI."""
        clean_name = self._sanitize_name(name)
        obj_id = f"{obj_type}.{self.project_id.replace('Project.', '')}.{clean_name}"
        
        return EURKAIObject(
            id=obj_id,
            type=obj_type,
            name=name,
            bundles=bundles,
            metadata={"source": source}
        )
    
    def _object_exists(self, objects: List[EURKAIObject], obj_type: str, name_hint: str) -> bool:
        """Vérifie si un objet similaire existe."""
        for obj in objects:
            if obj.type == obj_type:
                # Vérifier similarité du nom
                if name_hint and name_hint.lower() in obj.name.lower():
                    return True
        return False
    
    def _find_object_by_name(self, objects: List[EURKAIObject], name: str) -> Optional[EURKAIObject]:
        """Trouve un objet par son nom."""
        for obj in objects:
            if obj.name.lower() == name.lower():
                return obj
        return None
    
    def _sanitize_name(self, name: str) -> str:
        """Nettoie un nom pour l'utiliser comme identifiant."""
        # Supprimer les accents et caractères spéciaux
        clean = re.sub(r"[^A-Za-z0-9]", "", name)
        return clean[:30] if clean else "Unknown"
    
    def _log(self, message: str):
        self.logs.append(message)


# =============================================================================
# GÉNÉRATEUR DE RELATIONS
# =============================================================================

class RelationGenerator:
    """Génère les relations entre objets EURKAI."""
    
    def __init__(self, project_name: str, domain: ProjectDomain):
        self.project_name = project_name
        self.domain = domain
        self.logs: List[str] = []
    
    def generate(
        self,
        objects: List[EURKAIObject],
        analysis: AnalysisResult
    ) -> List[EURKAIRelation]:
        """
        Génère les relations entre objets.
        
        Combine:
        - Relations de base du template de domaine
        - Relations depuis les hints d'analyse
        - Relations du schéma partiel
        - Relations inférées (Agent → Config, Service → Data)
        """
        relations = []
        obj_map = {obj.name: obj.id for obj in objects}
        obj_id_map = {obj.id: obj for obj in objects}
        
        # 1. Relations de base du domaine
        template = DOMAIN_TEMPLATES.get(self.domain, DOMAIN_TEMPLATES[ProjectDomain.GENERIC])
        for base_rel in template["base_relations"]:
            source_id = obj_map.get(base_rel["from"])
            target_id = obj_map.get(base_rel["to"])
            if source_id and target_id:
                rel = EURKAIRelation(
                    source=source_id,
                    target=target_id,
                    type=base_rel["type"],
                    metadata={"source": "template"}
                )
                relations.append(rel)
                self._log(f"Relation template: {base_rel['from']} → {base_rel['to']}")
        
        # 2. Relations depuis les hints
        for hint in analysis.relation_hints:
            source_id = self._resolve_id(hint.get("source", ""), obj_map)
            target_id = self._resolve_id(hint.get("target", ""), obj_map)
            if source_id and target_id:
                rel = EURKAIRelation(
                    source=source_id,
                    target=target_id,
                    type=hint.get("type", "references"),
                    metadata={"source": "analysis"}
                )
                relations.append(rel)
        
        # 3. Relations depuis le schéma partiel
        if analysis.partial_schema:
            for schema_rel in analysis.partial_schema.get("relations", []):
                source_id = self._resolve_id(schema_rel.get("source") or schema_rel.get("from", ""), obj_map)
                target_id = self._resolve_id(schema_rel.get("target") or schema_rel.get("to", ""), obj_map)
                if source_id and target_id:
                    if not self._relation_exists(relations, source_id, target_id):
                        rel = EURKAIRelation(
                            source=source_id,
                            target=target_id,
                            type=schema_rel.get("type", "references"),
                            metadata={"source": "schema"}
                        )
                        relations.append(rel)
        
        # 4. Relations inférées
        config_objs = [o for o in objects if o.type == "Config"]
        agent_objs = [o for o in objects if o.type == "Agent"]
        
        for agent in agent_objs:
            for config in config_objs:
                if not self._relation_exists(relations, agent.id, config.id):
                    rel = EURKAIRelation(
                        source=agent.id,
                        target=config.id,
                        type="references",
                        metadata={"source": "inferred"}
                    )
                    relations.append(rel)
                    self._log(f"Relation inférée: {agent.name} → {config.name}")
        
        return relations
    
    def _resolve_id(self, name_or_id: str, obj_map: Dict[str, str]) -> Optional[str]:
        """Résout un nom ou ID vers l'ID complet."""
        if name_or_id in obj_map:
            return obj_map[name_or_id]
        # Chercher par ID partiel
        for name, obj_id in obj_map.items():
            if name_or_id in obj_id or name_or_id.lower() in name.lower():
                return obj_id
        return None
    
    def _relation_exists(
        self,
        relations: List[EURKAIRelation],
        source: str,
        target: str
    ) -> bool:
        """Vérifie si une relation existe déjà."""
        for rel in relations:
            if rel.source == source and rel.target == target:
                return True
        return False
    
    def _log(self, message: str):
        self.logs.append(message)


# =============================================================================
# GÉNÉRATEUR DE SCÉNARIOS
# =============================================================================

class ScenarioGenerator:
    """Génère les scénarios associés au projet."""
    
    def __init__(self, project_name: str, domain: ProjectDomain):
        self.project_name = project_name
        self.project_id = f"Project.{project_name}"
        self.domain = domain
        self.logs: List[str] = []
    
    def generate(
        self,
        objects: List[EURKAIObject],
        analysis: AnalysisResult
    ) -> List[EURKAIScenario]:
        """
        Génère les scénarios du projet.
        
        Inclut:
        - Scénarios de base du template de domaine
        - Scénarios personnalisés selon les features
        """
        scenarios = []
        
        # 1. Scénarios de base du domaine
        template = DOMAIN_TEMPLATES.get(self.domain, DOMAIN_TEMPLATES[ProjectDomain.GENERIC])
        for base_scen in template["base_scenarios"]:
            scen = EURKAIScenario(
                id=f"Scenario.{self.project_name}.{base_scen['id']}",
                name=base_scen["name"],
                type=base_scen["type"],
                steps_hint=self._generate_steps_hint(base_scen["type"], objects)
            )
            scenarios.append(scen)
            self._log(f"Scénario template: {scen.name}")
        
        # 2. Scénario d'analyse (toujours présent)
        if not any(s.type == "analysis" for s in scenarios):
            analyze_scen = EURKAIScenario(
                id=f"Scenario.{self.project_name}.Analyze",
                name="Analyse du projet",
                description="Analyse la structure et la cohérence du projet",
                type="analysis",
                steps_hint=["loadProject", "runMetaRules", "validateSchema", "renderReport"]
            )
            scenarios.append(analyze_scen)
        
        # 3. Scénarios depuis les features
        for feature in analysis.features[:3]:  # Max 3 scénarios custom
            scen = EURKAIScenario(
                id=f"Scenario.{self.project_name}.Feature_{len(scenarios)}",
                name=f"Feature: {feature[:50]}",
                description=feature,
                type="custom",
                steps_hint=["loadContext", "executeFeature", "validate", "render"]
            )
            scenarios.append(scen)
        
        return scenarios
    
    def _generate_steps_hint(self, scenario_type: str, objects: List[EURKAIObject]) -> List[str]:
        """Génère les étapes suggérées selon le type de scénario."""
        if scenario_type == "build":
            return ["loadTemplate", "createStructure", "validateStructure", "renderSkeleton"]
        elif scenario_type == "analysis":
            return ["loadObject", "runMetaRules", "applyERK", "renderAnalysis"]
        elif scenario_type == "deploy":
            return ["loadConfig", "prepareDeployment", "validate", "deploy", "renderStatus"]
        else:
            return ["loadContext", "execute", "validate", "render"]
    
    def _log(self, message: str):
        self.logs.append(message)


# =============================================================================
# GÉNÉRATEUR DE PROJET COMPLET
# =============================================================================

class ProjectGenerator:
    """
    Générateur principal qui orchestre la création d'un projet EURKAI complet.
    """
    
    def __init__(self, options: Dict[str, Any] = None):
        self.options = options or {}
        self.logs: List[str] = []
    
    def generate(self, analysis: AnalysisResult) -> EURKAIProject:
        """
        Génère un projet EURKAI complet à partir de l'analyse.
        
        Args:
            analysis: Résultat de l'analyse d'entrée
            
        Returns:
            EURKAIProject complet
        """
        project_name = analysis.name_hint or "NewProject"
        domain = analysis.domain
        
        self._log(f"Génération du projet: {project_name} (domaine: {domain.value})")
        
        # 1. Générer les objets
        obj_gen = ObjectGenerator(project_name, domain)
        objects = obj_gen.generate(analysis)
        self.logs.extend(obj_gen.logs)
        self._log(f"Objets générés: {len(objects)}")
        
        # 2. Générer les relations
        rel_gen = RelationGenerator(project_name, domain)
        relations = rel_gen.generate(objects, analysis)
        self.logs.extend(rel_gen.logs)
        self._log(f"Relations générées: {len(relations)}")
        
        # 3. Générer les scénarios
        scen_gen = ScenarioGenerator(project_name, domain)
        scenarios = scen_gen.generate(objects, analysis)
        self.logs.extend(scen_gen.logs)
        self._log(f"Scénarios générés: {len(scenarios)}")
        
        # 4. Assembler le projet
        project = EURKAIProject(
            project_id=f"Project.{self._sanitize_name(project_name)}",
            name=project_name,
            description=analysis.description,
            domain=domain.value,
            objects=objects,
            relations=relations,
            scenarios=scenarios,
            tags=analysis.tags,
            metadata={
                "input_type": analysis.input_type.value,
                "confidence": analysis.confidence,
                "features": analysis.features,
                "constraints": analysis.constraints,
                "generation_logs": self.logs
            }
        )
        
        self._log(f"Projet généré: {project.project_id}")
        
        return project
    
    def _sanitize_name(self, name: str) -> str:
        """Nettoie un nom pour l'utiliser comme identifiant."""
        clean = re.sub(r"[^A-Za-z0-9]", "", name)
        return clean[:30] if clean else "Unknown"
    
    def _log(self, message: str):
        self.logs.append(message)
