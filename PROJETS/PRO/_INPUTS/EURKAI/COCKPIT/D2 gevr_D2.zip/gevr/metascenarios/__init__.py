"""
EUREKAI D2/5 — MetaScénarios
============================

Ce module expose les MetaScénarios EUREKAI:
- MetaScenario.ProjetEURKAI: Transforme une idée en projet structuré

Version: D2/5 - MetaScénario "Projet EURKAI"
"""

from .projet_eurkai import (
    MetaScenarioProjetEURKAI,
    create_projet_eurkai_metascenario,
    PROJET_EURKAI_SCHEMA,
    register_projet_eurkai
)

from .analyzers import (
    InputAnalyzer,
    InputType,
    AnalysisResult
)

from .generators import (
    ObjectGenerator,
    RelationGenerator,
    ScenarioGenerator,
    ProjectGenerator
)

__all__ = [
    # MetaScénario principal
    "MetaScenarioProjetEURKAI",
    "create_projet_eurkai_metascenario",
    "PROJET_EURKAI_SCHEMA",
    "register_projet_eurkai",
    
    # Analyzers
    "InputAnalyzer",
    "InputType",
    "AnalysisResult",
    
    # Generators
    "ObjectGenerator",
    "RelationGenerator",
    "ScenarioGenerator",
    "ProjectGenerator"
]
