"""
EUREKAI D2/5 — MetaScénario "Projet EURKAI"
============================================

Ce module définit le MetaScénario central qui transforme une idée,
un brief ou un schéma en une structure de projet EURKAI complète.

Pipeline GEVR:
- GET: Analyser l'entrée, détecter le type, extraire les éléments
- EXECUTE: Générer les objets, relations, scénarios
- VALIDATE: Vérifier la cohérence, valider contre le schéma
- RENDER: Produire la structure finale du projet

Version: D2/5 - MetaScénario "Projet EURKAI"
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import json
import sys
import os

# Ajouter le chemin pour les imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Imports locaux
from .analyzers import InputAnalyzer, InputType, AnalysisResult, ProjectDomain
from .generators import (
    ProjectGenerator, EURKAIProject, EURKAIObject,
    EURKAIRelation, EURKAIScenario, PROJET_EURKAI_OUTPUT_SCHEMA
)


# =============================================================================
# SCHÉMA DE SORTIE STANDARD
# =============================================================================

PROJET_EURKAI_SCHEMA = PROJET_EURKAI_OUTPUT_SCHEMA


# =============================================================================
# RÉSULTAT DU METASCÉNARIO
# =============================================================================

@dataclass
class MetaScenarioResult:
    """Résultat d'exécution du MetaScénario."""
    status: str  # "success", "partial", "failed"
    project: Optional[EURKAIProject] = None
    
    # Résultats par phase
    get_result: Dict[str, Any] = field(default_factory=dict)
    execute_result: Dict[str, Any] = field(default_factory=dict)
    validate_result: Dict[str, Any] = field(default_factory=dict)
    render_result: Dict[str, Any] = field(default_factory=dict)
    
    # Logs et erreurs
    logs: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Métriques
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict:
        """Convertit en dictionnaire."""
        return {
            "status": self.status,
            "project": self.project.to_dict() if self.project else None,
            "phases": {
                "GET": self.get_result,
                "EXECUTE": self.execute_result,
                "VALIDATE": self.validate_result,
                "RENDER": self.render_result
            },
            "logs": self.logs,
            "errors": self.errors,
            "warnings": self.warnings,
            "duration_ms": self.duration_ms,
            "timestamp": self.started_at.isoformat()
        }
    
    @property
    def duration_ms(self) -> float:
        """Durée en millisecondes."""
        if not self.completed_at:
            return 0
        delta = self.completed_at - self.started_at
        return delta.total_seconds() * 1000
    
    @property
    def ok(self) -> bool:
        return self.status == "success"


# =============================================================================
# METASCÉNARIO "PROJET EURKAI"
# =============================================================================

class MetaScenarioProjetEURKAI:
    """
    MetaScénario principal: Idée → Projet EURKAI structuré.
    
    Ce MetaScénario orchestre la transformation d'une entrée
    (phrase, brief, schéma) en une structure de projet complète
    compatible avec la fractale EURKAI.
    
    Phases GEVR:
    
    GET (Analyse):
        - Détecte le type d'entrée
        - Extrait le domaine, les features, les contraintes
        - Identifie les hints d'objets et relations
        
    EXECUTE (Génération):
        - Génère les objets selon le template de domaine
        - Crée les relations entre objets
        - Définit les scénarios associés
        
    VALIDATE (Vérification):
        - Valide la cohérence des relations
        - Vérifie les cycles potentiels
        - Contrôle le schéma de sortie
        
    RENDER (Production):
        - Assemble la structure finale
        - Produit le JSON canonique du projet
        - Génère le rapport de création
    """
    
    ID = "MetaScenario.ProjetEURKAI"
    NAME = "Projet EURKAI"
    VERSION = "1.0.0"
    
    def __init__(self, options: Dict[str, Any] = None):
        """
        Initialise le MetaScénario.
        
        Args:
            options: Options de configuration
                - strict: Mode strict de validation (default: False)
                - include_logs: Inclure les logs détaillés (default: True)
                - auto_fix: Corriger automatiquement les problèmes (default: True)
        """
        self.options = options or {}
        self.strict = self.options.get("strict", False)
        self.include_logs = self.options.get("include_logs", True)
        self.auto_fix = self.options.get("auto_fix", True)
        
        # Composants
        self.analyzer = InputAnalyzer(options)
        self.generator = ProjectGenerator(options)
        
        # État
        self._logs: List[str] = []
        self._errors: List[str] = []
        self._warnings: List[str] = []
    
    def run(self, input_data: Any) -> MetaScenarioResult:
        """
        Exécute le MetaScénario complet.
        
        Args:
            input_data: Entrée (phrase, brief, dict, ou schéma JSON)
            
        Returns:
            MetaScenarioResult avec le projet généré
        """
        result = MetaScenarioResult(status="running")
        self._logs = []
        self._errors = []
        self._warnings = []
        
        self._log(f"[META] Démarrage MetaScénario: {self.NAME}")
        
        try:
            # Phase GET: Analyse
            self._log("[GET] Phase GET: Analyse de l'entrée")
            get_result = self._phase_get(input_data)
            result.get_result = get_result
            
            if not get_result.get("success"):
                result.status = "failed"
                result.errors = self._errors
                result.completed_at = datetime.now()
                return result
            
            analysis = get_result["analysis"]
            self._log(f"[GET] Type détecté: {analysis.input_type.value}")
            self._log(f"[GET] Domaine: {analysis.domain.value}")
            self._log(f"[GET] Confiance: {analysis.confidence:.2f}")
            
            # Phase EXECUTE: Génération
            self._log("[EXECUTE] Phase EXECUTE: Génération du projet")
            execute_result = self._phase_execute(analysis)
            result.execute_result = execute_result
            
            if not execute_result.get("success"):
                result.status = "partial"
                result.errors = self._errors
                result.completed_at = datetime.now()
                return result
            
            project = execute_result["project"]
            self._log(f"[EXECUTE] Projet: {project.project_id}")
            self._log(f"[EXECUTE] Objets: {len(project.objects)}")
            self._log(f"[EXECUTE] Relations: {len(project.relations)}")
            
            # Phase VALIDATE: Vérification
            self._log("[VALIDATE] Phase VALIDATE: Vérification de cohérence")
            validate_result = self._phase_validate(project)
            result.validate_result = validate_result
            
            if not validate_result.get("valid") and self.strict:
                result.status = "failed"
                result.errors = self._errors
                result.completed_at = datetime.now()
                return result
            
            # Phase RENDER: Production
            self._log("[RENDER] Phase RENDER: Production de la sortie")
            render_result = self._phase_render(project, analysis)
            result.render_result = render_result
            
            # Finaliser
            result.project = project
            result.status = "success" if not self._errors else "partial"
            result.logs = self._logs if self.include_logs else []
            result.errors = self._errors
            result.warnings = self._warnings
            result.completed_at = datetime.now()
            
            self._log(f"[META] MetaScénario terminé: {result.status}")
            self._log(f"[META] Durée: {result.duration_ms:.2f}ms")
            
            return result
            
        except Exception as e:
            self._error(f"Erreur fatale: {str(e)}")
            result.status = "failed"
            result.errors = self._errors
            result.logs = self._logs
            result.completed_at = datetime.now()
            return result
    
    # =========================================================================
    # PHASE GET: Analyse de l'entrée
    # =========================================================================
    
    def _phase_get(self, input_data: Any) -> Dict[str, Any]:
        """
        Phase GET: Analyse l'entrée et extrait les informations.
        
        Sous-scénarios:
        1. detectInputType: Détermine le type d'entrée
        2. extractDomain: Identifie le domaine du projet
        3. extractFeatures: Extrait les fonctionnalités
        4. extractHints: Identifie les hints d'objets/relations
        """
        try:
            # Analyser l'entrée
            analysis = self.analyzer.analyze(input_data)
            
            # Valider l'analyse
            if analysis.input_type == InputType.UNKNOWN:
                self._warning("Type d'entrée non reconnu, utilisation du mode générique")
            
            if analysis.confidence < 0.5:
                self._warning(f"Confiance faible: {analysis.confidence:.2f}")
            
            return {
                "success": True,
                "analysis": analysis,
                "input_type": analysis.input_type.value,
                "domain": analysis.domain.value,
                "name_hint": analysis.name_hint,
                "features_count": len(analysis.features),
                "object_hints_count": len(analysis.object_hints),
                "confidence": analysis.confidence
            }
            
        except Exception as e:
            self._error(f"[GET] Erreur d'analyse: {str(e)}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # PHASE EXECUTE: Génération du projet
    # =========================================================================
    
    def _phase_execute(self, analysis: AnalysisResult) -> Dict[str, Any]:
        """
        Phase EXECUTE: Génère la structure du projet.
        
        Sous-scénarios:
        1. mapToDomain: Applique le template de domaine
        2. generateObjects: Crée les objets
        3. generateRelations: Crée les relations
        4. generateScenarios: Crée les scénarios associés
        """
        try:
            # Générer le projet complet
            project = self.generator.generate(analysis)
            
            # Logs de génération
            self._logs.extend(self.generator.logs)
            
            return {
                "success": True,
                "project": project,
                "objects_count": len(project.objects),
                "relations_count": len(project.relations),
                "scenarios_count": len(project.scenarios)
            }
            
        except Exception as e:
            self._error(f"[EXECUTE] Erreur de génération: {str(e)}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # PHASE VALIDATE: Vérification de cohérence
    # =========================================================================
    
    def _phase_validate(self, project: EURKAIProject) -> Dict[str, Any]:
        """
        Phase VALIDATE: Vérifie la cohérence du projet.
        
        Sous-scénarios:
        1. validateObjects: Vérifie les objets (IDs uniques, types valides)
        2. validateRelations: Vérifie les relations (sources/targets existent)
        3. detectCycles: Détecte les cycles dans les relations
        4. validateSchema: Vérifie contre le schéma de sortie
        """
        errors = []
        warnings = []
        
        # 1. Valider les objets
        object_ids = [obj.id for obj in project.objects]
        if len(object_ids) != len(set(object_ids)):
            errors.append("IDs d'objets en double détectés")
        
        # Vérifier les types d'objets
        valid_types = {"Agent", "Service", "View", "Data", "Config", "Object", "Module"}
        for obj in project.objects:
            if obj.type not in valid_types:
                warnings.append(f"Type d'objet non standard: {obj.type}")
        
        # 2. Valider les relations
        for rel in project.relations:
            if rel.source not in object_ids:
                errors.append(f"Source de relation non trouvée: {rel.source}")
            if rel.target not in object_ids:
                errors.append(f"Cible de relation non trouvée: {rel.target}")
            if rel.source == rel.target:
                warnings.append(f"Relation auto-référentielle: {rel.source}")
        
        # 3. Détecter les cycles (simple pour l'instant)
        cycles = self._detect_simple_cycles(project.relations)
        if cycles:
            for cycle in cycles:
                warnings.append(f"Cycle détecté: {' → '.join(cycle)}")
        
        # 4. Valider le schéma de sortie
        try:
            output = project.to_dict()
            schema_errors = self._validate_against_schema(output)
            errors.extend(schema_errors)
        except Exception as e:
            errors.append(f"Erreur de sérialisation: {str(e)}")
        
        # Enregistrer les erreurs et warnings
        for e in errors:
            self._error(f"[VALIDATE] {e}")
        for w in warnings:
            self._warning(f"[VALIDATE] {w}")
        
        # Auto-fix si activé
        if self.auto_fix and errors:
            fixed = self._auto_fix_project(project, errors)
            if fixed:
                self._log("[VALIDATE] Corrections automatiques appliquées")
                errors = []  # Réinitialiser après fix
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "objects_validated": len(project.objects),
            "relations_validated": len(project.relations),
            "cycles_detected": len(cycles)
        }
    
    def _detect_simple_cycles(self, relations: List[EURKAIRelation]) -> List[List[str]]:
        """Détection simple de cycles (A → B → A)."""
        cycles = []
        edges = {(r.source, r.target) for r in relations}
        
        for r1 in relations:
            # Cycle direct A → B → A
            if (r1.target, r1.source) in edges:
                cycle = [r1.source, r1.target, r1.source]
                if cycle not in cycles and list(reversed(cycle)) not in cycles:
                    cycles.append(cycle)
        
        return cycles
    
    def _validate_against_schema(self, output: Dict) -> List[str]:
        """Validation basique contre le schéma."""
        errors = []
        
        # Champs requis
        if "projectId" not in output:
            errors.append("Champ requis manquant: projectId")
        if "name" not in output:
            errors.append("Champ requis manquant: name")
        if "objects" not in output:
            errors.append("Champ requis manquant: objects")
        
        # Format projectId
        if output.get("projectId") and not output["projectId"].startswith("Project."):
            errors.append("projectId doit commencer par 'Project.'")
        
        return errors
    
    def _auto_fix_project(self, project: EURKAIProject, errors: List[str]) -> bool:
        """Tente de corriger automatiquement les erreurs."""
        fixed = False
        
        # Corriger les relations avec sources/cibles manquantes
        object_ids = {obj.id for obj in project.objects}
        valid_relations = []
        for rel in project.relations:
            if rel.source in object_ids and rel.target in object_ids:
                valid_relations.append(rel)
            else:
                fixed = True
        project.relations = valid_relations
        
        # Corriger le projectId si nécessaire
        if not project.project_id.startswith("Project."):
            project.project_id = f"Project.{project.project_id}"
            fixed = True
        
        return fixed
    
    # =========================================================================
    # PHASE RENDER: Production de la sortie
    # =========================================================================
    
    def _phase_render(
        self,
        project: EURKAIProject,
        analysis: AnalysisResult
    ) -> Dict[str, Any]:
        """
        Phase RENDER: Produit la sortie finale.
        
        Sous-scénarios:
        1. assembleProject: Assemble la structure finale
        2. generateOutput: Produit le JSON canonique
        3. generateReport: Crée le rapport de création
        """
        try:
            # Générer la sortie JSON
            output = project.to_dict()
            
            # Générer le rapport
            report = {
                "type": "project_creation_report",
                "timestamp": datetime.now().isoformat(),
                "project_id": project.project_id,
                "project_name": project.name,
                "domain": project.domain,
                "input_type": analysis.input_type.value,
                "confidence": analysis.confidence,
                "statistics": {
                    "objects": len(project.objects),
                    "relations": len(project.relations),
                    "scenarios": len(project.scenarios),
                    "tags": len(project.tags)
                },
                "object_types": list(set(obj.type for obj in project.objects)),
                "relation_types": list(set(rel.type for rel in project.relations))
            }
            
            self._log(f"[RENDER] Projet {project.project_id} prêt")
            
            return {
                "success": True,
                "output": output,
                "report": report,
                "format": "json",
                "size_bytes": len(json.dumps(output))
            }
            
        except Exception as e:
            self._error(f"[RENDER] Erreur de rendu: {str(e)}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # UTILITAIRES
    # =========================================================================
    
    def _log(self, message: str):
        """Ajoute un log."""
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        self._logs.append(f"{timestamp} {message}")
    
    def _error(self, message: str):
        """Enregistre une erreur."""
        self._errors.append(message)
        self._log(f"ERROR: {message}")
    
    def _warning(self, message: str):
        """Enregistre un warning."""
        self._warnings.append(message)
        self._log(f"WARN: {message}")
    
    def to_dict(self) -> Dict:
        """Retourne la définition du MetaScénario."""
        return {
            "id": self.ID,
            "name": self.NAME,
            "version": self.VERSION,
            "description": self.__doc__,
            "phases": {
                "GET": {
                    "description": "Analyse l'entrée et extrait les informations",
                    "sub_scenarios": [
                        "detectInputType",
                        "extractDomain",
                        "extractFeatures",
                        "extractHints"
                    ]
                },
                "EXECUTE": {
                    "description": "Génère la structure du projet",
                    "sub_scenarios": [
                        "mapToDomain",
                        "generateObjects",
                        "generateRelations",
                        "generateScenarios"
                    ]
                },
                "VALIDATE": {
                    "description": "Vérifie la cohérence du projet",
                    "sub_scenarios": [
                        "validateObjects",
                        "validateRelations",
                        "detectCycles",
                        "validateSchema"
                    ]
                },
                "RENDER": {
                    "description": "Produit la sortie finale",
                    "sub_scenarios": [
                        "assembleProject",
                        "generateOutput",
                        "generateReport"
                    ]
                }
            },
            "input_types": [t.value for t in InputType],
            "output_schema": PROJET_EURKAI_SCHEMA,
            "options": {
                "strict": "Mode strict de validation",
                "include_logs": "Inclure les logs détaillés",
                "auto_fix": "Corriger automatiquement les problèmes"
            }
        }


# =============================================================================
# FACTORY ET ENREGISTREMENT
# =============================================================================

def create_projet_eurkai_metascenario(options: Dict[str, Any] = None) -> MetaScenarioProjetEURKAI:
    """Factory pour créer le MetaScénario."""
    return MetaScenarioProjetEURKAI(options)


def register_projet_eurkai(engine):
    """
    Enregistre le MetaScénario et ses handlers dans un moteur GEVR.
    
    Args:
        engine: Instance de GEVREngine
    """
    # Créer l'instance
    meta = MetaScenarioProjetEURKAI()
    
    # Enregistrer les handlers spécialisés
    try:
        from ..scenario import GEVRPhase, ScenarioBuilder
        from ..engine import register_handler
        
        # Handler GET: analyzeInput
        def handler_analyze_input(params, context):
            input_data = params.get("input") or context.get("input_data")
            analyzer = InputAnalyzer()
            analysis = analyzer.analyze(input_data)
            context.set("analysis", analysis)
            return analysis.to_dict()
        
        # Handler EXECUTE: generateProject
        def handler_generate_project(params, context):
            analysis = context.get("analysis")
            if not analysis:
                raise ValueError("No analysis found in context")
            generator = ProjectGenerator()
            project = generator.generate(analysis)
            context.set("project", project)
            return project.to_dict()
        
        # Handler VALIDATE: validateProject
        def handler_validate_project(params, context):
            project = context.get("project")
            if not project:
                return {"valid": False, "error": "No project to validate"}
            
            # Validation basique
            errors = []
            object_ids = [obj.id for obj in project.objects]
            for rel in project.relations:
                if rel.source not in object_ids:
                    errors.append(f"Invalid source: {rel.source}")
                if rel.target not in object_ids:
                    errors.append(f"Invalid target: {rel.target}")
            
            return {"valid": len(errors) == 0, "errors": errors}
        
        # Handler RENDER: renderProject
        def handler_render_project(params, context):
            project = context.get("project")
            if not project:
                return {"error": "No project to render"}
            return project.to_dict()
        
        # Enregistrer les handlers
        register_handler("analyzeInput", handler_analyze_input, GEVRPhase.GET)
        register_handler("generateProject", handler_generate_project, GEVRPhase.EXECUTE)
        register_handler("validateProject", handler_validate_project, GEVRPhase.VALIDATE)
        register_handler("renderProject", handler_render_project, GEVRPhase.RENDER)
        
        # Créer et enregistrer le scénario GEVR
        scenario = (ScenarioBuilder("Scenario.ProjetEURKAI")
            .name("Projet EURKAI")
            .description("Transforme une idée en projet EURKAI structuré")
            .version("1.0.0")
            .tag("meta", "project", "core")
            
            .get("analyzeInput", {"input": "${input.data}"})
            .execute("generateProject", {})
            .validate("validateProject", {})
            .render("renderProject", {})
            
            .build())
        
        engine.register_scenario(scenario)
        
    except ImportError:
        # Si les imports GEVR échouent, on ignore
        pass
    
    return meta
