"""
EUREKAI D2/5 — Analyseurs d'entrée pour MetaScénario Projet EURKAI
==================================================================

Ce module analyse les différents types d'entrées:
- Phrase simple ("Je veux un blog sur la créativité")
- Brief structuré (paragraphes avec objectifs, contraintes)
- Schéma technique (JSON/YAML avec objets partiellement définis)

L'analyseur détecte automatiquement le type et extrait les éléments clés.

Version: D2/5 - MetaScénario "Projet EURKAI"
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from enum import Enum
import re
import json


# =============================================================================
# TYPES D'ENTRÉE
# =============================================================================

class InputType(Enum):
    """Types d'entrée reconnus par le MetaScénario."""
    PHRASE = "phrase"           # Une phrase simple
    BRIEF = "brief"             # Un brief textuel structuré
    SCHEMA = "schema"           # Un schéma technique (JSON/YAML-like)
    MIXED = "mixed"             # Combinaison brief + schéma partiel
    UNKNOWN = "unknown"


class ProjectDomain(Enum):
    """Domaines de projet détectables."""
    WEB = "web"                 # Site web, blog, portail
    API = "api"                 # Service API, backend
    SAAS = "saas"               # Application SaaS
    LABO = "labo"               # Projet expérimental, recherche
    DATA = "data"               # Pipeline de données, analytics
    AGENT = "agent"             # Système multi-agents
    TOOL = "tool"               # Outil/utilitaire
    GAME = "game"               # Jeu, gamification
    GENERIC = "generic"         # Domaine non identifié


# =============================================================================
# RÉSULTAT D'ANALYSE
# =============================================================================

@dataclass
class AnalysisResult:
    """
    Résultat de l'analyse d'une entrée.
    
    Contient toutes les informations extraites pour générer le projet.
    """
    input_type: InputType
    domain: ProjectDomain
    
    # Informations de base
    name_hint: str = ""
    description: str = ""
    
    # Éléments extraits
    features: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    object_hints: List[Dict[str, Any]] = field(default_factory=list)
    relation_hints: List[Dict[str, Any]] = field(default_factory=list)
    
    # Tags et métadonnées
    tags: List[str] = field(default_factory=list)
    priority: str = "medium"  # low, medium, high
    
    # Schéma partiel fourni (si type SCHEMA ou MIXED)
    partial_schema: Optional[Dict] = None
    
    # Confiance de l'analyse (0.0 à 1.0)
    confidence: float = 0.8
    
    # Logs d'analyse
    analysis_logs: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convertit en dictionnaire."""
        return {
            "input_type": self.input_type.value,
            "domain": self.domain.value,
            "name_hint": self.name_hint,
            "description": self.description,
            "features": self.features,
            "constraints": self.constraints,
            "object_hints": self.object_hints,
            "relation_hints": self.relation_hints,
            "tags": self.tags,
            "priority": self.priority,
            "partial_schema": self.partial_schema,
            "confidence": self.confidence
        }


# =============================================================================
# ANALYSEUR D'ENTRÉE
# =============================================================================

class InputAnalyzer:
    """
    Analyseur d'entrées pour le MetaScénario Projet EURKAI.
    
    Détecte le type d'entrée et extrait les éléments structurants.
    """
    
    # Patterns de détection de domaine
    DOMAIN_PATTERNS = {
        ProjectDomain.WEB: [
            r"\b(blog|site|portail|page|landing|web|frontend)\b",
            r"\b(html|css|react|vue|angular)\b"
        ],
        ProjectDomain.API: [
            r"\b(api|rest|graphql|endpoint|backend|service)\b",
            r"\b(microservice|serveur|server)\b"
        ],
        ProjectDomain.SAAS: [
            r"\b(saas|application|app|plateforme|dashboard)\b",
            r"\b(utilisateur|user|subscription|abonnement)\b"
        ],
        ProjectDomain.LABO: [
            r"\b(labo|expérimental?|recherche|poc|prototype)\b",
            r"\b(test|essai|exploration)\b"
        ],
        ProjectDomain.DATA: [
            r"\b(data|pipeline|etl|analytics|bi|reporting)\b",
            r"\b(base de données|database|warehouse)\b"
        ],
        ProjectDomain.AGENT: [
            r"\b(agent|bot|ia|ai|orchestration|multi-agent)\b",
            r"\b(llm|gpt|claude|prompt)\b"
        ],
        ProjectDomain.TOOL: [
            r"\b(outil|tool|utilitaire|cli|script)\b",
            r"\b(automatisation|automation)\b"
        ],
        ProjectDomain.GAME: [
            r"\b(jeu|game|gamification|ludique)\b",
            r"\b(score|niveau|level|player)\b"
        ]
    }
    
    # Patterns d'extraction de fonctionnalités
    FEATURE_PATTERNS = [
        r"(?:avec|including|qui permet de|qui|permettant de)\s+(.+?)(?:\.|,|$)",
        r"(?:fonctionnalité|feature)s?\s*:?\s*(.+?)(?:\.|$)",
        r"(?:doit|should|must)\s+(.+?)(?:\.|,|$)"
    ]
    
    # Patterns d'extraction de contraintes
    CONSTRAINT_PATTERNS = [
        r"(?:contrainte|constraint|limite|limitation)s?\s*:?\s*(.+?)(?:\.|$)",
        r"(?:sans|without|pas de|no)\s+(.+?)(?:\.|,|$)",
        r"(?:obligatoire|required|mandatory)s?\s*:?\s*(.+?)(?:\.|$)"
    ]
    
    def __init__(self, options: Dict[str, Any] = None):
        """
        Initialise l'analyseur.
        
        Args:
            options: Options de configuration
        """
        self.options = options or {}
        self.logs: List[str] = []
    
    def analyze(self, input_data: Any) -> AnalysisResult:
        """
        Analyse une entrée et retourne les informations extraites.
        
        Args:
            input_data: Entrée brute (str, dict, ou objet structuré)
            
        Returns:
            AnalysisResult avec les éléments extraits
        """
        self.logs = []
        
        # Déterminer le type d'entrée
        input_type = self._detect_input_type(input_data)
        self._log(f"Type d'entrée détecté: {input_type.value}")
        
        # Analyser selon le type
        if input_type == InputType.SCHEMA:
            return self._analyze_schema(input_data)
        elif input_type == InputType.BRIEF:
            return self._analyze_brief(input_data)
        elif input_type == InputType.PHRASE:
            return self._analyze_phrase(input_data)
        elif input_type == InputType.MIXED:
            return self._analyze_mixed(input_data)
        else:
            return self._analyze_unknown(input_data)
    
    def _detect_input_type(self, input_data: Any) -> InputType:
        """Détecte le type d'entrée."""
        
        # Si c'est un dictionnaire avec des clés structurantes
        if isinstance(input_data, dict):
            if any(k in input_data for k in ["objects", "relations", "schema", "structure"]):
                return InputType.SCHEMA
            if any(k in input_data for k in ["brief", "description", "text"]):
                text = input_data.get("brief") or input_data.get("description") or input_data.get("text", "")
                if any(k in input_data for k in ["hints", "objects", "partial"]):
                    return InputType.MIXED
                return InputType.BRIEF if len(text) > 100 else InputType.PHRASE
        
        # Si c'est une chaîne
        if isinstance(input_data, str):
            text = input_data.strip()
            
            # Essayer de parser comme JSON
            if text.startswith("{") or text.startswith("["):
                try:
                    json.loads(text)
                    return InputType.SCHEMA
                except json.JSONDecodeError:
                    pass
            
            # Détecter un brief structuré (plusieurs paragraphes, sections)
            if len(text) > 200 or text.count("\n\n") > 1:
                return InputType.BRIEF
            
            # Phrase simple
            if len(text) < 200 and text.count("\n") < 2:
                return InputType.PHRASE
            
            return InputType.BRIEF
        
        return InputType.UNKNOWN
    
    def _detect_domain(self, text: str) -> Tuple[ProjectDomain, float]:
        """
        Détecte le domaine du projet.
        
        Returns:
            Tuple (domaine, confiance)
        """
        text_lower = text.lower()
        scores = {}
        
        for domain, patterns in self.DOMAIN_PATTERNS.items():
            score = 0
            for pattern in patterns:
                matches = re.findall(pattern, text_lower, re.IGNORECASE)
                score += len(matches)
            if score > 0:
                scores[domain] = score
        
        if not scores:
            return (ProjectDomain.GENERIC, 0.5)
        
        best_domain = max(scores, key=scores.get)
        total = sum(scores.values())
        confidence = scores[best_domain] / total if total > 0 else 0.5
        
        return (best_domain, min(confidence + 0.3, 1.0))
    
    def _extract_name_hint(self, text: str) -> str:
        """Extrait une suggestion de nom de projet."""
        patterns = [
            r"(?:projet|project)\s+[«\"]?([A-Za-zÀ-ÿ0-9_\-\s]+)[»\"]?",
            r"(?:créer|create|un|une)\s+([A-Za-zÀ-ÿ0-9_\-\s]+?)(?:\s+(?:sur|pour|avec|qui))",
            r"^([A-Za-zÀ-ÿ0-9_\-\s]{3,30})(?:\s*:|\s*-)"
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                # Nettoyer et formater
                name = re.sub(r"\s+", "", name.title())
                return name[:30]
        
        # Générer depuis les premiers mots significatifs
        words = re.findall(r"\b[A-Za-zÀ-ÿ]{3,}\b", text)
        if words:
            return "".join(w.title() for w in words[:2])[:20]
        
        return "NewProject"
    
    def _extract_features(self, text: str) -> List[str]:
        """Extrait les fonctionnalités mentionnées."""
        features = []
        
        for pattern in self.FEATURE_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            features.extend(m.strip() for m in matches if len(m.strip()) > 3)
        
        # Déduplication et nettoyage
        seen = set()
        unique = []
        for f in features:
            f_clean = f.lower().strip()
            if f_clean not in seen and len(f_clean) < 100:
                seen.add(f_clean)
                unique.append(f.strip())
        
        return unique[:10]  # Max 10 features
    
    def _extract_constraints(self, text: str) -> List[str]:
        """Extrait les contraintes mentionnées."""
        constraints = []
        
        for pattern in self.CONSTRAINT_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            constraints.extend(m.strip() for m in matches if len(m.strip()) > 3)
        
        # Déduplication
        return list(set(constraints))[:5]
    
    def _extract_object_hints(self, text: str, domain: ProjectDomain) -> List[Dict[str, Any]]:
        """Extrait des indices d'objets à créer."""
        hints = []
        
        # Patterns pour différents types d'objets
        object_patterns = {
            "Agent": [r"\b(agent|bot|assistant)\b", r"\b(orchestrateur|coordinator)\b"],
            "Service": [r"\b(service|api|backend)\b", r"\b(module|component)\b"],
            "View": [r"\b(page|vue|view|écran|screen)\b", r"\b(dashboard|interface)\b"],
            "Config": [r"\b(config|configuration|settings)\b", r"\b(paramètre|option)\b"],
            "Data": [r"\b(data|données|model|entité|entity)\b", r"\b(table|collection)\b"]
        }
        
        for obj_type, patterns in object_patterns.items():
            for pattern in patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                for match in matches:
                    hints.append({
                        "type": obj_type,
                        "name_hint": match.title(),
                        "source": "pattern_match"
                    })
        
        # Déduplication par type
        seen_types = set()
        unique = []
        for h in hints:
            if h["type"] not in seen_types:
                seen_types.add(h["type"])
                unique.append(h)
        
        return unique
    
    def _extract_tags(self, text: str, domain: ProjectDomain) -> List[str]:
        """Extrait les tags du projet."""
        tags = [domain.value]
        
        # Tags techniques
        tech_patterns = {
            "python": r"\bpython\b",
            "javascript": r"\b(javascript|js|node)\b",
            "react": r"\breact\b",
            "api": r"\bapi\b",
            "ai": r"\b(ai|ia|llm|gpt|claude)\b",
            "database": r"\b(database|sql|mongo|postgres)\b"
        }
        
        for tag, pattern in tech_patterns.items():
            if re.search(pattern, text, re.IGNORECASE):
                tags.append(tag)
        
        return list(set(tags))[:8]
    
    def _analyze_phrase(self, input_data: Any) -> AnalysisResult:
        """Analyse une phrase simple."""
        text = str(input_data).strip()
        
        domain, confidence = self._detect_domain(text)
        self._log(f"Domaine détecté: {domain.value} (confiance: {confidence:.2f})")
        
        name_hint = self._extract_name_hint(text)
        self._log(f"Nom suggéré: {name_hint}")
        
        features = self._extract_features(text)
        object_hints = self._extract_object_hints(text, domain)
        tags = self._extract_tags(text, domain)
        
        return AnalysisResult(
            input_type=InputType.PHRASE,
            domain=domain,
            name_hint=name_hint,
            description=text,
            features=features,
            object_hints=object_hints,
            tags=tags,
            confidence=confidence * 0.7,  # Confiance réduite pour phrase simple
            analysis_logs=self.logs.copy()
        )
    
    def _analyze_brief(self, input_data: Any) -> AnalysisResult:
        """Analyse un brief structuré."""
        if isinstance(input_data, dict):
            text = input_data.get("brief") or input_data.get("description") or input_data.get("text", "")
        else:
            text = str(input_data)
        
        domain, confidence = self._detect_domain(text)
        name_hint = self._extract_name_hint(text)
        features = self._extract_features(text)
        constraints = self._extract_constraints(text)
        object_hints = self._extract_object_hints(text, domain)
        tags = self._extract_tags(text, domain)
        
        # Extraire la description (premier paragraphe ou 200 premiers caractères)
        paragraphs = text.split("\n\n")
        description = paragraphs[0][:300] if paragraphs else text[:300]
        
        self._log(f"Brief analysé: {len(text)} chars, {len(features)} features, {len(constraints)} contraintes")
        
        return AnalysisResult(
            input_type=InputType.BRIEF,
            domain=domain,
            name_hint=name_hint,
            description=description,
            features=features,
            constraints=constraints,
            object_hints=object_hints,
            tags=tags,
            confidence=confidence * 0.85,
            analysis_logs=self.logs.copy()
        )
    
    def _analyze_schema(self, input_data: Any) -> AnalysisResult:
        """Analyse un schéma technique."""
        if isinstance(input_data, str):
            try:
                schema = json.loads(input_data)
            except json.JSONDecodeError:
                return self._analyze_brief(input_data)
        else:
            schema = input_data
        
        # Extraire les informations du schéma
        name_hint = schema.get("name") or schema.get("projectName") or schema.get("id", "Project")
        description = schema.get("description", "")
        
        # Déterminer le domaine depuis le schéma ou la description
        domain_str = schema.get("domain") or schema.get("type", "")
        try:
            domain = ProjectDomain(domain_str.lower()) if domain_str else ProjectDomain.GENERIC
        except ValueError:
            domain, _ = self._detect_domain(description or str(schema))
        
        # Extraire les objets
        object_hints = []
        for obj in schema.get("objects", []):
            object_hints.append({
                "type": obj.get("type", "Object"),
                "name_hint": obj.get("name") or obj.get("id", ""),
                "bundles": obj.get("bundles", []),
                "source": "schema"
            })
        
        # Extraire les relations
        relation_hints = []
        for rel in schema.get("relations", []):
            relation_hints.append({
                "source": rel.get("source") or rel.get("from", ""),
                "target": rel.get("target") or rel.get("to", ""),
                "type": rel.get("type", "references")
            })
        
        tags = schema.get("tags", [])
        if domain != ProjectDomain.GENERIC:
            tags.append(domain.value)
        
        self._log(f"Schéma analysé: {len(object_hints)} objets, {len(relation_hints)} relations")
        
        return AnalysisResult(
            input_type=InputType.SCHEMA,
            domain=domain,
            name_hint=name_hint,
            description=description,
            object_hints=object_hints,
            relation_hints=relation_hints,
            tags=list(set(tags)),
            partial_schema=schema,
            confidence=0.95,  # Haute confiance pour schéma explicite
            analysis_logs=self.logs.copy()
        )
    
    def _analyze_mixed(self, input_data: Any) -> AnalysisResult:
        """Analyse une entrée mixte (brief + schéma partiel)."""
        if not isinstance(input_data, dict):
            return self._analyze_brief(input_data)
        
        # Analyser la partie textuelle
        text = input_data.get("brief") or input_data.get("description") or input_data.get("text", "")
        brief_result = self._analyze_brief(text)
        
        # Fusionner avec les hints fournis
        object_hints = brief_result.object_hints.copy()
        for obj in input_data.get("hints", {}).get("objects", []):
            object_hints.append({
                "type": obj.get("type", "Object"),
                "name_hint": obj.get("name", ""),
                "source": "hint"
            })
        
        relation_hints = brief_result.relation_hints.copy()
        for rel in input_data.get("hints", {}).get("relations", []):
            relation_hints.append(rel)
        
        partial_schema = input_data.get("partial") or input_data.get("schema")
        
        return AnalysisResult(
            input_type=InputType.MIXED,
            domain=brief_result.domain,
            name_hint=brief_result.name_hint or input_data.get("name", ""),
            description=brief_result.description,
            features=brief_result.features,
            constraints=brief_result.constraints,
            object_hints=object_hints,
            relation_hints=relation_hints,
            tags=brief_result.tags,
            partial_schema=partial_schema,
            confidence=(brief_result.confidence + 0.9) / 2,
            analysis_logs=self.logs.copy()
        )
    
    def _analyze_unknown(self, input_data: Any) -> AnalysisResult:
        """Analyse une entrée de type inconnu."""
        self._log(f"Type inconnu, tentative d'analyse générique")
        
        # Essayer de convertir en string et analyser comme brief
        try:
            text = str(input_data)
            return self._analyze_brief(text)
        except Exception as e:
            self._log(f"Erreur d'analyse: {e}")
            return AnalysisResult(
                input_type=InputType.UNKNOWN,
                domain=ProjectDomain.GENERIC,
                name_hint="NewProject",
                description="Projet généré automatiquement",
                confidence=0.3,
                analysis_logs=self.logs.copy()
            )
    
    def _log(self, message: str):
        """Ajoute un message de log."""
        self.logs.append(message)
