"""
EUREKAI D2/5 — Module GEVR avec MetaScénarios
==============================================

Ce module étend GEVR D1 avec le MetaScénario "Projet EURKAI".

Exports:
- Classes et API GEVR (D1)
- MetaScénario ProjetEURKAI (D2)
- Analyseurs et Générateurs

Version: D2/5 - MetaScénario "Projet EURKAI"
"""

# =============================================================================
# EXPORTS D1: Scénarios GEVR de base
# =============================================================================

from .scenario import (
    GEVRPhase,
    StepStatus,
    ScenarioStatus,
    StepDefinition,
    StepResult,
    GEVRScenario,
    ScenarioResult,
    ScenarioBuilder,
    create_scenario
)

from .engine import (
    ExecutionContext,
    ActionHandler,
    FunctionHandler,
    HandlerRegistry,
    GEVREngine,
    get_engine,
    run_scenario,
    register_scenario,
    register_handler
)

from .handlers import (
    register_all_handlers,
    handler_load_bundle,
    handler_load_template,
    handler_run_metarules,
    handler_validate_schema,
    handler_render_analysis
)

# =============================================================================
# EXPORTS D2: MetaScénario Projet EURKAI
# =============================================================================

from .metascenarios import (
    # MetaScénario principal
    MetaScenarioProjetEURKAI,
    create_projet_eurkai_metascenario,
    register_projet_eurkai,
    PROJET_EURKAI_SCHEMA,
    
    # Analyseurs
    InputAnalyzer,
    InputType,
    AnalysisResult,
    
    # Générateurs
    ObjectGenerator,
    RelationGenerator,
    ScenarioGenerator,
    ProjectGenerator
)

# =============================================================================
# API FAÇADE D2
# =============================================================================

class GEVR:
    """
    Façade unifiée pour GEVR + MetaScénarios.
    
    Usage:
        # Exécuter un scénario standard
        result = GEVR.run("Scenario.AnalyzeObject", {"object_id": "..."})
        
        # Créer un projet à partir d'une idée
        project = GEVR.create_project("Je veux un blog sur la créativité")
        
        # Enregistrer un handler personnalisé
        @GEVR.handler("myAction", GEVRPhase.EXECUTE)
        def my_handler(params, context):
            return {"status": "done"}
    """
    
    _engine = None
    _metascenario = None
    
    @classmethod
    def _get_engine(cls):
        if cls._engine is None:
            cls._engine = GEVREngine()
            register_all_handlers(cls._engine)
        return cls._engine
    
    @classmethod
    def _get_metascenario(cls):
        if cls._metascenario is None:
            cls._metascenario = MetaScenarioProjetEURKAI()
        return cls._metascenario
    
    @classmethod
    def run(cls, scenario_id: str, input_data: dict = None, options: dict = None):
        """Exécute un scénario GEVR."""
        engine = cls._get_engine()
        return engine.run_scenario(scenario_id, input_data, options)
    
    @classmethod
    def create_project(cls, input_data, options: dict = None):
        """
        Crée un projet EURKAI à partir d'une entrée.
        
        Args:
            input_data: Phrase, brief, ou schéma
            options: Options du MetaScénario
            
        Returns:
            MetaScenarioResult avec le projet généré
        """
        meta = MetaScenarioProjetEURKAI(options)
        return meta.run(input_data)
    
    @classmethod
    def create(cls, scenario_id: str):
        """Retourne un ScenarioBuilder pour créer un scénario."""
        return ScenarioBuilder(scenario_id)
    
    @classmethod
    def register(cls, scenario: GEVRScenario):
        """Enregistre un scénario."""
        engine = cls._get_engine()
        engine.register_scenario(scenario)
    
    @classmethod
    def handler(cls, action: str, phase: GEVRPhase = None):
        """Décorateur pour enregistrer un handler."""
        def decorator(func):
            engine = cls._get_engine()
            engine.register_handler(action, func, phase)
            return func
        return decorator


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Façade
    "GEVR",
    
    # D1: Scénarios
    "GEVRPhase",
    "StepStatus",
    "ScenarioStatus",
    "StepDefinition",
    "StepResult",
    "GEVRScenario",
    "ScenarioResult",
    "ScenarioBuilder",
    "create_scenario",
    
    # D1: Moteur
    "ExecutionContext",
    "ActionHandler",
    "FunctionHandler",
    "HandlerRegistry",
    "GEVREngine",
    "get_engine",
    "run_scenario",
    "register_scenario",
    "register_handler",
    
    # D1: Handlers
    "register_all_handlers",
    
    # D2: MetaScénario
    "MetaScenarioProjetEURKAI",
    "create_projet_eurkai_metascenario",
    "register_projet_eurkai",
    "PROJET_EURKAI_SCHEMA",
    
    # D2: Analyseurs
    "InputAnalyzer",
    "InputType",
    "AnalysisResult",
    
    # D2: Générateurs
    "ObjectGenerator",
    "RelationGenerator",
    "ScenarioGenerator",
    "ProjectGenerator"
]

__version__ = "2.0.0"
