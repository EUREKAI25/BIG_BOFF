"""
EUREKAI D1/4 — Modèle de Scénario GEVR
========================================

Ce module définit la structure canonique d'un scénario GEVR:
- GEVR = GET → EXECUTE → VALIDATE → RENDER
- Chaque scénario est déclaratif et composable
- Chaque étape laisse une trace (log)

Architecture:
- GEVRPhase: Énumération des 4 phases
- StepDefinition: Définition d'une étape
- GEVRScenario: Scénario complet
- ScenarioResult: Résultat d'exécution

Version: D1/4 - Scénarios GEVR de base
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import (
    List, Dict, Any, Optional, Callable, 
    Union, Type, TypeVar, Generic
)
from enum import Enum, auto
from datetime import datetime
import json
import uuid


# =============================================================================
# ÉNUMÉRATIONS
# =============================================================================

class GEVRPhase(Enum):
    """Les 4 phases du pipeline GEVR."""
    GET = "GET"           # Récupérer les données nécessaires
    EXECUTE = "EXECUTE"   # Appliquer une action/transformation
    VALIDATE = "VALIDATE" # Vérifier la cohérence (MetaRules + ERK)
    RENDER = "RENDER"     # Produire un résultat lisible
    
    def __str__(self) -> str:
        return self.value


class StepStatus(Enum):
    """Statut d'exécution d'une étape."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


class ScenarioStatus(Enum):
    """Statut global d'un scénario."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"  # Certaines étapes ont échoué


# =============================================================================
# STRUCTURES DE DONNÉES
# =============================================================================

@dataclass
class StepDefinition:
    """
    Définition d'une étape dans un scénario GEVR.
    
    Attributes:
        phase: Phase GEVR (GET, EXECUTE, VALIDATE, RENDER)
        action: Nom de l'action à exécuter (ex: "loadObject", "runMetaRules")
        params: Paramètres de l'action
        description: Description humaine de l'étape
        required: Si True, l'échec stoppe le scénario
        condition: Condition optionnelle pour exécuter l'étape
        on_error: Comportement en cas d'erreur ("stop", "continue", "skip_phase")
        timeout: Timeout en secondes (0 = pas de timeout)
    """
    phase: GEVRPhase
    action: str
    params: Dict[str, Any] = field(default_factory=dict)
    description: str = ""
    required: bool = True
    condition: Optional[str] = None
    on_error: str = "stop"
    timeout: float = 0
    
    def to_dict(self) -> Dict:
        """Convertit l'étape en dictionnaire."""
        return {
            "phase": self.phase.value,
            "action": self.action,
            "params": self.params,
            "description": self.description or f"{self.phase.value}: {self.action}",
            "required": self.required,
            "condition": self.condition,
            "on_error": self.on_error,
            "timeout": self.timeout
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'StepDefinition':
        """Crée une StepDefinition depuis un dictionnaire."""
        phase = GEVRPhase(data.get("phase", "EXECUTE"))
        return cls(
            phase=phase,
            action=data.get("action", ""),
            params=data.get("params", {}),
            description=data.get("description", ""),
            required=data.get("required", True),
            condition=data.get("condition"),
            on_error=data.get("on_error", "stop"),
            timeout=data.get("timeout", 0)
        )
    
    def __str__(self) -> str:
        return f"[{self.phase.value}] {self.action}"


@dataclass
class StepResult:
    """
    Résultat d'exécution d'une étape.
    
    Attributes:
        step: Définition de l'étape exécutée
        status: Statut d'exécution
        output: Données produites par l'étape
        error: Message d'erreur si échec
        duration_ms: Durée d'exécution en millisecondes
        logs: Logs générés pendant l'exécution
        timestamp: Horodatage de fin d'exécution
    """
    step: StepDefinition
    status: StepStatus
    output: Any = None
    error: Optional[str] = None
    duration_ms: float = 0
    logs: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        """Convertit le résultat en dictionnaire."""
        return {
            "step": self.step.to_dict(),
            "status": self.status.value,
            "output": self.output,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "logs": self.logs,
            "timestamp": self.timestamp.isoformat()
        }
    
    @property
    def ok(self) -> bool:
        """Vérifie si l'étape a réussi."""
        return self.status == StepStatus.SUCCESS
    
    def add_log(self, message: str):
        """Ajoute un message de log."""
        self.logs.append(f"[{self.step.phase.value}] {message}")


@dataclass
class GEVRScenario:
    """
    Scénario GEVR complet.
    
    Un scénario est une séquence d'étapes organisées par phase GEVR.
    Il est déclaratif, composable et traçable.
    
    Attributes:
        id: Identifiant unique du scénario
        name: Nom lisible
        description: Description du scénario
        steps: Liste ordonnée des étapes
        metadata: Métadonnées additionnelles
        version: Version du scénario
        tags: Tags pour catégorisation
    """
    id: str
    name: str
    description: str = ""
    steps: List[StepDefinition] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    version: str = "1.0.0"
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convertit le scénario en dictionnaire JSON-compatible."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "steps": [s.to_dict() for s in self.steps],
            "metadata": self.metadata,
            "version": self.version,
            "tags": self.tags
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'GEVRScenario':
        """Crée un GEVRScenario depuis un dictionnaire."""
        steps = [StepDefinition.from_dict(s) for s in data.get("steps", [])]
        return cls(
            id=data.get("id", f"Scenario.{uuid.uuid4().hex[:8]}"),
            name=data.get("name", "Unnamed Scenario"),
            description=data.get("description", ""),
            steps=steps,
            metadata=data.get("metadata", {}),
            version=data.get("version", "1.0.0"),
            tags=data.get("tags", [])
        )
    
    def to_json(self, indent: int = 2) -> str:
        """Sérialise le scénario en JSON."""
        return json.dumps(self.to_dict(), indent=indent)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'GEVRScenario':
        """Désérialise un scénario depuis JSON."""
        return cls.from_dict(json.loads(json_str))
    
    def add_step(
        self,
        phase: GEVRPhase,
        action: str,
        params: Dict[str, Any] = None,
        **kwargs
    ) -> 'GEVRScenario':
        """
        Ajoute une étape au scénario (fluent API).
        
        Returns:
            self pour chaînage
        """
        step = StepDefinition(
            phase=phase,
            action=action,
            params=params or {},
            **kwargs
        )
        self.steps.append(step)
        return self
    
    def get_steps_by_phase(self, phase: GEVRPhase) -> List[StepDefinition]:
        """Retourne les étapes d'une phase spécifique."""
        return [s for s in self.steps if s.phase == phase]
    
    @property
    def phases_used(self) -> List[GEVRPhase]:
        """Liste des phases utilisées dans ce scénario."""
        seen = set()
        phases = []
        for step in self.steps:
            if step.phase not in seen:
                seen.add(step.phase)
                phases.append(step.phase)
        return phases
    
    def validate(self) -> List[str]:
        """
        Valide la structure du scénario.
        
        Returns:
            Liste des erreurs (vide si valide)
        """
        errors = []
        
        if not self.id:
            errors.append("Scenario ID is required")
        
        if not self.name:
            errors.append("Scenario name is required")
        
        if not self.steps:
            errors.append("Scenario must have at least one step")
        
        for i, step in enumerate(self.steps):
            if not step.action:
                errors.append(f"Step {i+1}: action is required")
        
        return errors
    
    def __str__(self) -> str:
        return f"GEVRScenario({self.id}, {len(self.steps)} steps)"
    
    def display(self) -> str:
        """Affichage formaté du scénario."""
        lines = [
            f"═══ Scenario: {self.name} ═══",
            f"ID: {self.id}",
            f"Version: {self.version}",
            f"Description: {self.description}",
            "",
            "Steps:"
        ]
        
        for i, step in enumerate(self.steps, 1):
            lines.append(f"  {i}. [{step.phase.value}] {step.action}")
            if step.description:
                lines.append(f"     └─ {step.description}")
        
        return "\n".join(lines)


@dataclass
class ScenarioResult:
    """
    Résultat complet d'exécution d'un scénario.
    
    Attributes:
        scenario: Le scénario exécuté
        status: Statut global
        step_results: Résultats de chaque étape
        output: Sortie finale consolidée
        logs: Logs globaux
        started_at: Début d'exécution
        completed_at: Fin d'exécution
        context: Contexte final après exécution
    """
    scenario: GEVRScenario
    status: ScenarioStatus
    step_results: List[StepResult] = field(default_factory=list)
    output: Any = None
    logs: List[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    context: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convertit le résultat en dictionnaire."""
        return {
            "scenario": self.scenario.to_dict(),
            "status": self.status.value,
            "step_results": [r.to_dict() for r in self.step_results],
            "output": self.output,
            "logs": self.logs,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_ms": self.duration_ms,
            "summary": self.summary()
        }
    
    @property
    def duration_ms(self) -> float:
        """Durée totale d'exécution en millisecondes."""
        if not self.completed_at:
            return 0
        delta = self.completed_at - self.started_at
        return delta.total_seconds() * 1000
    
    @property
    def ok(self) -> bool:
        """Vérifie si le scénario a complètement réussi."""
        return self.status == ScenarioStatus.COMPLETED
    
    def summary(self) -> Dict:
        """Résumé de l'exécution."""
        phases_status = {}
        for phase in GEVRPhase:
            phase_results = [
                r for r in self.step_results 
                if r.step.phase == phase
            ]
            if phase_results:
                success = all(r.ok for r in phase_results)
                phases_status[phase.value] = "ok" if success else "failed"
        
        return {
            "status": self.status.value,
            "total_steps": len(self.step_results),
            "successful_steps": sum(1 for r in self.step_results if r.ok),
            "failed_steps": sum(1 for r in self.step_results if r.status == StepStatus.FAILED),
            "skipped_steps": sum(1 for r in self.step_results if r.status == StepStatus.SKIPPED),
            "phases": phases_status,
            "duration_ms": self.duration_ms
        }
    
    def add_log(self, message: str, phase: GEVRPhase = None):
        """Ajoute un log global."""
        prefix = f"[{phase.value}] " if phase else ""
        self.logs.append(f"{prefix}{message}")
    
    def get_phase_output(self, phase: GEVRPhase) -> Any:
        """Récupère la sortie de la dernière étape réussie d'une phase."""
        phase_results = [
            r for r in self.step_results 
            if r.step.phase == phase and r.ok
        ]
        if phase_results:
            return phase_results[-1].output
        return None
    
    def display(self) -> str:
        """Affichage formaté du résultat."""
        lines = [
            "═" * 60,
            f"  SCENARIO RESULT: {self.scenario.name}",
            "═" * 60,
            f"  Status: {self.status.value}",
            f"  Duration: {self.duration_ms:.2f}ms",
            "",
            "  PHASES:",
        ]
        
        for phase in GEVRPhase:
            phase_results = [r for r in self.step_results if r.step.phase == phase]
            if phase_results:
                status_icon = "✓" if all(r.ok for r in phase_results) else "✗"
                lines.append(f"    {status_icon} {phase.value}")
                for r in phase_results:
                    step_icon = "✓" if r.ok else "✗"
                    lines.append(f"      {step_icon} {r.step.action} ({r.duration_ms:.1f}ms)")
                    if r.error:
                        lines.append(f"        └─ Error: {r.error}")
        
        if self.logs:
            lines.append("")
            lines.append("  LOGS:")
            for log in self.logs[-10:]:  # Derniers 10 logs
                lines.append(f"    {log}")
        
        lines.append("═" * 60)
        
        return "\n".join(lines)


# =============================================================================
# BUILDERS / FACTORY
# =============================================================================

class ScenarioBuilder:
    """
    Builder fluent pour créer des scénarios GEVR.
    
    Usage:
        scenario = (ScenarioBuilder("Scenario.MyScenario")
            .name("My Scenario")
            .get("loadObject", {"id": "..."})
            .execute("transform", {"action": "..."})
            .validate("checkRules")
            .render("generateReport")
            .build())
    """
    
    def __init__(self, scenario_id: str):
        self._id = scenario_id
        self._name = scenario_id
        self._description = ""
        self._steps: List[StepDefinition] = []
        self._metadata: Dict[str, Any] = {}
        self._version = "1.0.0"
        self._tags: List[str] = []
    
    def name(self, name: str) -> 'ScenarioBuilder':
        """Définit le nom du scénario."""
        self._name = name
        return self
    
    def description(self, description: str) -> 'ScenarioBuilder':
        """Définit la description."""
        self._description = description
        return self
    
    def version(self, version: str) -> 'ScenarioBuilder':
        """Définit la version."""
        self._version = version
        return self
    
    def tag(self, *tags: str) -> 'ScenarioBuilder':
        """Ajoute des tags."""
        self._tags.extend(tags)
        return self
    
    def metadata(self, **kwargs) -> 'ScenarioBuilder':
        """Ajoute des métadonnées."""
        self._metadata.update(kwargs)
        return self
    
    def step(
        self,
        phase: GEVRPhase,
        action: str,
        params: Dict[str, Any] = None,
        **kwargs
    ) -> 'ScenarioBuilder':
        """Ajoute une étape générique."""
        self._steps.append(StepDefinition(
            phase=phase,
            action=action,
            params=params or {},
            **kwargs
        ))
        return self
    
    def get(self, action: str, params: Dict[str, Any] = None, **kwargs) -> 'ScenarioBuilder':
        """Ajoute une étape GET."""
        return self.step(GEVRPhase.GET, action, params, **kwargs)
    
    def execute(self, action: str, params: Dict[str, Any] = None, **kwargs) -> 'ScenarioBuilder':
        """Ajoute une étape EXECUTE."""
        return self.step(GEVRPhase.EXECUTE, action, params, **kwargs)
    
    def validate(self, action: str, params: Dict[str, Any] = None, **kwargs) -> 'ScenarioBuilder':
        """Ajoute une étape VALIDATE."""
        return self.step(GEVRPhase.VALIDATE, action, params, **kwargs)
    
    def render(self, action: str, params: Dict[str, Any] = None, **kwargs) -> 'ScenarioBuilder':
        """Ajoute une étape RENDER."""
        return self.step(GEVRPhase.RENDER, action, params, **kwargs)
    
    def build(self) -> GEVRScenario:
        """Construit le scénario final."""
        scenario = GEVRScenario(
            id=self._id,
            name=self._name,
            description=self._description,
            steps=self._steps,
            metadata=self._metadata,
            version=self._version,
            tags=self._tags
        )
        
        # Validation
        errors = scenario.validate()
        if errors:
            raise ValueError(f"Invalid scenario: {'; '.join(errors)}")
        
        return scenario


def create_scenario(
    scenario_id: str,
    name: str = None,
    steps: List[Dict] = None,
    **kwargs
) -> GEVRScenario:
    """
    Factory pour créer un scénario depuis des données brutes.
    
    Args:
        scenario_id: ID du scénario
        name: Nom (défaut = ID)
        steps: Liste de définitions d'étapes
        **kwargs: Autres attributs
    
    Returns:
        GEVRScenario configuré
    """
    step_defs = [StepDefinition.from_dict(s) for s in (steps or [])]
    
    return GEVRScenario(
        id=scenario_id,
        name=name or scenario_id,
        steps=step_defs,
        **kwargs
    )
