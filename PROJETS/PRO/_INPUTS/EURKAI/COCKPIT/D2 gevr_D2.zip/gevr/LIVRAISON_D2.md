# LIVRAISON D2/5 — MetaScénario "Projet EURKAI"

## Résumé

Cette livraison implémente l'étape **D2/5** d'EUREKAI: le **MetaScénario "Projet EURKAI"**.

Ce MetaScénario est le **cœur du pipeline EUREKAI**:
> **Idée → Projet structuré**

Il prend en entrée une idée (phrase), un brief structuré, ou un schéma technique, et produit une **structure de projet EURKAI** complète (objets, relations, scénarios, tags).

---

## Ce qui a été livré

### 1. Nouveaux fichiers

| Fichier | Description |
|---------|-------------|
| `gevr/metascenarios/__init__.py` | Module principal, exports |
| `gevr/metascenarios/analyzers.py` | Analyseurs d'entrée (phrase, brief, schéma) |
| `gevr/metascenarios/generators.py` | Générateurs (objets, relations, scénarios) |
| `gevr/metascenarios/projet_eurkai.py` | MetaScénario principal avec pipeline GEVR |
| `gevr/tests/__init__.py` | Init des tests |
| `gevr/tests/test_metascenario.py` | 45+ tests couvrant tous les cas |

### 2. Intégrations

- **GEVR D1**: Utilise le format de scénario GEVR standard
- **Templates par domaine**: 9 domaines pré-configurés (web, api, saas, agent, data, labo, tool, game, generic)

---

## 1. Définition conceptuelle du MetaScénario

### Phases G/E/V/R explicites

```
┌─────────────────────────────────────────────────────────────────────┐
│                    MetaScenario.ProjetEURKAI                        │
│                         Pipeline GEVR                                │
└─────────────────────────────────────────────────────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        ▼                       ▼                       ▼
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│    INPUT      │     │    INPUT      │     │    INPUT      │
│   (phrase)    │     │   (brief)     │     │   (schéma)    │
└───────┬───────┘     └───────┬───────┘     └───────┬───────┘
        │                     │                     │
        └──────────────┬──────┴─────────────────────┘
                       ▼
┌──────────────────────────────────────────────────────────────────────┐
│  PHASE GET: Analyse de l'entrée                                       │
├──────────────────────────────────────────────────────────────────────┤
│  Sous-scénarios:                                                      │
│  • detectInputType: Détermine le type (phrase/brief/schéma/mixed)    │
│  • extractDomain: Identifie le domaine (web, api, saas, agent...)    │
│  • extractFeatures: Extrait les fonctionnalités demandées            │
│  • extractHints: Identifie les indices d'objets/relations            │
├──────────────────────────────────────────────────────────────────────┤
│  Output: AnalysisResult {                                             │
│    input_type, domain, name_hint, features, constraints,             │
│    object_hints, relation_hints, tags, confidence                    │
│  }                                                                    │
└───────────────────────────────────┬──────────────────────────────────┘
                                    ▼
┌──────────────────────────────────────────────────────────────────────┐
│  PHASE EXECUTE: Génération du projet                                  │
├──────────────────────────────────────────────────────────────────────┤
│  Sous-scénarios:                                                      │
│  • mapToDomain: Applique le template du domaine détecté              │
│  • generateObjects: Crée les objets EURKAI (Agent, Service, View...)│
│  • generateRelations: Crée les relations (depends_on, renders...)    │
│  • generateScenarios: Définit les scénarios associés                 │
├──────────────────────────────────────────────────────────────────────┤
│  Output: EURKAIProject {                                              │
│    project_id, name, objects[], relations[], scenarios[], tags[]    │
│  }                                                                    │
└───────────────────────────────────┬──────────────────────────────────┘
                                    ▼
┌──────────────────────────────────────────────────────────────────────┐
│  PHASE VALIDATE: Vérification de cohérence                            │
├──────────────────────────────────────────────────────────────────────┤
│  Sous-scénarios:                                                      │
│  • validateObjects: IDs uniques, types valides                       │
│  • validateRelations: Sources/targets existent                        │
│  • detectCycles: Détection de cycles dans les relations              │
│  • validateSchema: Conformité au schéma de sortie                    │
├──────────────────────────────────────────────────────────────────────┤
│  Output: {                                                            │
│    valid: boolean, errors: [], warnings: [], cycles_detected: n      │
│  }                                                                    │
└───────────────────────────────────┬──────────────────────────────────┘
                                    ▼
┌──────────────────────────────────────────────────────────────────────┐
│  PHASE RENDER: Production de la sortie                                │
├──────────────────────────────────────────────────────────────────────┤
│  Sous-scénarios:                                                      │
│  • assembleProject: Assemble la structure finale                     │
│  • generateOutput: Produit le JSON canonique                         │
│  • generateReport: Crée le rapport de création                       │
├──────────────────────────────────────────────────────────────────────┤
│  Output: Projet EURKAI complet (JSON)                                 │
└───────────────────────────────────┬──────────────────────────────────┘
                                    ▼
                          ┌─────────────────┐
                          │  PROJET EURKAI  │
                          │   (structuré)   │
                          └─────────────────┘
```

---

## 2. Schéma de sortie standard

### Format canonique du "Projet EURKAI"

```json
{
  "projectId": "Project.BlogCreatif",
  "name": "BlogCreatif",
  "description": "Un blog EURKAI sur la créativité",
  "domain": "web",
  
  "objects": [
    {
      "id": "Agent.BlogCreatif.WebAgent",
      "type": "Agent",
      "name": "WebAgent",
      "bundles": ["core", "prompt", "web"],
      "metadata": {"source": "template"}
    },
    {
      "id": "View.BlogCreatif.MainView",
      "type": "View",
      "name": "MainView",
      "bundles": ["core", "render"],
      "metadata": {"source": "template"}
    },
    {
      "id": "Service.BlogCreatif.ContentService",
      "type": "Service",
      "name": "ContentService",
      "bundles": ["core"],
      "metadata": {"source": "template"}
    },
    {
      "id": "Config.BlogCreatif.WebConfig",
      "type": "Config",
      "name": "WebConfig",
      "bundles": ["config"],
      "metadata": {"source": "template"}
    }
  ],
  
  "relations": [
    {
      "source": "Agent.BlogCreatif.WebAgent",
      "target": "View.BlogCreatif.MainView",
      "type": "renders",
      "metadata": {"source": "template"}
    },
    {
      "source": "Agent.BlogCreatif.WebAgent",
      "target": "Service.BlogCreatif.ContentService",
      "type": "depends_on",
      "metadata": {"source": "template"}
    },
    {
      "source": "Agent.BlogCreatif.WebAgent",
      "target": "Config.BlogCreatif.WebConfig",
      "type": "references",
      "metadata": {"source": "inferred"}
    }
  ],
  
  "scenarios": [
    {
      "id": "Scenario.BlogCreatif.Build",
      "name": "Build Web",
      "type": "build",
      "steps_hint": ["loadTemplate", "createStructure", "validateStructure", "renderSkeleton"]
    },
    {
      "id": "Scenario.BlogCreatif.Deploy",
      "name": "Deploy Static",
      "type": "deploy",
      "steps_hint": ["loadConfig", "prepareDeployment", "validate", "deploy", "renderStatus"]
    },
    {
      "id": "Scenario.BlogCreatif.Analyze",
      "name": "Analyse du projet",
      "type": "analysis",
      "steps_hint": ["loadProject", "runMetaRules", "validateSchema", "renderReport"]
    }
  ],
  
  "tags": ["web", "blog"],
  
  "metadata": {
    "created_at": "2024-01-15T10:30:00",
    "version": "1.0.0",
    "input_type": "phrase",
    "confidence": 0.85,
    "object_count": 4,
    "relation_count": 3,
    "scenario_count": 3
  }
}
```

---

## 3. Exemples d'entrées + sorties

### Exemple 1: Phrase simple

**Entrée:**
```python
"Je veux un blog EURKAI sur la créativité"
```

**Sortie:**
```json
{
  "projectId": "Project.BlogEURKAI",
  "name": "BlogEURKAI",
  "description": "Je veux un blog EURKAI sur la créativité",
  "domain": "web",
  "objects": [
    {"id": "Agent.BlogEURKAI.WebAgent", "type": "Agent", "name": "WebAgent", "bundles": ["core", "prompt", "web"]},
    {"id": "View.BlogEURKAI.MainView", "type": "View", "name": "MainView", "bundles": ["core", "render"]},
    {"id": "Service.BlogEURKAI.ContentService", "type": "Service", "name": "ContentService", "bundles": ["core"]},
    {"id": "Config.BlogEURKAI.WebConfig", "type": "Config", "name": "WebConfig", "bundles": ["config"]}
  ],
  "relations": [
    {"source": "Agent.BlogEURKAI.WebAgent", "target": "View.BlogEURKAI.MainView", "type": "renders"},
    {"source": "Agent.BlogEURKAI.WebAgent", "target": "Service.BlogEURKAI.ContentService", "type": "depends_on"},
    {"source": "Agent.BlogEURKAI.WebAgent", "target": "Config.BlogEURKAI.WebConfig", "type": "references"}
  ],
  "scenarios": [
    {"id": "Scenario.BlogEURKAI.Build", "name": "Build Web", "type": "build"},
    {"id": "Scenario.BlogEURKAI.Deploy", "name": "Deploy Static", "type": "deploy"}
  ],
  "tags": ["web"]
}
```

### Exemple 2: Brief structuré

**Entrée:**
```python
"""
Projet: Plateforme de gestion de tâches collaborative

Objectifs:
- Dashboard principal avec vue Kanban
- Gestion des utilisateurs et équipes
- Notifications en temps réel

Stack: Python, FastAPI, React

Contraintes:
- Authentification OAuth
- Support mobile
"""
```

**Sortie:**
```json
{
  "projectId": "Project.PlateformeGestion",
  "name": "PlateformeGestion",
  "domain": "saas",
  "objects": [
    {"id": "Agent.PlateformeGestion.AppAgent", "type": "Agent", "bundles": ["core", "prompt", "saas"]},
    {"id": "View.PlateformeGestion.Dashboard", "type": "View", "bundles": ["core", "render"]},
    {"id": "View.PlateformeGestion.UserProfile", "type": "View", "bundles": ["core", "render"]},
    {"id": "Service.PlateformeGestion.AuthService", "type": "Service", "bundles": ["core", "auth"]},
    {"id": "Service.PlateformeGestion.CoreService", "type": "Service", "bundles": ["core"]},
    {"id": "Data.PlateformeGestion.UserModel", "type": "Data", "bundles": ["data"]},
    {"id": "Config.PlateformeGestion.AppConfig", "type": "Config", "bundles": ["config"]}
  ],
  "relations": [
    {"source": "Agent.PlateformeGestion.AppAgent", "target": "View.PlateformeGestion.Dashboard", "type": "renders"},
    {"source": "Agent.PlateformeGestion.AppAgent", "target": "Service.PlateformeGestion.AuthService", "type": "depends_on"},
    {"source": "Service.PlateformeGestion.CoreService", "target": "Data.PlateformeGestion.UserModel", "type": "uses"}
  ],
  "scenarios": [
    {"id": "Scenario.PlateformeGestion.Build", "name": "Build App", "type": "build"},
    {"id": "Scenario.PlateformeGestion.Test", "name": "Integration Tests", "type": "analysis"},
    {"id": "Scenario.PlateformeGestion.Deploy", "name": "Deploy Cloud", "type": "deploy"}
  ],
  "tags": ["saas", "python", "api"]
}
```

### Exemple 3: Schéma technique

**Entrée:**
```json
{
  "name": "OrchestrateurIA",
  "domain": "agent",
  "objects": [
    {"type": "Agent", "name": "Orchestrator", "bundles": ["core", "orchestration"]},
    {"type": "Agent", "name": "Analyzer", "bundles": ["core", "analysis"]}
  ],
  "relations": [
    {"from": "Orchestrator", "to": "Analyzer", "type": "orchestrates"}
  ]
}
```

**Sortie:**
```json
{
  "projectId": "Project.OrchestrateurIA",
  "name": "OrchestrateurIA",
  "domain": "agent",
  "objects": [
    {"id": "Agent.OrchestrateurIA.OrchestratorAgent", "type": "Agent", "bundles": ["core", "prompt", "orchestration"]},
    {"id": "Agent.OrchestrateurIA.WorkerAgent", "type": "Agent", "bundles": ["core", "prompt"]},
    {"id": "Agent.OrchestrateurIA.Orchestrator", "type": "Agent", "bundles": ["core", "orchestration"]},
    {"id": "Agent.OrchestrateurIA.Analyzer", "type": "Agent", "bundles": ["core", "analysis"]},
    {"id": "Service.OrchestrateurIA.PromptService", "type": "Service", "bundles": ["core", "prompt"]},
    {"id": "Service.OrchestrateurIA.MemoryService", "type": "Service", "bundles": ["core", "memory"]},
    {"id": "Config.OrchestrateurIA.AgentConfig", "type": "Config", "bundles": ["config"]}
  ],
  "relations": [
    {"source": "Agent.OrchestrateurIA.OrchestratorAgent", "target": "Agent.OrchestrateurIA.WorkerAgent", "type": "orchestrates"},
    {"source": "Agent.OrchestrateurIA.Orchestrator", "target": "Agent.OrchestrateurIA.Analyzer", "type": "orchestrates"}
  ],
  "scenarios": [
    {"id": "Scenario.OrchestrateurIA.Analyze", "name": "Analyze Agents", "type": "analysis"},
    {"id": "Scenario.OrchestrateurIA.Build", "name": "Build Agents", "type": "build"},
    {"id": "Scenario.OrchestrateurIA.Run", "name": "Run Orchestration", "type": "custom"}
  ],
  "tags": ["agent", "ai"]
}
```

---

## 4. Cas de test (briefs variés et réponses attendues)

### Cas 1: Domaine WEB
| Entrée | Domaine attendu | Objets clés |
|--------|-----------------|-------------|
| "Site vitrine pour startup" | web | Agent, View, ContentService |
| "Blog React avec Tailwind" | web | WebAgent, MainView |
| "Portail d'actualités" | web | Agent, View, Service |

### Cas 2: Domaine API
| Entrée | Domaine attendu | Objets clés |
|--------|-----------------|-------------|
| "API REST pour e-commerce" | api | APIAgent, MainService, DataService |
| "Microservice de paiement" | api | Agent, Service |
| "Backend GraphQL" | api | APIAgent, Service |

### Cas 3: Domaine SAAS
| Entrée | Domaine attendu | Objets clés |
|--------|-----------------|-------------|
| "Application SaaS de CRM" | saas | AppAgent, Dashboard, AuthService, UserModel |
| "Plateforme de gestion" | saas | Agent, View, Service, Data |

### Cas 4: Domaine AGENT
| Entrée | Domaine attendu | Objets clés |
|--------|-----------------|-------------|
| "Système multi-agents LLM" | agent | OrchestratorAgent, WorkerAgent, PromptService |
| "Bot conversationnel IA" | agent | Agent, MemoryService |

### Cas 5: Domaine DATA
| Entrée | Domaine attendu | Objets clés |
|--------|-----------------|-------------|
| "Pipeline ETL pour analytics" | data | DataAgent, ExtractService, TransformService, LoadService |
| "Entrepôt de données" | data | Agent, DataModel |

### Cas 6: Entrées mixtes
| Entrée | Type détecté | Confiance |
|--------|--------------|-----------|
| `{"brief": "API", "hints": {...}}` | mixed | ~0.85 |
| Brief long (>200 chars) | brief | ~0.80 |
| JSON valide avec "objects" | schema | ~0.95 |

---

## 5. Stratégie d'enrichissement itératif

### Principe

Le projet généré peut être **progressivement enrichi** par des scénarios secondaires:

```
Projet Initial (D2)
       │
       ▼
┌─────────────────────────────────────────────────────┐
│  Scénarios d'enrichissement (D3+)                   │
├─────────────────────────────────────────────────────┤
│                                                      │
│  1. Scenario.AddFeature                              │
│     → Ajoute des objets/relations pour une feature  │
│                                                      │
│  2. Scenario.RefineObject                            │
│     → Complète les bundles d'un objet existant      │
│                                                      │
│  3. Scenario.ValidateArchitecture                    │
│     → Vérifie la cohérence globale (cycles, etc.)   │
│                                                      │
│  4. Scenario.GenerateCode                            │
│     → Génère le code de base pour les objets        │
│                                                      │
│  5. Scenario.Deploy                                  │
│     → Prépare le déploiement                         │
│                                                      │
└─────────────────────────────────────────────────────┘
       │
       ▼
   Projet Complet
```

### Scénarios secondaires suggérés

| Scénario | Phase | Description |
|----------|-------|-------------|
| `Scenario.AddObject` | E/F | Ajoute un objet au projet existant |
| `Scenario.AddRelation` | E/F | Crée une nouvelle relation |
| `Scenario.RefineBundle` | E | Complète les bundles d'un objet |
| `Scenario.ValidateAll` | D3 | Validation complète du projet |
| `Scenario.GenerateCode` | E/F | Génération de code |
| `Scenario.ExportProject` | F | Export vers fichiers |

### Exemple d'enrichissement

```python
# 1. Génération initiale
result1 = MetaScenario.run("Blog simple")
project = result1.project

# 2. Enrichissement avec nouveau service
enrichment = {
    "partial": {
        "objects": [
            {"type": "Service", "name": "CommentService", "bundles": ["core", "comments"]}
        ],
        "relations": [
            {"from": "WebAgent", "to": "CommentService", "type": "depends_on"}
        ]
    },
    "brief": f"Ajouter un système de commentaires au projet {project.name}"
}
result2 = MetaScenario.run(enrichment)

# 3. Le nouveau projet intègre le service de commentaires
```

---

## API d'utilisation

### Utilisation directe

```python
from gevr.metascenarios import MetaScenarioProjetEURKAI

# Créer le MetaScénario
meta = MetaScenarioProjetEURKAI()

# Exécuter avec une phrase
result = meta.run("Je veux un blog sur la créativité")

# Vérifier le résultat
if result.ok:
    project = result.project
    print(f"Projet créé: {project.project_id}")
    print(f"Objets: {len(project.objects)}")
    print(f"Relations: {len(project.relations)}")
    
    # Exporter en JSON
    import json
    output = project.to_dict()
    print(json.dumps(output, indent=2))
else:
    print(f"Erreurs: {result.errors}")
```

### Avec options

```python
meta = MetaScenarioProjetEURKAI({
    "strict": True,      # Mode strict (erreurs = échec)
    "include_logs": True, # Inclure les logs détaillés
    "auto_fix": False    # Désactiver les corrections automatiques
})
```

### Intégration avec GEVR

```python
from gevr import GEVREngine
from gevr.metascenarios import register_projet_eurkai

# Créer le moteur
engine = GEVREngine()

# Enregistrer le MetaScénario
register_projet_eurkai(engine)

# Exécuter via le moteur GEVR
result = engine.run_scenario("Scenario.ProjetEURKAI", {
    "data": "Mon projet de blog"
})
```

---

## Tests

```bash
# Lancer les tests du MetaScénario (45+ tests)
cd gevr
pytest tests/test_metascenario.py -v

# Résultat attendu: 45+ tests passed
```

### Couverture des tests

- Détection du type d'entrée: 6 tests
- Détection du domaine: 6 tests
- Extraction de features: 4 tests
- Génération d'objets: 3 tests
- Génération de relations: 2 tests
- Génération de projet complet: 2 tests
- Exécution MetaScénario: 5 tests
- Exemples concrets: 3 tests
- Cas limites: 4 tests
- Validation: 3 tests
- Stratégie d'enrichissement: 2 tests

---

## Checklist de validation

- [x] Le MetaScénario "Projet EURKAI" est défini de manière **générique**
- [x] Il peut accepter au moins **3 types d'entrées** (phrase, brief, schéma)
- [x] Il produit une structure **réutilisable** dans EURKAI (objets, relations, scénarios)
- [x] **Exemples + cas de test** cohérents fournis
- [x] **Templates par domaine** (9 domaines)
- [x] **Pipeline GEVR** complet avec sous-scénarios explicites
- [x] **Stratégie d'enrichissement** documentée
- [x] **45+ tests** passent
- [x] Compatible avec la **fractale EURKAI**
- [x] Exploitable par les **scénarios futurs** (D3, E, F)

---

## Version

**MetaScénario Projet EURKAI v1.0.0** — D2/5
