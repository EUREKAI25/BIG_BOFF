#!/usr/bin/env python3
"""
EUREKAI D2/5 — Démonstration du MetaScénario "Projet EURKAI"
============================================================

Ce script démontre l'utilisation du MetaScénario avec:
1. Une phrase simple
2. Un brief structuré
3. Un schéma technique

Usage:
    python demo_metascenario.py
"""

import json
import sys
import os

# Ajouter le chemin du module
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from metascenarios import MetaScenarioProjetEURKAI


def separator(title: str):
    """Affiche un séparateur avec titre."""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70 + "\n")


def demo_phrase_simple():
    """Démonstration avec une phrase simple."""
    separator("EXEMPLE 1: Phrase simple")
    
    meta = MetaScenarioProjetEURKAI()
    result = meta.run("Je veux un blog EURKAI sur la créativité")
    
    print(f"Status: {result.status}")
    print(f"Projet ID: {result.project.project_id}")
    print(f"Domaine: {result.project.domain}")
    print(f"Objets: {len(result.project.objects)}")
    print(f"Relations: {len(result.project.relations)}")
    print(f"Scénarios: {len(result.project.scenarios)}")
    print(f"Durée: {result.duration_ms:.2f}ms")
    
    print("\nObjets générés:")
    for obj in result.project.objects:
        print(f"  - {obj.id} ({obj.type})")
    
    print("\nRelations:")
    for rel in result.project.relations:
        print(f"  - {rel.source.split('.')[-1]} → {rel.target.split('.')[-1]} ({rel.type})")
    
    print("\nScénarios:")
    for scen in result.project.scenarios:
        print(f"  - {scen.name} ({scen.type})")


def demo_brief():
    """Démonstration avec un brief structuré."""
    separator("EXEMPLE 2: Brief structuré")
    
    brief = """
    Projet: Plateforme de gestion de tâches collaborative
    
    Objectifs:
    - Dashboard principal avec vue Kanban
    - Gestion des utilisateurs et équipes
    - Notifications en temps réel
    
    Stack: Python, FastAPI, React
    
    Contraintes:
    - Authentification OAuth
    - Support mobile
    """
    
    meta = MetaScenarioProjetEURKAI()
    result = meta.run(brief)
    
    print(f"Status: {result.status}")
    print(f"Projet: {result.project.name}")
    print(f"Domaine détecté: {result.project.domain}")
    print(f"Confiance: {result.get_result.get('confidence', 0):.2f}")
    
    print("\nStructure générée:")
    output = result.project.to_dict()
    print(json.dumps({
        "projectId": output["projectId"],
        "domain": output["domain"],
        "objects": [{"id": o["id"], "type": o["type"]} for o in output["objects"]],
        "relations": output["relations"][:5],  # Limiter l'affichage
        "scenarios": [{"id": s["id"], "type": s["type"]} for s in output["scenarios"]]
    }, indent=2))


def demo_schema():
    """Démonstration avec un schéma technique."""
    separator("EXEMPLE 3: Schéma technique")
    
    schema = {
        "name": "OrchestrateurIA",
        "domain": "agent",
        "objects": [
            {"type": "Agent", "name": "Orchestrator", "bundles": ["core", "orchestration"]},
            {"type": "Agent", "name": "Analyzer", "bundles": ["core", "analysis"]},
            {"type": "Service", "name": "LLMService", "bundles": ["core", "llm"]}
        ],
        "relations": [
            {"from": "Orchestrator", "to": "Analyzer", "type": "orchestrates"},
            {"from": "Analyzer", "to": "LLMService", "type": "uses"}
        ]
    }
    
    meta = MetaScenarioProjetEURKAI()
    result = meta.run(schema)
    
    print(f"Status: {result.status}")
    print(f"Type d'entrée: {result.get_result.get('input_type')}")
    print(f"Confiance: {result.get_result.get('confidence', 0):.2f}")
    
    print("\nObjets générés (template + schéma):")
    for obj in result.project.objects:
        source = obj.metadata.get("source", "unknown")
        print(f"  - {obj.name} ({obj.type}) [source: {source}]")
    
    print("\nJSON de sortie complet:")
    print(json.dumps(result.project.to_dict(), indent=2))


def demo_api_facade():
    """Démonstration de l'API façade GEVR."""
    separator("EXEMPLE 4: API Façade GEVR")
    
    from __init__ import GEVR
    
    # Créer un projet directement via la façade
    result = GEVR.create_project("API REST pour e-commerce")
    
    print(f"Status: {result.status}")
    print(f"Projet: {result.project.project_id}")
    print(f"Domaine: {result.project.domain}")
    
    print("\nLa façade GEVR permet aussi:")
    print("  - GEVR.run('Scenario.ID', input) → exécuter un scénario")
    print("  - GEVR.create('Scenario.New').get(...).execute(...).build() → créer un scénario")
    print("  - @GEVR.handler('action', phase) → enregistrer un handler")


def main():
    """Exécute toutes les démonstrations."""
    print("\n" + "#" * 70)
    print("#" + " " * 68 + "#")
    print("#   EUREKAI D2/5 — Démonstration MetaScénario 'Projet EURKAI'    #")
    print("#" + " " * 68 + "#")
    print("#" * 70)
    
    try:
        demo_phrase_simple()
        demo_brief()
        demo_schema()
        demo_api_facade()
        
        separator("FIN DE LA DÉMONSTRATION")
        print("Tous les exemples ont été exécutés avec succès!")
        print("\nPour plus de détails, consultez:")
        print("  - LIVRAISON_D2.md : Documentation complète")
        print("  - tests/test_metascenario.py : Tous les tests")
        print("  - metascenarios/projet_eurkai.py : Code source du MetaScénario")
        
    except Exception as e:
        print(f"\nErreur: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
