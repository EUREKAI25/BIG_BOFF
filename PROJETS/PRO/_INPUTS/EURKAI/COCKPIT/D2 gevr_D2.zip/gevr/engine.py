"""
EUREKAI D1/4 — Moteur d'exécution GEVR
=======================================

Ce module implémente le moteur d'exécution des scénarios GEVR:
- runScenario(scenarioId, input) -> { status, logs, output }
- Gestion des handlers par phase
- Logging et traçabilité

Architecture:
- GEVREngine: Orchestrateur principal
- ActionHandler: Interface pour les handlers d'actions
- ExecutionContext: Contexte partagé entre étapes

Version: D1/4 - Scénarios GEVR de base
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import (
    Dict, Any, Optional, Callable, List, 
    Type, TypeVar, Union
)
from datetime import datetime
import time
import traceback
import sys

# Imports locaux
from .scenario import (
    GEVRScenario, GEVRPhase, StepDefinition,
    StepStatus, ScenarioStatus,
    StepResult, ScenarioResult
)


# =============================================================================
# CONTEXTE D'EXÉCUTION
# =============================================================================

@dataclass
class ExecutionContext:
    """
    Contexte partagé pendant l'exécution d'un scénario.
    
    Permet aux étapes de:
    - Partager des données entre phases
    - Accéder au store/fractale
    - Configurer le comportement
    
    Attributes:
        input: Données d'entrée du scénario
        data: Données intermédiaires (accumulées par les étapes)
        store: Référence au store fractal (optionnel)
        options: Options de configuration
        phase_outputs: Sorties par phase
        current_step: Étape en cours
        logs: Logs accumulés
    """
    input: Dict[str, Any] = field(default_factory=dict)
    data: Dict[str, Any] = field(default_factory=dict)
    store: Any = None
    options: Dict[str, Any] = field(default_factory=dict)
    phase_outputs: Dict[str, Any] = field(default_factory=dict)
    current_step: Optional[StepDefinition] = None
    logs: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    
    def set(self, key: str, value: Any):
        """Définit une valeur dans le contexte."""
        self.data[key] = value
    
    def get(self, key: str, default: Any = None) -> Any:
        """Récupère une valeur du contexte."""
        return self.data.get(key, self.input.get(key, default))
    
    def set_phase_output(self, phase: GEVRPhase, output: Any):
        """Enregistre la sortie d'une phase."""
        self.phase_outputs[phase.value] = output
    
    def get_phase_output(self, phase: GEVRPhase) -> Any:
        """Récupère la sortie d'une phase."""
        return self.phase_outputs.get(phase.value)
    
    def log(self, message: str, phase: GEVRPhase = None):
        """Ajoute un log au contexte."""
        prefix = f"[{phase.value}] " if phase else ""
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        self.logs.append(f"{timestamp} {prefix}{message}")
    
    def add_error(self, error: str):
        """Enregistre une erreur."""
        self.errors.append(error)
    
    def to_dict(self) -> Dict:
        """Exporte le contexte."""
        return {
            "input": self.input,
            "data": self.data,
            "phase_outputs": self.phase_outputs,
            "logs": self.logs,
            "errors": self.errors
        }


# =============================================================================
# INTERFACE HANDLER
# =============================================================================

class ActionHandler(ABC):
    """
    Interface pour les handlers d'actions GEVR.
    
    Chaque action dans un scénario est traitée par un handler spécifique.
    """
    
    @abstractmethod
    def execute(
        self,
        params: Dict[str, Any],
        context: ExecutionContext
    ) -> Any:
        """
        Exécute l'action.
        
        Args:
            params: Paramètres de l'action
            context: Contexte d'exécution
            
        Returns:
            Sortie de l'action
            
        Raises:
            Exception en cas d'erreur
        """
        pass
    
    @property
    def name(self) -> str:
        """Nom de l'action."""
        return self.__class__.__name__


class FunctionHandler(ActionHandler):
    """
    Handler basé sur une fonction callable.
    
    Permet d'enregistrer des fonctions simples comme handlers.
    """
    
    def __init__(self, func: Callable, action_name: str = None):
        self._func = func
        self._name = action_name or func.__name__
    
    def execute(self, params: Dict[str, Any], context: ExecutionContext) -> Any:
        return self._func(params, context)
    
    @property
    def name(self) -> str:
        return self._name


# =============================================================================
# REGISTRE DES HANDLERS
# =============================================================================

class HandlerRegistry:
    """
    Registre des handlers d'actions par phase.
    
    Organisation: phase → action_name → handler
    """
    
    def __init__(self):
        self._handlers: Dict[GEVRPhase, Dict[str, ActionHandler]] = {
            phase: {} for phase in GEVRPhase
        }
        self._global_handlers: Dict[str, ActionHandler] = {}
    
    def register(
        self,
        action: str,
        handler: Union[ActionHandler, Callable],
        phase: GEVRPhase = None
    ):
        """
        Enregistre un handler pour une action.
        
        Args:
            action: Nom de l'action
            handler: Handler ou callable
            phase: Phase spécifique (None = global)
        """
        if callable(handler) and not isinstance(handler, ActionHandler):
            handler = FunctionHandler(handler, action)
        
        if phase:
            self._handlers[phase][action] = handler
        else:
            self._global_handlers[action] = handler
    
    def get(self, action: str, phase: GEVRPhase) -> Optional[ActionHandler]:
        """
        Récupère le handler pour une action.
        
        Recherche d'abord dans la phase spécifique, puis dans les globaux.
        """
        # Chercher dans la phase
        if action in self._handlers[phase]:
            return self._handlers[phase][action]
        
        # Chercher dans les globaux
        if action in self._global_handlers:
            return self._global_handlers[action]
        
        return None
    
    def has(self, action: str, phase: GEVRPhase = None) -> bool:
        """Vérifie si un handler existe."""
        if phase:
            return action in self._handlers[phase] or action in self._global_handlers
        return action in self._global_handlers
    
    def list_actions(self, phase: GEVRPhase = None) -> List[str]:
        """Liste les actions enregistrées."""
        if phase:
            return list(self._handlers[phase].keys())
        return list(self._global_handlers.keys())


# =============================================================================
# HANDLERS INTÉGRÉS
# =============================================================================

def _handler_noop(params: Dict, context: ExecutionContext) -> Any:
    """Handler no-op pour les tests."""
    context.log("No-op action executed")
    return {"status": "noop"}


def _handler_log(params: Dict, context: ExecutionContext) -> Any:
    """Handler pour logger un message."""
    message = params.get("message", "Log step executed")
    level = params.get("level", "info")
    context.log(f"[{level.upper()}] {message}")
    return {"logged": message, "level": level}


def _handler_set_data(params: Dict, context: ExecutionContext) -> Any:
    """Handler pour définir des données dans le contexte."""
    key = params.get("key")
    value = params.get("value")
    if key:
        context.set(key, value)
        return {"set": key, "value": value}
    return {"error": "key is required"}


def _handler_get_data(params: Dict, context: ExecutionContext) -> Any:
    """Handler pour récupérer des données du contexte."""
    key = params.get("key")
    default = params.get("default")
    value = context.get(key, default)
    return {"key": key, "value": value}


def _handler_load_object(params: Dict, context: ExecutionContext) -> Any:
    """
    Handler GET: Charger un objet depuis le store.
    """
    object_id = params.get("id") or params.get("object_id")
    
    if not object_id:
        raise ValueError("object_id is required")
    
    # Si un store est disponible
    if context.store:
        if hasattr(context.store, 'get'):
            obj = context.store.get(object_id)
        elif isinstance(context.store, dict):
            obj = context.store.get(object_id)
        else:
            obj = None
        
        if obj is None:
            raise ValueError(f"Object not found: {object_id}")
        
        context.set("object", obj)
        context.set("object_id", object_id)
        context.log(f"Loaded object: {object_id}", GEVRPhase.GET)
        return obj
    
    # Mode simulation (pas de store)
    context.log(f"Simulated load: {object_id}", GEVRPhase.GET)
    simulated_obj = {
        "id": object_id,
        "type": "Object",
        "metadata": {},
        "_simulated": True
    }
    context.set("object", simulated_obj)
    context.set("object_id", object_id)
    return simulated_obj


def _handler_check_errors(params: Dict, context: ExecutionContext) -> Any:
    """
    Handler VALIDATE: Vérifier les erreurs accumulées.
    """
    strict = params.get("strict", False)
    
    if context.errors:
        if strict:
            raise ValueError(f"Validation failed: {'; '.join(context.errors)}")
        return {
            "valid": False,
            "errors": context.errors.copy()
        }
    
    context.log("Validation passed: no errors", GEVRPhase.VALIDATE)
    return {"valid": True, "errors": []}


def _handler_render_report(params: Dict, context: ExecutionContext) -> Any:
    """
    Handler RENDER: Générer un rapport.
    """
    format_type = params.get("format", "text")
    include_logs = params.get("include_logs", True)
    
    report = {
        "type": "report",
        "format": format_type,
        "data": context.data.copy(),
        "phase_outputs": context.phase_outputs.copy(),
        "timestamp": datetime.now().isoformat()
    }
    
    if include_logs:
        report["logs"] = context.logs.copy()
    
    context.log(f"Report generated ({format_type})", GEVRPhase.RENDER)
    return report


def _handler_render_json(params: Dict, context: ExecutionContext) -> Any:
    """
    Handler RENDER: Sortie JSON structurée.
    """
    include = params.get("include", ["data", "phase_outputs"])
    
    result = {}
    if "data" in include:
        result["data"] = context.data.copy()
    if "phase_outputs" in include:
        result["phase_outputs"] = context.phase_outputs.copy()
    if "logs" in include:
        result["logs"] = context.logs.copy()
    if "input" in include:
        result["input"] = context.input.copy()
    
    return result


# =============================================================================
# MOTEUR D'EXÉCUTION
# =============================================================================

class GEVREngine:
    """
    Moteur d'exécution des scénarios GEVR.
    
    Usage:
        engine = GEVREngine()
        result = engine.run_scenario("Scenario.AnalyzeObject", {"object_id": "..."})
    
    Attributes:
        registry: Registre des handlers
        scenarios: Scénarios enregistrés
        store: Store fractal (optionnel)
        options: Options globales
    """
    
    def __init__(
        self,
        store: Any = None,
        register_defaults: bool = True
    ):
        self.registry = HandlerRegistry()
        self.scenarios: Dict[str, GEVRScenario] = {}
        self.store = store
        self.options: Dict[str, Any] = {}
        
        if register_defaults:
            self._register_default_handlers()
    
    def _register_default_handlers(self):
        """Enregistre les handlers par défaut."""
        # Handlers globaux
        self.registry.register("noop", _handler_noop)
        self.registry.register("log", _handler_log)
        self.registry.register("setData", _handler_set_data)
        self.registry.register("getData", _handler_get_data)
        
        # Handlers GET
        self.registry.register("loadObject", _handler_load_object, GEVRPhase.GET)
        
        # Handlers VALIDATE
        self.registry.register("checkErrors", _handler_check_errors, GEVRPhase.VALIDATE)
        
        # Handlers RENDER
        self.registry.register("renderReport", _handler_render_report, GEVRPhase.RENDER)
        self.registry.register("renderJson", _handler_render_json, GEVRPhase.RENDER)
    
    def register_handler(
        self,
        action: str,
        handler: Union[ActionHandler, Callable],
        phase: GEVRPhase = None
    ):
        """
        Enregistre un handler personnalisé.
        
        Args:
            action: Nom de l'action
            handler: Handler ou callable
            phase: Phase spécifique (None = global)
        """
        self.registry.register(action, handler, phase)
    
    def register_scenario(self, scenario: GEVRScenario):
        """
        Enregistre un scénario.
        
        Args:
            scenario: Scénario à enregistrer
        """
        errors = scenario.validate()
        if errors:
            raise ValueError(f"Invalid scenario: {'; '.join(errors)}")
        
        self.scenarios[scenario.id] = scenario
    
    def get_scenario(self, scenario_id: str) -> Optional[GEVRScenario]:
        """Récupère un scénario par son ID."""
        return self.scenarios.get(scenario_id)
    
    def run_scenario(
        self,
        scenario_id: str,
        input_data: Dict[str, Any] = None,
        options: Dict[str, Any] = None
    ) -> ScenarioResult:
        """
        Exécute un scénario enregistré.
        
        Args:
            scenario_id: ID du scénario
            input_data: Données d'entrée
            options: Options d'exécution
            
        Returns:
            ScenarioResult avec status, logs, output
        """
        scenario = self.get_scenario(scenario_id)
        if not scenario:
            raise ValueError(f"Scenario not found: {scenario_id}")
        
        return self.execute(scenario, input_data, options)
    
    def execute(
        self,
        scenario: GEVRScenario,
        input_data: Dict[str, Any] = None,
        options: Dict[str, Any] = None
    ) -> ScenarioResult:
        """
        Exécute un scénario.
        
        Args:
            scenario: Scénario à exécuter
            input_data: Données d'entrée
            options: Options d'exécution
            
        Returns:
            ScenarioResult complet
        """
        # Initialiser le contexte
        context = ExecutionContext(
            input=input_data or {},
            store=self.store,
            options={**self.options, **(options or {})}
        )
        
        # Initialiser le résultat
        result = ScenarioResult(
            scenario=scenario,
            status=ScenarioStatus.RUNNING,
            started_at=datetime.now()
        )
        
        result.add_log(f"Starting scenario: {scenario.name}")
        
        # Exécuter chaque étape
        failed = False
        for step in scenario.steps:
            if failed and step.required:
                # Ignorer les étapes requises après un échec
                step_result = StepResult(
                    step=step,
                    status=StepStatus.SKIPPED,
                    error="Previous required step failed"
                )
                result.step_results.append(step_result)
                continue
            
            # Exécuter l'étape
            step_result = self._execute_step(step, context)
            result.step_results.append(step_result)
            
            # Mettre à jour le contexte avec la sortie
            if step_result.ok:
                context.set_phase_output(step.phase, step_result.output)
            
            # Gérer les erreurs
            if not step_result.ok:
                result.add_log(f"Step failed: {step.action} - {step_result.error}", step.phase)
                
                if step.required and step.on_error == "stop":
                    failed = True
                elif step.on_error == "skip_phase":
                    # Ignorer les autres étapes de la même phase
                    pass
        
        # Finaliser le résultat
        result.completed_at = datetime.now()
        result.context = context.to_dict()
        result.logs.extend(context.logs)
        
        # Déterminer le statut final
        if failed:
            result.status = ScenarioStatus.FAILED
        elif any(r.status == StepStatus.FAILED for r in result.step_results):
            result.status = ScenarioStatus.PARTIAL
        else:
            result.status = ScenarioStatus.COMPLETED
        
        # Extraire la sortie finale (dernière étape RENDER)
        render_output = context.get_phase_output(GEVRPhase.RENDER)
        result.output = render_output or context.data
        
        result.add_log(f"Scenario completed: {result.status.value}")
        
        return result
    
    def _execute_step(
        self,
        step: StepDefinition,
        context: ExecutionContext
    ) -> StepResult:
        """
        Exécute une étape individuelle.
        
        Args:
            step: Définition de l'étape
            context: Contexte d'exécution
            
        Returns:
            StepResult
        """
        context.current_step = step
        start_time = time.time()
        
        # Vérifier la condition (si présente)
        if step.condition:
            # TODO: Évaluer la condition avec ERK
            pass
        
        # Récupérer le handler
        handler = self.registry.get(step.action, step.phase)
        
        if not handler:
            return StepResult(
                step=step,
                status=StepStatus.FAILED,
                error=f"No handler for action: {step.action}",
                duration_ms=(time.time() - start_time) * 1000
            )
        
        # Exécuter le handler
        try:
            context.log(f"Executing: {step.action}", step.phase)
            output = handler.execute(step.params, context)
            
            duration_ms = (time.time() - start_time) * 1000
            
            return StepResult(
                step=step,
                status=StepStatus.SUCCESS,
                output=output,
                duration_ms=duration_ms,
                logs=context.logs.copy()
            )
            
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            error_msg = str(e)
            
            # Log détaillé en mode debug
            if context.options.get("debug"):
                error_msg += f"\n{traceback.format_exc()}"
            
            context.add_error(error_msg)
            
            return StepResult(
                step=step,
                status=StepStatus.FAILED,
                error=error_msg,
                duration_ms=duration_ms,
                logs=context.logs.copy()
            )


# =============================================================================
# API SIMPLIFIÉE
# =============================================================================

# Instance globale du moteur
_default_engine: Optional[GEVREngine] = None


def get_engine(store: Any = None) -> GEVREngine:
    """Obtient l'instance globale du moteur (lazy init)."""
    global _default_engine
    if _default_engine is None:
        _default_engine = GEVREngine(store=store)
    elif store is not None:
        _default_engine.store = store
    return _default_engine


def run_scenario(
    scenario_id: str,
    input_data: Dict[str, Any] = None,
    options: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    API centrale pour exécuter un scénario.
    
    Args:
        scenario_id: ID du scénario
        input_data: Données d'entrée
        options: Options d'exécution
        
    Returns:
        Dict avec status, logs, output
    """
    engine = get_engine()
    result = engine.run_scenario(scenario_id, input_data, options)
    return result.to_dict()


def register_scenario(scenario: GEVRScenario):
    """Enregistre un scénario dans le moteur global."""
    engine = get_engine()
    engine.register_scenario(scenario)


def register_handler(
    action: str,
    handler: Union[ActionHandler, Callable],
    phase: GEVRPhase = None
):
    """Enregistre un handler dans le moteur global."""
    engine = get_engine()
    engine.register_handler(action, handler, phase)
