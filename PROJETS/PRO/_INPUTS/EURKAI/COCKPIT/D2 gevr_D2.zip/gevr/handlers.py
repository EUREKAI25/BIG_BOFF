"""
EUREKAI D1/4 — Handlers GEVR spécialisés
=========================================

Ce module fournit les handlers d'actions qui intègrent:
- ERK (Évaluation de règles B3)
- MetaRelations (Analyse de structure C3)
- Opérations fractales

Handlers par phase:
- GET: loadObject, loadBundle, loadTemplate
- EXECUTE: runMetaRules, applyERK, transform
- VALIDATE: checkErrors, validateSchema, validateERK
- RENDER: renderReport, renderLog, renderView

Version: D1/4 - Scénarios GEVR de base
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional
from datetime import datetime
import sys
import os

# Ajouter les chemins pour les imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Imports GEVR
from .scenario import GEVRPhase
from .engine import ExecutionContext, ActionHandler, FunctionHandler

# Imports ERK (B3)
try:
    from erk import (
        ERK, parse, evaluate_rule, evaluate_with_actions,
        EvalResult, ActionCollector, SuggestedAction
    )
    ERK_AVAILABLE = True
except ImportError:
    ERK_AVAILABLE = False

# Imports MetaRelations (C3)
try:
    from C3_metarelations.metarelations_engine import (
        MetaRelationsEngine, RelationGraph, Relation,
        RelationType, analyze_relations, quick_analyze
    )
    METARELATIONS_AVAILABLE = True
except ImportError:
    METARELATIONS_AVAILABLE = False


# =============================================================================
# HANDLERS GET
# =============================================================================

def handler_load_bundle(params: Dict, context: ExecutionContext) -> Any:
    """
    GET: Charge un bundle d'objet (avec ses dépendances).
    
    Params:
        id: ID de l'objet principal
        include_relations: Inclure les objets liés (default: True)
        depth: Profondeur de résolution (default: 1)
    """
    object_id = params.get("id")
    include_relations = params.get("include_relations", True)
    depth = params.get("depth", 1)
    
    if not object_id:
        raise ValueError("id is required")
    
    bundle = {
        "id": object_id,
        "objects": {},
        "relations": []
    }
    
    # Charger l'objet principal
    if context.store:
        main_obj = context.store.get(object_id) if hasattr(context.store, 'get') else context.store.get(object_id, {})
        bundle["objects"][object_id] = main_obj
        
        # Charger les relations si demandé
        if include_relations and main_obj:
            relations = main_obj.get("metadata", {}).get("relations", [])
            bundle["relations"] = relations
            
            # Résoudre les objets liés (niveau 1)
            if depth >= 1:
                for rel in relations:
                    target_id = rel.get("target")
                    if target_id and target_id not in bundle["objects"]:
                        target_obj = context.store.get(target_id)
                        if target_obj:
                            bundle["objects"][target_id] = target_obj
    else:
        # Mode simulation
        bundle["objects"][object_id] = {
            "id": object_id,
            "type": "Object",
            "_simulated": True
        }
    
    context.set("bundle", bundle)
    context.log(f"Loaded bundle: {object_id} ({len(bundle['objects'])} objects)", GEVRPhase.GET)
    
    return bundle


def handler_load_template(params: Dict, context: ExecutionContext) -> Any:
    """
    GET: Charge un template de projet.
    
    Params:
        template_id: ID du template
        type: Type de template (project, agent, service, etc.)
    """
    # Résoudre les paramètres depuis params ou input du contexte
    template_id = params.get("template_id") or params.get("id")
    if template_id and template_id.startswith("${"):
        # Résoudre depuis le contexte input
        template_id = context.get("template_id")
    
    template_type = params.get("type", "project")
    if template_type and template_type.startswith("${"):
        template_type = context.get("template_type", "project")
    
    if not template_id:
        raise ValueError("template_id is required")
    
    # Templates prédéfinis
    templates = {
        "project.basic": {
            "id": "Template.Project.Basic",
            "name": "Basic Project",
            "structure": [
                {"type": "Agent", "name": "MainAgent", "bundles": ["core", "prompt"]},
                {"type": "Service", "name": "MainService", "bundles": ["core"]},
                {"type": "Config", "name": "ProjectConfig", "bundles": ["config"]}
            ],
            "relations": [
                {"from": "MainAgent", "to": "MainService", "type": "depends_on"},
                {"from": "MainAgent", "to": "ProjectConfig", "type": "references"}
            ]
        },
        "agent.minimal": {
            "id": "Template.Agent.Minimal",
            "name": "Minimal Agent",
            "structure": [
                {"type": "Agent", "name": "Agent", "bundles": ["core"]}
            ],
            "relations": []
        }
    }
    
    # Chercher dans le store ou les prédéfinis
    template = None
    if context.store:
        template = context.store.get(template_id)
    
    if not template:
        template = templates.get(template_id) or templates.get(f"{template_type}.{template_id}")
    
    if not template:
        raise ValueError(f"Template not found: {template_id}")
    
    context.set("template", template)
    context.log(f"Loaded template: {template.get('name', template_id)}", GEVRPhase.GET)
    
    return template


def handler_load_rules(params: Dict, context: ExecutionContext) -> Any:
    """
    GET: Charge les règles ERK d'un objet.
    
    Params:
        object_id: ID de l'objet
        rule_names: Liste des règles à charger (optionnel)
    """
    object_id = params.get("object_id") or context.get("object_id")
    rule_names = params.get("rule_names")
    
    if not object_id:
        raise ValueError("object_id is required")
    
    rules = {}
    
    if context.store:
        obj = context.store.get(object_id)
        if obj:
            all_rules = obj.get("rules", {})
            if rule_names:
                rules = {k: v for k, v in all_rules.items() if k in rule_names}
            else:
                rules = all_rules
    
    context.set("rules", rules)
    context.log(f"Loaded {len(rules)} rules for {object_id}", GEVRPhase.GET)
    
    return rules


# =============================================================================
# HANDLERS EXECUTE
# =============================================================================

def handler_run_metarules(params: Dict, context: ExecutionContext) -> Any:
    """
    EXECUTE: Exécute l'analyse MetaRelations sur un objet/bundle.
    
    Params:
        detect_cycles: Détecter les cycles (default: True)
        detect_redundancies: Détecter les redondances (default: True)
        generate_suggestions: Générer des suggestions (default: True)
    """
    if not METARELATIONS_AVAILABLE:
        context.log("MetaRelations not available, skipping", GEVRPhase.EXECUTE)
        return {"skipped": True, "reason": "MetaRelations not available"}
    
    detect_cycles = params.get("detect_cycles", True)
    detect_redundancies = params.get("detect_redundancies", True)
    generate_suggestions = params.get("generate_suggestions", True)
    
    # Récupérer les relations du contexte
    bundle = context.get("bundle")
    obj = context.get("object")
    
    relations_data = []
    
    if bundle:
        relations_data = bundle.get("relations", [])
    elif obj:
        relations_data = obj.get("metadata", {}).get("relations", [])
    
    if not relations_data:
        context.log("No relations to analyze", GEVRPhase.EXECUTE)
        return {
            "cycles": [],
            "redundancies": [],
            "suggestions": [],
            "stats": {"total_relations": 0}
        }
    
    # Exécuter l'analyse
    result = quick_analyze(relations_data)
    
    # Enregistrer les résultats dans le contexte
    context.set("metarelations_result", result)
    
    if result.get("cycles"):
        context.add_error(f"Found {len(result['cycles'])} cycles in relations")
    
    context.log(
        f"MetaRelations: {len(result.get('cycles', []))} cycles, "
        f"{len(result.get('redundancies', []))} redundancies, "
        f"{len(result.get('suggestions', []))} suggestions",
        GEVRPhase.EXECUTE
    )
    
    return result


def handler_apply_erk(params: Dict, context: ExecutionContext) -> Any:
    """
    EXECUTE: Applique les règles ERK sur un objet.
    
    Params:
        object_id: ID de l'objet cible
        rule_name: Nom de la règle (optionnel, toutes si absent)
        collect_actions: Collecter les actions suggérées (default: True)
    """
    if not ERK_AVAILABLE:
        context.log("ERK not available, skipping", GEVRPhase.EXECUTE)
        return {"skipped": True, "reason": "ERK not available"}
    
    object_id = params.get("object_id") or context.get("object_id")
    rule_name = params.get("rule_name")
    collect_actions = params.get("collect_actions", True)
    
    if not object_id:
        raise ValueError("object_id is required")
    
    obj = context.get("object")
    rules = context.get("rules", {})
    
    results = []
    all_actions = []
    
    # Construire le contexte ERK
    erk_context = {
        "this": obj or {"id": object_id},
        "ctx": {
            "phase": "EXECUTE",
            "scenario": context.options.get("scenario_id", "unknown")
        }
    }
    
    # Évaluer les règles
    rules_to_eval = {rule_name: rules.get(rule_name)} if rule_name else rules
    
    for name, rule_text in rules_to_eval.items():
        if not rule_text:
            continue
        
        try:
            if collect_actions:
                result = ERK.quick_eval_with_actions(rule_text, erk_context)
                if result.get("suggested_actions"):
                    all_actions.extend(result["suggested_actions"])
            else:
                result = ERK.quick_eval(rule_text, erk_context)
            
            results.append({
                "rule": name,
                "result": result
            })
        except Exception as e:
            results.append({
                "rule": name,
                "error": str(e)
            })
    
    context.set("erk_results", results)
    context.set("suggested_actions", all_actions)
    
    context.log(
        f"ERK: evaluated {len(results)} rules, {len(all_actions)} actions suggested",
        GEVRPhase.EXECUTE
    )
    
    return {
        "results": results,
        "suggested_actions": all_actions
    }


def handler_transform(params: Dict, context: ExecutionContext) -> Any:
    """
    EXECUTE: Applique une transformation sur les données.
    
    Params:
        action: Type de transformation (complete_bundles, merge, filter, etc.)
        target: Cible de la transformation
        options: Options spécifiques
    """
    action = params.get("action", "identity")
    target = params.get("target", "data")
    options = params.get("options", {})
    
    data = context.get(target)
    
    if action == "identity":
        # Pas de transformation
        result = data
    
    elif action == "complete_bundles":
        # Compléter les bundles manquants
        if isinstance(data, dict) and "bundles" in data:
            existing = set(data.get("bundles", []))
            required = set(options.get("required_bundles", ["core"]))
            missing = required - existing
            
            result = {
                **data,
                "bundles": list(existing | required),
                "bundles_added": list(missing)
            }
        else:
            result = data
    
    elif action == "merge":
        # Fusionner avec d'autres données
        other_key = options.get("with")
        other = context.get(other_key, {})
        result = {**(data or {}), **other}
    
    elif action == "filter":
        # Filtrer les données
        keys = options.get("keys", [])
        if isinstance(data, dict):
            result = {k: v for k, v in data.items() if k in keys}
        else:
            result = data
    
    else:
        raise ValueError(f"Unknown transform action: {action}")
    
    context.set(f"{target}_transformed", result)
    context.log(f"Transform '{action}' applied to {target}", GEVRPhase.EXECUTE)
    
    return result


def handler_create_structure(params: Dict, context: ExecutionContext) -> Any:
    """
    EXECUTE: Crée une structure de projet à partir d'un template.
    
    Params:
        name: Nom du projet
        template: Template à utiliser (ou depuis contexte)
        customize: Personnalisations
    """
    name = params.get("name", "NewProject")
    if name and name.startswith("${"):
        name = context.get("project_name", "NewProject")
    
    template = params.get("template") or context.get("template")
    
    customize = params.get("customize", {})
    if customize and isinstance(customize, str) and customize.startswith("${"):
        customize = context.get("customize", {})
    
    if not template:
        raise ValueError("template is required (in params or context)")
    
    # Générer la structure
    structure = {
        "id": f"Project.{name}",
        "name": name,
        "type": "Project",
        "objects": [],
        "relations": []
    }
    
    # Créer les objets selon le template
    for item in template.get("structure", []):
        obj_type = item.get("type", "Object")
        obj_name = item.get("name", f"New{obj_type}")
        bundles = item.get("bundles", ["core"])
        
        # Appliquer les personnalisations
        if obj_name in customize:
            custom = customize[obj_name]
            obj_name = custom.get("name", obj_name)
            bundles = custom.get("bundles", bundles)
        
        obj = {
            "id": f"{obj_type}.{name}.{obj_name}",
            "type": obj_type,
            "name": obj_name,
            "bundles": bundles,
            "metadata": {
                "created_from_template": template.get("id"),
                "created_at": datetime.now().isoformat()
            }
        }
        structure["objects"].append(obj)
    
    # Créer les relations
    for rel in template.get("relations", []):
        from_name = rel.get("from")
        to_name = rel.get("to")
        rel_type = rel.get("type", "related_to")
        
        # Résoudre les IDs
        from_id = None
        to_id = None
        for obj in structure["objects"]:
            if from_name in obj["id"]:
                from_id = obj["id"]
            if to_name in obj["id"]:
                to_id = obj["id"]
        
        if from_id and to_id:
            structure["relations"].append({
                "source": from_id,
                "target": to_id,
                "type": rel_type
            })
    
    context.set("created_structure", structure)
    context.log(
        f"Created structure '{name}' with {len(structure['objects'])} objects",
        GEVRPhase.EXECUTE
    )
    
    return structure


# =============================================================================
# HANDLERS VALIDATE
# =============================================================================

def handler_validate_schema(params: Dict, context: ExecutionContext) -> Any:
    """
    VALIDATE: Valide un objet contre un schéma.
    
    Params:
        target: Clé de la donnée à valider (default: "object")
        schema: Schéma à utiliser (ou schema_id pour lookup)
        strict: Mode strict (default: False)
    """
    target = params.get("target", "object")
    schema = params.get("schema", {})
    strict = params.get("strict", False)
    
    data = context.get(target)
    
    if not data:
        return {"valid": False, "errors": [f"No data found for '{target}'"]}
    
    errors = []
    warnings = []
    
    # Validation basique si pas de schéma
    if not schema:
        required_fields = ["id", "type"]
        for field in required_fields:
            if field not in data:
                errors.append(f"Missing required field: {field}")
    else:
        # Valider selon le schéma
        for field, rules in schema.get("required", {}).items():
            if field not in data:
                errors.append(f"Missing required field: {field}")
        
        for field, allowed in schema.get("allowed_values", {}).items():
            if field in data and data[field] not in allowed:
                errors.append(f"Invalid value for {field}: {data[field]}")
    
    # Enregistrer les erreurs dans le contexte
    for error in errors:
        context.add_error(error)
    
    result = {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings
    }
    
    context.set("validation_result", result)
    context.log(
        f"Schema validation: {'passed' if result['valid'] else 'failed'}",
        GEVRPhase.VALIDATE
    )
    
    return result


def handler_validate_erk(params: Dict, context: ExecutionContext) -> Any:
    """
    VALIDATE: Valide les résultats ERK et les actions suggérées.
    
    Params:
        fail_on_deny: Échouer si une règle deny est vraie
        validate_actions: Valider les actions suggérées
    """
    fail_on_deny = params.get("fail_on_deny", True)
    validate_actions = params.get("validate_actions", True)
    
    erk_results = context.get("erk_results", [])
    suggested_actions = context.get("suggested_actions", [])
    
    errors = []
    
    # Vérifier les résultats ERK
    for item in erk_results:
        result = item.get("result", {})
        if result.get("action") == "deny" and result.get("value") == True:
            if fail_on_deny:
                errors.append(f"Rule '{item.get('rule')}' denied: {result.get('reason', 'no reason')}")
    
    # Valider les actions suggérées
    if validate_actions and ERK_AVAILABLE:
        from erk import validate_action, SuggestedAction, ActionType
        
        for action_dict in suggested_actions:
            # Reconstruire l'action pour validation
            try:
                action_type = ActionType[action_dict.get("type", "CUSTOM").upper()]
                action = SuggestedAction(
                    action_type=action_type,
                    target=action_dict.get("target", ""),
                    params=action_dict.get("params", {})
                )
                action_errors = validate_action(action)
                errors.extend(action_errors)
            except Exception as e:
                errors.append(f"Invalid action: {e}")
    
    for error in errors:
        context.add_error(error)
    
    result = {
        "valid": len(errors) == 0,
        "errors": errors,
        "erk_results_count": len(erk_results),
        "suggested_actions_count": len(suggested_actions)
    }
    
    context.log(
        f"ERK validation: {len(errors)} errors",
        GEVRPhase.VALIDATE
    )
    
    return result


def handler_validate_structure(params: Dict, context: ExecutionContext) -> Any:
    """
    VALIDATE: Valide une structure créée (relations, cohérence).
    """
    structure = context.get("created_structure")
    
    if not structure:
        return {"valid": False, "errors": ["No structure to validate"]}
    
    errors = []
    
    # Vérifier que les objets ont des IDs uniques
    obj_ids = [obj["id"] for obj in structure.get("objects", [])]
    if len(obj_ids) != len(set(obj_ids)):
        errors.append("Duplicate object IDs detected")
    
    # Vérifier que les relations pointent vers des objets existants
    for rel in structure.get("relations", []):
        if rel["source"] not in obj_ids:
            errors.append(f"Relation source not found: {rel['source']}")
        if rel["target"] not in obj_ids:
            errors.append(f"Relation target not found: {rel['target']}")
    
    # Vérifier les cycles si MetaRelations disponible
    if METARELATIONS_AVAILABLE and structure.get("relations"):
        result = quick_analyze(structure["relations"])
        if result.get("cycles"):
            for cycle in result["cycles"]:
                errors.append(f"Cycle detected: {cycle.get('display', cycle)}")
    
    for error in errors:
        context.add_error(error)
    
    result = {
        "valid": len(errors) == 0,
        "errors": errors,
        "objects_count": len(structure.get("objects", [])),
        "relations_count": len(structure.get("relations", []))
    }
    
    context.log(
        f"Structure validation: {'passed' if result['valid'] else 'failed'}",
        GEVRPhase.VALIDATE
    )
    
    return result


# =============================================================================
# HANDLERS RENDER
# =============================================================================

def handler_render_analysis(params: Dict, context: ExecutionContext) -> Any:
    """
    RENDER: Génère un rapport d'analyse complet.
    """
    format_type = params.get("format", "full")
    
    report = {
        "type": "analysis_report",
        "timestamp": datetime.now().isoformat(),
        "format": format_type
    }
    
    # Collecter les résultats de chaque phase
    obj = context.get("object")
    if obj:
        report["object"] = {
            "id": obj.get("id"),
            "type": obj.get("type"),
            "bundles": obj.get("bundles", [])
        }
    
    metarelations = context.get("metarelations_result")
    if metarelations:
        report["metarelations"] = {
            "cycles": len(metarelations.get("cycles", [])),
            "redundancies": len(metarelations.get("redundancies", [])),
            "suggestions": metarelations.get("suggestions", [])
        }
    
    erk_results = context.get("erk_results")
    if erk_results:
        report["erk"] = {
            "rules_evaluated": len(erk_results),
            "results": erk_results if format_type == "full" else None
        }
    
    suggested_actions = context.get("suggested_actions")
    if suggested_actions:
        report["suggested_actions"] = suggested_actions
    
    validation = context.get("validation_result")
    if validation:
        report["validation"] = validation
    
    # Résumé
    errors = context.errors
    report["summary"] = {
        "status": "ok" if not errors else "has_issues",
        "errors_count": len(errors),
        "errors": errors if format_type == "full" else None
    }
    
    context.log(f"Analysis report generated ({format_type})", GEVRPhase.RENDER)
    
    return report


def handler_render_skeleton(params: Dict, context: ExecutionContext) -> Any:
    """
    RENDER: Génère la sortie pour un squelette de projet créé.
    """
    format_type = params.get("format", "summary")
    
    structure = context.get("created_structure")
    
    if not structure:
        return {"error": "No structure to render"}
    
    output = {
        "type": "skeleton_output",
        "timestamp": datetime.now().isoformat(),
        "project": {
            "id": structure.get("id"),
            "name": structure.get("name")
        }
    }
    
    if format_type in ("full", "detailed"):
        output["objects"] = structure.get("objects", [])
        output["relations"] = structure.get("relations", [])
    else:
        output["objects_count"] = len(structure.get("objects", []))
        output["relations_count"] = len(structure.get("relations", []))
        output["object_types"] = list(set(obj["type"] for obj in structure.get("objects", [])))
    
    # Ajouter les erreurs de validation si présentes
    validation = context.get("validation_result")
    if validation:
        output["validation"] = {
            "valid": validation.get("valid"),
            "errors_count": len(validation.get("errors", []))
        }
    
    context.log(f"Skeleton output generated ({format_type})", GEVRPhase.RENDER)
    
    return output


def handler_render_log(params: Dict, context: ExecutionContext) -> Any:
    """
    RENDER: Génère un log formaté de l'exécution.
    """
    include_data = params.get("include_data", False)
    max_entries = params.get("max_entries", 100)
    
    output = {
        "type": "execution_log",
        "timestamp": datetime.now().isoformat(),
        "entries": context.logs[-max_entries:],
        "errors": context.errors
    }
    
    if include_data:
        output["data_keys"] = list(context.data.keys())
        output["phase_outputs"] = list(context.phase_outputs.keys())
    
    return output


# =============================================================================
# REGISTRE DES HANDLERS
# =============================================================================

def register_all_handlers(engine):
    """
    Enregistre tous les handlers spécialisés dans un moteur GEVR.
    
    Args:
        engine: Instance de GEVREngine
    """
    # Handlers GET
    engine.register_handler("loadBundle", handler_load_bundle, GEVRPhase.GET)
    engine.register_handler("loadTemplate", handler_load_template, GEVRPhase.GET)
    engine.register_handler("loadRules", handler_load_rules, GEVRPhase.GET)
    
    # Handlers EXECUTE
    engine.register_handler("runMetaRules", handler_run_metarules, GEVRPhase.EXECUTE)
    engine.register_handler("applyERK", handler_apply_erk, GEVRPhase.EXECUTE)
    engine.register_handler("transform", handler_transform, GEVRPhase.EXECUTE)
    engine.register_handler("createStructure", handler_create_structure, GEVRPhase.EXECUTE)
    
    # Handlers VALIDATE
    engine.register_handler("validateSchema", handler_validate_schema, GEVRPhase.VALIDATE)
    engine.register_handler("validateERK", handler_validate_erk, GEVRPhase.VALIDATE)
    engine.register_handler("validateStructure", handler_validate_structure, GEVRPhase.VALIDATE)
    
    # Handlers RENDER
    engine.register_handler("renderAnalysis", handler_render_analysis, GEVRPhase.RENDER)
    engine.register_handler("renderSkeleton", handler_render_skeleton, GEVRPhase.RENDER)
    engine.register_handler("renderLog", handler_render_log, GEVRPhase.RENDER)
