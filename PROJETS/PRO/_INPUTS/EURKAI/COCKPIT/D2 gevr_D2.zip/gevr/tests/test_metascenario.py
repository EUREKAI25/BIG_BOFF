"""
EUREKAI D2/5 — Tests du MetaScénario "Projet EURKAI"
====================================================

Ce module teste:
- Analyseurs d'entrée (phrase, brief, schéma)
- Générateurs (objets, relations, scénarios)
- MetaScénario complet (pipeline GEVR)
- Exemples variés et cas limites

Version: D2/5 - MetaScénario "Projet EURKAI"
"""

import pytest
import json
import sys
import os

# Ajouter le chemin pour les imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from metascenarios.analyzers import (
    InputAnalyzer, InputType, AnalysisResult, ProjectDomain
)
from metascenarios.generators import (
    ObjectGenerator, RelationGenerator, ScenarioGenerator,
    ProjectGenerator, EURKAIProject, EURKAIObject
)
from metascenarios.projet_eurkai import (
    MetaScenarioProjetEURKAI, MetaScenarioResult,
    PROJET_EURKAI_SCHEMA
)


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture
def analyzer():
    """Retourne un analyseur configuré."""
    return InputAnalyzer()


@pytest.fixture
def metascenario():
    """Retourne une instance du MetaScénario."""
    return MetaScenarioProjetEURKAI()


# =============================================================================
# TESTS ANALYSEUR - TYPE D'ENTRÉE
# =============================================================================

class TestInputTypeDetection:
    """Tests de détection du type d'entrée."""
    
    def test_detect_phrase_simple(self, analyzer):
        """Détecte une phrase simple."""
        result = analyzer.analyze("Je veux un blog sur la créativité")
        assert result.input_type == InputType.PHRASE
    
    def test_detect_phrase_courte(self, analyzer):
        """Détecte une phrase très courte."""
        result = analyzer.analyze("Blog EURKAI")
        assert result.input_type == InputType.PHRASE
    
    def test_detect_brief(self, analyzer):
        """Détecte un brief structuré."""
        brief = """
        Projet: Plateforme de gestion de contenu
        
        Objectifs:
        - Permettre la création d'articles
        - Gérer les utilisateurs
        - Dashboard analytics
        
        Contraintes:
        - Performance temps réel
        - Compatibilité mobile
        """
        result = analyzer.analyze(brief)
        assert result.input_type == InputType.BRIEF
    
    def test_detect_schema_json(self, analyzer):
        """Détecte un schéma JSON."""
        schema = {
            "name": "MonProjet",
            "objects": [
                {"type": "Agent", "name": "MainAgent"}
            ]
        }
        result = analyzer.analyze(schema)
        assert result.input_type == InputType.SCHEMA
    
    def test_detect_schema_json_string(self, analyzer):
        """Détecte un schéma JSON en string."""
        schema = '{"name": "MonProjet", "objects": []}'
        result = analyzer.analyze(schema)
        assert result.input_type == InputType.SCHEMA
    
    def test_detect_mixed(self, analyzer):
        """Détecte une entrée mixte."""
        mixed = {
            "brief": "Je veux créer une API de gestion",
            "hints": {
                "objects": [{"type": "Service", "name": "API"}]
            }
        }
        result = analyzer.analyze(mixed)
        assert result.input_type == InputType.MIXED


# =============================================================================
# TESTS ANALYSEUR - DOMAINE
# =============================================================================

class TestDomainDetection:
    """Tests de détection du domaine."""
    
    def test_detect_web_domain(self, analyzer):
        """Détecte le domaine web."""
        result = analyzer.analyze("Créer un blog avec React et Tailwind")
        assert result.domain == ProjectDomain.WEB
    
    def test_detect_api_domain(self, analyzer):
        """Détecte le domaine API."""
        result = analyzer.analyze("API REST pour gérer les utilisateurs")
        assert result.domain == ProjectDomain.API
    
    def test_detect_saas_domain(self, analyzer):
        """Détecte le domaine SaaS."""
        result = analyzer.analyze("Application SaaS avec dashboard utilisateur")
        assert result.domain == ProjectDomain.SAAS
    
    def test_detect_agent_domain(self, analyzer):
        """Détecte le domaine agent/IA."""
        result = analyzer.analyze("Système multi-agents avec orchestration LLM")
        assert result.domain == ProjectDomain.AGENT
    
    def test_detect_data_domain(self, analyzer):
        """Détecte le domaine data."""
        result = analyzer.analyze("Pipeline ETL pour analytics")
        assert result.domain == ProjectDomain.DATA
    
    def test_detect_generic_domain(self, analyzer):
        """Détecte le domaine générique."""
        result = analyzer.analyze("Projet simple sans contexte précis")
        assert result.domain == ProjectDomain.GENERIC


# =============================================================================
# TESTS ANALYSEUR - EXTRACTION
# =============================================================================

class TestFeatureExtraction:
    """Tests d'extraction de features."""
    
    def test_extract_name_hint(self, analyzer):
        """Extrait le nom suggéré."""
        result = analyzer.analyze("Projet BlogCreatif: un blog sur la créativité")
        assert result.name_hint  # Doit extraire quelque chose
    
    def test_extract_features(self, analyzer):
        """Extrait les fonctionnalités."""
        result = analyzer.analyze(
            "Application avec authentification, qui permet de gérer les articles"
        )
        assert len(result.features) > 0
    
    def test_extract_object_hints(self, analyzer):
        """Extrait les hints d'objets."""
        result = analyzer.analyze(
            "Système avec un agent principal, un service de données et une vue dashboard"
        )
        assert len(result.object_hints) > 0
    
    def test_extract_tags(self, analyzer):
        """Extrait les tags."""
        result = analyzer.analyze("Application Python avec API REST")
        assert "python" in result.tags or "api" in result.tags


# =============================================================================
# TESTS GÉNÉRATEUR D'OBJETS
# =============================================================================

class TestObjectGenerator:
    """Tests du générateur d'objets."""
    
    def test_generate_base_objects(self):
        """Génère les objets de base."""
        gen = ObjectGenerator("TestProject", ProjectDomain.WEB)
        analysis = AnalysisResult(
            input_type=InputType.PHRASE,
            domain=ProjectDomain.WEB,
            name_hint="TestProject"
        )
        objects = gen.generate(analysis)
        
        assert len(objects) > 0
        assert any(obj.type == "Agent" for obj in objects)
        assert any(obj.type == "View" for obj in objects)
    
    def test_generate_with_hints(self):
        """Génère avec hints supplémentaires."""
        gen = ObjectGenerator("TestProject", ProjectDomain.GENERIC)
        analysis = AnalysisResult(
            input_type=InputType.PHRASE,
            domain=ProjectDomain.GENERIC,
            name_hint="TestProject",
            object_hints=[
                {"type": "Data", "name_hint": "UserModel"}
            ]
        )
        objects = gen.generate(analysis)
        
        assert any(obj.type == "Data" for obj in objects)
    
    def test_object_ids_format(self):
        """Vérifie le format des IDs."""
        gen = ObjectGenerator("MyApp", ProjectDomain.API)
        analysis = AnalysisResult(
            input_type=InputType.PHRASE,
            domain=ProjectDomain.API,
            name_hint="MyApp"
        )
        objects = gen.generate(analysis)
        
        for obj in objects:
            assert obj.id.startswith(f"{obj.type}.")
            assert "MyApp" in obj.id


# =============================================================================
# TESTS GÉNÉRATEUR DE RELATIONS
# =============================================================================

class TestRelationGenerator:
    """Tests du générateur de relations."""
    
    def test_generate_base_relations(self):
        """Génère les relations de base."""
        objects = [
            EURKAIObject("Agent.Test.MainAgent", "Agent", "MainAgent"),
            EURKAIObject("Service.Test.MainService", "Service", "MainService"),
            EURKAIObject("Config.Test.Config", "Config", "Config")
        ]
        
        gen = RelationGenerator("Test", ProjectDomain.GENERIC)
        analysis = AnalysisResult(
            input_type=InputType.PHRASE,
            domain=ProjectDomain.GENERIC
        )
        relations = gen.generate(objects, analysis)
        
        assert len(relations) > 0
    
    def test_infer_agent_config_relation(self):
        """Infère la relation Agent → Config."""
        objects = [
            EURKAIObject("Agent.Test.Agent", "Agent", "Agent"),
            EURKAIObject("Config.Test.Config", "Config", "Config")
        ]
        
        gen = RelationGenerator("Test", ProjectDomain.GENERIC)
        analysis = AnalysisResult(
            input_type=InputType.PHRASE,
            domain=ProjectDomain.GENERIC
        )
        relations = gen.generate(objects, analysis)
        
        assert any(
            r.source.startswith("Agent.") and r.target.startswith("Config.")
            for r in relations
        )


# =============================================================================
# TESTS GÉNÉRATEUR DE PROJET COMPLET
# =============================================================================

class TestProjectGenerator:
    """Tests du générateur de projet."""
    
    def test_generate_complete_project(self):
        """Génère un projet complet."""
        gen = ProjectGenerator()
        analysis = AnalysisResult(
            input_type=InputType.PHRASE,
            domain=ProjectDomain.WEB,
            name_hint="BlogCreatif",
            description="Un blog sur la créativité"
        )
        
        project = gen.generate(analysis)
        
        assert project.project_id.startswith("Project.")
        assert project.name == "BlogCreatif"
        assert len(project.objects) > 0
        assert len(project.scenarios) > 0
    
    def test_project_to_dict(self):
        """Vérifie la sérialisation."""
        gen = ProjectGenerator()
        analysis = AnalysisResult(
            input_type=InputType.PHRASE,
            domain=ProjectDomain.API,
            name_hint="TestAPI"
        )
        
        project = gen.generate(analysis)
        output = project.to_dict()
        
        assert "projectId" in output
        assert "objects" in output
        assert "relations" in output
        assert "scenarios" in output


# =============================================================================
# TESTS METASCÉNARIO COMPLET
# =============================================================================

class TestMetaScenarioExecution:
    """Tests d'exécution du MetaScénario."""
    
    def test_run_with_phrase(self, metascenario):
        """Exécute avec une phrase simple."""
        result = metascenario.run("Je veux un blog EURKAI sur la créativité")
        
        assert result.status in ["success", "partial"]
        assert result.project is not None
        assert result.project.project_id.startswith("Project.")
    
    def test_run_with_brief(self, metascenario):
        """Exécute avec un brief structuré."""
        brief = """
        Projet de plateforme SaaS pour la gestion de projets.
        
        Fonctionnalités:
        - Dashboard principal
        - Gestion des tâches
        - Collaboration en équipe
        
        Contraintes:
        - Temps réel
        - Mobile-first
        """
        result = metascenario.run(brief)
        
        assert result.ok
        assert result.project.domain == "saas"
    
    def test_run_with_schema(self, metascenario):
        """Exécute avec un schéma JSON."""
        schema = {
            "name": "MonAPI",
            "domain": "api",
            "objects": [
                {"type": "Agent", "name": "APIAgent", "bundles": ["core", "api"]},
                {"type": "Service", "name": "UserService", "bundles": ["core"]}
            ],
            "relations": [
                {"from": "APIAgent", "to": "UserService", "type": "orchestrates"}
            ]
        }
        result = metascenario.run(schema)
        
        assert result.ok
        assert len(result.project.objects) >= 2
    
    def test_phases_executed(self, metascenario):
        """Vérifie que toutes les phases sont exécutées."""
        result = metascenario.run("Test project")
        
        assert result.get_result.get("success") == True
        assert result.execute_result.get("success") == True
        assert "valid" in result.validate_result
        assert result.render_result.get("success") == True
    
    def test_result_to_dict(self, metascenario):
        """Vérifie la sérialisation du résultat."""
        result = metascenario.run("Test")
        output = result.to_dict()
        
        assert "status" in output
        assert "project" in output
        assert "phases" in output


# =============================================================================
# TESTS D'EXEMPLES CONCRETS
# =============================================================================

class TestConcreteExamples:
    """Tests avec des exemples concrets du prompt D2."""
    
    def test_example_blog_phrase(self, metascenario):
        """Exemple: phrase simple pour un blog."""
        result = metascenario.run("Je veux un blog EURKAI sur la créativité")
        
        assert result.ok
        project = result.project
        
        # Vérifier la structure
        assert project.domain == "web"
        assert any(obj.type == "Agent" for obj in project.objects)
        assert any(obj.type == "View" for obj in project.objects)
        assert len(project.scenarios) > 0
    
    def test_example_api_brief(self, metascenario):
        """Exemple: brief pour une API."""
        brief = """
        API de gestion de tâches collaboratives.
        
        L'API doit permettre de:
        - Créer et gérer des projets
        - Assigner des tâches aux utilisateurs
        - Suivre l'avancement
        
        Stack technique: Python, FastAPI, PostgreSQL
        
        Contraintes:
        - Authentification JWT
        - Rate limiting
        """
        result = metascenario.run(brief)
        
        assert result.ok
        project = result.project
        
        assert project.domain == "api"
        assert "python" in project.tags or "api" in project.tags
    
    def test_example_agent_system(self, metascenario):
        """Exemple: système multi-agents."""
        input_data = {
            "brief": "Système d'orchestration multi-agents avec GPT pour l'analyse de documents",
            "hints": {
                "objects": [
                    {"type": "Agent", "name": "Orchestrator"},
                    {"type": "Agent", "name": "Analyzer"}
                ]
            }
        }
        result = metascenario.run(input_data)
        
        assert result.ok
        project = result.project
        
        assert project.domain == "agent"
        # Doit avoir au moins les 2 agents mentionnés
        agent_count = sum(1 for obj in project.objects if obj.type == "Agent")
        assert agent_count >= 2


# =============================================================================
# TESTS DE CAS LIMITES
# =============================================================================

class TestEdgeCases:
    """Tests de cas limites."""
    
    def test_empty_input(self, metascenario):
        """Gère une entrée vide."""
        result = metascenario.run("")
        
        # Doit quand même produire quelque chose
        assert result.project is not None or result.status == "failed"
    
    def test_very_long_input(self, metascenario):
        """Gère une entrée très longue."""
        long_input = "Un projet " + "avec beaucoup de features " * 100
        result = metascenario.run(long_input)
        
        assert result.status in ["success", "partial"]
    
    def test_special_characters(self, metascenario):
        """Gère les caractères spéciaux."""
        result = metascenario.run("Projet @#$% avec émojis 🚀 et accents éàü")
        
        assert result.status in ["success", "partial"]
        # Le nom doit être nettoyé
        assert all(c.isalnum() or c == "." for c in result.project.project_id)
    
    def test_invalid_schema(self, metascenario):
        """Gère un schéma invalide."""
        invalid = {"invalid": "structure", "no_objects": True}
        result = metascenario.run(invalid)
        
        # Doit traiter comme brief/unknown
        assert result.project is not None


# =============================================================================
# TESTS DE VALIDATION
# =============================================================================

class TestValidation:
    """Tests de validation."""
    
    def test_no_duplicate_object_ids(self, metascenario):
        """Vérifie l'absence de doublons d'IDs."""
        result = metascenario.run("Projet complexe avec plusieurs services")
        
        ids = [obj.id for obj in result.project.objects]
        assert len(ids) == len(set(ids))
    
    def test_relations_reference_valid_objects(self, metascenario):
        """Vérifie que les relations pointent vers des objets valides."""
        result = metascenario.run("Projet avec relations")
        
        object_ids = {obj.id for obj in result.project.objects}
        for rel in result.project.relations:
            assert rel.source in object_ids
            assert rel.target in object_ids
    
    def test_output_matches_schema(self, metascenario):
        """Vérifie que la sortie correspond au schéma."""
        result = metascenario.run("Test project")
        output = result.project.to_dict()
        
        # Vérifier les champs requis
        assert "projectId" in output
        assert "name" in output
        assert "objects" in output
        assert isinstance(output["objects"], list)


# =============================================================================
# TESTS DE STRATÉGIE D'ENRICHISSEMENT
# =============================================================================

class TestEnrichmentStrategy:
    """Tests de la stratégie d'enrichissement itératif."""
    
    def test_can_add_objects_to_project(self, metascenario):
        """Peut enrichir un projet avec de nouveaux objets."""
        # Première génération
        result1 = metascenario.run("Blog simple")
        project1 = result1.project
        
        # Enrichissement avec schéma partiel
        enriched_input = {
            "partial": {
                "objects": [
                    {"type": "Service", "name": "CommentService", "bundles": ["core"]}
                ]
            },
            "brief": f"Enrichir le projet {project1.name} avec un service de commentaires"
        }
        result2 = metascenario.run(enriched_input)
        
        # Le nouveau projet doit avoir plus d'objets
        assert result2.ok
    
    def test_scenarios_adapt_to_domain(self, metascenario):
        """Les scénarios s'adaptent au domaine."""
        web_result = metascenario.run("Site web statique")
        api_result = metascenario.run("API REST")
        
        web_scenarios = [s.name for s in web_result.project.scenarios]
        api_scenarios = [s.name for s in api_result.project.scenarios]
        
        # Les scénarios doivent être différents
        assert web_scenarios != api_scenarios


# =============================================================================
# EXÉCUTION DES TESTS
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
