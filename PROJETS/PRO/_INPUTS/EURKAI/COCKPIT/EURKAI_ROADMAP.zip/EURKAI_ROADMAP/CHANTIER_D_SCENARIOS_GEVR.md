
# Chantier D — Scénarios & Exécution (GEVR)

## Objectif global
Permettre à EURKAI de **déployer des scénarios** (suite d’étapes) pour transformer une entrée (idée, brief, cahier des charges, schéma complet) en **projet structuré et exécutable**, en s’appuyant sur la fractale.

GEVR = GET → EXECUTE → VALIDATE → RENDER.

---

## Étape 11 — Scénarios GEVR de base

**But :** exécuter un scénario simple sur la base de la fractale.

- Définir quelques scénarios types :
  - “Créer un nouveau projet à partir d’un brief”
  - “Analyser un objet et compléter ses bundles”
- Implémenter GEVR au niveau cockpit (simulation contrôlée)

**Objectifs de validation :**
- [ ] Je peux lancer un scénario GEVR depuis le cockpit.
- [ ] Je vois les étapes s’exécuter (log ou UI simple).
- [ ] Le scénario utilise réellement les objets et règles existants.

---

## Étape 12 — MetaScénario “Projet EURKAI”

**But :** avoir un **MetaScénario générique** qui prend en entrée :  
- une phrase d’idée,
- un brief,
- un cahier des charges,
- ou un schéma complet,

…et qui le transforme en **structure de projet EURKAI**.

- Analyse de l’entrée
- Mapping vers des ObjectTypes existants ou à créer
- Construction d’un arbre de projet (lineages, scénarios, ressources)
- Production d’un premier backlog / plan d’actions

**Objectifs de validation :**
- [ ] Je peux fournir une idée en une phrase et obtenir une proposition de structure de projet dans la fractale.
- [ ] Je peux fournir un brief ou un cahier des charges et obtenir un projet plus détaillé (objets, relations, premiers scénarios).
- [ ] Le résultat est intégrable à EURKAI (pas un artefact isolé).

---

## Étape 13 — Orchestrate (Superviseur de scénarios)

**But :** centraliser la gestion des scénarios.

- SuperTool **Orchestrate** (on garde ce nom, `execute` est déjà pris par GEVR)
- Choisit quel scénario GEVR est adapté au contexte
- Gère la reprise après erreur, les validations intermédiaires, les retours IA

**Objectifs de validation :**
- [ ] Je peux demander à Orchestrate “prends cette idée et fais-en un projet EURKAI”.
- [ ] Orchestrate choisit un scénario, l’exécute, et me montre le résultat.
- [ ] En cas d’erreur ou de manque d’info, Orchestrate revient vers moi ou vers un agent IA avec une question claire.
