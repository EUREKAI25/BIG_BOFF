
# Layers EURKAI, Labo & Blog

## Layers

On recale les layers ainsi :

- **Layer 0 — CORE**  
  - Langage ERK  
  - MetaSchema  
  - Logic (familles de règles, relations, invariants)  
  - Cœur des chantiers B & C

- **Layer 1 — SYSTÈME**  
  - Cockpit (Object Fractal Tool)  
  - SuperTools  
  - Scénarios GEVR  
  - Orchestrate  
  - Chantiers A, D, E

- **Layer 2 — AGENCE (EURKAI)**  
  - Projets concrets (clients, internes)  
  - Labo EURKAI  
  - Blog EURKAI  
  - Produits, apps, SaaS générés
  - Chantiers F & G

- **Layer 3 — ÉCOSYSTÈME**  
  - Réseau social fractal anonymisé (si tu le maintiens)  
  - Interconnexion de plusieurs instances d’EURKAI  
  - Partenaires, API externes, etc.

## Labo EURKAI

Le **Labo** est un projet EURKAI comme un autre, mais avec un rôle spécial :

- zone d’expérimentation contrôlée,
- tests d’idées, de formats, de scénarios,
- démonstrations de ce que le système sait faire,
- pas obligé d’être public.

Il sera créé et géré via le MetaScénario “Créer un projet” (Chantier D), puis déployé via le Chantier F.

## Blog EURKAI

Le **Blog** est un autre projet type :

- vitrine d’EURKAI,
- contenu éditorial (articles, journaux de bord, docs vulgarisées),
- connecté à la fractale (chaque article peut être lié à des objets, scénarios, couches).

Lui aussi est un projet généré par EURKAI, pas une exception.  
C’est un excellent **projet pilote** pour tester :

- la génération de structures de contenu,
- la génération de templates front,
- la génération de scénarios éditoriaux (planning, séries d’articles).
