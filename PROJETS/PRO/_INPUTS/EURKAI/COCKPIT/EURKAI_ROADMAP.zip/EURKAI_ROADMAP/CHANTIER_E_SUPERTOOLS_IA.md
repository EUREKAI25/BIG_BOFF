
# Chantier E — SuperTools & Interaction IA

## Objectif global
Créer la couche d’outils “surpuissants” (SuperTools) qui utilisent la fractale, les scénarios et ERK pour **générer, analyser, refactorer et optimiser** les projets EURKAI, en collaboration avec des agents IA.

---

## Étape 14 — SuperTools centraux

**But :** définir et implémenter les SuperTools de base.

- SuperCreate : générer des objets / structures / fichiers à partir de la fractale
- SuperRead : explorer / expliquer / résumer la fractale
- SuperUpdate : refactorer / renommer / restructurer
- SuperDelete : marquer pour suppression, archiver
- SuperEvaluate : analyser la qualité / cohérence / performance
- SuperOrchestrate : piloter les scénarios (cf. Chantier D)

**Objectifs de validation :**
- [ ] Chaque SuperTool a une signature claire (inputs / outputs) et un contexte d’usage.
- [ ] Je peux appeler un SuperTool depuis le cockpit ou un scénario GEVR.
- [ ] Les SuperTools ne sortent jamais du cadre : ils ne modifient que via les règles et le MetaSchema.

---

## Étape 15 — Mode IA assistée (agents IA)

**But :** confier aux agents IA ce qui est pénible et répétitif, en restant sous contrôle.

- L’IA :
  - ne crée pas de concepts fondamentaux,
  - ne modifie pas les MetaRules,
  - ne décide pas seule du déploiement,
  - mais remplit, complète, propose, corrige.
- Les agents IA utilisent les SuperTools + la fractale + les scénarios.

**Objectifs de validation :**
- [ ] Je peux donner une tâche à un agent IA (ex : “compléter ce type d’Agent”) et l’IA travaille **via le cockpit** et les SuperTools.
- [ ] Toute action IA est traçable (logs, diffs).
- [ ] Rien n’est appliqué sans garde-fous (ERK + validation humaine pour les changements importants).
