
# Chantier F — Export, Génération & Bootstrapping

## Objectif global
Faire sortir EURKAI de son cockpit HTML pour en faire **un système utilisable en production** : génération de code, de structures, d’APIs, de projets concrets (sites, apps, outils…)

---

## Étape 16 — Manifest fractal (export JSON officiel)

**But :** définir un format d’export stable.

- Manifest JSON ou équivalent qui décrit :
  - ObjectTypes + lineages
  - Bundles complets (attrs, methods, rules, relations)
  - Scénarios associés
  - Tags / catégories / alias

**Objectifs de validation :**
- [ ] Je peux exporter la fractale complète d’EURKAI dans un seul fichier manifest.
- [ ] Ce manifest peut être relu et rechargé dans le cockpit sans perte.
- [ ] Le format est documenté (README + exemples).

---

## Étape 17 — Génération de modules

**But :** transformer la fractale en artefacts concrets.

- Génération automatique :
  - de squelettes de code (Python, Node, autre)
  - de fichiers de config
  - de templates de projets (ex : projet SaaS, blog, labo)
- Utilisation des scénarios et du MetaSchema pour choisir quoi générer.

**Objectifs de validation :**
- [ ] À partir d’un projet défini dans EURKAI, je peux générer un squelette de code complet.
- [ ] Le squelette est cohérent avec ce qui est décrit dans la fractale (noms, relations, méthodes).
- [ ] Je peux regénérer sans casser le travail déjà effectué manuellement (respect des zones “générées” vs “humaines”).

---

## Étape 18 — Bootstrapping complet d’un projet

**But :** transformer un projet EURKAI en système lancé.

- Lecture du manifest
- Création des dossiers, fichiers, configs
- Lancement des premières tâches (tests, migrations, déploiement de base)
- Intégration de monitoring minimal

**Objectifs de validation :**
- [ ] Je peux prendre un projet (ex : “Blog EURKAI”, “Labo EURKAI”) et le déployer de bout en bout à partir du cockpit.
- [ ] Le projet est relié à EURKAI (logs, monitoring, liens de navigation).
- [ ] Je peux itérer : modifier le projet dans EURKAI, regénérer ce qui est générable, sans casser le reste.
