
# Chantier G — Optimisation, Meta-Tests & Déploiement autonome

## Objectif global
Faire passer EURKAI d’un système générateur puissant à un système **auto-optimisant**, capable de se tester, se corriger et déployer des projets en continu, en sécurité.

---

## Étape 19 — PGCD / PPCM logiques (optimisation structurelle)

**But :** utiliser concrètement les intuitions PGCD / PPCM.

- PGCD logique : extraction du “cœur commun” d’un ensemble d’objets ou de scénarios
- PPCM logique : identification du “set minimal” de méthodes / règles couvrant un ensemble de besoins
- Outils d’audit et de refactorisation guidée

**Objectifs de validation :**
- [ ] Je peux sélectionner un groupe d’objets ou de scénarios et demander un “PGCD logique”.
- [ ] Le cockpit me propose un cœur commun à factoriser (nouveau parent, interface, pattern).
- [ ] Je peux demander un “PPCM logique” et voir quelles méthodes suffisent à couvrir tous les cas d’usage choisis.

---

## Étape 20 — Méta-tests & auto-debug

**But :** doter EURKAI d’outils de test structurés.

- Génération automatique de cas de test à partir de la fractale
- Vérification de la cohérence après chaque modification importante
- Rapports lisibles (par chantier, par objet, par scénario)

**Objectifs de validation :**
- [ ] Je peux lancer une campagne de tests fractale.
- [ ] Les résultats sont présentés par chantier / couche / type d’objets.
- [ ] Les régressions sont détectées et reliées aux modifications récentes.

---

## Étape 21 — Déploiement autonome multi-projets

**But :** permettre à EURKAI de gérer un **portefeuille de projets**.

- Gestion multi-clients / multi-projets
- Déploiements orchestrés
- Monitoring centralisé
- Intégration des projets comme “citoyens” du réseau EURKAI (blog, labo, apps, SaaS…)

**Objectifs de validation :**
- [ ] EURKAI peut héberger et superviser plusieurs projets en parallèle (ex : Blog EURKAI, Labo EURKAI, outils internes).
- [ ] Je peux visualiser l’état de chaque projet (version, incidents, logs, scénarios actifs).
- [ ] L’ajout d’un nouveau projet suit toujours la même logique : idée → brief → projet → déploiement → monitoring.
