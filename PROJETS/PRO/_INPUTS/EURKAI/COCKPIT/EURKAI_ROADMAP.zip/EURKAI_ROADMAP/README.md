
# Roadmap EURKAI — Vue d’ensemble

Ce dossier décrit **les chantiers structurants d’EURKAI** et les **objectifs concrets** à atteindre pour valider chaque étape.

- L’agence s’appelle désormais et pour toujours **EURKAI**.
- Le cockpit s’appelle **Object Fractal Tool** et sert de centre de pilotage.
- Tu restes **architecte en chef** : tu définis le langage, les règles, les couches (layers), les limites.  
- Les **agents IA** exécutent, complètent, refactorent et testent à partir de ce cadre.

## Rôles

- **Toi (humaine / architecte)**  
  - définis les concepts (MetaSchema, ERK, grandes familles d’objets, éthique, priorités)  
  - arbitres les décisions structurelles (noms, relations, patterns, layers)  
  - valides ou refuses les propositions des IA  
  - décides quels projets sont déployés, publiés, monétisés

- **Cockpit (Object Fractal Tool)**  
  - représente la fractale en temps réel (objets, lineages, bundles, règles, relations)  
  - sert d’interface unique pour éditer, visualiser, tester et exporter la structure d’EURKAI  
  - devient la “carte” officielle du système

- **Agents IA**  
  - remplissent les schémas (bundles) à partir de tes règles et du langage ERK  
  - génèrent du code, des prompts, des scénarios, des tests, des docs à partir de la fractale  
  - proposent des optimisations (jamais en freestyle : toujours via le cadre)  
  - exécutent les scénarios (GEVR) pour transformer une idée ou un brief en projet complet

Les fichiers suivants détaillent, par chantier, les étapes et les objectifs de validation.
