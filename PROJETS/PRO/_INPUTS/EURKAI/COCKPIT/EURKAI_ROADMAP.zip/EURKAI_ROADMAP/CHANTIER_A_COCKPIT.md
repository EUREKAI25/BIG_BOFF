
# Chantier A — Cockpit Fractal (Object Fractal Tool)

## Objectif global
Disposer d’un **centre de pilotage graphique** qui représente et édite toute la fractale d’EURKAI (Objets, lineages, bundles, règles, relations, tags), avec une console de test basique.

---

## Étape 0 — Initialisation & Store

**But :** poser la base du cockpit.

- Arbre des ObjectTypes
- Lineage parser + auto-création des parents manquants
- Store JSON global (in-memory)

**Objectifs de validation :**
- [ ] Je peux créer un ObjectType, le voir apparaître dans l’arbre, et son lineage est cohérent.
- [ ] Si je tape un lineage complet, les parents intermédiaires sont créés automatiquement et marqués `toFinalize`.
- [ ] Le store JSON contient bien tous les objets visibles.

---

## Étape 1 — Vue Fractale

**But :** visualiser l’héritage et la composition d’un objet.

- Affichage des ancêtres d’un ObjectType sélectionné
- Vue fractale avec bundles **owned / inherited / injected**
- Slider de profondeur pour limiter l’affichage

**Objectifs de validation :**
- [ ] Quand je sélectionne un objet, je vois la chaîne d’ancêtres.
- [ ] Les éléments inherited, injected et owned sont clairement distingués.
- [ ] Le slider de profondeur modifie ce qui est affiché sans bug.

---

## Étape 2 — Tags, catégories, alias

**But :** ajouter la couche de vocabulaire et de navigation.

- Sidebar des tags (drag & drop → affectation aux objets)
- Tags pouvant devenir des catégories avec parentCategory
- Alias pointant vers un lineage ou un vecteur

**Objectifs de validation :**
- [ ] Je peux créer un tag, le glisser sur un objet, et le retrouver dans ses métadonnées.
- [ ] Je peux marquer un tag comme catégorie et lui assigner une catégorie parente.
- [ ] Je peux créer un alias sur un objet et l’utiliser pour y revenir rapidement.

---

## Étape 3 — Édition des bundles

**But :** transformer le cockpit en éditeur complet de MetaSchema.

- Ajout / modification / suppression d’éléments dans :
  - AttributeList
  - MethodList
  - RelationList
  - RuleList (rules ERK stockées en texte brut pour l’instant)
- Mise à jour live de la vue fractale et du store

**Objectifs de validation :**
- [ ] Quand j’ajoute un attribut ou une méthode à un objet, la carte fractale se met à jour immédiatement.
- [ ] Si je modifie un parent, les descendants héritent correctement des changements (inherited).
- [ ] Je peux exporter l’état du store (JSON) et y retrouver toutes mes modifications.

---

## Étape 4 — Console de test (mock)

**But :** commencer à “parler” au système en langage objet.

- Onglet / panneau Console
- Saisie de commandes de type `ObjectType.methodName(args)`
- Résolution dans le store
- Exécution mock (retourne un JSON structuré : ok / erreur / détails)

**Objectifs de validation :**
- [ ] Je peux appeler une méthode existante sur un objet (`AIAgent.prompt(...)`) et obtenir une réponse JSON mock.
- [ ] Si la méthode ou l’objet n’existe pas, je reçois une erreur claire.
- [ ] La console n’invente pas d’objets ni de méthodes : elle ne fait que travailler avec la fractale existante.
