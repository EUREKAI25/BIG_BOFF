
# Chantier C — MetaSchema & Héritages Automatiques

## Objectif global
Faire en sorte que le **MetaSchema** d’EURKAI (tout objet = bundle, bundles = inherited/injected/owned, etc.) soit non seulement décrit, mais **appliqué automatiquement** à chaque nouvel objet ou lineage.

---

## Étape 8 — Génération automatique d’héritages (lineages “assistés”)

**But :** réduire l’effort manuel de définition des objets.

- Analyser les patterns de lineages existants
- Proposer automatiquement un parent ou une famille pour un nouvel objet
- Marquer les choix comme “suggérés” pour validation humaine

**Objectifs de validation :**
- [ ] Quand je crée un nouvel objet, le cockpit peut me proposer un parent probable.
- [ ] Je peux accepter ou refuser la suggestion, et voir le lineage mis à jour.
- [ ] Aucune suggestion n’est appliquée sans validation explicite.

---

## Étape 9 — MetaRules de structure (cohérence globale)

**But :** garantir que tous les objets respectent les invariants du système.

- Définir des règles globales : “tout ObjectType doit avoir au moins X”
- Exemples : id, name, createdAt, un minimum de méthodes centrales, etc.
- Exécuter ces MetaRules périodiquement ou à la demande

**Objectifs de validation :**
- [ ] Je peux lancer une vérification globale et voir quels objets ne respectent pas les invariants.
- [ ] Les problèmes sont listés par type (manque d’attribut, relation invalide, etc.).
- [ ] Je peux corriger les objets directement depuis le cockpit ou marquer les warnings comme “acceptés”.

---

## Étape 10 — MetaRelations & optimisation structurelle

**But :** clarifier et optimiser le réseau de relations.

- Détection des cycles indésirables
- Mise en évidence des relations redondantes ou inutiles
- Propositions de simplification (sans auto-application)

**Objectifs de validation :**
- [ ] Je peux lancer un audit de relations et obtenir un rapport lisible.
- [ ] Les cycles potentiellement dangereux sont identifiés.
- [ ] Je reste décisionnaire : aucune suppression automatique n’est faite sans mon accord.
