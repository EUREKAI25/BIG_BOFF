
# Chantier B — Langage ERK & Interpréteur

## Objectif global
Donner vie au **langage ERK** à l’intérieur du cockpit, pour que les règles puissent être **lues, comprises et partiellement exécutées** sur la fractale.

---

## Étape 5 — Mini-interpréteur ERK (V1)

**But :** exécuter un sous-ensemble simple de règles ERK.

- Parser quelques formes simples de règles (ex : `enable: this.prompt`, `depends_on = Core:Config`)
- Construire un petit AST (représentation interne)
- Résoudre `this`, les targets de `depends_on`, etc.
- Intégrer l’interpréteur à la Console (appel d’une règle par nom)

**Objectifs de validation :**
- [ ] Je peux demander à la console d’évaluer une règle nommée sur un objet (ex : `AIAgent.rules.check("enable")`).
- [ ] La règle est traduite en AST et évaluée sur l’objet courant.
- [ ] Le résultat indique clairement si la règle est satisfaite, et pourquoi.

---

## Étape 6 — ERK étendu (conditions & contexte)

**But :** couvrir les cas ERK les plus fréquents sans tout implémenter.

- Ajouter les conditions simples (IF / WHEN / MATCH minimal)
- Gérer quelques variables de contexte (ex : state simple, flags)
- Permettre des règles du type : “si X alors activer/désactiver Y”

**Objectifs de validation :**
- [ ] Je peux exprimer une règle conditionnelle simple en ERK et la voir évaluée sur un objet.
- [ ] La console me montre clairement quelles branches de la règle ont été suivies.
- [ ] Aucun effet de bord : l’évaluation reste sandboxée (ne modifie pas la fractale).

---

## Étape 7 — ERK → Actions système (V2)

**But :** permettre à ERK d’agir sur la fractale, sous contrôle.

- Certaines règles peuvent proposer des modifications (ajouter un tag, activer une méthode, marquer un objet comme incomplet)
- La console affiche les “actions proposées” et tu décides de les appliquer ou non

**Objectifs de validation :**
- [ ] Depuis la console, une règle peut proposer une action concrète (ex : “ajouter tag ‘core’ à Agent”).
- [ ] Les actions ne sont appliquées que si je confirme (pas d’auto-modification silencieuse).
- [ ] Les modifications sont immédiatement visibles dans la vue fractale si je les accepte.
