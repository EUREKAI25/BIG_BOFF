"""
Tests pour l'interpréteur ERK B3/3 - Actions système.

Ces tests vérifient:
- La rétrocompatibilité avec B1/1 et B2/2
- Le parsing des expressions SUGGEST
- L'évaluation et collecte des actions
- La validation des actions
- Les cas limites et erreurs

Version: B3/3 - Actions système (modifications contrôlées)
"""

import pytest
from erk import (
    ERK,
    parse,
    parse_expression,
    parse_conditional,
    tokenize,
    evaluate,
    evaluate_rule,
    evaluate_with_actions,
    collect_actions,
    get_all_suggested_actions,
    ERKConsole,
    StoreAdapter,
    ERKParseError,
    ERKEvalError,
    ERKReferenceError,
    TokenType,
    EvalTrace,
    TraceEventType,
    SuggestNode,
    NodeType,
    # B3 Actions
    ActionType,
    SuggestedAction,
    ActionCollector,
    ActionResult,
    create_action_from_call,
    validate_action,
    ACTION_FUNCTION_MAPPING,
)


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def sample_store():
    """Store de test avec des objets et règles pour B3."""
    store = StoreAdapter()
    
    # Objets de test
    store.objects = {
        "agent_001": {
            "id": "agent_001",
            "type": "Agent",
            "priority": "natural",
            "status": "active",
            "flags": ["prompt_enabled", "can_execute"],
            "tags": ["system"],
            "config": {
                "api_key": "sk-xxx",
                "max_tokens": 1000
            },
            "credits": 100
        },
        "agent_002": {
            "id": "agent_002",
            "type": "Agent",
            "priority": "high",
            "status": "suspended",
            "flags": [],
            "tags": [],
            "config": {},
            "credits": 0
        },
        "task_001": {
            "id": "task_001",
            "type": "Task",
            "owner": "agent_001",
            "status": "pending",
            "priority": 5,
            "tags": []
        }
    }
    
    # Lineages
    store.lineages = {
        "active_agents": ["agent_001"],
        "all_agents": ["agent_001", "agent_002"]
    }
    
    # Règles avec actions B3
    store.rules = {
        "agent_001": {
            "can_prompt": "enable: this.flags.contains('prompt_enabled')",
            "can_execute": "allow: this.status == 'active' AND this.credits > 0",
            "ensure_core_tag": "check: IF NOT this.tags.contains('core') THEN SUGGEST addTag(this, 'core')",
            "mark_for_review": "enable: SUGGEST mark(this, 'toReview')"
        },
        "agent_002": {
            "add_missing_tags": "check: IF this.tags.isEmpty() THEN SUGGEST addTag(this, 'untagged')",
            "activate_agent": "enable: SUGGEST activate(this)"
        },
        "task_001": {
            "enable_prompt": "enable: SUGGEST enableMethod(this, 'prompt')"
        }
    }
    
    return store


@pytest.fixture
def console(sample_store):
    """Console configurée avec le store de test."""
    return ERKConsole(sample_store)


# ============================================================================
# TESTS DE RÉTROCOMPATIBILITÉ B1/1 et B2/2
# ============================================================================

class TestBackwardCompatibility:
    """Tests de rétrocompatibilité avec B1/1 et B2/2."""
    
    def test_b1_simple_rule_still_works(self):
        """Les règles simples B1 fonctionnent toujours."""
        context = {"this": {"active": True}}
        result = ERK.quick_eval("enable: this.active", context)
        assert result["ok"] == True
    
    def test_b2_if_then_still_works(self):
        """Les constructions IF/THEN B2 fonctionnent."""
        context = {"this": {"priority": "natural"}}
        result = ERK.quick_eval(
            "check: IF this.priority == 'natural' THEN true ELSE false",
            context
        )
        assert result["ok"] == True
    
    def test_b2_when_then_still_works(self):
        """Les constructions WHEN/THEN B2 fonctionnent."""
        context = {
            "this": {"type": "Agent"},
            "ctx": {"layer": "System"}
        }
        result = ERK.quick_eval(
            "allow: WHEN ctx.layer == 'System' AND this.type == 'Agent' THEN true",
            context
        )
        assert result["ok"] == True
    
    def test_b2_ctx_access_still_works(self):
        """L'accès à ctx B2 fonctionne."""
        context = {
            "this": {},
            "ctx": {"mode": "strict"}
        }
        result = ERK.quick_eval("check: ctx.mode == 'strict'", context)
        assert result["ok"] == True


# ============================================================================
# TESTS LEXER B3
# ============================================================================

class TestLexerB3:
    """Tests du lexer avec le nouveau token SUGGEST."""
    
    def test_suggest_token(self):
        """Tokenize SUGGEST."""
        tokens = tokenize("SUGGEST addTag(this, 'core')")
        types = [t.type for t in tokens if t.type != TokenType.EOF]
        assert TokenType.SUGGEST in types
    
    def test_suggest_in_if_then(self):
        """Tokenize SUGGEST dans IF/THEN."""
        tokens = tokenize("IF this.a THEN SUGGEST mark(this, 'x')")
        types = [t.type for t in tokens if t.type != TokenType.EOF]
        assert TokenType.IF in types
        assert TokenType.SUGGEST in types


# ============================================================================
# TESTS PARSER B3
# ============================================================================

class TestParserB3:
    """Tests du parser avec les expressions SUGGEST."""
    
    def test_parse_simple_suggest(self):
        """Parse SUGGEST basique."""
        ast = parse("check: SUGGEST addTag(this, 'core')")
        assert ast.action == "check"
        assert isinstance(ast.expression, SuggestNode)
        assert ast.expression.function == "addTag"
    
    def test_parse_suggest_multiple_args(self):
        """Parse SUGGEST avec plusieurs arguments."""
        ast = parse("enable: SUGGEST setAttribute(this, 'status', 'active')")
        expr = ast.expression
        assert isinstance(expr, SuggestNode)
        assert expr.function == "setAttribute"
        assert len(expr.arguments) == 2  # 'status' et 'active'
    
    def test_parse_suggest_in_if_then(self):
        """Parse SUGGEST dans IF/THEN."""
        ast = parse("check: IF this.missing THEN SUGGEST addTag(this, 'core')")
        assert ast.action == "check"
        # L'expression est un IfThenElse
        from erk import IfThenElseNode
        assert isinstance(ast.expression, IfThenElseNode)
        # Le then_branch est un SuggestNode
        assert isinstance(ast.expression.then_branch, SuggestNode)
    
    def test_parse_suggest_in_when_then(self):
        """Parse SUGGEST dans WHEN/THEN."""
        ast = parse("allow: WHEN ctx.mode == 'strict' THEN SUGGEST enableMethod(this, 'validate')")
        from erk import WhenThenNode
        assert isinstance(ast.expression, WhenThenNode)
        assert isinstance(ast.expression.then_result, SuggestNode)
    
    def test_parse_suggest_with_expression_target(self):
        """Parse SUGGEST avec une expression comme cible."""
        ast = parse("check: SUGGEST mark(this.child, 'processed')")
        expr = ast.expression
        assert isinstance(expr, SuggestNode)
        # La cible est une expression MemberAccess
        from erk import MemberAccessNode
        assert isinstance(expr.target, MemberAccessNode)
    
    def test_validate_suggest_syntax(self):
        """Valide la syntaxe SUGGEST."""
        result = ERK.validate("enable: SUGGEST addTag(this, 'core')")
        assert result["valid"] == True
    
    def test_invalid_suggest_no_target(self):
        """SUGGEST sans cible est invalide."""
        with pytest.raises(ERKParseError):
            parse("check: SUGGEST addTag()")


# ============================================================================
# TESTS ÉVALUATION B3 - ACTIONS
# ============================================================================

class TestEvaluationB3:
    """Tests de l'évaluation avec collecte d'actions."""
    
    def test_simple_suggest_collects_action(self):
        """SUGGEST collecte une action."""
        context = {
            "this": {"id": "obj_001", "tags": []}
        }
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST addTag(this, 'core')",
            context
        )
        assert result["ok"] == True
        assert "suggested_actions" in result
        assert len(result["suggested_actions"]) == 1
        
        action = result["suggested_actions"][0]
        assert action["type"] == "add_tag"
        assert action["params"]["tag"] == "core"
    
    def test_conditional_suggest(self):
        """SUGGEST conditionnel collecte action si condition vraie."""
        # Cas 1: condition vraie -> action collectée
        context = {"this": {"id": "obj_001", "missing": True}}
        result = ERK.quick_eval_with_actions(
            "check: IF this.missing THEN SUGGEST addTag(this, 'fixed')",
            context
        )
        assert len(result.get("suggested_actions", [])) == 1
        
        # Cas 2: condition fausse -> pas d'action
        context = {"this": {"id": "obj_001", "missing": False}}
        result = ERK.quick_eval_with_actions(
            "check: IF this.missing THEN SUGGEST addTag(this, 'fixed')",
            context
        )
        assert len(result.get("suggested_actions", [])) == 0
    
    def test_when_suggest(self):
        """SUGGEST dans WHEN/THEN."""
        context = {
            "this": {"id": "obj_001"},
            "ctx": {"mode": "strict"}
        }
        result = ERK.quick_eval_with_actions(
            "allow: WHEN ctx.mode == 'strict' THEN SUGGEST mark(this, 'validated')",
            context
        )
        assert len(result.get("suggested_actions", [])) == 1
        action = result["suggested_actions"][0]
        assert action["type"] == "mark"
        assert action["params"]["marker"] == "validated"
    
    def test_action_target_id_extraction(self):
        """L'ID de la cible est correctement extrait."""
        context = {"this": {"id": "my_object_123"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST addTag(this, 'test')",
            context
        )
        action = result["suggested_actions"][0]
        assert action["target"] == "my_object_123"
    
    def test_action_includes_rule_name(self):
        """L'action inclut le nom de la règle."""
        context = {"this": {"id": "obj_001"}}
        ast = parse("check: SUGGEST mark(this, 'reviewed')")
        result = evaluate_with_actions(ast, context, "review_rule")
        
        if result.suggested_actions:
            action = result.suggested_actions[0]
            assert action.rule_name == "review_rule"
    
    def test_no_action_applied_automatically(self):
        """Les actions ne modifient PAS l'objet."""
        context = {"this": {"id": "obj_001", "tags": []}}
        ERK.quick_eval_with_actions(
            "check: SUGGEST addTag(this, 'core')",
            context
        )
        # L'objet n'a pas été modifié
        assert "core" not in context["this"]["tags"]
    
    def test_multiple_actions_in_sequence(self):
        """Plusieurs règles peuvent générer plusieurs actions."""
        context = {"this": {"id": "obj_001"}}
        
        rules = [
            parse("check: SUGGEST addTag(this, 'tag1')"),
            parse("check: SUGGEST addTag(this, 'tag2')"),
            parse("check: SUGGEST mark(this, 'processed')"),
        ]
        
        results = collect_actions(rules, context, ["rule1", "rule2", "rule3"])
        all_actions = get_all_suggested_actions(results)
        
        assert len(all_actions) == 3
        types = [a.action_type for a in all_actions]
        assert ActionType.ADD_TAG in types
        assert ActionType.MARK in types


# ============================================================================
# TESTS TYPES D'ACTIONS
# ============================================================================

class TestActionTypes:
    """Tests des différents types d'actions."""
    
    def test_add_tag_action(self):
        """Action addTag."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST addTag(this, 'core')",
            context
        )
        action = result["suggested_actions"][0]
        assert action["type"] == "add_tag"
        assert action["params"]["tag"] == "core"
    
    def test_remove_tag_action(self):
        """Action removeTag."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST removeTag(this, 'deprecated')",
            context
        )
        action = result["suggested_actions"][0]
        assert action["type"] == "remove_tag"
        assert action["params"]["tag"] == "deprecated"
    
    def test_mark_action(self):
        """Action mark."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST mark(this, 'toReview')",
            context
        )
        action = result["suggested_actions"][0]
        assert action["type"] == "mark"
        assert action["params"]["marker"] == "toReview"
    
    def test_enable_method_action(self):
        """Action enableMethod."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST enableMethod(this, 'prompt')",
            context
        )
        action = result["suggested_actions"][0]
        assert action["type"] == "enable_method"
        assert action["params"]["method"] == "prompt"
    
    def test_set_attribute_action(self):
        """Action setAttribute."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST setAttribute(this, 'status', 'active')",
            context
        )
        action = result["suggested_actions"][0]
        assert action["type"] == "set_attribute"
        assert action["params"]["attribute"] == "status"
        assert action["params"]["value"] == "active"
    
    def test_activate_action(self):
        """Action activate."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST activate(this)",
            context
        )
        action = result["suggested_actions"][0]
        assert action["type"] == "activate"
    
    def test_notify_action(self):
        """Action notify."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST notify(this, 'Object needs attention')",
            context
        )
        action = result["suggested_actions"][0]
        assert action["type"] == "notify"
        assert action["params"]["message"] == "Object needs attention"


# ============================================================================
# TESTS VALIDATION D'ACTIONS
# ============================================================================

class TestActionValidation:
    """Tests de validation des actions."""
    
    def test_validate_complete_action(self):
        """Action complète est valide."""
        action = SuggestedAction(
            action_type=ActionType.ADD_TAG,
            target="obj_001",
            params={"tag": "core"},
            rule_name="test_rule"
        )
        errors = validate_action(action)
        assert len(errors) == 0
    
    def test_validate_missing_target(self):
        """Action sans cible est invalide."""
        action = SuggestedAction(
            action_type=ActionType.ADD_TAG,
            target="",
            params={"tag": "core"}
        )
        errors = validate_action(action)
        assert len(errors) > 0
        assert any("target" in e.lower() for e in errors)
    
    def test_validate_missing_tag_param(self):
        """Action addTag sans tag est invalide."""
        action = SuggestedAction(
            action_type=ActionType.ADD_TAG,
            target="obj_001",
            params={}
        )
        errors = validate_action(action)
        assert len(errors) > 0
        assert any("tag" in e.lower() for e in errors)
    
    def test_unknown_action_function(self):
        """Fonction d'action inconnue génère une erreur."""
        context = {"this": {"id": "obj"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST unknownAction(this, 'param')",
            context
        )
        # L'évaluation réussit mais l'action n'est pas créée
        # ou une erreur est enregistrée
        assert "action_errors" in result.get("details", {}) or \
               result.get("errors") is not None or \
               len(result.get("suggested_actions", [])) == 0


# ============================================================================
# TESTS CONSOLE B3
# ============================================================================

class TestConsoleB3:
    """Tests d'intégration console B3."""
    
    def test_console_apply(self, console):
        """Console.apply retourne les actions."""
        result = console.apply("agent_001", "mark_for_review")
        assert result["status"] in ("ok", "failed")
        assert "actions" in result
        assert len(result["actions"]) >= 1
    
    def test_console_apply_conditional(self, console):
        """Console.apply avec règle conditionnelle."""
        result = console.apply("agent_001", "ensure_core_tag")
        assert "actions" in result
        # agent_001 a déjà "system" mais pas "core"
        # donc l'action devrait être collectée
    
    def test_console_apply_all(self, console):
        """Console.apply_all collecte toutes les actions."""
        result = console.apply_all("agent_002")
        assert "all_actions" in result
        assert "summary" in result
    
    def test_console_validates_suggest_syntax(self, console):
        """Console valide la syntaxe SUGGEST."""
        result = console.validate("check: SUGGEST addTag(this, 'test')")
        assert result["valid"] == True
    
    def test_console_parses_suggest(self, console):
        """Console parse correctement SUGGEST."""
        result = console.parse("check: SUGGEST mark(this, 'flag')")
        assert result["ok"] == True
        assert "SUGGEST" in str(result["ast"])


# ============================================================================
# TESTS FAÇADE ERK B3
# ============================================================================

class TestERKFacadeB3:
    """Tests de la façade ERK avec B3."""
    
    def test_quick_eval_with_actions(self):
        """ERK.quick_eval_with_actions fonctionne."""
        context = {"this": {"id": "obj", "missing": True}}
        result = ERK.quick_eval_with_actions(
            "check: IF this.missing THEN SUGGEST addTag(this, 'fixed')",
            context
        )
        assert "suggested_actions" in result
        assert len(result["suggested_actions"]) == 1


# ============================================================================
# TESTS CAS LIMITES
# ============================================================================

class TestEdgeCases:
    """Tests des cas limites."""
    
    def test_suggest_with_null_target(self):
        """SUGGEST avec cible null."""
        context = {"this": {"id": "obj", "child": None}}
        # Ne devrait pas crasher
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST mark(this.child, 'processed')",
            context
        )
        # L'action peut avoir "None" comme cible ou générer une erreur
        assert result is not None
    
    def test_deeply_nested_suggest(self):
        """SUGGEST dans IF imbriqués."""
        context = {"this": {"id": "obj", "a": True, "b": True, "c": True}}
        result = ERK.quick_eval_with_actions(
            "check: IF this.a THEN IF this.b THEN IF this.c THEN SUGGEST addTag(this, 'deep')",
            context
        )
        assert len(result.get("suggested_actions", [])) == 1
    
    def test_suggest_in_else_branch(self):
        """SUGGEST dans la branche ELSE."""
        context = {"this": {"id": "obj", "condition": False}}
        result = ERK.quick_eval_with_actions(
            "check: IF this.condition THEN true ELSE SUGGEST addTag(this, 'fallback')",
            context
        )
        assert len(result.get("suggested_actions", [])) == 1
    
    def test_suggest_preserves_rule_evaluation(self):
        """SUGGEST n'affecte pas le résultat de la règle."""
        context = {"this": {"id": "obj"}}
        
        # SUGGEST retourne True, donc la règle "check" devrait passer
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST addTag(this, 'test')",
            context
        )
        assert result["ok"] == True
    
    def test_action_with_complex_params(self):
        """Action avec paramètres complexes."""
        context = {"this": {"id": "obj", "value": 42}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST setAttribute(this, 'computed', this.value)",
            context
        )
        action = result["suggested_actions"][0]
        assert action["params"]["value"] == 42


# ============================================================================
# TESTS FORMAT DE SORTIE
# ============================================================================

class TestOutputFormat:
    """Tests du format de sortie des actions."""
    
    def test_action_dict_format(self):
        """Format dictionnaire d'une action."""
        action = SuggestedAction(
            action_type=ActionType.ADD_TAG,
            target="Object:Agent:Core",
            params={"tag": "core"},
            rule_name="ensure_core_tag"
        )
        d = action.to_dict()
        
        assert d["type"] == "add_tag"
        assert d["target"] == "Object:Agent:Core"
        assert d["params"] == {"tag": "core"}
        assert "ensure_core_tag" in d["reason"]
    
    def test_action_result_format(self):
        """Format ActionResult."""
        result = ActionResult(
            ok=True,
            rule="test_rule",
            action="check",
            value=True,
            reason="condition met",
            suggested_actions=[
                SuggestedAction(
                    action_type=ActionType.MARK,
                    target="obj_001",
                    params={"marker": "reviewed"}
                )
            ]
        )
        d = result.to_dict()
        
        assert d["ok"] == True
        assert d["rule"] == "test_rule"
        assert "suggested_actions" in d
        assert d["action_count"] == 1


# ============================================================================
# TESTS EXEMPLES DOCUMENTÉS
# ============================================================================

class TestDocumentedExamples:
    """Tests des exemples du prompt B3/3."""
    
    def test_example_1_add_tag(self):
        """SUGGEST addTag(this, 'core')"""
        context = {"this": {"id": "Object:Agent:Core"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST addTag(this, 'core')",
            context
        )
        
        assert len(result["suggested_actions"]) == 1
        action = result["suggested_actions"][0]
        assert action["type"] == "add_tag"
        assert action["target"] == "Object:Agent:Core"
        assert action["params"]["tag"] == "core"
    
    def test_example_2_mark_to_review(self):
        """SUGGEST mark(this, 'toReview')"""
        context = {"this": {"id": "obj_123"}}
        result = ERK.quick_eval_with_actions(
            "check: SUGGEST mark(this, 'toReview')",
            context
        )
        
        action = result["suggested_actions"][0]
        assert action["type"] == "mark"
        assert action["params"]["marker"] == "toReview"
    
    def test_example_3_enable_method(self):
        """SUGGEST enableMethod(this, 'prompt')"""
        context = {"this": {"id": "agent_001"}}
        result = ERK.quick_eval_with_actions(
            "enable: SUGGEST enableMethod(this, 'prompt')",
            context
        )
        
        action = result["suggested_actions"][0]
        assert action["type"] == "enable_method"
        assert action["params"]["method"] == "prompt"


# ============================================================================
# TESTS INTÉGRATION COMPLÈTE
# ============================================================================

class TestFullIntegration:
    """Tests d'intégration complète du workflow B3."""
    
    def test_full_workflow(self, console, sample_store):
        """Workflow complet: évaluation → collecte → validation."""
        # 1. Évaluer une règle avec actions
        result = console.apply("agent_002", "add_missing_tags")
        
        # 2. Vérifier que les actions sont collectées
        assert "actions" in result
        
        # 3. Les actions ne sont pas appliquées
        obj = sample_store.get_object("agent_002")
        assert "untagged" not in obj.get("tags", [])
        
        # 4. Les actions peuvent être validées
        for action_dict in result["actions"]:
            action = SuggestedAction(
                action_type=ActionType[action_dict["type"].upper()],
                target=action_dict["target"],
                params=action_dict["params"]
            )
            errors = validate_action(action)
            assert len(errors) == 0


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
