"""
ERK Actions - Système d'actions proposées B3/3.

Ce module définit:
- Les types d'actions que les règles ERK peuvent suggérer
- La structure des actions proposées
- Le collecteur d'actions pour l'évaluation

CONTRAINTE FONDAMENTALE:
Les actions sont PROPOSÉES, jamais appliquées automatiquement.
L'application est déléguée à une couche supérieure (UI/Orchestrator).

Version: B3/3 - Actions système (modifications contrôlées)
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum, auto


class ActionType(Enum):
    """Types d'actions système supportées."""
    
    # Tags
    ADD_TAG = auto()        # Ajouter un tag à un objet
    REMOVE_TAG = auto()     # Retirer un tag d'un objet
    
    # Marquage/Flags
    MARK = auto()           # Marquer un objet (flag temporaire)
    UNMARK = auto()         # Retirer un marquage
    SET_FLAG = auto()       # Définir un flag
    CLEAR_FLAG = auto()     # Effacer un flag
    
    # Méthodes/Capacités
    ENABLE_METHOD = auto()  # Activer une méthode sur l'objet
    DISABLE_METHOD = auto() # Désactiver une méthode
    
    # Attributs
    SET_ATTRIBUTE = auto()  # Modifier un attribut
    INCREMENT = auto()      # Incrémenter une valeur
    DECREMENT = auto()      # Décrémenter une valeur
    
    # Relations
    ADD_RELATION = auto()   # Ajouter une relation
    REMOVE_RELATION = auto()# Retirer une relation
    
    # Lifecycle
    ACTIVATE = auto()       # Activer un objet
    DEACTIVATE = auto()     # Désactiver un objet
    ARCHIVE = auto()        # Archiver un objet
    
    # Notification/Logging
    NOTIFY = auto()         # Créer une notification
    LOG = auto()            # Enregistrer dans le journal
    
    # Personnalisé
    CUSTOM = auto()         # Action personnalisée


# Mapping des noms de fonctions vers les types d'actions
ACTION_FUNCTION_MAPPING = {
    # Tags
    'addTag': ActionType.ADD_TAG,
    'removeTag': ActionType.REMOVE_TAG,
    
    # Marquage
    'mark': ActionType.MARK,
    'unmark': ActionType.UNMARK,
    'setFlag': ActionType.SET_FLAG,
    'clearFlag': ActionType.CLEAR_FLAG,
    
    # Méthodes
    'enableMethod': ActionType.ENABLE_METHOD,
    'disableMethod': ActionType.DISABLE_METHOD,
    
    # Attributs
    'setAttribute': ActionType.SET_ATTRIBUTE,
    'increment': ActionType.INCREMENT,
    'decrement': ActionType.DECREMENT,
    
    # Relations
    'addRelation': ActionType.ADD_RELATION,
    'removeRelation': ActionType.REMOVE_RELATION,
    
    # Lifecycle
    'activate': ActionType.ACTIVATE,
    'deactivate': ActionType.DEACTIVATE,
    'archive': ActionType.ARCHIVE,
    
    # Notification
    'notify': ActionType.NOTIFY,
    'log': ActionType.LOG,
    
    # Custom
    'custom': ActionType.CUSTOM,
}


@dataclass
class SuggestedAction:
    """
    Une action proposée par une règle ERK.
    
    Cette structure représente une modification potentielle sur la fractale.
    Elle n'est JAMAIS appliquée automatiquement.
    
    Attributs:
        action_type: Type de l'action (enum ActionType)
        target: Référence à l'objet cible (ID ou expression)
        params: Paramètres de l'action
        rule_name: Règle qui a généré cette action
        condition: Condition qui a déclenché la suggestion (optionnel)
        priority: Priorité de l'action (pour ordonnancement)
        metadata: Données additionnelles
    """
    action_type: ActionType
    target: str  # ID ou expression de l'objet cible
    params: Dict[str, Any] = field(default_factory=dict)
    rule_name: str = ""
    condition: Optional[str] = None
    priority: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        """Convertit l'action en format JSON standard."""
        return {
            "type": self.action_type.name.lower(),
            "target": self.target,
            "params": self.params,
            "reason": f"rule: {self.rule_name}" if self.rule_name else "",
            "condition": self.condition,
            "priority": self.priority,
            "metadata": self.metadata
        }
    
    def to_compact(self) -> str:
        """Représentation compacte pour le logging."""
        params_str = ", ".join(f"{k}={v!r}" for k, v in self.params.items())
        return f"SUGGEST {self.action_type.name}({self.target}, {params_str})"
    
    def __repr__(self):
        return f"SuggestedAction({self.action_type.name}, target={self.target!r}, params={self.params})"


@dataclass
class ActionCollector:
    """
    Collecteur d'actions pour une évaluation ERK.
    
    Accumule les actions suggérées pendant l'évaluation d'une règle
    ou d'un ensemble de règles.
    """
    actions: List[SuggestedAction] = field(default_factory=list)
    rule_name: str = ""
    errors: List[str] = field(default_factory=list)
    
    def suggest(
        self,
        action_type: ActionType,
        target: str,
        params: Dict[str, Any] = None,
        condition: str = None,
        priority: int = 0,
        metadata: Dict[str, Any] = None
    ) -> SuggestedAction:
        """
        Ajoute une action suggérée au collecteur.
        
        Args:
            action_type: Type de l'action
            target: Cible de l'action
            params: Paramètres
            condition: Condition qui a déclenché
            priority: Priorité
            metadata: Métadonnées
            
        Returns:
            L'action créée
        """
        action = SuggestedAction(
            action_type=action_type,
            target=target,
            params=params or {},
            rule_name=self.rule_name,
            condition=condition,
            priority=priority,
            metadata=metadata or {}
        )
        self.actions.append(action)
        return action
    
    def add_error(self, error: str):
        """Ajoute une erreur de génération d'action."""
        self.errors.append(error)
    
    def has_actions(self) -> bool:
        """Vérifie si des actions ont été collectées."""
        return len(self.actions) > 0
    
    def has_errors(self) -> bool:
        """Vérifie s'il y a eu des erreurs."""
        return len(self.errors) > 0
    
    def clear(self):
        """Réinitialise le collecteur."""
        self.actions = []
        self.errors = []
    
    def to_dict(self) -> dict:
        """Exporte le collecteur en dictionnaire."""
        return {
            "actions": [a.to_dict() for a in self.actions],
            "count": len(self.actions),
            "rule": self.rule_name,
            "errors": self.errors if self.errors else None
        }
    
    def to_list(self) -> List[dict]:
        """Exporte les actions en liste de dictionnaires."""
        return [a.to_dict() for a in self.actions]
    
    def filter_by_type(self, *types: ActionType) -> List[SuggestedAction]:
        """Filtre les actions par type."""
        return [a for a in self.actions if a.action_type in types]
    
    def filter_by_target(self, target: str) -> List[SuggestedAction]:
        """Filtre les actions par cible."""
        return [a for a in self.actions if a.target == target]
    
    def sorted_by_priority(self) -> List[SuggestedAction]:
        """Retourne les actions triées par priorité (décroissante)."""
        return sorted(self.actions, key=lambda a: -a.priority)


@dataclass
class ActionResult:
    """
    Résultat d'une évaluation ERK avec actions.
    
    Étend EvalResult pour inclure les actions proposées.
    """
    ok: bool
    rule: str
    action: str  # L'action ERK (enable, allow, etc.)
    value: Any = None
    reason: str = ""
    details: dict = field(default_factory=dict)
    suggested_actions: List[SuggestedAction] = field(default_factory=list)
    action_errors: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        """Convertit en dictionnaire pour la console."""
        result = {
            "ok": self.ok,
            "rule": self.rule,
            "action": self.action,
            "value": self.value,
            "reason": self.reason,
            "details": self.details,
        }
        
        # Ajouter les actions si présentes
        if self.suggested_actions:
            result["suggested_actions"] = [a.to_dict() for a in self.suggested_actions]
            result["action_count"] = len(self.suggested_actions)
        
        # Ajouter les erreurs d'actions si présentes
        if self.action_errors:
            result["action_errors"] = self.action_errors
        
        return result
    
    def has_actions(self) -> bool:
        """Vérifie si des actions sont proposées."""
        return len(self.suggested_actions) > 0


def create_action_from_call(
    function_name: str,
    target: str,
    args: List[Any],
    rule_name: str = "",
    condition: str = None
) -> SuggestedAction:
    """
    Crée une action à partir d'un appel de fonction SUGGEST.
    
    Args:
        function_name: Nom de la fonction (addTag, mark, etc.)
        target: Expression cible
        args: Arguments de la fonction
        rule_name: Nom de la règle source
        condition: Condition qui a déclenché
        
    Returns:
        SuggestedAction configurée
        
    Raises:
        ValueError: Si la fonction n'est pas reconnue
    """
    if function_name not in ACTION_FUNCTION_MAPPING:
        raise ValueError(f"Unknown action function: {function_name}")
    
    action_type = ACTION_FUNCTION_MAPPING[function_name]
    
    # Construire les params selon le type d'action
    params = {}
    
    if action_type in (ActionType.ADD_TAG, ActionType.REMOVE_TAG):
        # addTag(target, "tag_name")
        if args:
            params["tag"] = args[0]
    
    elif action_type in (ActionType.MARK, ActionType.UNMARK):
        # mark(target, "flag_name")
        if args:
            params["marker"] = args[0]
    
    elif action_type in (ActionType.SET_FLAG, ActionType.CLEAR_FLAG):
        # setFlag(target, "flag_name", value?)
        if len(args) >= 1:
            params["flag"] = args[0]
        if len(args) >= 2:
            params["value"] = args[1]
    
    elif action_type in (ActionType.ENABLE_METHOD, ActionType.DISABLE_METHOD):
        # enableMethod(target, "method_name")
        if args:
            params["method"] = args[0]
    
    elif action_type == ActionType.SET_ATTRIBUTE:
        # setAttribute(target, "attr_name", value)
        if len(args) >= 2:
            params["attribute"] = args[0]
            params["value"] = args[1]
    
    elif action_type in (ActionType.INCREMENT, ActionType.DECREMENT):
        # increment(target, "field", amount?)
        if len(args) >= 1:
            params["field"] = args[0]
        if len(args) >= 2:
            params["amount"] = args[1]
        else:
            params["amount"] = 1
    
    elif action_type in (ActionType.ADD_RELATION, ActionType.REMOVE_RELATION):
        # addRelation(target, "relation_type", "target_id")
        if len(args) >= 2:
            params["relation"] = args[0]
            params["related_to"] = args[1]
    
    elif action_type in (ActionType.ACTIVATE, ActionType.DEACTIVATE, ActionType.ARCHIVE):
        # Pas de params supplémentaires
        pass
    
    elif action_type == ActionType.NOTIFY:
        # notify(target, "message", level?)
        if len(args) >= 1:
            params["message"] = args[0]
        if len(args) >= 2:
            params["level"] = args[1]
    
    elif action_type == ActionType.LOG:
        # log(target, "message", category?)
        if len(args) >= 1:
            params["message"] = args[0]
        if len(args) >= 2:
            params["category"] = args[1]
    
    elif action_type == ActionType.CUSTOM:
        # custom(target, "action_name", ...params)
        if len(args) >= 1:
            params["action_name"] = args[0]
        if len(args) >= 2:
            params["custom_params"] = args[1:]
    
    return SuggestedAction(
        action_type=action_type,
        target=target,
        params=params,
        rule_name=rule_name,
        condition=condition
    )


def validate_action(action: SuggestedAction) -> List[str]:
    """
    Valide une action proposée.
    
    Args:
        action: L'action à valider
        
    Returns:
        Liste des erreurs (vide si valide)
    """
    errors = []
    
    # Vérifier la cible
    if not action.target:
        errors.append("Action target is required")
    
    # Valider selon le type
    if action.action_type in (ActionType.ADD_TAG, ActionType.REMOVE_TAG):
        if "tag" not in action.params:
            errors.append(f"{action.action_type.name}: 'tag' parameter is required")
    
    elif action.action_type in (ActionType.MARK, ActionType.UNMARK):
        if "marker" not in action.params:
            errors.append(f"{action.action_type.name}: 'marker' parameter is required")
    
    elif action.action_type in (ActionType.ENABLE_METHOD, ActionType.DISABLE_METHOD):
        if "method" not in action.params:
            errors.append(f"{action.action_type.name}: 'method' parameter is required")
    
    elif action.action_type == ActionType.SET_ATTRIBUTE:
        if "attribute" not in action.params or "value" not in action.params:
            errors.append("SET_ATTRIBUTE: 'attribute' and 'value' parameters are required")
    
    return errors
