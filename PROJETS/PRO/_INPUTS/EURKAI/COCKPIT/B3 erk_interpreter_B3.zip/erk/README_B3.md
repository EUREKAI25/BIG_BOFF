# ERK Interpreter B3/3 - Actions Système

## Vue d'ensemble

Cette version B3/3 de l'interpréteur ERK ajoute la capacité pour les règles de **proposer des actions** sur la fractale, tout en respectant la contrainte fondamentale:

> **AUCUNE action n'est appliquée automatiquement. Les actions sont collectées, structurées et retournées pour validation externe.**

## Nouvelle syntaxe: SUGGEST

### Syntaxe de base

```
SUGGEST function(target, params...)
```

### Exemples

```erk
# Ajouter un tag
check: SUGGEST addTag(this, "core")

# Marquer pour revue
enable: SUGGEST mark(this, "toReview")

# Activer une méthode
allow: SUGGEST enableMethod(this, "prompt")

# Modifier un attribut
check: SUGGEST setAttribute(this, "status", "active")
```

### Dans des conditions

```erk
# Suggérer si condition remplie
check: IF NOT this.tags.contains("core") THEN SUGGEST addTag(this, "core")

# Avec contexte
allow: WHEN ctx.mode == "strict" THEN SUGGEST enableMethod(this, "validate")

# Dans la branche ELSE
check: IF this.valid THEN true ELSE SUGGEST mark(this, "toFix")
```

## Types d'actions supportés

| Fonction | Type | Paramètres | Description |
|----------|------|------------|-------------|
| `addTag(target, tag)` | ADD_TAG | tag | Ajouter un tag |
| `removeTag(target, tag)` | REMOVE_TAG | tag | Retirer un tag |
| `mark(target, marker)` | MARK | marker | Marquer l'objet |
| `unmark(target, marker)` | UNMARK | marker | Retirer marquage |
| `setFlag(target, flag, value?)` | SET_FLAG | flag, value | Définir un flag |
| `clearFlag(target, flag)` | CLEAR_FLAG | flag | Effacer un flag |
| `enableMethod(target, method)` | ENABLE_METHOD | method | Activer méthode |
| `disableMethod(target, method)` | DISABLE_METHOD | method | Désactiver méthode |
| `setAttribute(target, attr, value)` | SET_ATTRIBUTE | attribute, value | Modifier attribut |
| `increment(target, field, amount?)` | INCREMENT | field, amount | Incrémenter |
| `decrement(target, field, amount?)` | DECREMENT | field, amount | Décrémenter |
| `activate(target)` | ACTIVATE | - | Activer l'objet |
| `deactivate(target)` | DEACTIVATE | - | Désactiver l'objet |
| `archive(target)` | ARCHIVE | - | Archiver l'objet |
| `notify(target, message, level?)` | NOTIFY | message, level | Notification |
| `log(target, message, category?)` | LOG | message, category | Log |

## Format de sortie d'une action

```json
{
  "type": "add_tag",
  "target": "Object:Agent:Core",
  "params": { "tag": "core" },
  "reason": "rule: ensure_core_tag",
  "condition": null,
  "priority": 0,
  "metadata": {}
}
```

## API

### Évaluation avec actions

```python
from erk import ERK, parse, evaluate_with_actions

# Via la façade
result = ERK.quick_eval_with_actions(
    "check: SUGGEST addTag(this, 'core')",
    {"this": {"id": "obj_001"}}
)

# Accès aux actions
for action in result["suggested_actions"]:
    print(f"Action: {action['type']} sur {action['target']}")

# Via le parser/evaluator
ast = parse("check: SUGGEST mark(this, 'reviewed')")
result = evaluate_with_actions(ast, context, "rule_name")
# result.suggested_actions contient les SuggestedAction
```

### Console: apply()

```python
from erk import ERKConsole, StoreAdapter

console = ERKConsole(store)

# Évaluer et collecter les actions (sans les appliquer)
result = console.apply("agent_001", "ensure_core_tag")

# Résultat
{
    "status": "ok",
    "actions": [
        {"type": "add_tag", "target": "agent_001", "params": {"tag": "core"}, ...}
    ],
    "log": "condition met",
    "action_count": 1
}
```

### Collecte multiple

```python
from erk import collect_actions, get_all_suggested_actions, parse

rules = [
    parse("check: SUGGEST addTag(this, 'tag1')"),
    parse("check: SUGGEST mark(this, 'processed')"),
]

results = collect_actions(rules, context, ["rule1", "rule2"])
all_actions = get_all_suggested_actions(results)
```

## Flux d'exécution

1. L'utilisateur ou un agent IA appelle `ERK.apply(objectId, ruleName)`
2. ERK évalue la règle
3. Les actions SUGGEST sont collectées (jamais appliquées)
4. Le résultat est retourné avec `status`, `actions[]`, et `log`
5. Une couche supérieure (UI/Orchestrator) décide d'appliquer ou non

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   User/Agent    │────▶│   ERK.apply()   │────▶│  ActionResult   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │                        │
                               ▼                        ▼
                        ┌─────────────┐         ┌─────────────────┐
                        │  Evaluate   │         │ suggested_actions│
                        │  + Collect  │         │ (not applied)   │
                        └─────────────┘         └─────────────────┘
                                                        │
                                                        ▼
                                               ┌─────────────────┐
                                               │ UI/Orchestrator │
                                               │ decides & apply │
                                               └─────────────────┘
```

## Validation des actions

```python
from erk import SuggestedAction, validate_action, ActionType

action = SuggestedAction(
    action_type=ActionType.ADD_TAG,
    target="obj_001",
    params={"tag": "core"}
)

errors = validate_action(action)
if not errors:
    print("Action valide!")
```

## Contraintes et garanties

1. **Idempotence**: Les actions sont conçues pour être idempotentes
2. **Traçabilité**: Chaque action inclut la règle qui l'a générée
3. **Robustesse**: Les erreurs de génération n'interrompent pas l'évaluation
4. **Isolation**: Le store n'est JAMAIS modifié par l'évaluation

## Exemples complets

### Règle: Assurer un tag core

```erk
# Règle ERK
check: IF NOT this.tags.contains("core") THEN SUGGEST addTag(this, "core")
```

```python
# Évaluation
context = {
    "this": {
        "id": "agent_001",
        "tags": ["system"]  # pas de "core"
    }
}

result = ERK.quick_eval_with_actions(rule, context)

# Résultat
assert result["ok"] == True
assert len(result["suggested_actions"]) == 1
assert result["suggested_actions"][0]["type"] == "add_tag"
assert result["suggested_actions"][0]["params"]["tag"] == "core"

# L'objet n'a PAS été modifié
assert "core" not in context["this"]["tags"]
```

### Workflow complet avec console

```python
store = StoreAdapter()
store.objects = {"agent_001": {...}}
store.rules = {
    "agent_001": {
        "ensure_tags": "check: IF this.tags.isEmpty() THEN SUGGEST addTag(this, 'default')"
    }
}

console = ERKConsole(store)

# 1. Évaluer et collecter
result = console.apply("agent_001", "ensure_tags")

# 2. Afficher les actions proposées
for action in result["actions"]:
    print(f"Proposé: {action['type']} -> {action['target']}")

# 3. Validation externe (UI/Orchestrator décide)
if user_approves(result["actions"]):
    apply_actions_to_store(store, result["actions"])
```

## Checklist de validation

- [x] Les règles peuvent générer des actions proposées sous forme structurée
- [x] Aucune action n'est appliquée automatiquement
- [x] Les actions incluent: type, cible, paramètres, règle d'origine
- [x] L'évaluation ERK reste robuste même avec actions invalides
- [x] Exemples de règles + actions + cas de test fournis
- [x] Rétrocompatibilité B1/1 et B2/2 maintenue

## Tests

```bash
# Exécuter les tests B3
pytest erk/tests/test_erk_b3.py -v

# Tous les tests (B1 + B2 + B3)
pytest erk/tests/ -v
```

## Version

- **B3/3** - Actions système (modifications contrôlées)
- Compatible avec B2/2 (conditions étendues) et B1/1 (parser de base)
