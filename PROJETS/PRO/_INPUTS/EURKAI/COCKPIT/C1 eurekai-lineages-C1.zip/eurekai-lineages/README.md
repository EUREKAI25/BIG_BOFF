# EUREKAI C1/1 — Lineages Assistés

> Système de suggestions d'héritage pour objets orphelins ou incomplets

---

## 📋 Résumé du livrable

Ce module implémente un système de **lineages assistés** pour le cockpit EUREKAI. Il permet de suggérer automatiquement des parents probables pour les objets sans parent déclaré ou avec un lineage incomplet.

---

## 🏗️ Architecture

```
eurekai-lineages/
├── src/
│   ├── lineage-suggester.ts       # Module principal (TypeScript)
│   ├── lineage-suggester.test.ts  # Tests et exemples
│   └── components/
│       └── LineageSuggesterPanel.tsx  # Composant React cockpit
├── demo.js                        # Démonstration exécutable
├── package.json
└── README.md
```

---

## 🎯 Stratégie de suggestion

### Critères pondérés

| Critère | Poids | Description |
|---------|-------|-------------|
| **Préfixe de lineage** | 40% | `Core:Agent` est candidat pour `Core:Agent:LLM:Claude` |
| **Similarité sémantique** | 25% | Proximité lexicale des noms (Jaccard + substring) |
| **Profondeur structurelle** | 15% | Parent direct (N-1) = score max |
| **Tags partagés** | 10% | Ratio de tags en commun |
| **Bundle partagé** | 5% | Objets du même bundle |
| **Règles ERK** | 5% | Patterns explicites (ex: LLM → Agent) |

### Niveaux de confiance

- 🟢 **High** (≥70): Suggestion quasi-certaine
- 🟡 **Medium** (40-69): Suggestion probable, vérification recommandée  
- 🔴 **Low** (<40): Suggestion incertaine, alternatives à considérer

---

## 📦 API

### `suggestParents(objectId: string): ParentSuggestion[]`

```typescript
interface ParentSuggestion {
  parentId: string;
  parentName: string;
  parentLineage: string;
  score: number;              // 0-100
  confidence: 'high' | 'medium' | 'low';
  reasons: SuggestionReason[];
}

interface SuggestionReason {
  criterion: SuggestionCriterion;
  weight: number;
  detail: string;
}
```

### Autres méthodes

- `findOrphans()` — Liste tous les objets orphelins/incomplets
- `suggestAllOrphans()` — Suggestions pour tous les orphelins

---

## 🧪 Cas de test

### CAS 1: Parent évident
**Input**: `Claude` avec lineage `Core:Agent:LLM:Claude`  
**Output**: `LLM (Core:Agent:LLM)` avec score 67% 🟡

### CAS 2: Ambiguïté
**Input**: `Connector` avec lineage `Connector` (incomplet)  
**Output**: 
- `Infrastructure` — 25% 🔴 (tags: system, technical)
- `Core` — 20% 🔴 (tag: system)

### CAS 3: Aucun match
**Input**: `QuantumFluxCapacitor` avec lineage `Experimental:Quantum:Flux`  
**Output**: Aucune suggestion (pas de correspondance)

### CAS 4: Référence cassée
**Input**: `Widget` avec `parentId: 'non-existent-ui'`  
**Output**: `Core` suggéré comme remplacement — 48% 🟡

### CAS 5: Incohérence
**Input**: `Report` avec lineage `Agency:Project:Report` mais `parentId: 'root-core'`  
**Output**: Aucune suggestion (incohérence détectée)

---

## 🖥️ Intégration Cockpit

Le composant `LineageSuggesterPanel` s'intègre dans le cockpit pour :

1. Afficher les suggestions quand un objet orphelin est sélectionné
2. Permettre d'appliquer ou rejeter chaque suggestion
3. Afficher les raisons détaillées de chaque suggestion
4. Marquer les suggestions avec leur niveau de confiance

### Fonctionnalités UI

- ⚠️ Banner d'avertissement (suggestions automatiques)
- 🟢🟡🔴 Indicateurs de confiance
- 📊 Barre de score visuelle
- 📝 Raisons détaillées (expandable)
- ✓/✗ Boutons Appliquer/Ignorer

---

## ✅ Checklist de validation

- [x] Pour tout objet sans parent clair, le système fournit 0, 1 ou plusieurs suggestions
- [x] Les suggestions sont accompagnées de scores et de raisons
- [x] Aucun changement n'est fait à la fractale sans validation explicite
- [x] Exemples fournis pour chaque type de cas

---

## 🚀 Exécution

```bash
# Démonstration
node demo.js

# Tests TypeScript (nécessite ts-node)
npm install
npm test
```

---

## 🔮 Extensions futures

1. **Apprentissage**: Ajuster les poids selon les validations/rejets utilisateur
2. **ERK avancé**: Règles complexes avec conditions multiples
3. **Statistiques**: Patterns découverts automatiquement par analyse de corpus
4. **IA**: Embeddings sémantiques pour similarité de noms

---

## 📜 Licence

EUREKAI Internal — Module C1/1
