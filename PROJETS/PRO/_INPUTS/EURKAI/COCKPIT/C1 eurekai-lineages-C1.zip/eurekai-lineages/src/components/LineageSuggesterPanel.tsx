/**
 * EUREKAI - Lineages Assistés (C1/1)
 * Composant Cockpit React pour les suggestions de parents
 */

import React, { useState, useMemo, useCallback } from 'react';

// ============================================================================
// TYPES (repris du module principal)
// ============================================================================

interface ParentSuggestion {
  parentId: string;
  parentName: string;
  parentLineage: string;
  score: number;
  confidence: 'high' | 'medium' | 'low';
  reasons: Array<{
    criterion: string;
    weight: number;
    detail: string;
  }>;
}

interface FractalObject {
  id: string;
  name: string;
  lineage: string;
  parentId: string | null;
  depth: number;
  tags: string[];
}

interface LineageSuggesterAPI {
  getSuggestions(objectId: string): ParentSuggestion[];
  applySuggestion(objectId: string, parentId: string): boolean;
  rejectSuggestion(objectId: string, parentId: string, reason?: string): void;
}

// ============================================================================
// COMPOSANTS UI
// ============================================================================

interface SuggestionCardProps {
  suggestion: ParentSuggestion;
  onApply: () => void;
  onReject: () => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const SuggestionCard: React.FC<SuggestionCardProps> = ({
  suggestion,
  onApply,
  onReject,
  isExpanded,
  onToggleExpand
}) => {
  const confidenceColors = {
    high: { bg: 'bg-green-50', border: 'border-green-200', badge: 'bg-green-100 text-green-800' },
    medium: { bg: 'bg-yellow-50', border: 'border-yellow-200', badge: 'bg-yellow-100 text-yellow-800' },
    low: { bg: 'bg-red-50', border: 'border-red-200', badge: 'bg-red-100 text-red-800' }
  };

  const colors = confidenceColors[suggestion.confidence];

  return (
    <div className={`rounded-lg border-2 ${colors.border} ${colors.bg} p-4 mb-3 transition-all`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="font-semibold text-gray-900">{suggestion.parentName}</span>
            <span className="text-sm text-gray-500 font-mono">{suggestion.parentLineage}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors.badge}`}>
            {suggestion.score}%
          </span>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors.badge}`}>
            {suggestion.confidence}
          </span>
        </div>
      </div>

      {/* Score Bar */}
      <div className="mt-3 h-2 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className={`h-full transition-all ${
            suggestion.confidence === 'high' ? 'bg-green-500' :
            suggestion.confidence === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
          }`}
          style={{ width: `${suggestion.score}%` }}
        />
      </div>

      {/* Toggle Reasons */}
      <button
        onClick={onToggleExpand}
        className="mt-3 text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
      >
        {isExpanded ? '▼' : '▶'} {suggestion.reasons.length} raison(s)
      </button>

      {/* Reasons (expanded) */}
      {isExpanded && (
        <div className="mt-2 pl-4 border-l-2 border-gray-300">
          {suggestion.reasons.map((reason, idx) => (
            <div key={idx} className="text-sm text-gray-600 mb-1">
              <span className="font-medium">{reason.criterion}:</span>{' '}
              {reason.detail}
              <span className="text-gray-400 ml-2">({reason.weight.toFixed(0)}%)</span>
            </div>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="mt-4 flex gap-2">
        <button
          onClick={onApply}
          className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 
                     transition-colors font-medium text-sm"
        >
          ✓ Appliquer ce parent
        </button>
        <button
          onClick={onReject}
          className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg 
                     hover:bg-gray-100 transition-colors text-sm"
        >
          ✗ Ignorer
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// COMPOSANT PRINCIPAL
// ============================================================================

interface LineageSuggesterPanelProps {
  selectedObject: FractalObject | null;
  api: LineageSuggesterAPI;
  onParentApplied?: (objectId: string, parentId: string) => void;
}

export const LineageSuggesterPanel: React.FC<LineageSuggesterPanelProps> = ({
  selectedObject,
  api,
  onParentApplied
}) => {
  const [expandedIdx, setExpandedIdx] = useState<number | null>(null);
  const [appliedParent, setAppliedParent] = useState<string | null>(null);
  const [rejectedParents, setRejectedParents] = useState<Set<string>>(new Set());

  // Récupérer les suggestions
  const suggestions = useMemo(() => {
    if (!selectedObject) return [];
    return api.getSuggestions(selectedObject.id)
      .filter(s => !rejectedParents.has(s.parentId));
  }, [selectedObject, api, rejectedParents]);

  // Handlers
  const handleApply = useCallback((suggestion: ParentSuggestion) => {
    if (!selectedObject) return;
    
    const success = api.applySuggestion(selectedObject.id, suggestion.parentId);
    if (success) {
      setAppliedParent(suggestion.parentId);
      onParentApplied?.(selectedObject.id, suggestion.parentId);
    }
  }, [selectedObject, api, onParentApplied]);

  const handleReject = useCallback((suggestion: ParentSuggestion) => {
    if (!selectedObject) return;
    
    api.rejectSuggestion(selectedObject.id, suggestion.parentId);
    setRejectedParents(prev => new Set([...prev, suggestion.parentId]));
  }, [selectedObject, api]);

  // Reset quand l'objet sélectionné change
  React.useEffect(() => {
    setExpandedIdx(null);
    setAppliedParent(null);
    setRejectedParents(new Set());
  }, [selectedObject?.id]);

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────

  if (!selectedObject) {
    return (
      <div className="p-6 text-center text-gray-500">
        <div className="text-4xl mb-3">🔍</div>
        <p>Sélectionnez un objet pour voir les suggestions de parent</p>
      </div>
    );
  }

  // Objet a déjà un parent valide
  if (selectedObject.parentId && appliedParent === null) {
    return (
      <div className="p-6">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-green-800">
            <span className="text-xl">✓</span>
            <span className="font-medium">Parent déjà défini</span>
          </div>
          <p className="mt-2 text-sm text-green-700">
            Cet objet a déjà un parent: <code className="font-mono">{selectedObject.parentId}</code>
          </p>
        </div>
      </div>
    );
  }

  // Parent vient d'être appliqué
  if (appliedParent) {
    return (
      <div className="p-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-blue-800">
            <span className="text-xl">🎉</span>
            <span className="font-medium">Parent assigné avec succès</span>
          </div>
          <p className="mt-2 text-sm text-blue-700">
            Le parent <code className="font-mono">{appliedParent}</code> a été assigné à cet objet.
          </p>
        </div>
      </div>
    );
  }

  // Aucune suggestion disponible
  if (suggestions.length === 0) {
    return (
      <div className="p-6">
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-gray-600">
            <span className="text-xl">∅</span>
            <span className="font-medium">Aucune suggestion</span>
          </div>
          <p className="mt-2 text-sm text-gray-500">
            Le système n'a pas trouvé de parent probable pour cet objet.
            Vous pouvez définir le parent manuellement.
          </p>
        </div>
      </div>
    );
  }

  // Afficher les suggestions
  return (
    <div className="p-4">
      {/* Header */}
      <div className="mb-4">
        <h3 className="font-semibold text-gray-900 flex items-center gap-2">
          <span>💡</span> Parents suggérés
        </h3>
        <p className="text-sm text-gray-500 mt-1">
          {suggestions.length} suggestion(s) pour{' '}
          <code className="font-mono text-blue-600">{selectedObject.name}</code>
        </p>
      </div>

      {/* Warning Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
        <p className="text-sm text-amber-800">
          ⚠️ Ces suggestions sont basées sur des patterns automatiques.
          Vérifiez avant d'appliquer.
        </p>
      </div>

      {/* Suggestion Cards */}
      {suggestions.map((suggestion, idx) => (
        <SuggestionCard
          key={suggestion.parentId}
          suggestion={suggestion}
          onApply={() => handleApply(suggestion)}
          onReject={() => handleReject(suggestion)}
          isExpanded={expandedIdx === idx}
          onToggleExpand={() => setExpandedIdx(expandedIdx === idx ? null : idx)}
        />
      ))}

      {/* Footer Info */}
      <div className="mt-4 text-xs text-gray-400 text-center">
        Les suggestions sont triées par score décroissant.
        Aucune modification n'est faite sans confirmation.
      </div>
    </div>
  );
};

// ============================================================================
// COMPOSANT BADGE POUR LA SIDEBAR
// ============================================================================

interface OrphanBadgeProps {
  count: number;
  onClick?: () => void;
}

export const OrphanBadge: React.FC<OrphanBadgeProps> = ({ count, onClick }) => {
  if (count === 0) return null;

  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 px-3 py-2 bg-orange-100 text-orange-800 
                 rounded-lg hover:bg-orange-200 transition-colors"
    >
      <span className="text-lg">⚠️</span>
      <span className="font-medium">{count} orphelin{count > 1 ? 's' : ''}</span>
    </button>
  );
};

// ============================================================================
// EXPORT DEFAULT
// ============================================================================

export default LineageSuggesterPanel;
