/**
 * EUREKAI - Lineages Assistés (C1/1)
 * Exemples et Cas de Test
 */

import {
  LineageSuggester,
  FractalObject,
  ParentSuggestion,
  ERK_RULE_LLM_AGENT,
  ERK_RULE_PROJECT_DOMAIN
} from './lineage-suggester';

// ============================================================================
// DONNÉES DE TEST - STORE FRACTAL SIMULÉ
// ============================================================================

export const TEST_OBJECTS: FractalObject[] = [
  // Niveau 0 - Racines
  {
    id: 'root-core',
    name: 'Core',
    lineage: 'Core',
    parentId: null,
    depth: 0,
    tags: ['system', 'foundation'],
    bundleId: 'core-bundle',
    metadata: {}
  },
  {
    id: 'root-agency',
    name: 'Agency',
    lineage: 'Agency',
    parentId: null,
    depth: 0,
    tags: ['domain', 'business'],
    bundleId: 'agency-bundle',
    metadata: {}
  },
  {
    id: 'root-infra',
    name: 'Infrastructure',
    lineage: 'Infrastructure',
    parentId: null,
    depth: 0,
    tags: ['system', 'technical'],
    bundleId: 'infra-bundle',
    metadata: {}
  },

  // Niveau 1 - Core
  {
    id: 'core-agent',
    name: 'Agent',
    lineage: 'Core:Agent',
    parentId: 'root-core',
    depth: 1,
    tags: ['system', 'actor'],
    bundleId: 'core-bundle',
    metadata: {}
  },
  {
    id: 'core-object',
    name: 'Object',
    lineage: 'Core:Object',
    parentId: 'root-core',
    depth: 1,
    tags: ['system', 'entity'],
    bundleId: 'core-bundle',
    metadata: {}
  },

  // Niveau 2 - Core:Agent
  {
    id: 'agent-llm',
    name: 'LLM',
    lineage: 'Core:Agent:LLM',
    parentId: 'core-agent',
    depth: 2,
    tags: ['system', 'actor', 'ai'],
    bundleId: 'core-bundle',
    metadata: {}
  },
  {
    id: 'agent-human',
    name: 'Human',
    lineage: 'Core:Agent:Human',
    parentId: 'core-agent',
    depth: 2,
    tags: ['system', 'actor', 'user'],
    bundleId: 'core-bundle',
    metadata: {}
  },

  // Niveau 1 - Agency
  {
    id: 'agency-project',
    name: 'Project',
    lineage: 'Agency:Project',
    parentId: 'root-agency',
    depth: 1,
    tags: ['domain', 'work'],
    bundleId: 'agency-bundle',
    metadata: {}
  },
  {
    id: 'agency-client',
    name: 'Client',
    lineage: 'Agency:Client',
    parentId: 'root-agency',
    depth: 1,
    tags: ['domain', 'contact'],
    bundleId: 'agency-bundle',
    metadata: {}
  },

  // Niveau 2 - Agency:Project
  {
    id: 'project-blog',
    name: 'Blog',
    lineage: 'Agency:Project:Blog',
    parentId: 'agency-project',
    depth: 2,
    tags: ['domain', 'work', 'content'],
    bundleId: 'agency-bundle',
    metadata: {}
  }
];

// ============================================================================
// CAS DE TEST
// ============================================================================

/**
 * CAS 1: Objet avec parent évident
 * Un nouvel objet "Claude" de lineage "Core:Agent:LLM:Claude"
 * → Le parent évident est "Core:Agent:LLM"
 */
export const CASE_1_OBVIOUS_PARENT: FractalObject = {
  id: 'orphan-claude',
  name: 'Claude',
  lineage: 'Core:Agent:LLM:Claude',
  parentId: null,  // ORPHELIN
  depth: 3,
  tags: ['system', 'actor', 'ai', 'anthropic'],
  bundleId: 'core-bundle',
  metadata: {}
};

/**
 * CAS 2: Objet avec plusieurs parents possibles
 * Un objet "Connector" qui pourrait être sous Infrastructure OU Core
 */
export const CASE_2_AMBIGUOUS: FractalObject = {
  id: 'orphan-connector',
  name: 'Connector',
  lineage: 'Connector',  // Lineage incomplet
  parentId: null,
  depth: 1,
  tags: ['system', 'technical'],
  bundleId: null,
  metadata: {}
};

/**
 * CAS 3: Objet unique sans parent raisonnable
 * Un objet complètement nouveau sans rapport avec l'existant
 */
export const CASE_3_NO_MATCH: FractalObject = {
  id: 'orphan-exotic',
  name: 'QuantumFluxCapacitor',
  lineage: 'Experimental:Quantum:Flux',
  parentId: null,
  depth: 2,
  tags: ['experimental', 'research'],
  bundleId: null,
  metadata: {}
};

/**
 * CAS 4: Objet avec parent déclaré mais inexistant
 * Le parent référencé n'existe pas dans le store
 */
export const CASE_4_BROKEN_REFERENCE: FractalObject = {
  id: 'orphan-broken',
  name: 'Widget',
  lineage: 'Core:UI:Widget',
  parentId: 'non-existent-ui',  // Parent inexistant!
  depth: 2,
  tags: ['system', 'ui'],
  bundleId: 'core-bundle',
  metadata: {}
};

/**
 * CAS 5: Objet avec lineage incohérent
 * Le lineage ne correspond pas au parent déclaré
 */
export const CASE_5_INCONSISTENT: FractalObject = {
  id: 'orphan-inconsistent',
  name: 'Report',
  lineage: 'Agency:Project:Report',  // Dit Agency:Project
  parentId: 'root-core',              // Mais parent = Core !
  depth: 2,
  tags: ['domain', 'document'],
  bundleId: 'agency-bundle',
  metadata: {}
};

// ============================================================================
// RUNNER DE TEST
// ============================================================================

export function runTests(): void {
  console.log('═══════════════════════════════════════════════════════════════');
  console.log('        EUREKAI - Lineages Assistés - Tests C1/1');
  console.log('═══════════════════════════════════════════════════════════════\n');

  // Initialiser le suggester avec les données de test
  const allObjects = [
    ...TEST_OBJECTS,
    CASE_1_OBVIOUS_PARENT,
    CASE_2_AMBIGUOUS,
    CASE_3_NO_MATCH,
    CASE_4_BROKEN_REFERENCE,
    CASE_5_INCONSISTENT
  ];

  const suggester = new LineageSuggester(
    allObjects,
    { minScore: 15 },  // Seuil bas pour voir plus de suggestions
    [ERK_RULE_LLM_AGENT, ERK_RULE_PROJECT_DOMAIN]
  );

  // Test 1: Parent évident
  console.log('┌─────────────────────────────────────────────────────────────┐');
  console.log('│ CAS 1: Parent évident (Claude → Core:Agent:LLM)            │');
  console.log('└─────────────────────────────────────────────────────────────┘');
  printSuggestions(suggester.suggestParents(CASE_1_OBVIOUS_PARENT.id), CASE_1_OBVIOUS_PARENT);

  // Test 2: Ambiguïté
  console.log('\n┌─────────────────────────────────────────────────────────────┐');
  console.log('│ CAS 2: Parents ambigus (Connector)                         │');
  console.log('└─────────────────────────────────────────────────────────────┘');
  printSuggestions(suggester.suggestParents(CASE_2_AMBIGUOUS.id), CASE_2_AMBIGUOUS);

  // Test 3: Pas de match
  console.log('\n┌─────────────────────────────────────────────────────────────┐');
  console.log('│ CAS 3: Aucune suggestion (QuantumFluxCapacitor)            │');
  console.log('└─────────────────────────────────────────────────────────────┘');
  printSuggestions(suggester.suggestParents(CASE_3_NO_MATCH.id), CASE_3_NO_MATCH);

  // Test 4: Référence cassée
  console.log('\n┌─────────────────────────────────────────────────────────────┐');
  console.log('│ CAS 4: Référence cassée (Widget → parent inexistant)       │');
  console.log('└─────────────────────────────────────────────────────────────┘');
  printSuggestions(suggester.suggestParents(CASE_4_BROKEN_REFERENCE.id), CASE_4_BROKEN_REFERENCE);

  // Test 5: Incohérence
  console.log('\n┌─────────────────────────────────────────────────────────────┐');
  console.log('│ CAS 5: Lineage incohérent (Report)                         │');
  console.log('└─────────────────────────────────────────────────────────────┘');
  printSuggestions(suggester.suggestParents(CASE_5_INCONSISTENT.id), CASE_5_INCONSISTENT);

  // Test global: tous les orphelins
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('                    DÉTECTION GLOBALE DES ORPHELINS');
  console.log('═══════════════════════════════════════════════════════════════\n');
  
  const orphans = suggester.findOrphans();
  console.log(`Orphelins détectés: ${orphans.length}`);
  orphans.forEach(o => {
    console.log(`  • ${o.name} (${o.lineage}) - parentId: ${o.parentId || 'null'}`);
  });

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('                         FIN DES TESTS');
  console.log('═══════════════════════════════════════════════════════════════\n');
}

function printSuggestions(suggestions: ParentSuggestion[], target: FractalObject): void {
  console.log(`\nObjet: "${target.name}" (${target.lineage})`);
  console.log(`Tags: [${target.tags.join(', ')}]`);
  console.log(`Parent actuel: ${target.parentId || 'AUCUN'}\n`);

  if (suggestions.length === 0) {
    console.log('  ⚠️  Aucune suggestion disponible\n');
    return;
  }

  console.log('Suggestions:');
  suggestions.forEach((s, i) => {
    const confidenceIcon = s.confidence === 'high' ? '🟢' : 
                          s.confidence === 'medium' ? '🟡' : '🔴';
    
    console.log(`\n  ${i + 1}. ${s.parentName} (${s.parentLineage})`);
    console.log(`     Score: ${s.score}/100 ${confidenceIcon} [${s.confidence}]`);
    console.log(`     Raisons:`);
    s.reasons.forEach(r => {
      console.log(`       • ${r.criterion}: ${r.detail} (poids: ${r.weight.toFixed(0)})`);
    });
  });
  console.log('');
}

// ============================================================================
// EXPORT POUR INTÉGRATION COCKPIT
// ============================================================================

export interface CockpitSuggestionAPI {
  /** Récupère les suggestions pour un objet */
  getSuggestions(objectId: string): ParentSuggestion[];
  /** Liste tous les orphelins avec leurs suggestions */
  getOrphansWithSuggestions(): Map<string, ParentSuggestion[]>;
  /** Applique une suggestion (avec confirmation) */
  applySuggestion(objectId: string, parentId: string): boolean;
  /** Rejette une suggestion (feedback) */
  rejectSuggestion(objectId: string, parentId: string, reason?: string): void;
}

/**
 * Adaptateur pour l'intégration au cockpit EUREKAI
 */
export class CockpitLineageAdapter implements CockpitSuggestionAPI {
  private suggester: LineageSuggester;
  private rejectedSuggestions: Map<string, Set<string>> = new Map();
  private onApply?: (objectId: string, parentId: string) => void;

  constructor(
    suggester: LineageSuggester,
    onApply?: (objectId: string, parentId: string) => void
  ) {
    this.suggester = suggester;
    this.onApply = onApply;
  }

  getSuggestions(objectId: string): ParentSuggestion[] {
    const suggestions = this.suggester.suggestParents(objectId);
    
    // Filtrer les suggestions rejetées
    const rejected = this.rejectedSuggestions.get(objectId);
    if (rejected) {
      return suggestions.filter(s => !rejected.has(s.parentId));
    }
    
    return suggestions;
  }

  getOrphansWithSuggestions(): Map<string, ParentSuggestion[]> {
    const result = new Map<string, ParentSuggestion[]>();
    const allSuggestions = this.suggester.suggestAllOrphans();
    
    for (const [objectId, suggestions] of allSuggestions) {
      result.set(objectId, this.getSuggestions(objectId));
    }
    
    return result;
  }

  applySuggestion(objectId: string, parentId: string): boolean {
    if (this.onApply) {
      this.onApply(objectId, parentId);
      return true;
    }
    console.warn('⚠️  Aucun handler onApply configuré - suggestion non appliquée');
    return false;
  }

  rejectSuggestion(objectId: string, parentId: string, reason?: string): void {
    if (!this.rejectedSuggestions.has(objectId)) {
      this.rejectedSuggestions.set(objectId, new Set());
    }
    this.rejectedSuggestions.get(objectId)!.add(parentId);
    
    if (reason) {
      console.log(`Suggestion rejetée: ${objectId} → ${parentId} (${reason})`);
    }
  }
}

// Exécuter si appelé directement
if (typeof require !== 'undefined' && require.main === module) {
  runTests();
}
