/**
 * EUREKAI - Lineages Assistés (C1/1)
 * Système de suggestion de parents pour objets orphelins ou incomplets
 * 
 * @author EUREKAI System
 * @version 1.0.0
 */

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

export interface FractalObject {
  id: string;
  name: string;
  lineage: string;           // Ex: "Core:Agent:LLM"
  parentId: string | null;
  depth: number;
  tags: string[];
  bundleId: string | null;
  metadata: Record<string, unknown>;
}

export interface ParentSuggestion {
  parentId: string;
  parentName: string;
  parentLineage: string;
  score: number;             // 0-100
  confidence: 'high' | 'medium' | 'low';
  reasons: SuggestionReason[];
}

export interface SuggestionReason {
  criterion: SuggestionCriterion;
  weight: number;
  detail: string;
}

export type SuggestionCriterion = 
  | 'lineage_prefix'
  | 'semantic_similarity'
  | 'structural_depth'
  | 'shared_tags'
  | 'shared_bundle'
  | 'erk_rule';

export interface SuggesterConfig {
  weights: Record<SuggestionCriterion, number>;
  minScore: number;
  maxSuggestions: number;
  enableERK: boolean;
}

// ============================================================================
// CONFIGURATION PAR DÉFAUT
// ============================================================================

export const DEFAULT_CONFIG: SuggesterConfig = {
  weights: {
    lineage_prefix: 40,
    semantic_similarity: 25,
    structural_depth: 15,
    shared_tags: 10,
    shared_bundle: 5,
    erk_rule: 5
  },
  minScore: 20,
  maxSuggestions: 5,
  enableERK: true
};

// ============================================================================
// CLASSE PRINCIPALE
// ============================================================================

export class LineageSuggester {
  private store: Map<string, FractalObject>;
  private config: SuggesterConfig;
  private erkRules: ERKRule[];

  constructor(
    objects: FractalObject[],
    config: Partial<SuggesterConfig> = {},
    erkRules: ERKRule[] = []
  ) {
    this.store = new Map(objects.map(obj => [obj.id, obj]));
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.erkRules = erkRules;
  }

  // --------------------------------------------------------------------------
  // API PRINCIPALE
  // --------------------------------------------------------------------------

  /**
   * Suggère des parents potentiels pour un objet donné
   * @param objectId - ID de l'objet orphelin ou incomplet
   * @returns Liste de suggestions triées par score décroissant
   */
  suggestParents(objectId: string): ParentSuggestion[] {
    const target = this.store.get(objectId);
    if (!target) {
      return [];
    }

    // Si l'objet a déjà un parent, retourner vide (sauf si forcé)
    if (target.parentId && this.store.has(target.parentId)) {
      return [];
    }

    const candidates = this.findCandidates(target);
    const scored = candidates.map(candidate => this.scoreCandidate(target, candidate));
    
    return scored
      .filter(s => s.score >= this.config.minScore)
      .sort((a, b) => b.score - a.score)
      .slice(0, this.config.maxSuggestions);
  }

  /**
   * Trouve tous les objets orphelins ou avec lineage incomplet
   */
  findOrphans(): FractalObject[] {
    return Array.from(this.store.values()).filter(obj => {
      // Pas de parent déclaré
      if (!obj.parentId) return true;
      // Parent déclaré mais inexistant
      if (!this.store.has(obj.parentId)) return true;
      // Lineage incohérent avec le parent
      const parent = this.store.get(obj.parentId);
      if (parent && !obj.lineage.startsWith(parent.lineage)) return true;
      return false;
    });
  }

  /**
   * Suggère des parents pour tous les orphelins
   */
  suggestAllOrphans(): Map<string, ParentSuggestion[]> {
    const orphans = this.findOrphans();
    const results = new Map<string, ParentSuggestion[]>();
    
    for (const orphan of orphans) {
      const suggestions = this.suggestParents(orphan.id);
      if (suggestions.length > 0) {
        results.set(orphan.id, suggestions);
      }
    }
    
    return results;
  }

  // --------------------------------------------------------------------------
  // DÉTECTION DE CANDIDATS
  // --------------------------------------------------------------------------

  private findCandidates(target: FractalObject): FractalObject[] {
    const candidates: FractalObject[] = [];
    const targetSegments = this.parseLineage(target.lineage);

    for (const [id, obj] of this.store) {
      // Exclure l'objet lui-même
      if (id === target.id) continue;
      
      // Exclure les objets de profondeur >= target (un parent doit être moins profond)
      if (obj.depth >= target.depth) continue;

      // Vérifier si c'est un candidat potentiel
      if (this.isPotentialParent(target, obj, targetSegments)) {
        candidates.push(obj);
      }
    }

    return candidates;
  }

  private isPotentialParent(
    target: FractalObject, 
    candidate: FractalObject,
    targetSegments: string[]
  ): boolean {
    const candidateSegments = this.parseLineage(candidate.lineage);
    
    // Critère 1: Le lineage du candidat est un préfixe du target
    if (this.isPrefix(candidateSegments, targetSegments)) {
      return true;
    }

    // Critère 2: Similarité sémantique suffisante
    if (this.computeSemanticSimilarity(target.name, candidate.name) > 0.3) {
      return true;
    }

    // Critère 3: Tags ou bundle en commun
    if (this.hasCommonTags(target, candidate) || target.bundleId === candidate.bundleId) {
      return true;
    }

    return false;
  }

  // --------------------------------------------------------------------------
  // SCORING
  // --------------------------------------------------------------------------

  private scoreCandidate(target: FractalObject, candidate: FractalObject): ParentSuggestion {
    const reasons: SuggestionReason[] = [];
    let totalScore = 0;

    // 1. Score de préfixe de lineage
    const prefixScore = this.scorePrefixMatch(target, candidate);
    if (prefixScore > 0) {
      totalScore += prefixScore * (this.config.weights.lineage_prefix / 100);
      reasons.push({
        criterion: 'lineage_prefix',
        weight: prefixScore,
        detail: `Lineage "${candidate.lineage}" est préfixe de "${target.lineage}"`
      });
    }

    // 2. Score de similarité sémantique
    const semanticScore = this.computeSemanticSimilarity(target.name, candidate.name) * 100;
    if (semanticScore > 0) {
      totalScore += semanticScore * (this.config.weights.semantic_similarity / 100);
      reasons.push({
        criterion: 'semantic_similarity',
        weight: semanticScore,
        detail: `Similarité de nom: ${semanticScore.toFixed(0)}%`
      });
    }

    // 3. Score de profondeur structurelle
    const depthScore = this.scoreDepthMatch(target, candidate);
    if (depthScore > 0) {
      totalScore += depthScore * (this.config.weights.structural_depth / 100);
      reasons.push({
        criterion: 'structural_depth',
        weight: depthScore,
        detail: `Profondeur parent (${candidate.depth}) = enfant (${target.depth}) - 1`
      });
    }

    // 4. Score de tags partagés
    const tagScore = this.scoreSharedTags(target, candidate);
    if (tagScore > 0) {
      totalScore += tagScore * (this.config.weights.shared_tags / 100);
      reasons.push({
        criterion: 'shared_tags',
        weight: tagScore,
        detail: `${this.countCommonTags(target, candidate)} tag(s) en commun`
      });
    }

    // 5. Score de bundle partagé
    if (target.bundleId && target.bundleId === candidate.bundleId) {
      const bundleScore = 80;
      totalScore += bundleScore * (this.config.weights.shared_bundle / 100);
      reasons.push({
        criterion: 'shared_bundle',
        weight: bundleScore,
        detail: `Même bundle: ${target.bundleId}`
      });
    }

    // 6. Score ERK (si activé)
    if (this.config.enableERK) {
      const erkScore = this.scoreERKRules(target, candidate);
      if (erkScore > 0) {
        totalScore += erkScore * (this.config.weights.erk_rule / 100);
        reasons.push({
          criterion: 'erk_rule',
          weight: erkScore,
          detail: `Règle ERK applicable`
        });
      }
    }

    // Normaliser le score
    const normalizedScore = Math.min(100, Math.round(totalScore));

    return {
      parentId: candidate.id,
      parentName: candidate.name,
      parentLineage: candidate.lineage,
      score: normalizedScore,
      confidence: this.getConfidence(normalizedScore),
      reasons
    };
  }

  // --------------------------------------------------------------------------
  // FONCTIONS DE SCORING SPÉCIFIQUES
  // --------------------------------------------------------------------------

  private scorePrefixMatch(target: FractalObject, candidate: FractalObject): number {
    const targetSegments = this.parseLineage(target.lineage);
    const candidateSegments = this.parseLineage(candidate.lineage);

    if (!this.isPrefix(candidateSegments, targetSegments)) {
      return 0;
    }

    // Plus le préfixe est long (proche), plus le score est élevé
    const prefixLength = candidateSegments.length;
    const targetLength = targetSegments.length;
    
    // Parent direct (N-1) = score max
    if (prefixLength === targetLength - 1) {
      return 100;
    }
    
    // Ancêtre plus éloigné = score dégressif
    return Math.max(20, 100 - (targetLength - prefixLength - 1) * 25);
  }

  private scoreDepthMatch(target: FractalObject, candidate: FractalObject): number {
    const depthDiff = target.depth - candidate.depth;
    
    if (depthDiff === 1) return 100;  // Parent direct
    if (depthDiff === 2) return 60;   // Grand-parent
    if (depthDiff > 2) return 30;     // Ancêtre éloigné
    
    return 0; // Même profondeur ou candidat plus profond
  }

  private scoreSharedTags(target: FractalObject, candidate: FractalObject): number {
    const common = this.countCommonTags(target, candidate);
    if (common === 0) return 0;
    
    const maxTags = Math.max(target.tags.length, candidate.tags.length);
    return Math.round((common / maxTags) * 100);
  }

  private scoreERKRules(target: FractalObject, candidate: FractalObject): number {
    // Vérifier si une règle ERK suggère cette relation parent-enfant
    for (const rule of this.erkRules) {
      if (rule.matches(target, candidate)) {
        return rule.confidence;
      }
    }
    return 0;
  }

  // --------------------------------------------------------------------------
  // UTILITAIRES
  // --------------------------------------------------------------------------

  private parseLineage(lineage: string): string[] {
    return lineage.split(':').filter(s => s.length > 0);
  }

  private isPrefix(prefix: string[], full: string[]): boolean {
    if (prefix.length >= full.length) return false;
    return prefix.every((seg, i) => seg === full[i]);
  }

  private computeSemanticSimilarity(a: string, b: string): number {
    // Normaliser les noms
    const na = a.toLowerCase().replace(/[^a-z0-9]/g, '');
    const nb = b.toLowerCase().replace(/[^a-z0-9]/g, '');

    // Similarité de Jaccard sur les tokens
    const tokensA = new Set(na.match(/[a-z]+/g) || []);
    const tokensB = new Set(nb.match(/[a-z]+/g) || []);
    
    const intersection = new Set([...tokensA].filter(t => tokensB.has(t)));
    const union = new Set([...tokensA, ...tokensB]);
    
    if (union.size === 0) return 0;
    
    const jaccard = intersection.size / union.size;

    // Bonus si l'un est sous-chaîne de l'autre
    const substringBonus = (na.includes(nb) || nb.includes(na)) ? 0.2 : 0;

    return Math.min(1, jaccard + substringBonus);
  }

  private hasCommonTags(a: FractalObject, b: FractalObject): boolean {
    return a.tags.some(t => b.tags.includes(t));
  }

  private countCommonTags(a: FractalObject, b: FractalObject): number {
    return a.tags.filter(t => b.tags.includes(t)).length;
  }

  private getConfidence(score: number): 'high' | 'medium' | 'low' {
    if (score >= 70) return 'high';
    if (score >= 40) return 'medium';
    return 'low';
  }
}

// ============================================================================
// INTERFACE ERK (PLACEHOLDER)
// ============================================================================

export interface ERKRule {
  id: string;
  name: string;
  confidence: number;
  matches(target: FractalObject, candidate: FractalObject): boolean;
}

// Règle ERK exemple: les objets "LLM" héritent de "Agent"
export const ERK_RULE_LLM_AGENT: ERKRule = {
  id: 'erk-llm-agent',
  name: 'LLM hérite de Agent',
  confidence: 90,
  matches(target, candidate) {
    return target.name.includes('LLM') && 
           candidate.lineage.endsWith('Agent');
  }
};

// Règle ERK exemple: les objets "Project" héritent de leur domaine
export const ERK_RULE_PROJECT_DOMAIN: ERKRule = {
  id: 'erk-project-domain',
  name: 'Project hérite du domaine',
  confidence: 80,
  matches(target, candidate) {
    if (!target.lineage.includes('Project')) return false;
    const targetDomain = target.lineage.split(':')[0];
    return candidate.lineage.startsWith(targetDomain) && 
           candidate.depth === target.depth - 1;
  }
};
