/**
 * EUREKAI - Lineages Assistés (C1/1)
 * Script de démonstration
 * 
 * Exécuter: node demo.js
 */

// ============================================================================
// CONFIGURATION
// ============================================================================

const DEFAULT_CONFIG = {
  weights: {
    lineage_prefix: 40,
    semantic_similarity: 25,
    structural_depth: 15,
    shared_tags: 10,
    shared_bundle: 5,
    erk_rule: 5
  },
  minScore: 15,
  maxSuggestions: 5,
  enableERK: true
};

// ============================================================================
// LINEAGE SUGGESTER (VERSION SIMPLIFIÉE)
// ============================================================================

class LineageSuggester {
  constructor(objects, config = {}, erkRules = []) {
    this.store = new Map(objects.map(obj => [obj.id, obj]));
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.erkRules = erkRules;
  }

  suggestParents(objectId) {
    const target = this.store.get(objectId);
    if (!target) return [];

    if (target.parentId && this.store.has(target.parentId)) {
      return [];
    }

    const candidates = this.findCandidates(target);
    const scored = candidates.map(c => this.scoreCandidate(target, c));
    
    return scored
      .filter(s => s.score >= this.config.minScore)
      .sort((a, b) => b.score - a.score)
      .slice(0, this.config.maxSuggestions);
  }

  findOrphans() {
    return Array.from(this.store.values()).filter(obj => {
      if (!obj.parentId) return true;
      if (!this.store.has(obj.parentId)) return true;
      const parent = this.store.get(obj.parentId);
      if (parent && !obj.lineage.startsWith(parent.lineage)) return true;
      return false;
    });
  }

  findCandidates(target) {
    const candidates = [];
    const targetSegments = this.parseLineage(target.lineage);

    for (const [id, obj] of this.store) {
      if (id === target.id) continue;
      if (obj.depth >= target.depth) continue;

      if (this.isPotentialParent(target, obj, targetSegments)) {
        candidates.push(obj);
      }
    }
    return candidates;
  }

  isPotentialParent(target, candidate, targetSegments) {
    const candidateSegments = this.parseLineage(candidate.lineage);
    
    if (this.isPrefix(candidateSegments, targetSegments)) return true;
    if (this.computeSemanticSimilarity(target.name, candidate.name) > 0.3) return true;
    if (this.hasCommonTags(target, candidate)) return true;
    if (target.bundleId && target.bundleId === candidate.bundleId) return true;
    
    return false;
  }

  scoreCandidate(target, candidate) {
    const reasons = [];
    let totalScore = 0;

    // 1. Préfixe de lineage
    const prefixScore = this.scorePrefixMatch(target, candidate);
    if (prefixScore > 0) {
      totalScore += prefixScore * (this.config.weights.lineage_prefix / 100);
      reasons.push({
        criterion: 'lineage_prefix',
        weight: prefixScore,
        detail: `"${candidate.lineage}" est préfixe de "${target.lineage}"`
      });
    }

    // 2. Similarité sémantique
    const semanticScore = this.computeSemanticSimilarity(target.name, candidate.name) * 100;
    if (semanticScore > 0) {
      totalScore += semanticScore * (this.config.weights.semantic_similarity / 100);
      reasons.push({
        criterion: 'semantic_similarity',
        weight: semanticScore,
        detail: `Similarité de nom: ${semanticScore.toFixed(0)}%`
      });
    }

    // 3. Profondeur
    const depthScore = this.scoreDepthMatch(target, candidate);
    if (depthScore > 0) {
      totalScore += depthScore * (this.config.weights.structural_depth / 100);
      reasons.push({
        criterion: 'structural_depth',
        weight: depthScore,
        detail: `Profondeur parent (${candidate.depth}) = enfant (${target.depth}) - 1`
      });
    }

    // 4. Tags partagés
    const tagScore = this.scoreSharedTags(target, candidate);
    if (tagScore > 0) {
      totalScore += tagScore * (this.config.weights.shared_tags / 100);
      const commonCount = this.countCommonTags(target, candidate);
      reasons.push({
        criterion: 'shared_tags',
        weight: tagScore,
        detail: `${commonCount} tag(s) en commun`
      });
    }

    // 5. Bundle partagé
    if (target.bundleId && target.bundleId === candidate.bundleId) {
      const bundleScore = 80;
      totalScore += bundleScore * (this.config.weights.shared_bundle / 100);
      reasons.push({
        criterion: 'shared_bundle',
        weight: bundleScore,
        detail: `Même bundle: ${target.bundleId}`
      });
    }

    // 6. ERK
    for (const rule of this.erkRules) {
      if (rule.matches(target, candidate)) {
        const erkScore = rule.confidence;
        totalScore += erkScore * (this.config.weights.erk_rule / 100);
        reasons.push({
          criterion: 'erk_rule',
          weight: erkScore,
          detail: `Règle "${rule.name}" applicable`
        });
        break;
      }
    }

    const normalizedScore = Math.min(100, Math.round(totalScore));

    return {
      parentId: candidate.id,
      parentName: candidate.name,
      parentLineage: candidate.lineage,
      score: normalizedScore,
      confidence: normalizedScore >= 70 ? 'high' : normalizedScore >= 40 ? 'medium' : 'low',
      reasons
    };
  }

  // Utilitaires
  parseLineage(lineage) {
    return lineage.split(':').filter(s => s.length > 0);
  }

  isPrefix(prefix, full) {
    if (prefix.length >= full.length) return false;
    return prefix.every((seg, i) => seg === full[i]);
  }

  scorePrefixMatch(target, candidate) {
    const targetSegments = this.parseLineage(target.lineage);
    const candidateSegments = this.parseLineage(candidate.lineage);
    if (!this.isPrefix(candidateSegments, targetSegments)) return 0;
    
    const prefixLength = candidateSegments.length;
    const targetLength = targetSegments.length;
    if (prefixLength === targetLength - 1) return 100;
    return Math.max(20, 100 - (targetLength - prefixLength - 1) * 25);
  }

  scoreDepthMatch(target, candidate) {
    const diff = target.depth - candidate.depth;
    if (diff === 1) return 100;
    if (diff === 2) return 60;
    if (diff > 2) return 30;
    return 0;
  }

  scoreSharedTags(target, candidate) {
    const common = this.countCommonTags(target, candidate);
    if (common === 0) return 0;
    const max = Math.max(target.tags.length, candidate.tags.length);
    return Math.round((common / max) * 100);
  }

  computeSemanticSimilarity(a, b) {
    const na = a.toLowerCase().replace(/[^a-z0-9]/g, '');
    const nb = b.toLowerCase().replace(/[^a-z0-9]/g, '');
    
    const tokensA = new Set((na.match(/[a-z]+/g) || []));
    const tokensB = new Set((nb.match(/[a-z]+/g) || []));
    
    const intersection = [...tokensA].filter(t => tokensB.has(t));
    const union = new Set([...tokensA, ...tokensB]);
    
    if (union.size === 0) return 0;
    const jaccard = intersection.length / union.size;
    const substringBonus = (na.includes(nb) || nb.includes(na)) ? 0.2 : 0;
    
    return Math.min(1, jaccard + substringBonus);
  }

  hasCommonTags(a, b) {
    return a.tags.some(t => b.tags.includes(t));
  }

  countCommonTags(a, b) {
    return a.tags.filter(t => b.tags.includes(t)).length;
  }
}

// ============================================================================
// DONNÉES DE TEST
// ============================================================================

const TEST_OBJECTS = [
  // Racines (niveau 0)
  { id: 'root-core', name: 'Core', lineage: 'Core', parentId: null, depth: 0, 
    tags: ['system', 'foundation'], bundleId: 'core-bundle' },
  { id: 'root-agency', name: 'Agency', lineage: 'Agency', parentId: null, depth: 0, 
    tags: ['domain', 'business'], bundleId: 'agency-bundle' },
  { id: 'root-infra', name: 'Infrastructure', lineage: 'Infrastructure', parentId: null, depth: 0, 
    tags: ['system', 'technical'], bundleId: 'infra-bundle' },

  // Niveau 1 - Core
  { id: 'core-agent', name: 'Agent', lineage: 'Core:Agent', parentId: 'root-core', depth: 1, 
    tags: ['system', 'actor'], bundleId: 'core-bundle' },
  { id: 'core-object', name: 'Object', lineage: 'Core:Object', parentId: 'root-core', depth: 1, 
    tags: ['system', 'entity'], bundleId: 'core-bundle' },

  // Niveau 2 - Core:Agent
  { id: 'agent-llm', name: 'LLM', lineage: 'Core:Agent:LLM', parentId: 'core-agent', depth: 2, 
    tags: ['system', 'actor', 'ai'], bundleId: 'core-bundle' },
  { id: 'agent-human', name: 'Human', lineage: 'Core:Agent:Human', parentId: 'core-agent', depth: 2, 
    tags: ['system', 'actor', 'user'], bundleId: 'core-bundle' },

  // Niveau 1 - Agency
  { id: 'agency-project', name: 'Project', lineage: 'Agency:Project', parentId: 'root-agency', depth: 1, 
    tags: ['domain', 'work'], bundleId: 'agency-bundle' },
  { id: 'agency-client', name: 'Client', lineage: 'Agency:Client', parentId: 'root-agency', depth: 1, 
    tags: ['domain', 'contact'], bundleId: 'agency-bundle' },

  // Niveau 2 - Agency:Project
  { id: 'project-blog', name: 'Blog', lineage: 'Agency:Project:Blog', parentId: 'agency-project', depth: 2, 
    tags: ['domain', 'work', 'content'], bundleId: 'agency-bundle' }
];

// Cas de test
const ORPHAN_CLAUDE = {
  id: 'orphan-claude', name: 'Claude', lineage: 'Core:Agent:LLM:Claude', parentId: null, depth: 3,
  tags: ['system', 'actor', 'ai', 'anthropic'], bundleId: 'core-bundle'
};

const ORPHAN_AMBIGUOUS = {
  id: 'orphan-connector', name: 'Connector', lineage: 'Connector', parentId: null, depth: 1,
  tags: ['system', 'technical'], bundleId: null
};

const ORPHAN_NO_MATCH = {
  id: 'orphan-exotic', name: 'QuantumFluxCapacitor', lineage: 'Experimental:Quantum:Flux', 
  parentId: null, depth: 2, tags: ['experimental', 'research'], bundleId: null
};

const ORPHAN_BROKEN = {
  id: 'orphan-broken', name: 'Widget', lineage: 'Core:UI:Widget', parentId: 'non-existent-ui', 
  depth: 2, tags: ['system', 'ui'], bundleId: 'core-bundle'
};

const ORPHAN_INCONSISTENT = {
  id: 'orphan-inconsistent', name: 'Report', lineage: 'Agency:Project:Report', parentId: 'root-core',
  depth: 2, tags: ['domain', 'document'], bundleId: 'agency-bundle'
};

// Règles ERK
const ERK_RULES = [
  {
    id: 'erk-llm-agent',
    name: 'LLM hérite de Agent',
    confidence: 90,
    matches: (target, candidate) => 
      target.name.includes('LLM') && candidate.lineage.endsWith('Agent')
  },
  {
    id: 'erk-project-domain',
    name: 'Project hérite du domaine',
    confidence: 80,
    matches: (target, candidate) => {
      if (!target.lineage.includes('Project')) return false;
      const targetDomain = target.lineage.split(':')[0];
      return candidate.lineage.startsWith(targetDomain) && candidate.depth === target.depth - 1;
    }
  }
];

// ============================================================================
// EXÉCUTION DES TESTS
// ============================================================================

function printHeader(title) {
  console.log('\n' + '═'.repeat(70));
  console.log(`  ${title}`);
  console.log('═'.repeat(70));
}

function printSection(title) {
  console.log('\n┌' + '─'.repeat(68) + '┐');
  console.log('│ ' + title.padEnd(67) + '│');
  console.log('└' + '─'.repeat(68) + '┘');
}

function printSuggestions(suggestions, target) {
  console.log(`\nObjet: "${target.name}" (${target.lineage})`);
  console.log(`Tags: [${target.tags.join(', ')}]`);
  console.log(`Parent actuel: ${target.parentId || 'AUCUN'}\n`);

  if (suggestions.length === 0) {
    console.log('  ⚠️  Aucune suggestion disponible\n');
    return;
  }

  console.log('Suggestions:');
  suggestions.forEach((s, i) => {
    const icon = s.confidence === 'high' ? '🟢' : s.confidence === 'medium' ? '🟡' : '🔴';
    
    console.log(`\n  ${i + 1}. ${s.parentName} (${s.parentLineage})`);
    console.log(`     Score: ${s.score}/100 ${icon} [${s.confidence}]`);
    console.log(`     Raisons:`);
    s.reasons.forEach(r => {
      console.log(`       • ${r.criterion}: ${r.detail} (${r.weight.toFixed(0)}%)`);
    });
  });
}

// Main
function main() {
  printHeader('EUREKAI - Lineages Assistés - Démonstration C1/1');

  const allObjects = [
    ...TEST_OBJECTS,
    ORPHAN_CLAUDE,
    ORPHAN_AMBIGUOUS,
    ORPHAN_NO_MATCH,
    ORPHAN_BROKEN,
    ORPHAN_INCONSISTENT
  ];

  const suggester = new LineageSuggester(allObjects, { minScore: 15 }, ERK_RULES);

  // Cas 1
  printSection('CAS 1: Parent évident (Claude → Core:Agent:LLM)');
  printSuggestions(suggester.suggestParents('orphan-claude'), ORPHAN_CLAUDE);

  // Cas 2
  printSection('CAS 2: Parents ambigus (Connector)');
  printSuggestions(suggester.suggestParents('orphan-connector'), ORPHAN_AMBIGUOUS);

  // Cas 3
  printSection('CAS 3: Aucune suggestion (QuantumFluxCapacitor)');
  printSuggestions(suggester.suggestParents('orphan-exotic'), ORPHAN_NO_MATCH);

  // Cas 4
  printSection('CAS 4: Référence cassée (Widget → parent inexistant)');
  printSuggestions(suggester.suggestParents('orphan-broken'), ORPHAN_BROKEN);

  // Cas 5
  printSection('CAS 5: Lineage incohérent (Report)');
  printSuggestions(suggester.suggestParents('orphan-inconsistent'), ORPHAN_INCONSISTENT);

  // Détection globale
  printHeader('DÉTECTION GLOBALE DES ORPHELINS');
  
  const orphans = suggester.findOrphans();
  console.log(`\nOrphelins détectés: ${orphans.length}`);
  orphans.forEach(o => {
    console.log(`  • ${o.name} (${o.lineage}) - parentId: ${o.parentId || 'null'}`);
  });

  // Résumé
  printHeader('CHECKLIST DE VALIDATION');
  console.log(`
  [✓] Pour tout objet sans parent clair, le système fournit 0, 1 ou plusieurs suggestions
  [✓] Les suggestions sont accompagnées de scores et de raisons
  [✓] Aucun changement n'est fait à la fractale sans validation explicite
  [✓] Exemples fournis: parent évident, ambigu, aucun match, référence cassée, incohérent
  `);

  printHeader('FIN DE LA DÉMONSTRATION');
}

main();
