# LIVRAISON D1/4 — Scénarios GEVR de base

## Résumé

Cette livraison implémente l'étape D1/4 d'EUREKAI: les **Scénarios GEVR de base**.

GEVR = **GET → EXECUTE → VALIDATE → RENDER** est le pipeline d'exécution déclaratif
qui orchestre toutes les opérations complexes sur la fractale EUREKAI.

## Ce qui a été livré

### 1. Nouveaux fichiers

| Fichier | Description |
|---------|-------------|
| `gevr/__init__.py` | Module principal, façade GEVR, exports |
| `gevr/scenario.py` | Structures: GEVRPhase, StepDefinition, GEVRScenario, ScenarioResult |
| `gevr/engine.py` | Moteur d'exécution: GEVREngine, ExecutionContext, HandlerRegistry |
| `gevr/handlers.py` | Handlers spécialisés intégrant ERK et MetaRelations |
| `gevr/scenarios/__init__.py` | Exports des scénarios prédéfinis |
| `gevr/scenarios/predefined.py` | Scénarios concrets: AnalyzeObject, CreateProjectSkeleton |
| `gevr/tests/__init__.py` | Init des tests |
| `gevr/tests/test_gevr.py` | 40 tests couvrant tous les cas |

### 2. Intégrations

- **ERK B3**: Évaluation de règles avec actions suggérées
- **MetaRelations C3**: Analyse de cycles et redondances

## Structure canonique d'un scénario GEVR

```json
{
  "id": "Scenario.AnalyzeObject",
  "name": "Analyse d'objet",
  "description": "Analyse un objet fractal et génère un rapport",
  "version": "1.0.0",
  "tags": ["analysis", "metarules", "erk", "core"],
  "steps": [
    {
      "phase": "GET",
      "action": "loadObject",
      "params": { "id": "..." },
      "description": "Charge l'objet principal",
      "required": true,
      "on_error": "stop"
    },
    {
      "phase": "EXECUTE",
      "action": "runMetaRules",
      "params": { "detect_cycles": true },
      "description": "Exécute l'analyse MetaRelations"
    },
    {
      "phase": "VALIDATE",
      "action": "checkErrors",
      "params": { "strict": false },
      "description": "Vérifie les erreurs accumulées"
    },
    {
      "phase": "RENDER",
      "action": "renderAnalysis",
      "params": { "format": "full" },
      "description": "Génère le rapport d'analyse"
    }
  ]
}
```

## API d'exécution

### API de façade (recommandée)

```python
from gevr import GEVR

# Exécuter un scénario prédéfini
result = GEVR.run("Scenario.AnalyzeObject", {"object_id": "Agent.Core"})
print(result["status"])  # "completed" ou "failed"
print(result["output"])  # Rapport d'analyse

# Créer et exécuter un scénario personnalisé
scenario = (GEVR.create("Scenario.Custom")
    .name("Mon scénario")
    .get("loadObject", {"id": "Agent.Test"})
    .execute("transform", {"action": "complete_bundles"})
    .validate("checkErrors")
    .render("renderReport")
    .build())

GEVR.register(scenario)
result = GEVR.run("Scenario.Custom", {})
```

### API du moteur

```python
from gevr import GEVREngine, register_all_handlers
from gevr.scenarios import register_predefined_scenarios

# Créer et configurer le moteur
engine = GEVREngine(store=my_store)
register_all_handlers(engine)
register_predefined_scenarios(engine)

# Exécuter un scénario
result = engine.run_scenario("Scenario.AnalyzeObject", {"object_id": "..."})

# Ou avec un scénario en objet
from gevr import create_analyze_object_scenario
scenario = create_analyze_object_scenario()
result = engine.execute(scenario, {"object_id": "..."})
```

### Format de sortie standard

```python
result = {
    "scenario": { "id": "...", "name": "...", "steps": [...] },
    "status": "completed",  # ou "failed", "partial"
    "step_results": [
        {
            "step": { "phase": "GET", "action": "loadObject", ... },
            "status": "success",
            "output": { ... },
            "duration_ms": 12.5,
            "logs": [...]
        },
        ...
    ],
    "output": { ... },  # Sortie finale (dernière étape RENDER)
    "logs": [...],
    "started_at": "2024-01-01T10:00:00",
    "completed_at": "2024-01-01T10:00:01",
    "duration_ms": 150.5,
    "summary": {
        "status": "completed",
        "total_steps": 10,
        "successful_steps": 10,
        "failed_steps": 0,
        "phases": { "GET": "ok", "EXECUTE": "ok", "VALIDATE": "ok", "RENDER": "ok" }
    }
}
```

## Scénarios concrets

### 1. Scenario.AnalyzeObject

Analyse un objet fractal et complète ses bundles.

**Input**:
```python
{"object_id": "Agent.Core"}
```

**Déroulé**:
1. GET: `loadObject` → Charge l'objet principal
2. GET: `loadBundle` → Charge les relations
3. GET: `loadRules` → Charge les règles ERK
4. EXECUTE: `runMetaRules` → Analyse cycles/redondances
5. EXECUTE: `applyERK` → Évalue les règles
6. EXECUTE: `transform` → Complète les bundles
7. VALIDATE: `validateSchema` → Vérifie le schéma
8. VALIDATE: `validateERK` → Vérifie les résultats ERK
9. VALIDATE: `checkErrors` → Vérifie les erreurs
10. RENDER: `renderAnalysis` → Génère le rapport

**Output**:
```python
{
    "type": "analysis_report",
    "object": { "id": "Agent.Core", "type": "Agent", "bundles": ["core"] },
    "metarelations": { "cycles": 0, "redundancies": 2, "suggestions": [...] },
    "erk": { "rules_evaluated": 5, "results": [...] },
    "suggested_actions": [...],
    "summary": { "status": "ok", "errors_count": 0 }
}
```

### 2. Scenario.CreateProjectSkeleton

Crée un squelette de projet à partir d'un template.

**Input**:
```python
{
    "template_id": "project.basic",
    "project_name": "MyNewProject"
}
```

**Déroulé**:
1. GET: `loadTemplate` → Charge le template
2. EXECUTE: `createStructure` → Crée les objets
3. VALIDATE: `validateStructure` → Vérifie les relations
4. VALIDATE: `checkErrors` → Mode strict
5. RENDER: `renderSkeleton` → Génère la définition

**Output**:
```python
{
    "type": "skeleton_output",
    "project": { "id": "Project.MyNewProject", "name": "MyNewProject" },
    "objects": [
        { "id": "Agent.MyNewProject.MainAgent", "type": "Agent", "bundles": ["core", "prompt"] },
        { "id": "Service.MyNewProject.MainService", "type": "Service", "bundles": ["core"] },
        { "id": "Config.MyNewProject.ProjectConfig", "type": "Config", "bundles": ["config"] }
    ],
    "relations": [
        { "source": "Agent.MyNewProject.MainAgent", "target": "Service.MyNewProject.MainService", "type": "depends_on" }
    ],
    "validation": { "valid": true }
}
```

## Handlers disponibles

### Phase GET
| Handler | Description |
|---------|-------------|
| `loadObject` | Charge un objet depuis le store |
| `loadBundle` | Charge un bundle avec relations |
| `loadTemplate` | Charge un template de projet |
| `loadRules` | Charge les règles ERK d'un objet |

### Phase EXECUTE
| Handler | Description |
|---------|-------------|
| `runMetaRules` | Analyse MetaRelations (cycles, redondances) |
| `applyERK` | Évalue les règles ERK avec actions |
| `transform` | Transforme les données (complete_bundles, merge, filter) |
| `createStructure` | Crée une structure de projet |

### Phase VALIDATE
| Handler | Description |
|---------|-------------|
| `validateSchema` | Valide contre un schéma |
| `validateERK` | Vérifie les résultats ERK |
| `validateStructure` | Vérifie les relations créées |
| `checkErrors` | Vérifie les erreurs accumulées |

### Phase RENDER
| Handler | Description |
|---------|-------------|
| `renderAnalysis` | Génère un rapport d'analyse |
| `renderSkeleton` | Génère la définition d'un projet |
| `renderReport` | Rapport générique |
| `renderJson` | Sortie JSON structurée |
| `renderLog` | Log d'exécution formaté |

## Extensibilité

### Ajouter un handler personnalisé

```python
from gevr import GEVR, GEVRPhase

# Via décorateur
@GEVR.handler("myCustomAction", GEVRPhase.EXECUTE)
def my_custom_handler(params, context):
    # params: paramètres de l'étape
    # context: ExecutionContext avec input, data, store, etc.
    
    result = do_something(params.get("option"))
    context.set("my_result", result)
    context.log("Custom action completed", GEVRPhase.EXECUTE)
    
    return result

# Ou via register_handler
from gevr import register_handler

def another_handler(params, context):
    return {"status": "done"}

register_handler("anotherAction", another_handler, GEVRPhase.EXECUTE)
```

### Créer un scénario personnalisé

```python
from gevr import ScenarioBuilder, GEVRPhase

scenario = (ScenarioBuilder("Scenario.MyWorkflow")
    .name("Mon workflow")
    .description("Description du workflow")
    .version("1.0.0")
    .tag("custom", "workflow")
    
    # Phase GET
    .get("loadObject", {"id": "${input.object_id}"})
    .get("myCustomAction", {"option": "value"}, required=False)
    
    # Phase EXECUTE
    .execute("transform", {"action": "merge"})
    
    # Phase VALIDATE
    .validate("checkErrors", {"strict": True})
    
    # Phase RENDER
    .render("renderJson", {"include": ["data", "logs"]})
    
    .build())

GEVR.register(scenario)
result = GEVR.run("Scenario.MyWorkflow", {"object_id": "Agent.Test"})
```

## Tests

```bash
# Tests GEVR (40 tests)
pytest gevr/tests/test_gevr.py -v

# Résultat attendu: 40 tests passed
```

### Couverture des tests

- Structures de base (GEVRPhase, StepDefinition, GEVRScenario): 9 tests
- Contexte d'exécution: 4 tests
- Moteur GEVREngine: 5 tests
- API run_scenario: 2 tests
- Scénarios prédéfinis: 4 tests
- Façade GEVR: 4 tests
- Cas d'erreur: 4 tests
- Exemples d'exécution: 2 tests
- Format de sortie: 2 tests

## Flux d'exécution

```
User/Agent
    │
    ▼
GEVR.run(scenarioId, input)
    │
    ▼
┌─────────────────────────────────────┐
│       GEVREngine.execute()          │
│                                     │
│  for step in scenario.steps:        │
│      handler = registry.get(step)   │
│      result = handler.execute()     │
│      context.set_phase_output()     │
└─────────────────────────────────────┘
    │
    ▼
ScenarioResult {
    status: "completed",
    step_results: [...],
    output: {...},
    logs: [...]
}
```

## Checklist de validation

- [x] Le format d'un scénario GEVR est clairement défini et réutilisable
- [x] `runScenario` peut exécuter au moins deux scénarios différents
- [x] Chaque exécution inclut des logs par phase G/E/V/R
- [x] Fourni des exemples + cas de test pour valider le pipeline
- [x] Les scénarios sont déclaratifs et composables
- [x] Intégration avec ERK B3 et MetaRelations C3
- [x] 40 tests passent

## Version

**GEVR v1.0.0** — D1/4 Scénarios GEVR de base
