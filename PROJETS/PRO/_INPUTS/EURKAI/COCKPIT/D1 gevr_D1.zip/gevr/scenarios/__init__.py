"""
EUREKAI D1/4 — Scénarios prédéfinis
====================================

Exports des scénarios GEVR prédéfinis.
"""

from .predefined import (
    create_analyze_object_scenario,
    create_project_skeleton_scenario,
    create_minimal_scenario,
    get_predefined_scenarios,
    register_predefined_scenarios,
    ANALYZE_OBJECT_JSON,
    CREATE_PROJECT_SKELETON_JSON
)

__all__ = [
    'create_analyze_object_scenario',
    'create_project_skeleton_scenario',
    'create_minimal_scenario',
    'get_predefined_scenarios',
    'register_predefined_scenarios',
    'ANALYZE_OBJECT_JSON',
    'CREATE_PROJECT_SKELETON_JSON'
]
