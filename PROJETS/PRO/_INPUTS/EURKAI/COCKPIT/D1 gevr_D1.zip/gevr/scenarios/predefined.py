"""
EUREKAI D1/4 — Scénarios GEVR prédéfinis
=========================================

Ce module définit les scénarios GEVR concrets demandés:
1. Scenario.AnalyzeObject - Analyse un objet et complète ses bundles
2. Scenario.CreateProjectSkeleton - Crée un squelette de projet

Chaque scénario suit le pipeline GEVR complet:
GET → EXECUTE → VALIDATE → RENDER

Version: D1/4 - Scénarios GEVR de base
"""

from __future__ import annotations
from typing import Dict, Any

from ..scenario import (
    GEVRScenario, GEVRPhase, StepDefinition,
    ScenarioBuilder, create_scenario
)


# =============================================================================
# SCENARIO.ANALYZEOBJECT
# =============================================================================

def create_analyze_object_scenario() -> GEVRScenario:
    """
    Crée le scénario Scenario.AnalyzeObject.
    
    Ce scénario:
    1. GET: Charge l'objet et ses relations
    2. EXECUTE: Exécute les MetaRules et ERK
    3. VALIDATE: Vérifie la cohérence
    4. RENDER: Produit un rapport d'analyse
    
    Input attendu:
        - object_id: ID de l'objet à analyser
        - options: Options d'analyse (optionnel)
    
    Output:
        - Rapport d'analyse avec cycles, redondances, actions suggérées
    """
    return (ScenarioBuilder("Scenario.AnalyzeObject")
        .name("Analyse d'objet")
        .description(
            "Analyse un objet fractal: charge ses données, "
            "exécute les MetaRules pour détecter les problèmes de structure, "
            "applique les règles ERK, et génère un rapport complet."
        )
        .version("1.0.0")
        .tag("analysis", "metarules", "erk", "core")
        
        # Phase GET: Charger l'objet et son bundle
        .get(
            "loadObject",
            {"id": "${input.object_id}"},
            description="Charge l'objet principal"
        )
        .get(
            "loadBundle",
            {
                "id": "${input.object_id}",
                "include_relations": True,
                "depth": 1
            },
            description="Charge le bundle avec relations"
        )
        .get(
            "loadRules",
            {"object_id": "${input.object_id}"},
            description="Charge les règles ERK de l'objet"
        )
        
        # Phase EXECUTE: Analyser et transformer
        .execute(
            "runMetaRules",
            {
                "detect_cycles": True,
                "detect_redundancies": True,
                "generate_suggestions": True
            },
            description="Exécute l'analyse MetaRelations"
        )
        .execute(
            "applyERK",
            {
                "object_id": "${input.object_id}",
                "collect_actions": True
            },
            description="Évalue les règles ERK",
            required=False  # Ne pas bloquer si ERK échoue
        )
        .execute(
            "transform",
            {
                "action": "complete_bundles",
                "target": "object",
                "options": {"required_bundles": ["core"]}
            },
            description="Complète les bundles manquants",
            required=False
        )
        
        # Phase VALIDATE: Vérifier la cohérence
        .validate(
            "validateSchema",
            {
                "target": "object",
                "strict": False
            },
            description="Valide le schéma de l'objet"
        )
        .validate(
            "validateERK",
            {
                "fail_on_deny": False,
                "validate_actions": True
            },
            description="Valide les résultats ERK",
            required=False
        )
        .validate(
            "checkErrors",
            {"strict": False},
            description="Vérifie les erreurs accumulées"
        )
        
        # Phase RENDER: Générer le rapport
        .render(
            "renderAnalysis",
            {"format": "full"},
            description="Génère le rapport d'analyse complet"
        )
        
        .metadata(
            author="EUREKAI",
            created="2024-01-01"
        )
        .build()
    )


# Version JSON pour référence
ANALYZE_OBJECT_JSON = {
    "id": "Scenario.AnalyzeObject",
    "name": "Analyse d'objet",
    "description": "Analyse un objet fractal et génère un rapport",
    "version": "1.0.0",
    "tags": ["analysis", "metarules", "erk", "core"],
    "steps": [
        {
            "phase": "GET",
            "action": "loadObject",
            "params": {"id": "${input.object_id}"},
            "description": "Charge l'objet principal"
        },
        {
            "phase": "GET",
            "action": "loadBundle",
            "params": {
                "id": "${input.object_id}",
                "include_relations": True,
                "depth": 1
            },
            "description": "Charge le bundle avec relations"
        },
        {
            "phase": "GET",
            "action": "loadRules",
            "params": {"object_id": "${input.object_id}"},
            "description": "Charge les règles ERK"
        },
        {
            "phase": "EXECUTE",
            "action": "runMetaRules",
            "params": {
                "detect_cycles": True,
                "detect_redundancies": True,
                "generate_suggestions": True
            },
            "description": "Analyse MetaRelations"
        },
        {
            "phase": "EXECUTE",
            "action": "applyERK",
            "params": {"collect_actions": True},
            "description": "Évalue les règles ERK",
            "required": False
        },
        {
            "phase": "EXECUTE",
            "action": "transform",
            "params": {
                "action": "complete_bundles",
                "target": "object",
                "options": {"required_bundles": ["core"]}
            },
            "required": False
        },
        {
            "phase": "VALIDATE",
            "action": "validateSchema",
            "params": {"target": "object"}
        },
        {
            "phase": "VALIDATE",
            "action": "validateERK",
            "params": {"fail_on_deny": False},
            "required": False
        },
        {
            "phase": "VALIDATE",
            "action": "checkErrors",
            "params": {"strict": False}
        },
        {
            "phase": "RENDER",
            "action": "renderAnalysis",
            "params": {"format": "full"}
        }
    ]
}


# =============================================================================
# SCENARIO.CREATEPROJECTSKELETON
# =============================================================================

def create_project_skeleton_scenario() -> GEVRScenario:
    """
    Crée le scénario Scenario.CreateProjectSkeleton.
    
    Ce scénario:
    1. GET: Charge le template de projet
    2. EXECUTE: Crée la structure du projet
    3. VALIDATE: Vérifie les relations et la cohérence
    4. RENDER: Produit la définition du projet
    
    Input attendu:
        - template_id: ID du template (ex: "project.basic")
        - project_name: Nom du nouveau projet
        - customize: Personnalisations (optionnel)
    
    Output:
        - Structure du projet créé (objets + relations)
    """
    return (ScenarioBuilder("Scenario.CreateProjectSkeleton")
        .name("Création de squelette de projet")
        .description(
            "Crée un nouveau projet à partir d'un template: "
            "charge le template, génère les objets et relations, "
            "valide la structure, et produit la définition finale."
        )
        .version("1.0.0")
        .tag("creation", "project", "template", "core")
        
        # Phase GET: Charger le template
        .get(
            "loadTemplate",
            {
                "template_id": "${input.template_id}",
                "type": "${input.template_type}"
            },
            description="Charge le template de projet"
        )
        
        # Phase EXECUTE: Créer la structure
        .execute(
            "createStructure",
            {
                "name": "${input.project_name}",
                "customize": "${input.customize}"
            },
            description="Crée la structure du projet"
        )
        
        # Phase VALIDATE: Vérifier la structure
        .validate(
            "validateStructure",
            {},
            description="Valide les objets et relations créés"
        )
        .validate(
            "checkErrors",
            {"strict": True},
            description="Vérifie qu'il n'y a pas d'erreurs"
        )
        
        # Phase RENDER: Produire la sortie
        .render(
            "renderSkeleton",
            {"format": "detailed"},
            description="Génère la définition du projet"
        )
        
        .metadata(
            author="EUREKAI",
            created="2024-01-01"
        )
        .build()
    )


# Version JSON pour référence
CREATE_PROJECT_SKELETON_JSON = {
    "id": "Scenario.CreateProjectSkeleton",
    "name": "Création de squelette de projet",
    "description": "Crée un projet à partir d'un template",
    "version": "1.0.0",
    "tags": ["creation", "project", "template", "core"],
    "steps": [
        {
            "phase": "GET",
            "action": "loadTemplate",
            "params": {
                "template_id": "${input.template_id}",
                "type": "${input.template_type}"
            },
            "description": "Charge le template"
        },
        {
            "phase": "EXECUTE",
            "action": "createStructure",
            "params": {
                "name": "${input.project_name}",
                "customize": "${input.customize}"
            },
            "description": "Crée la structure"
        },
        {
            "phase": "VALIDATE",
            "action": "validateStructure",
            "description": "Valide la structure"
        },
        {
            "phase": "VALIDATE",
            "action": "checkErrors",
            "params": {"strict": True},
            "description": "Vérifie les erreurs"
        },
        {
            "phase": "RENDER",
            "action": "renderSkeleton",
            "params": {"format": "detailed"},
            "description": "Génère la sortie"
        }
    ]
}


# =============================================================================
# SCENARIO MINIMAL (pour tests)
# =============================================================================

def create_minimal_scenario() -> GEVRScenario:
    """
    Crée un scénario minimal pour les tests.
    
    Simple pipeline GET → EXECUTE → VALIDATE → RENDER.
    """
    return (ScenarioBuilder("Scenario.Minimal")
        .name("Scénario minimal")
        .description("Scénario de test minimal")
        .version("1.0.0")
        .tag("test", "minimal")
        
        .get("log", {"message": "GET phase"})
        .execute("log", {"message": "EXECUTE phase"})
        .validate("checkErrors", {"strict": False})
        .render("renderJson", {"include": ["logs"]})
        
        .build()
    )


# =============================================================================
# REGISTRE DES SCÉNARIOS
# =============================================================================

def get_predefined_scenarios() -> Dict[str, GEVRScenario]:
    """
    Retourne tous les scénarios prédéfinis.
    
    Returns:
        Dict {scenario_id: GEVRScenario}
    """
    return {
        "Scenario.AnalyzeObject": create_analyze_object_scenario(),
        "Scenario.CreateProjectSkeleton": create_project_skeleton_scenario(),
        "Scenario.Minimal": create_minimal_scenario()
    }


def register_predefined_scenarios(engine):
    """
    Enregistre tous les scénarios prédéfinis dans un moteur.
    
    Args:
        engine: Instance de GEVREngine
    """
    for scenario in get_predefined_scenarios().values():
        engine.register_scenario(scenario)
