"""
EUREKAI D1/4 — Tests GEVR
==========================

Tests complets pour le pipeline GEVR:
- Structures de données (Scenario, Step, Result)
- Moteur d'exécution
- Handlers intégrés
- Scénarios prédéfinis
- Cas de succès et d'échec

Couverture:
- Structure canonique GEVR
- API runScenario
- 2 scénarios concrets
- Exemples d'exécution
- Cas de test (succès/échec)

Version: D1/4 - Scénarios GEVR de base
"""

import pytest
import sys
import os
from datetime import datetime

# Ajouter le chemin du module
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gevr import (
    # Énumérations
    GEVRPhase, StepStatus, ScenarioStatus,
    
    # Structures
    StepDefinition, StepResult, GEVRScenario, ScenarioResult,
    ExecutionContext,
    
    # Builders
    ScenarioBuilder, create_scenario,
    
    # Moteur
    GEVREngine, get_engine, run_scenario,
    
    # Façade
    GEVR,
    
    # Scénarios
    create_analyze_object_scenario,
    create_project_skeleton_scenario,
    create_minimal_scenario,
    get_predefined_scenarios,
    
    # Handlers
    register_all_handlers,
)


# =============================================================================
# TESTS STRUCTURES DE BASE
# =============================================================================

class TestGEVRPhase:
    """Tests des phases GEVR."""
    
    def test_all_phases_defined(self):
        """Vérifie que les 4 phases sont définies."""
        assert GEVRPhase.GET.value == "GET"
        assert GEVRPhase.EXECUTE.value == "EXECUTE"
        assert GEVRPhase.VALIDATE.value == "VALIDATE"
        assert GEVRPhase.RENDER.value == "RENDER"
    
    def test_phase_to_string(self):
        """Vérifie la conversion en string."""
        assert str(GEVRPhase.GET) == "GET"


class TestStepDefinition:
    """Tests de la définition d'étape."""
    
    def test_step_creation(self):
        """Crée une étape basique."""
        step = StepDefinition(
            phase=GEVRPhase.GET,
            action="loadObject",
            params={"id": "test"}
        )
        assert step.phase == GEVRPhase.GET
        assert step.action == "loadObject"
        assert step.params == {"id": "test"}
        assert step.required == True
    
    def test_step_to_dict(self):
        """Vérifie la sérialisation."""
        step = StepDefinition(
            phase=GEVRPhase.EXECUTE,
            action="transform",
            params={"action": "merge"},
            description="Merge data"
        )
        d = step.to_dict()
        assert d["phase"] == "EXECUTE"
        assert d["action"] == "transform"
        assert d["description"] == "Merge data"
    
    def test_step_from_dict(self):
        """Vérifie la désérialisation."""
        data = {
            "phase": "VALIDATE",
            "action": "checkErrors",
            "params": {"strict": True}
        }
        step = StepDefinition.from_dict(data)
        assert step.phase == GEVRPhase.VALIDATE
        assert step.params["strict"] == True


class TestGEVRScenario:
    """Tests du scénario GEVR."""
    
    def test_scenario_creation(self):
        """Crée un scénario basique."""
        scenario = GEVRScenario(
            id="Scenario.Test",
            name="Test Scenario",
            steps=[
                StepDefinition(GEVRPhase.GET, "loadObject"),
                StepDefinition(GEVRPhase.RENDER, "renderReport")
            ]
        )
        assert scenario.id == "Scenario.Test"
        assert len(scenario.steps) == 2
    
    def test_scenario_validate(self):
        """Vérifie la validation."""
        # Scénario valide
        valid = GEVRScenario(
            id="Valid",
            name="Valid",
            steps=[StepDefinition(GEVRPhase.GET, "load")]
        )
        assert valid.validate() == []
        
        # Scénario invalide
        invalid = GEVRScenario(id="", name="", steps=[])
        errors = invalid.validate()
        assert len(errors) > 0
    
    def test_scenario_to_json(self):
        """Vérifie la sérialisation JSON."""
        scenario = GEVRScenario(
            id="Scenario.Json",
            name="JSON Test",
            steps=[StepDefinition(GEVRPhase.GET, "load")]
        )
        json_str = scenario.to_json()
        assert '"id": "Scenario.Json"' in json_str
    
    def test_scenario_from_json(self):
        """Vérifie la désérialisation JSON."""
        json_str = '''
        {
            "id": "Scenario.FromJson",
            "name": "From JSON",
            "steps": [
                {"phase": "GET", "action": "loadObject"}
            ]
        }
        '''
        scenario = GEVRScenario.from_json(json_str)
        assert scenario.id == "Scenario.FromJson"
        assert len(scenario.steps) == 1


class TestScenarioBuilder:
    """Tests du builder de scénarios."""
    
    def test_builder_fluent_api(self):
        """Vérifie l'API fluente."""
        scenario = (ScenarioBuilder("Scenario.Fluent")
            .name("Fluent Test")
            .description("Test description")
            .version("2.0.0")
            .tag("test", "fluent")
            .get("loadObject", {"id": "test"})
            .execute("transform", {"action": "merge"})
            .validate("checkErrors")
            .render("renderReport")
            .build()
        )
        
        assert scenario.id == "Scenario.Fluent"
        assert scenario.name == "Fluent Test"
        assert scenario.version == "2.0.0"
        assert "test" in scenario.tags
        assert len(scenario.steps) == 4
    
    def test_builder_phases_order(self):
        """Vérifie que les phases sont dans le bon ordre."""
        scenario = (ScenarioBuilder("Scenario.Order")
            .name("Order Test")
            .get("load")
            .execute("exec")
            .validate("check")
            .render("output")
            .build()
        )
        
        phases = [s.phase for s in scenario.steps]
        assert phases == [
            GEVRPhase.GET,
            GEVRPhase.EXECUTE,
            GEVRPhase.VALIDATE,
            GEVRPhase.RENDER
        ]


# =============================================================================
# TESTS CONTEXTE D'EXÉCUTION
# =============================================================================

class TestExecutionContext:
    """Tests du contexte d'exécution."""
    
    def test_context_set_get(self):
        """Vérifie set/get."""
        ctx = ExecutionContext()
        ctx.set("key", "value")
        assert ctx.get("key") == "value"
        assert ctx.get("missing", "default") == "default"
    
    def test_context_input_fallback(self):
        """Vérifie le fallback sur input."""
        ctx = ExecutionContext(input={"input_key": "input_value"})
        assert ctx.get("input_key") == "input_value"
    
    def test_context_phase_outputs(self):
        """Vérifie les sorties par phase."""
        ctx = ExecutionContext()
        ctx.set_phase_output(GEVRPhase.GET, {"loaded": True})
        assert ctx.get_phase_output(GEVRPhase.GET) == {"loaded": True}
    
    def test_context_logging(self):
        """Vérifie le logging."""
        ctx = ExecutionContext()
        ctx.log("Test message")
        ctx.log("GET message", GEVRPhase.GET)
        assert len(ctx.logs) == 2
        assert "[GET]" in ctx.logs[1]


# =============================================================================
# TESTS MOTEUR D'EXÉCUTION
# =============================================================================

class TestGEVREngine:
    """Tests du moteur GEVR."""
    
    def test_engine_creation(self):
        """Crée un moteur."""
        engine = GEVREngine()
        assert engine is not None
        assert engine.registry is not None
    
    def test_engine_register_scenario(self):
        """Enregistre un scénario."""
        engine = GEVREngine()
        scenario = create_minimal_scenario()
        engine.register_scenario(scenario)
        
        assert "Scenario.Minimal" in engine.scenarios
        assert engine.get_scenario("Scenario.Minimal") is not None
    
    def test_engine_register_handler(self):
        """Enregistre un handler personnalisé."""
        engine = GEVREngine()
        
        def custom_handler(params, ctx):
            return {"custom": True}
        
        engine.register_handler("customAction", custom_handler, GEVRPhase.EXECUTE)
        
        handler = engine.registry.get("customAction", GEVRPhase.EXECUTE)
        assert handler is not None
    
    def test_engine_run_minimal_scenario(self):
        """Exécute le scénario minimal."""
        engine = GEVREngine()
        register_all_handlers(engine)
        
        scenario = create_minimal_scenario()
        engine.register_scenario(scenario)
        
        result = engine.run_scenario("Scenario.Minimal", {})
        
        assert result.status in [ScenarioStatus.COMPLETED, ScenarioStatus.PARTIAL]
        assert len(result.step_results) > 0
        assert result.completed_at is not None
    
    def test_engine_execute_custom_scenario(self):
        """Exécute un scénario personnalisé."""
        engine = GEVREngine()
        
        scenario = (ScenarioBuilder("Scenario.Custom")
            .name("Custom")
            .get("log", {"message": "Hello"})
            .validate("checkErrors")
            .render("renderJson")
            .build()
        )
        
        result = engine.execute(scenario, {})
        
        assert result.ok
        assert result.status == ScenarioStatus.COMPLETED


class TestRunScenarioAPI:
    """Tests de l'API run_scenario."""
    
    def test_run_scenario_returns_dict(self):
        """Vérifie que run_scenario retourne un dict."""
        # Réinitialiser le moteur global
        import gevr.engine as eng
        eng._default_engine = None
        
        engine = get_engine()
        scenario = create_minimal_scenario()
        engine.register_scenario(scenario)
        
        result = run_scenario("Scenario.Minimal", {})
        
        assert isinstance(result, dict)
        assert "status" in result
        assert "step_results" in result
    
    def test_run_scenario_with_input(self):
        """Exécute avec des données d'entrée."""
        import gevr.engine as eng
        eng._default_engine = None
        
        engine = get_engine()
        
        scenario = (ScenarioBuilder("Scenario.WithInput")
            .name("With Input")
            .get("log", {"message": "Processing ${input.name}"})
            .render("renderJson", {"include": ["input"]})
            .build()
        )
        engine.register_scenario(scenario)
        
        result = run_scenario("Scenario.WithInput", {"name": "TestProject"})
        
        assert result["status"] in ["completed", "partial"]


# =============================================================================
# TESTS SCÉNARIOS PRÉDÉFINIS
# =============================================================================

class TestAnalyzeObjectScenario:
    """Tests du scénario AnalyzeObject."""
    
    def test_scenario_structure(self):
        """Vérifie la structure du scénario."""
        scenario = create_analyze_object_scenario()
        
        assert scenario.id == "Scenario.AnalyzeObject"
        assert len(scenario.steps) >= 4  # Au moins G, E, V, R
        
        # Vérifie les phases
        phases_used = scenario.phases_used
        assert GEVRPhase.GET in phases_used
        assert GEVRPhase.EXECUTE in phases_used
        assert GEVRPhase.VALIDATE in phases_used
        assert GEVRPhase.RENDER in phases_used
    
    def test_scenario_execution_simulated(self):
        """Exécute le scénario en mode simulé."""
        engine = GEVREngine()
        register_all_handlers(engine)
        
        scenario = create_analyze_object_scenario()
        
        result = engine.execute(scenario, {"object_id": "Agent.Test"})
        
        # Doit produire un résultat même sans store
        assert result.status in [ScenarioStatus.COMPLETED, ScenarioStatus.PARTIAL]
        assert result.output is not None


class TestCreateProjectSkeletonScenario:
    """Tests du scénario CreateProjectSkeleton."""
    
    def test_scenario_structure(self):
        """Vérifie la structure du scénario."""
        scenario = create_project_skeleton_scenario()
        
        assert scenario.id == "Scenario.CreateProjectSkeleton"
        
        # Vérifie les étapes clés
        actions = [s.action for s in scenario.steps]
        assert "loadTemplate" in actions
        assert "createStructure" in actions
        assert "validateStructure" in actions
        assert "renderSkeleton" in actions
    
    def test_scenario_execution_with_template(self):
        """Exécute le scénario avec un template."""
        engine = GEVREngine()
        register_all_handlers(engine)
        
        scenario = create_project_skeleton_scenario()
        
        result = engine.execute(scenario, {
            "template_id": "project.basic",
            "project_name": "MyNewProject"
        })
        
        # Vérifier le résultat
        assert result.status in [ScenarioStatus.COMPLETED, ScenarioStatus.PARTIAL]
        
        # Vérifier la structure créée
        if result.ok:
            output = result.output
            assert output is not None
            assert "project" in output or "objects_count" in output


class TestPredefinedScenariosRegistry:
    """Tests du registre des scénarios prédéfinis."""
    
    def test_get_all_predefined(self):
        """Récupère tous les scénarios prédéfinis."""
        scenarios = get_predefined_scenarios()
        
        assert "Scenario.AnalyzeObject" in scenarios
        assert "Scenario.CreateProjectSkeleton" in scenarios
        assert "Scenario.Minimal" in scenarios
    
    def test_register_in_engine(self):
        """Enregistre les scénarios dans un moteur."""
        engine = GEVREngine()
        register_all_handlers(engine)
        
        from gevr.scenarios import register_predefined_scenarios
        register_predefined_scenarios(engine)
        
        assert "Scenario.AnalyzeObject" in engine.scenarios
        assert "Scenario.CreateProjectSkeleton" in engine.scenarios


# =============================================================================
# TESTS FAÇADE GEVR
# =============================================================================

class TestGEVRFacade:
    """Tests de la façade GEVR."""
    
    def test_facade_run(self):
        """Exécute via la façade."""
        result = GEVR.run("Scenario.Minimal", {})
        
        assert isinstance(result, dict)
        assert "status" in result
    
    def test_facade_create_and_run(self):
        """Crée et exécute un scénario via la façade."""
        scenario = (GEVR.create("Scenario.FacadeTest")
            .name("Facade Test")
            .get("log", {"message": "Test"})
            .render("renderJson")
            .build()
        )
        
        GEVR.register(scenario)
        result = GEVR.run("Scenario.FacadeTest", {})
        
        assert result["status"] in ["completed", "partial"]
    
    def test_facade_list_scenarios(self):
        """Liste les scénarios."""
        scenarios = GEVR.list_scenarios()
        
        assert isinstance(scenarios, list)
        assert "Scenario.Minimal" in scenarios
    
    def test_facade_handler_decorator(self):
        """Enregistre un handler via décorateur."""
        @GEVR.handler("decoratedAction", GEVRPhase.EXECUTE)
        def my_handler(params, ctx):
            return {"decorated": True}
        
        handler = GEVR.engine.registry.get("decoratedAction", GEVRPhase.EXECUTE)
        assert handler is not None


# =============================================================================
# TESTS CAS D'ERREUR
# =============================================================================

class TestErrorCases:
    """Tests des cas d'erreur."""
    
    def test_missing_scenario(self):
        """Scénario inexistant."""
        engine = GEVREngine()
        
        with pytest.raises(ValueError, match="not found"):
            engine.run_scenario("Scenario.NotFound", {})
    
    def test_missing_handler(self):
        """Handler inexistant."""
        engine = GEVREngine(register_defaults=False)  # Pas de handlers par défaut
        
        scenario = (ScenarioBuilder("Scenario.MissingHandler")
            .name("Missing Handler")
            .get("unknownAction", {})
            .build()
        )
        engine.register_scenario(scenario)
        
        result = engine.run_scenario("Scenario.MissingHandler", {})
        
        # Doit échouer proprement
        assert result.status == ScenarioStatus.FAILED
        assert any(r.status == StepStatus.FAILED for r in result.step_results)
    
    def test_step_failure_with_required(self):
        """Échec d'une étape requise."""
        engine = GEVREngine()
        
        def failing_handler(params, ctx):
            raise ValueError("Intentional failure")
        
        engine.register_handler("failingAction", failing_handler)
        
        scenario = (ScenarioBuilder("Scenario.Failing")
            .name("Failing")
            .get("failingAction", {}, required=True)
            .render("renderJson")
            .build()
        )
        engine.register_scenario(scenario)
        
        result = engine.run_scenario("Scenario.Failing", {})
        
        assert result.status == ScenarioStatus.FAILED
    
    def test_step_failure_with_optional(self):
        """Échec d'une étape optionnelle."""
        engine = GEVREngine()
        
        def failing_handler(params, ctx):
            raise ValueError("Intentional failure")
        
        engine.register_handler("failingOptional", failing_handler)
        
        scenario = (ScenarioBuilder("Scenario.OptionalFail")
            .name("Optional Fail")
            .get("log", {"message": "Start"})
            .execute("failingOptional", {}, required=False)
            .render("renderJson")
            .build()
        )
        engine.register_scenario(scenario)
        
        result = engine.run_scenario("Scenario.OptionalFail", {})
        
        # Doit continuer malgré l'échec optionnel
        assert result.status == ScenarioStatus.PARTIAL


# =============================================================================
# TESTS D'EXEMPLES D'EXÉCUTION
# =============================================================================

class TestExecutionExamples:
    """
    Tests qui démontrent des exemples complets d'exécution.
    Ces tests servent aussi de documentation.
    """
    
    def test_example_analyze_object(self):
        """
        Exemple complet: Analyser un objet.
        
        Input:
            object_id: "Agent.Core"
        
        Déroulé:
            1. GET: loadObject -> charge l'objet
            2. GET: loadBundle -> charge les relations
            3. EXECUTE: runMetaRules -> analyse les cycles
            4. EXECUTE: applyERK -> évalue les règles
            5. VALIDATE: checkErrors -> vérifie la cohérence
            6. RENDER: renderAnalysis -> produit le rapport
        
        Output:
            Rapport avec cycles, redondances, actions suggérées
        """
        # Setup
        engine = GEVREngine()
        register_all_handlers(engine)
        scenario = create_analyze_object_scenario()
        
        # Input
        input_data = {
            "object_id": "Agent.Core"
        }
        
        # Exécution
        result = engine.execute(scenario, input_data)
        
        # Vérifications
        assert result.scenario.id == "Scenario.AnalyzeObject"
        assert len(result.step_results) > 0
        
        # Logs par phase
        get_steps = [r for r in result.step_results if r.step.phase == GEVRPhase.GET]
        execute_steps = [r for r in result.step_results if r.step.phase == GEVRPhase.EXECUTE]
        validate_steps = [r for r in result.step_results if r.step.phase == GEVRPhase.VALIDATE]
        render_steps = [r for r in result.step_results if r.step.phase == GEVRPhase.RENDER]
        
        assert len(get_steps) > 0, "Phase GET doit avoir des étapes"
        assert len(render_steps) > 0, "Phase RENDER doit avoir des étapes"
        
        # Output
        output = result.to_dict()
        assert "output" in output
        assert "summary" in output
        
        print("\n=== EXEMPLE: Analyse d'objet ===")
        print(f"Input: {input_data}")
        print(f"Status: {result.status.value}")
        print(f"Steps: {len(result.step_results)}")
        print(f"Duration: {result.duration_ms:.2f}ms")
    
    def test_example_create_project(self):
        """
        Exemple complet: Créer un projet.
        
        Input:
            template_id: "project.basic"
            project_name: "MyAgentProject"
        
        Déroulé:
            1. GET: loadTemplate -> charge le template
            2. EXECUTE: createStructure -> crée les objets
            3. VALIDATE: validateStructure -> vérifie les relations
            4. RENDER: renderSkeleton -> produit la définition
        
        Output:
            Structure du projet (objets + relations)
        """
        # Setup
        engine = GEVREngine()
        register_all_handlers(engine)
        scenario = create_project_skeleton_scenario()
        
        # Input
        input_data = {
            "template_id": "project.basic",
            "project_name": "MyAgentProject"
        }
        
        # Exécution
        result = engine.execute(scenario, input_data)
        
        # Vérifications
        assert result.scenario.id == "Scenario.CreateProjectSkeleton"
        
        # Le template devrait être chargé
        get_results = [r for r in result.step_results if r.step.phase == GEVRPhase.GET]
        assert any(r.ok for r in get_results), "GET doit réussir"
        
        # Output
        output = result.to_dict()
        
        print("\n=== EXEMPLE: Création de projet ===")
        print(f"Input: {input_data}")
        print(f"Status: {result.status.value}")
        print(f"Steps: {len(result.step_results)}")
        print(f"Duration: {result.duration_ms:.2f}ms")
        if result.output:
            print(f"Output type: {type(result.output)}")


# =============================================================================
# TESTS FORMAT DE SORTIE
# =============================================================================

class TestOutputFormat:
    """Tests du format de sortie standard."""
    
    def test_result_to_dict_format(self):
        """Vérifie le format de sortie to_dict()."""
        engine = GEVREngine()
        scenario = create_minimal_scenario()
        
        result = engine.execute(scenario, {})
        output = result.to_dict()
        
        # Champs requis
        assert "scenario" in output
        assert "status" in output
        assert "step_results" in output
        assert "output" in output
        assert "logs" in output
        assert "started_at" in output
        assert "duration_ms" in output
        assert "summary" in output
    
    def test_summary_format(self):
        """Vérifie le format du résumé."""
        engine = GEVREngine()
        scenario = create_minimal_scenario()
        
        result = engine.execute(scenario, {})
        summary = result.summary()
        
        assert "status" in summary
        assert "total_steps" in summary
        assert "successful_steps" in summary
        assert "failed_steps" in summary
        assert "phases" in summary
        assert "duration_ms" in summary


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
