#!/usr/bin/env python3
"""
EUREKAI D1/4 — Démonstration GEVR
==================================

Ce script démontre l'utilisation du pipeline GEVR avec:
1. Scénario AnalyzeObject
2. Scénario CreateProjectSkeleton
3. Scénario personnalisé

Usage:
    python demo_gevr.py
"""

import sys
import os

# Ajouter le chemin du module
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gevr import (
    GEVR, GEVRPhase, ScenarioBuilder,
    create_analyze_object_scenario,
    create_project_skeleton_scenario
)


def print_separator(title: str):
    """Affiche un séparateur avec titre."""
    print("\n" + "═" * 60)
    print(f"  {title}")
    print("═" * 60)


def demo_analyze_object():
    """Démo du scénario AnalyzeObject."""
    print_separator("DEMO 1: Scenario.AnalyzeObject")
    
    # Afficher la structure du scénario
    scenario = create_analyze_object_scenario()
    print(f"\nScénario: {scenario.name}")
    print(f"ID: {scenario.id}")
    print(f"Description: {scenario.description}")
    print(f"\nÉtapes ({len(scenario.steps)}):")
    
    for i, step in enumerate(scenario.steps, 1):
        req = "✓" if step.required else "○"
        print(f"  {i}. [{step.phase.value}] {step.action} {req}")
    
    # Exécuter le scénario
    print("\n--- Exécution ---")
    result = GEVR.run("Scenario.AnalyzeObject", {"object_id": "Agent.Core"})
    
    # Afficher les résultats
    print(f"\nStatus: {result['status']}")
    print(f"Durée: {result['duration_ms']:.2f}ms")
    
    summary = result['summary']
    print(f"\nRésumé:")
    print(f"  - Étapes totales: {summary['total_steps']}")
    print(f"  - Réussies: {summary['successful_steps']}")
    print(f"  - Échouées: {summary['failed_steps']}")
    
    print(f"\nPhases:")
    for phase, status in summary['phases'].items():
        icon = "✓" if status == "ok" else "✗"
        print(f"  {icon} {phase}: {status}")
    
    # Output
    if result.get('output'):
        print(f"\nOutput type: {result['output'].get('type', 'unknown')}")


def demo_create_project():
    """Démo du scénario CreateProjectSkeleton."""
    print_separator("DEMO 2: Scenario.CreateProjectSkeleton")
    
    # Afficher la structure du scénario
    scenario = create_project_skeleton_scenario()
    print(f"\nScénario: {scenario.name}")
    print(f"ID: {scenario.id}")
    
    print(f"\nÉtapes ({len(scenario.steps)}):")
    for i, step in enumerate(scenario.steps, 1):
        print(f"  {i}. [{step.phase.value}] {step.action}")
    
    # Exécuter le scénario
    print("\n--- Exécution ---")
    result = GEVR.run("Scenario.CreateProjectSkeleton", {
        "template_id": "project.basic",
        "project_name": "MyDemoProject"
    })
    
    # Afficher les résultats
    print(f"\nStatus: {result['status']}")
    print(f"Durée: {result['duration_ms']:.2f}ms")
    
    # Output
    output = result.get('output', {})
    if output:
        print(f"\nProjet créé:")
        project = output.get('project', {})
        print(f"  - ID: {project.get('id')}")
        print(f"  - Nom: {project.get('name')}")
        
        objects_count = output.get('objects_count', len(output.get('objects', [])))
        relations_count = output.get('relations_count', len(output.get('relations', [])))
        
        print(f"  - Objets: {objects_count}")
        print(f"  - Relations: {relations_count}")
        
        if output.get('objects'):
            print(f"\nObjets créés:")
            for obj in output['objects'][:5]:
                print(f"  - {obj['id']} ({obj['type']})")


def demo_custom_scenario():
    """Démo d'un scénario personnalisé."""
    print_separator("DEMO 3: Scénario personnalisé")
    
    # Créer un scénario personnalisé avec l'API fluente
    print("\nCréation du scénario via ScenarioBuilder...")
    
    scenario = (ScenarioBuilder("Scenario.CustomDemo")
        .name("Démonstration personnalisée")
        .description("Un scénario créé dynamiquement")
        .version("1.0.0")
        .tag("demo", "custom")
        
        # GET: Logger un message
        .get("log", {"message": "Démarrage du traitement", "level": "info"})
        
        # EXECUTE: Définir des données
        .execute("setData", {"key": "status", "value": "processing"})
        .execute("log", {"message": "Traitement en cours", "level": "debug"})
        
        # VALIDATE: Vérifier les erreurs
        .validate("checkErrors", {"strict": False})
        
        # RENDER: Générer la sortie
        .render("renderJson", {"include": ["data", "logs"]})
        
        .build()
    )
    
    # Afficher la structure
    print(f"\nScénario créé: {scenario.name}")
    print(f"Tags: {', '.join(scenario.tags)}")
    print(f"Étapes: {len(scenario.steps)}")
    
    # Enregistrer et exécuter
    GEVR.register(scenario)
    
    print("\n--- Exécution ---")
    result = GEVR.run("Scenario.CustomDemo", {})
    
    print(f"\nStatus: {result['status']}")
    
    # Afficher les logs
    if result.get('logs'):
        print(f"\nLogs ({len(result['logs'])}):")
        for log in result['logs'][-5:]:
            print(f"  {log}")


def demo_facade_decorator():
    """Démo du décorateur de handler."""
    print_separator("DEMO 4: Handler personnalisé")
    
    # Créer un handler personnalisé via décorateur
    @GEVR.handler("computeMetrics", GEVRPhase.EXECUTE)
    def compute_metrics(params, context):
        """Handler personnalisé qui calcule des métriques."""
        data = context.get("data", {})
        
        metrics = {
            "keys_count": len(data),
            "has_errors": len(context.errors) > 0,
            "phase_outputs": len(context.phase_outputs)
        }
        
        context.set("metrics", metrics)
        context.log("Métriques calculées", GEVRPhase.EXECUTE)
        
        return metrics
    
    # Créer un scénario utilisant ce handler
    scenario = (ScenarioBuilder("Scenario.WithMetrics")
        .name("Avec métriques")
        .get("log", {"message": "Init"})
        .execute("setData", {"key": "test", "value": 123})
        .execute("computeMetrics", {})  # Notre handler personnalisé
        .validate("checkErrors")
        .render("renderJson", {"include": ["data"]})
        .build()
    )
    
    GEVR.register(scenario)
    
    print("\nHandler 'computeMetrics' enregistré")
    print("\n--- Exécution ---")
    
    result = GEVR.run("Scenario.WithMetrics", {})
    
    print(f"\nStatus: {result['status']}")
    
    # Récupérer les métriques calculées
    for step_result in result.get('step_results', []):
        if step_result['step']['action'] == 'computeMetrics':
            print(f"\nMétriques calculées:")
            metrics = step_result.get('output', {})
            for key, value in metrics.items():
                print(f"  - {key}: {value}")


def main():
    """Point d'entrée principal."""
    print("\n" + "█" * 60)
    print("  EUREKAI D1/4 — Démonstration GEVR")
    print("  Pipeline GET → EXECUTE → VALIDATE → RENDER")
    print("█" * 60)
    
    # Liste des scénarios disponibles
    print(f"\nScénarios disponibles: {GEVR.list_scenarios()}")
    
    # Exécuter les démos
    demo_analyze_object()
    demo_create_project()
    demo_custom_scenario()
    demo_facade_decorator()
    
    # Résumé final
    print_separator("RÉSUMÉ")
    print(f"\nScénarios enregistrés: {len(GEVR.list_scenarios())}")
    for scenario_id in GEVR.list_scenarios():
        scenario = GEVR.get_scenario(scenario_id)
        if scenario:
            print(f"  - {scenario_id}: {len(scenario.steps)} étapes")
    
    print("\n✓ Démonstration GEVR terminée avec succès!")


if __name__ == "__main__":
    main()
