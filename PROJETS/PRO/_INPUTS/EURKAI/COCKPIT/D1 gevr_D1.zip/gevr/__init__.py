"""
EUREKAI D1/4 — Scénarios GEVR de base
======================================

Ce module implémente le pipeline GEVR (GET → EXECUTE → VALIDATE → RENDER)
pour l'orchestration des opérations sur la fractale EUREKAI.

GEVR définit un modèle d'exécution déclaratif où chaque opération complexe
est découpée en 4 phases distinctes:

- **GET**: Récupération des données nécessaires (objets, bundles, templates)
- **EXECUTE**: Application des transformations (MetaRules, ERK, création)
- **VALIDATE**: Vérification de la cohérence (schéma, règles, structure)
- **RENDER**: Production du résultat lisible (rapport, log, vue)

Usage basique:
    from gevr import GEVREngine, run_scenario
    
    # Exécuter un scénario prédéfini
    result = run_scenario("Scenario.AnalyzeObject", {"object_id": "Agent.Core"})
    
    # Ou créer un scénario personnalisé
    from gevr import ScenarioBuilder, GEVRPhase
    
    scenario = (ScenarioBuilder("Scenario.Custom")
        .name("Mon scénario")
        .get("loadObject", {"id": "..."})
        .execute("transform", {"action": "..."})
        .validate("checkErrors")
        .render("renderReport")
        .build())
    
    engine = GEVREngine()
    engine.register_scenario(scenario)
    result = engine.run_scenario("Scenario.Custom", input_data)

Scénarios prédéfinis:
    - Scenario.AnalyzeObject: Analyse un objet et complète ses bundles
    - Scenario.CreateProjectSkeleton: Crée un projet à partir d'un template
    - Scenario.Minimal: Scénario de test minimal

Intégration:
    - ERK (B3): Évaluation de règles avec actions suggérées
    - MetaRelations (C3): Analyse de cycles et redondances

Version: D1/4 - Scénarios GEVR de base
"""

__version__ = "1.0.0"
__author__ = "EUREKAI"

# Imports des structures de données
from .scenario import (
    # Énumérations
    GEVRPhase,
    StepStatus,
    ScenarioStatus,
    
    # Structures
    StepDefinition,
    StepResult,
    GEVRScenario,
    ScenarioResult,
    
    # Builders
    ScenarioBuilder,
    create_scenario,
)

# Imports du moteur
from .engine import (
    # Contexte
    ExecutionContext,
    
    # Handlers
    ActionHandler,
    FunctionHandler,
    HandlerRegistry,
    
    # Moteur
    GEVREngine,
    
    # API simplifiée
    get_engine,
    run_scenario,
    register_scenario,
    register_handler,
)

# Imports des handlers spécialisés
from .handlers import (
    # GET handlers
    handler_load_bundle,
    handler_load_template,
    handler_load_rules,
    
    # EXECUTE handlers
    handler_run_metarules,
    handler_apply_erk,
    handler_transform,
    handler_create_structure,
    
    # VALIDATE handlers
    handler_validate_schema,
    handler_validate_erk,
    handler_validate_structure,
    
    # RENDER handlers
    handler_render_analysis,
    handler_render_skeleton,
    handler_render_log,
    
    # Enregistrement
    register_all_handlers,
)

# Imports des scénarios prédéfinis
from .scenarios import (
    create_analyze_object_scenario,
    create_project_skeleton_scenario,
    create_minimal_scenario,
    get_predefined_scenarios,
    register_predefined_scenarios,
    ANALYZE_OBJECT_JSON,
    CREATE_PROJECT_SKELETON_JSON,
)


# =============================================================================
# FAÇADE GEVR
# =============================================================================

class _GEVRFacade:
    """
    Façade simplifiée pour l'API GEVR.
    
    Permet d'utiliser GEVR.run(), GEVR.create(), etc. directement.
    """
    
    def __init__(self):
        self._engine = None
        self._initialized = False
    
    @property
    def engine(self) -> GEVREngine:
        """Obtient le moteur (lazy init avec handlers et scénarios)."""
        if not self._initialized:
            self._engine = GEVREngine()
            register_all_handlers(self._engine)
            register_predefined_scenarios(self._engine)
            self._initialized = True
        return self._engine
    
    def configure(self, store=None, **options):
        """Configure le moteur GEVR."""
        if store:
            self.engine.store = store
        self.engine.options.update(options)
        return self
    
    def run(
        self,
        scenario_id: str,
        input_data: dict = None,
        options: dict = None
    ) -> dict:
        """
        Exécute un scénario et retourne le résultat.
        
        Args:
            scenario_id: ID du scénario
            input_data: Données d'entrée
            options: Options d'exécution
            
        Returns:
            Dict avec status, logs, output
        """
        result = self.engine.run_scenario(scenario_id, input_data, options)
        return result.to_dict()
    
    def execute(
        self,
        scenario: GEVRScenario,
        input_data: dict = None,
        options: dict = None
    ) -> ScenarioResult:
        """
        Exécute un scénario (objet) et retourne le résultat complet.
        """
        return self.engine.execute(scenario, input_data, options)
    
    def register(self, scenario: GEVRScenario):
        """Enregistre un scénario."""
        self.engine.register_scenario(scenario)
        return self
    
    def create(self, scenario_id: str) -> ScenarioBuilder:
        """
        Crée un nouveau scénario avec un builder.
        
        Usage:
            scenario = (GEVR.create("Scenario.MyScenario")
                .name("My Scenario")
                .get("loadObject", {"id": "..."})
                .build())
        """
        return ScenarioBuilder(scenario_id)
    
    def list_scenarios(self) -> list:
        """Liste les scénarios enregistrés."""
        return list(self.engine.scenarios.keys())
    
    def get_scenario(self, scenario_id: str) -> GEVRScenario:
        """Récupère un scénario par son ID."""
        return self.engine.get_scenario(scenario_id)
    
    def handler(self, action: str, phase: GEVRPhase = None):
        """
        Décorateur pour enregistrer un handler.
        
        Usage:
            @GEVR.handler("myAction", GEVRPhase.EXECUTE)
            def my_handler(params, context):
                ...
        """
        def decorator(func):
            self.engine.register_handler(action, func, phase)
            return func
        return decorator


# Instance globale
GEVR = _GEVRFacade()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Façade
    'GEVR',
    
    # Version
    '__version__',
    
    # Énumérations
    'GEVRPhase',
    'StepStatus',
    'ScenarioStatus',
    
    # Structures
    'StepDefinition',
    'StepResult',
    'GEVRScenario',
    'ScenarioResult',
    'ExecutionContext',
    
    # Builders
    'ScenarioBuilder',
    'create_scenario',
    
    # Handlers
    'ActionHandler',
    'FunctionHandler',
    'HandlerRegistry',
    'register_all_handlers',
    
    # Moteur
    'GEVREngine',
    'get_engine',
    'run_scenario',
    'register_scenario',
    'register_handler',
    
    # Scénarios prédéfinis
    'create_analyze_object_scenario',
    'create_project_skeleton_scenario',
    'create_minimal_scenario',
    'get_predefined_scenarios',
    'register_predefined_scenarios',
    'ANALYZE_OBJECT_JSON',
    'CREATE_PROJECT_SKELETON_JSON',
    
    # Handlers spécialisés (pour extension)
    'handler_load_bundle',
    'handler_load_template',
    'handler_load_rules',
    'handler_run_metarules',
    'handler_apply_erk',
    'handler_transform',
    'handler_create_structure',
    'handler_validate_schema',
    'handler_validate_erk',
    'handler_validate_structure',
    'handler_render_analysis',
    'handler_render_skeleton',
    'handler_render_log',
]
