"""Tests package for eurekai_gen."""
