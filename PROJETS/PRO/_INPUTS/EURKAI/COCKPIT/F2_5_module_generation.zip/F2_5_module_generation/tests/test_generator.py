"""
Tests F2/5 — Module Generator

Ces tests valident le pipeline RESOLVE → TRANSFORM → RENDER.
"""

import pytest
from pathlib import Path

from eurekai_gen import (
    ModuleGenerator,
    GenerationOptions,
    TargetStack,
    FileTree,
)


# ═══════════════════════════════════════════════════════════════════════════════
# FIXTURES
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def minimal_manifest():
    """Manifest minimal avec un seul objet."""
    return {
        "meta": {"name": "Minimal", "version": "1.0.0"},
        "objects": {
            "Item": {
                "identity": {
                    "id": "string",
                    "name": "string"
                }
            }
        }
    }


@pytest.fixture
def task_manifest():
    """Manifest complet avec Task/TaskList."""
    return {
        "meta": {
            "name": "TaskManager",
            "version": "1.0.0",
            "lineage": ["@eurekai/core"]
        },
        "objects": {
            "Task": {
                "identity": {
                    "id": "string",
                    "title": "string",
                    "status": "string",
                    "priority": "int",
                },
                "view": {
                    "methods": [
                        "start() -> void",
                        "complete() -> void",
                    ],
                    "properties": [
                        "is_overdue: bool (computed)"
                    ]
                },
                "context": {
                    "defaults": {
                        "status": "pending",
                        "priority": 0
                    },
                    "validation": {
                        "priority": "[0, 10]"
                    }
                }
            },
            "TaskList": {
                "identity": {
                    "id": "string",
                    "name": "string",
                },
                "relations": [
                    {"defines": "Task"}
                ]
            }
        },
        "scenarios": {
            "CreateTask": {
                "trigger": "user.request",
                "steps": ["validate_input", "create_task", "notify"]
            }
        },
        "meta_rules": [
            "@validate/required: [id, title]",
            "@audit/track_changes"
        ]
    }


@pytest.fixture
def relations_manifest():
    """Manifest avec relations uses/extends."""
    return {
        "meta": {"name": "WithRelations", "version": "1.0.0"},
        "objects": {
            "BaseEntity": {
                "identity": {
                    "id": "string",
                    "created_at": "datetime"
                }
            },
            "User": {
                "identity": {
                    "username": "string",
                    "email": "string"
                },
                "relations": [
                    {"extends": "BaseEntity"}
                ]
            },
            "Order": {
                "identity": {
                    "order_id": "string",
                    "amount": "float"
                },
                "relations": [
                    {"uses": "User"}
                ]
            }
        }
    }


@pytest.fixture
def generator():
    """Générateur avec options par défaut."""
    return ModuleGenerator(GenerationOptions(
        output_dir=Path("/tmp/eurekai_test"),
        generate_tests=True,
    ))


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 1: Manifest Minimal → Structure Minimale
# ═══════════════════════════════════════════════════════════════════════════════

class TestMinimalGeneration:
    """Tests sur un manifest minimal."""
    
    def test_generates_file_tree(self, generator, minimal_manifest):
        """Génère un FileTree valide."""
        tree = generator.generate_modules(minimal_manifest)
        
        assert isinstance(tree, FileTree)
        assert tree.manifest_hash.startswith("sha256:")
        assert len(tree.files) > 0
    
    def test_creates_package_structure(self, generator, minimal_manifest):
        """Crée la structure de package Python."""
        tree = generator.generate_modules(minimal_manifest)
        
        paths = {str(f.path) for f in tree.files}
        
        assert "minimal/__init__.py" in paths
        assert "minimal/models/__init__.py" in paths
        assert "minimal/models/item.py" in paths
    
    def test_model_has_dataclass(self, generator, minimal_manifest):
        """Le modèle généré utilise @dataclass."""
        tree = generator.generate_modules(minimal_manifest)
        
        item_file = tree.get_file("item.py")
        assert item_file is not None
        assert "@dataclass" in item_file.content
        assert "class Item:" in item_file.content
    
    def test_model_has_attributes(self, generator, minimal_manifest):
        """Le modèle a les attributs définis."""
        tree = generator.generate_modules(minimal_manifest)
        
        item_file = tree.get_file("item.py")
        assert "id: str" in item_file.content
        assert "name: str" in item_file.content


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 2: Relations → Imports Corrects
# ═══════════════════════════════════════════════════════════════════════════════

class TestRelationsGeneration:
    """Tests sur les relations entre objets."""
    
    def test_extends_creates_inheritance(self, generator, relations_manifest):
        """La relation 'extends' génère un héritage."""
        tree = generator.generate_modules(relations_manifest)
        
        user_file = tree.get_file("user.py")
        assert user_file is not None
        assert "class User(BaseEntity):" in user_file.content
    
    def test_extends_imports_parent(self, generator, relations_manifest):
        """La relation 'extends' importe la classe parente."""
        tree = generator.generate_modules(relations_manifest)
        
        user_file = tree.get_file("user.py")
        assert "from .base_entity import BaseEntity" in user_file.content


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 3: Scénarios → Scripts GEVR
# ═══════════════════════════════════════════════════════════════════════════════

class TestScenarioGeneration:
    """Tests sur la génération des scénarios."""
    
    def test_scenario_creates_class(self, generator, task_manifest):
        """Les scénarios génèrent des classes."""
        tree = generator.generate_modules(task_manifest)
        
        scenario_file = tree.get_file("create_task.py")
        assert scenario_file is not None
        assert "class CreateTaskScenario:" in scenario_file.content
    
    def test_scenario_has_execute(self, generator, task_manifest):
        """Les scénarios ont une méthode execute."""
        tree = generator.generate_modules(task_manifest)
        
        scenario_file = tree.get_file("create_task.py")
        assert "def execute(self" in scenario_file.content
    
    def test_scenario_has_all_steps(self, generator, task_manifest):
        """Tous les steps sont générés comme méthodes."""
        tree = generator.generate_modules(task_manifest)
        
        scenario_file = tree.get_file("create_task.py")
        assert "def validate_input(" in scenario_file.content
        assert "def create_task(" in scenario_file.content
        assert "def notify(" in scenario_file.content


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 4: View → Interfaces
# ═══════════════════════════════════════════════════════════════════════════════

class TestInterfaceGeneration:
    """Tests sur la génération des interfaces."""
    
    def test_view_creates_protocol(self, generator, task_manifest):
        """La view génère un Protocol."""
        tree = generator.generate_modules(task_manifest)
        
        interface_file = tree.get_file("task_interface.py")
        assert interface_file is not None
        assert "class TaskProtocol(Protocol):" in interface_file.content
    
    def test_view_has_methods(self, generator, task_manifest):
        """L'interface a les méthodes définies."""
        tree = generator.generate_modules(task_manifest)
        
        interface_file = tree.get_file("task_interface.py")
        assert "def start(self)" in interface_file.content
        assert "def complete(self)" in interface_file.content
    
    def test_view_has_properties(self, generator, task_manifest):
        """L'interface a les propriétés définies."""
        tree = generator.generate_modules(task_manifest)
        
        interface_file = tree.get_file("task_interface.py")
        assert "def is_overdue(self)" in interface_file.content
        assert "@property" in interface_file.content


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 5: Context → Config
# ═══════════════════════════════════════════════════════════════════════════════

class TestConfigGeneration:
    """Tests sur la génération des configs."""
    
    def test_context_creates_yaml(self, generator, task_manifest):
        """Le context génère un fichier YAML."""
        tree = generator.generate_modules(task_manifest)
        
        config_file = tree.get_file("task_config.yaml")
        assert config_file is not None
    
    def test_config_has_defaults(self, generator, task_manifest):
        """La config contient les defaults."""
        tree = generator.generate_modules(task_manifest)
        
        config_file = tree.get_file("task_config.yaml")
        assert "status: pending" in config_file.content
        assert "priority: 0" in config_file.content


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 6: MetaRules → Validators
# ═══════════════════════════════════════════════════════════════════════════════

class TestValidatorGeneration:
    """Tests sur la génération des validateurs."""
    
    def test_metarules_create_validators(self, generator, task_manifest):
        """Les meta_rules génèrent des validateurs."""
        tree = generator.generate_modules(task_manifest)
        
        rules_file = tree.get_file("rules.py")
        assert rules_file is not None
    
    def test_required_validator(self, generator, task_manifest):
        """@validate/required génère validate_required."""
        tree = generator.generate_modules(task_manifest)
        
        rules_file = tree.get_file("rules.py")
        assert "def validate_required(" in rules_file.content
    
    def test_audit_decorator(self, generator, task_manifest):
        """@audit/track génère audit_track decorator."""
        tree = generator.generate_modules(task_manifest)
        
        rules_file = tree.get_file("rules.py")
        assert "def audit_track(" in rules_file.content


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 7: Zones Custom
# ═══════════════════════════════════════════════════════════════════════════════

class TestCustomZones:
    """Tests sur les zones générées vs custom."""
    
    def test_has_generated_markers(self, generator, minimal_manifest):
        """Les fichiers ont les marqueurs GENERATED."""
        tree = generator.generate_modules(minimal_manifest)
        
        item_file = tree.get_file("item.py")
        assert "EUREKAI:GENERATED:BEGIN" in item_file.content
        assert "EUREKAI:GENERATED:END" in item_file.content
    
    def test_has_custom_markers(self, generator, minimal_manifest):
        """Les fichiers ont les marqueurs CUSTOM."""
        tree = generator.generate_modules(minimal_manifest)
        
        item_file = tree.get_file("item.py")
        assert "EUREKAI:CUSTOM:BEGIN" in item_file.content
        assert "EUREKAI:CUSTOM:END" in item_file.content


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 8: Preview & Diff
# ═══════════════════════════════════════════════════════════════════════════════

class TestPreviewAndDiff:
    """Tests sur preview et diff."""
    
    def test_preview_returns_dict(self, generator, minimal_manifest):
        """Preview retourne un dict path→content."""
        result = generator.preview(minimal_manifest)
        
        assert isinstance(result, dict)
        assert len(result) > 0
        assert all(isinstance(k, str) for k in result.keys())
        assert all(isinstance(v, str) for v in result.values())
    
    def test_preview_no_side_effects(self, generator, minimal_manifest):
        """Preview ne crée pas de fichiers."""
        # Juste vérifier que ça ne lève pas d'exception
        result = generator.preview(minimal_manifest)
        assert len(result) > 0


# ═══════════════════════════════════════════════════════════════════════════════
# TEST 9: Stats
# ═══════════════════════════════════════════════════════════════════════════════

class TestStats:
    """Tests sur les statistiques de génération."""
    
    def test_tree_has_stats(self, generator, task_manifest):
        """Le FileTree contient des stats."""
        tree = generator.generate_modules(task_manifest)
        
        assert "total_files" in tree.stats
        assert "generated" in tree.stats
        assert tree.stats["total_files"] > 0
    
    def test_to_dict(self, generator, minimal_manifest):
        """FileTree.to_dict() fonctionne."""
        tree = generator.generate_modules(minimal_manifest)
        
        d = tree.to_dict()
        assert "root" in d
        assert "files" in d
        assert "stats" in d


# ═══════════════════════════════════════════════════════════════════════════════
# RUN
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
