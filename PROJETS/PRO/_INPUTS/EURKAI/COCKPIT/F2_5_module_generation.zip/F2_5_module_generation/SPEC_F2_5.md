# F2/5 — Stratégie de Génération de Modules EUREKAI

## 1. STRATÉGIE DE GÉNÉRATION

### 1.1 Principe Fondamental : Projection Fractale → Code

La génération suit le principe **"Le manifest EST le code"** : chaque élément du manifest se projette déterministiquement vers des artefacts concrets.

```
┌─────────────────────────────────────────────────────────────────┐
│                    PIPELINE DE GÉNÉRATION                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   MANIFEST (F1/4)                                               │
│        │                                                        │
│        ▼                                                        │
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐        │
│   │   RESOLVE   │───▶│  TRANSFORM  │───▶│   RENDER    │        │
│   │  (Héritage) │    │  (Mapping)  │    │  (Output)   │        │
│   └─────────────┘    └─────────────┘    └─────────────┘        │
│        │                   │                   │                │
│        ▼                   ▼                   ▼                │
│   Objets résolus     Templates         FileTree               │
│   (flat + merged)    sélectionnés      final                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 Règles de Projection Objet → Module

| Type Manifest | Cible Générée | Pattern Appliqué |
|---------------|---------------|------------------|
| `object` (racine) | Package/Module Python | `__init__.py` + structure |
| `object.identity` | Classe principale | Dataclass ou BaseModel |
| `object.view` | Interface/Protocole | Abstract methods |
| `object.context` | Configuration | YAML/JSON + loader |
| `relation.defines` | Import interne | `from .child import` |
| `relation.uses` | Import externe | `from package import` |
| `relation.extends` | Héritage de classe | `class X(Parent):` |
| `scenario` | Script exécutable | `__main__.py` ou CLI |
| `metarule` | Decorator/Validator | `@validate`, `@enforce` |

### 1.3 Gestion des Zones Générées vs Manuelles

Les fichiers générés utilisent des marqueurs pour délimiter les zones :

- `EUREKAI:GENERATED:BEGIN/END` — Zones écrasées à chaque génération
- `EUREKAI:CUSTOM:BEGIN/END` — Zones préservées et réinjectées

**Stratégie de régénération** :
1. Parser le fichier existant
2. Extraire les zones CUSTOM
3. Régénérer les zones GENERATED
4. Réinjecter les zones CUSTOM
5. Hash de contenu pour détecter les conflits

---

## 2. FORMAT FileTree (RÉSULTAT)

```yaml
FileTree:
  root: "./generated"
  manifest_hash: "sha256:abc123..."
  generated_at: "2025-06-01T10:00:00Z"
  stats:
    total_files: 15
    generated: 12
    preserved: 3
  files:
    - path: "task_manager/__init__.py"
      source_ref: "meta"
      checksum: "sha256:..."
      is_generated: true
    - path: "task_manager/models/task.py"
      source_ref: "objects.Task.identity"
      checksum: "sha256:..."
      is_generated: true
```

---

## 3. CHECKLIST DE VALIDATION

- [x] Stratégie de génération claire et alignée avec la fractale
- [x] Un manifest simple peut donner un squelette de projet cohérent
- [x] Les frontières entre code généré et code humain sont définies
- [x] Exemples + cas de test fournis
