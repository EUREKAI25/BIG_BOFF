"""
F2/5 — Types de base pour la génération de modules EUREKAI.

Ce module définit toutes les structures de données utilisées
par le générateur de modules.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional


# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════════════════════════

class TargetStack(Enum):
    """Stack cible pour la génération."""
    PYTHON = "python"
    NODEJS = "nodejs"
    CONFIG_ONLY = "config"
    FULL_STACK = "fullstack"


class RelationType(Enum):
    """Types de relations entre objets."""
    DEFINES = "defines"
    USES = "uses"
    EXTENDS = "extends"
    IMPLEMENTS = "implements"


# ═══════════════════════════════════════════════════════════════════════════════
# OPTIONS DE GÉNÉRATION
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class GenerationOptions:
    """Options de configuration pour la génération."""
    
    target_stack: TargetStack = TargetStack.PYTHON
    output_dir: Path = field(default_factory=lambda: Path("./generated"))
    preserve_custom: bool = True
    generate_tests: bool = True
    generate_docs: bool = True
    dry_run: bool = False
    
    # Granularité
    include_objects: Optional[List[str]] = None  # None = tous
    exclude_objects: Optional[List[str]] = None
    
    # Templates
    template_overrides: Dict[str, Path] = field(default_factory=dict)
    
    def __post_init__(self):
        if isinstance(self.output_dir, str):
            self.output_dir = Path(self.output_dir)


# ═══════════════════════════════════════════════════════════════════════════════
# STRUCTURES DE FICHIERS
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class FileNode:
    """Nœud dans l'arbre de fichiers généré."""
    
    path: Path
    content: str
    is_generated: bool = True
    source_ref: Optional[str] = None  # Référence manifest (ex: "objects.Task.identity")
    checksum: Optional[str] = None
    
    def __post_init__(self):
        if isinstance(self.path, str):
            self.path = Path(self.path)


@dataclass
class FileTree:
    """Résultat complet de la génération."""
    
    root: Path
    files: List[FileNode]
    manifest_hash: str
    generated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    stats: Dict[str, int] = field(default_factory=dict)
    
    def __post_init__(self):
        if isinstance(self.root, str):
            self.root = Path(self.root)
        
        # Calcul des stats si non fournies
        if not self.stats:
            self.stats = {
                "total_files": len(self.files),
                "generated": sum(1 for f in self.files if f.is_generated),
                "preserved": sum(1 for f in self.files if not f.is_generated),
            }
    
    def to_dict(self) -> Dict[str, Any]:
        """Sérialise le FileTree en dictionnaire."""
        return {
            "root": str(self.root),
            "manifest_hash": self.manifest_hash,
            "generated_at": self.generated_at,
            "stats": self.stats,
            "files": [
                {
                    "path": str(f.path),
                    "source_ref": f.source_ref,
                    "checksum": f.checksum,
                    "is_generated": f.is_generated,
                }
                for f in self.files
            ]
        }
    
    def get_file(self, path: str) -> Optional[FileNode]:
        """Récupère un fichier par son chemin."""
        for f in self.files:
            if str(f.path) == path or f.path.name == path:
                return f
        return None


@dataclass
class FileDiff:
    """Différence entre deux versions d'un fichier."""
    
    path: Path
    status: Literal["added", "modified", "deleted", "unchanged"]
    old_checksum: Optional[str] = None
    new_checksum: Optional[str] = None
    changes: Optional[str] = None  # Diff textuel


# ═══════════════════════════════════════════════════════════════════════════════
# SPÉCIFICATIONS INTERMÉDIAIRES (IVC)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class AttributeSpec:
    """Spécification d'un attribut."""
    
    name: str
    type_hint: str
    default: Optional[Any] = None
    required: bool = True
    description: Optional[str] = None


@dataclass
class MethodSpec:
    """Spécification d'une méthode."""
    
    name: str
    parameters: List[AttributeSpec] = field(default_factory=list)
    return_type: str = "None"
    is_async: bool = False
    description: Optional[str] = None


@dataclass
class PropertySpec:
    """Spécification d'une propriété."""
    
    name: str
    type_hint: str
    computed: bool = False
    readonly: bool = True
    description: Optional[str] = None


@dataclass
class EventSpec:
    """Spécification d'un événement."""
    
    name: str
    payload_type: Optional[str] = None
    description: Optional[str] = None


@dataclass
class IdentitySpec:
    """Spécification de l'identité (→ classe)."""
    
    class_name: str
    attributes: List[AttributeSpec] = field(default_factory=list)
    base_classes: List[str] = field(default_factory=list)


@dataclass
class ViewSpec:
    """Spécification de la vue (→ interface/protocole)."""
    
    methods: List[MethodSpec] = field(default_factory=list)
    properties: List[PropertySpec] = field(default_factory=list)
    events: List[EventSpec] = field(default_factory=list)


@dataclass
class ContextSpec:
    """Spécification du contexte (→ config)."""
    
    config_schema: Dict[str, Any] = field(default_factory=dict)
    defaults: Dict[str, Any] = field(default_factory=dict)
    env_mappings: Dict[str, str] = field(default_factory=dict)
    validation_rules: Dict[str, str] = field(default_factory=dict)


@dataclass
class DependencySpec:
    """Spécification d'une dépendance."""
    
    target: str
    relation_type: RelationType
    import_as: Optional[str] = None
    optional: bool = False


@dataclass
class ModuleSpec:
    """Spécification complète d'un module à générer."""
    
    name: str
    qualified_name: str  # ex: "eurekai.core.entity"
    source_object: str   # Chemin dans le manifest
    
    # IVC décomposé
    identity: IdentitySpec
    view: Optional[ViewSpec] = None
    context: Optional[ContextSpec] = None
    
    # Relations
    dependencies: List[DependencySpec] = field(default_factory=list)
    children: List[str] = field(default_factory=list)
    
    # Métadonnées
    lineage: List[str] = field(default_factory=list)
    meta_rules: List[str] = field(default_factory=list)


@dataclass
class ScenarioSpec:
    """Spécification d'un scénario."""
    
    name: str
    trigger: str
    steps: List[str]
    source_ref: str
    
    # Dépendances inférées
    required_objects: List[str] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════════════════
# MANIFEST RÉSOLU
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ResolvedManifest:
    """Manifest après résolution de l'héritage et des références."""
    
    name: str
    version: str
    modules: List[ModuleSpec]
    scenarios: List[ScenarioSpec]
    meta_rules: List[str]
    lineage: List[str]
    
    # Métadonnées
    original_hash: str
    resolved_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
