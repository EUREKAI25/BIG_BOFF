"""
EUREKAI Module Generator — F2/5

Génère du code à partir d'un manifest fractal.

Usage:
    from eurekai_gen import ModuleGenerator, GenerationOptions, TargetStack
    
    generator = ModuleGenerator()
    tree = generator.generate_modules(manifest, TargetStack.PYTHON)
"""

from .types import (
    AttributeSpec,
    ContextSpec,
    DependencySpec,
    FileDiff,
    FileNode,
    FileTree,
    GenerationOptions,
    IdentitySpec,
    MethodSpec,
    ModuleSpec,
    PropertySpec,
    RelationType,
    ResolvedManifest,
    ScenarioSpec,
    TargetStack,
    ViewSpec,
)
from .generator import ModuleGenerator

__version__ = "0.1.0"
__all__ = [
    # Main
    "ModuleGenerator",
    # Options
    "GenerationOptions",
    "TargetStack",
    # Types
    "FileTree",
    "FileNode",
    "FileDiff",
    "ModuleSpec",
    "ResolvedManifest",
    # IVC Specs
    "IdentitySpec",
    "ViewSpec",
    "ContextSpec",
    "AttributeSpec",
    "MethodSpec",
    "PropertySpec",
    "DependencySpec",
    "RelationType",
    "ScenarioSpec",
]
