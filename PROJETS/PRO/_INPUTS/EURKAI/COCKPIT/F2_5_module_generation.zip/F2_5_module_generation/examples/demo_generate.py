#!/usr/bin/env python3
"""
F2/5 — Démonstration du générateur de modules EUREKAI.

Ce script montre comment utiliser le ModuleGenerator
pour générer un projet Python à partir d'un manifest.

Usage:
    python demo_generate.py
"""

import sys
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from eurekai_gen import ModuleGenerator, GenerationOptions, TargetStack


def main():
    """Exécute la démonstration."""
    
    print("=" * 70)
    print("F2/5 — EUREKAI Module Generator Demo")
    print("=" * 70)
    print()
    
    # ─────────────────────────────────────────────────────────────────────────
    # Définition du manifest
    # ─────────────────────────────────────────────────────────────────────────
    
    manifest = {
        "meta": {
            "name": "TaskManager",
            "version": "1.0.0",
            "lineage": ["@eurekai/core"]
        },
        "objects": {
            "Task": {
                "identity": {
                    "id": "string",
                    "title": "string",
                    "status": "string",
                    "priority": "int",
                    "created_at": "datetime",
                },
                "view": {
                    "methods": [
                        "start() -> void",
                        "complete() -> void",
                        "cancel() -> void",
                    ],
                    "properties": [
                        "is_overdue: bool (computed)",
                    ]
                },
                "context": {
                    "defaults": {
                        "status": "pending",
                        "priority": 0
                    },
                    "validation": {
                        "priority": "[0, 10]"
                    }
                }
            },
            "TaskList": {
                "identity": {
                    "id": "string",
                    "name": "string",
                },
                "view": {
                    "methods": [
                        "add_task(task: Task) -> void",
                        "remove_task(task_id: string) -> bool",
                    ]
                },
                "relations": [
                    {"defines": "Task"}
                ]
            }
        },
        "scenarios": {
            "CreateTask": {
                "trigger": "user.request",
                "steps": ["validate_input", "create_task", "add_to_list", "notify"]
            }
        },
        "meta_rules": [
            "@validate/required: [id, title]",
            "@audit/track_changes"
        ]
    }
    
    # ─────────────────────────────────────────────────────────────────────────
    # Configuration du générateur
    # ─────────────────────────────────────────────────────────────────────────
    
    options = GenerationOptions(
        target_stack=TargetStack.PYTHON,
        output_dir=Path("./generated_output"),
        generate_tests=True,
        generate_docs=True,
    )
    
    generator = ModuleGenerator(options)
    
    # ─────────────────────────────────────────────────────────────────────────
    # Génération
    # ─────────────────────────────────────────────────────────────────────────
    
    print("📦 Génération des modules...")
    print()
    
    tree = generator.generate_modules(manifest)
    
    # ─────────────────────────────────────────────────────────────────────────
    # Affichage des résultats
    # ─────────────────────────────────────────────────────────────────────────
    
    print(f"✅ Génération terminée!")
    print(f"   Root: {tree.root}")
    print(f"   Hash: {tree.manifest_hash}")
    print(f"   Date: {tree.generated_at}")
    print()
    
    print("📊 Statistiques:")
    for key, value in tree.stats.items():
        print(f"   {key}: {value}")
    print()
    
    print("📁 Fichiers générés:")
    print("-" * 70)
    
    for file_node in sorted(tree.files, key=lambda f: str(f.path)):
        print(f"   {file_node.path}")
        print(f"      ← {file_node.source_ref}")
    
    print("-" * 70)
    print()
    
    # ─────────────────────────────────────────────────────────────────────────
    # Affichage d'un exemple de fichier
    # ─────────────────────────────────────────────────────────────────────────
    
    print("📄 Exemple: task.py")
    print("=" * 70)
    
    task_file = tree.get_file("task.py")
    if task_file:
        print(task_file.content)
    
    print("=" * 70)
    print()
    
    # ─────────────────────────────────────────────────────────────────────────
    # Affichage du scénario
    # ─────────────────────────────────────────────────────────────────────────
    
    print("📄 Exemple: create_task.py (scénario)")
    print("=" * 70)
    
    scenario_file = tree.get_file("create_task.py")
    if scenario_file:
        print(scenario_file.content)
    
    print("=" * 70)
    print()
    
    # ─────────────────────────────────────────────────────────────────────────
    # Export JSON
    # ─────────────────────────────────────────────────────────────────────────
    
    print("📋 FileTree as JSON:")
    print("-" * 70)
    
    import json
    print(json.dumps(tree.to_dict(), indent=2))
    
    print("-" * 70)
    print()
    print("✨ Demo complete!")


if __name__ == "__main__":
    main()
