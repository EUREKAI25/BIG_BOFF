"""
EUREKAI D3/6 — SuperTool Orchestrate (Superviseur de Scénarios)
================================================================

Ce module implémente l'**Orchestrateur GEVR**, le chef d'orchestre logique
qui supervise l'exécution des scénarios GEVR.

Rôle d'Orchestrate:
- Sélectionner le scénario adapté au contexte
- Chaîner les scénarios (séquentiellement ou conditionnellement)
- Gérer les erreurs et les manques d'information
- Produire des logs compréhensibles à chaque étape

Architecture:
- Orchestrate: Superviseur principal
- OrchestrationPlan: Plan d'exécution des scénarios
- OrchestrationResult: Résultat complet de l'orchestration
- ScenarioSelector: Logique de sélection contextuelle
- ErrorHandler: Gestion intelligente des erreurs

Version: D3/6 - Orchestrate (Superviseur de scénarios)
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import (
    Dict, Any, Optional, Callable, List, 
    Type, TypeVar, Union, Tuple, Set
)
from datetime import datetime
from enum import Enum, auto
import time
import traceback
import json
import re


# =============================================================================
# ÉNUMÉRATIONS
# =============================================================================

class RequestType(Enum):
    """Types de requêtes que l'Orchestrate peut traiter."""
    IDEA = "idea"                      # Idée simple (phrase courte)
    BRIEF = "brief"                    # Brief structuré
    TRANSFORM = "transform"            # Transformation d'un projet existant
    ENRICH = "enrich"                  # Enrichissement d'un projet
    ANALYZE = "analyze"                # Analyse d'un objet/projet
    VALIDATE = "validate"              # Validation seule
    GENERATE = "generate"              # Génération de code/artefacts
    DEPLOY = "deploy"                  # Déploiement
    COMPOSITE = "composite"            # Requête composite (multi-scénarios)
    UNKNOWN = "unknown"                # Non déterminé


class OrchestrationStatus(Enum):
    """Statuts possibles de l'orchestration."""
    PENDING = "pending"
    PLANNING = "planning"
    RUNNING = "running"
    WAITING_INPUT = "waiting_input"    # En attente d'infos supplémentaires
    COMPLETED = "completed"
    PARTIAL = "partial"                # Partiellement complété
    FAILED = "failed"
    ABORTED = "aborted"


class ErrorRecoveryAction(Enum):
    """Actions possibles en cas d'erreur."""
    RETRY = "retry"                    # Réessayer le scénario
    SKIP = "skip"                      # Ignorer et continuer
    FALLBACK = "fallback"              # Utiliser un scénario alternatif
    REQUEST_INFO = "request_info"       # Demander des informations
    PROPOSE_HYPOTHESIS = "propose"      # Proposer des hypothèses
    ABORT = "abort"                    # Arrêter l'orchestration


# =============================================================================
# STRUCTURES DE DONNÉES
# =============================================================================

@dataclass
class MissingInfo:
    """Information manquante détectée."""
    field: str                          # Champ manquant
    description: str                    # Description humaine
    required: bool = True               # Obligatoire ou optionnel
    suggestions: List[str] = field(default_factory=list)  # Suggestions
    default: Any = None                 # Valeur par défaut si optionnel
    
    def to_dict(self) -> Dict:
        return {
            "field": self.field,
            "description": self.description,
            "required": self.required,
            "suggestions": self.suggestions,
            "default": self.default
        }


@dataclass
class Hypothesis:
    """Hypothèse proposée par l'Orchestrate."""
    field: str
    value: Any
    confidence: float                   # 0.0 - 1.0
    reasoning: str                      # Justification
    
    def to_dict(self) -> Dict:
        return {
            "field": self.field,
            "value": self.value,
            "confidence": self.confidence,
            "reasoning": self.reasoning
        }


@dataclass
class ScenarioExecution:
    """Résultat d'exécution d'un scénario individuel."""
    scenario_id: str
    status: str                         # "success", "failed", "skipped"
    result: Any = None
    error: Optional[str] = None
    duration_ms: float = 0
    logs: List[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict:
        return {
            "scenario_id": self.scenario_id,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "logs": self.logs,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None
        }
    
    @property
    def ok(self) -> bool:
        return self.status == "success"


@dataclass
class OrchestrationPlan:
    """Plan d'exécution des scénarios."""
    scenarios: List[str]                # IDs des scénarios à exécuter
    dependencies: Dict[str, List[str]]  # Dépendances entre scénarios
    conditions: Dict[str, str]          # Conditions d'exécution
    fallbacks: Dict[str, str]           # Scénarios de repli
    parallel_groups: List[List[str]]    # Groupes parallélisables
    
    def to_dict(self) -> Dict:
        return {
            "scenarios": self.scenarios,
            "dependencies": self.dependencies,
            "conditions": self.conditions,
            "fallbacks": self.fallbacks,
            "parallel_groups": self.parallel_groups
        }
    
    @classmethod
    def simple(cls, scenario_id: str) -> 'OrchestrationPlan':
        """Crée un plan simple avec un seul scénario."""
        return cls(
            scenarios=[scenario_id],
            dependencies={},
            conditions={},
            fallbacks={},
            parallel_groups=[]
        )
    
    @classmethod
    def chain(cls, *scenario_ids: str) -> 'OrchestrationPlan':
        """Crée un plan de scénarios chaînés."""
        scenarios = list(scenario_ids)
        dependencies = {}
        for i in range(1, len(scenarios)):
            dependencies[scenarios[i]] = [scenarios[i-1]]
        return cls(
            scenarios=scenarios,
            dependencies=dependencies,
            conditions={},
            fallbacks={},
            parallel_groups=[]
        )


@dataclass
class OrchestrationResult:
    """Résultat complet de l'orchestration."""
    status: OrchestrationStatus
    request_type: RequestType
    plan: Optional[OrchestrationPlan] = None
    
    # Résultats des scénarios
    executions: List[ScenarioExecution] = field(default_factory=list)
    final_output: Any = None
    
    # Logs et erreurs
    logs: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Info manquantes / hypothèses
    missing_info: List[MissingInfo] = field(default_factory=list)
    hypotheses: List[Hypothesis] = field(default_factory=list)
    
    # Métriques
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict:
        return {
            "status": self.status.value,
            "request_type": self.request_type.value,
            "plan": self.plan.to_dict() if self.plan else None,
            "executions": [e.to_dict() for e in self.executions],
            "final_output": self.final_output,
            "logs": self.logs,
            "errors": self.errors,
            "warnings": self.warnings,
            "missing_info": [m.to_dict() for m in self.missing_info],
            "hypotheses": [h.to_dict() for h in self.hypotheses],
            "duration_ms": self.duration_ms,
            "summary": self.summary()
        }
    
    @property
    def duration_ms(self) -> float:
        if not self.completed_at:
            return 0
        delta = self.completed_at - self.started_at
        return delta.total_seconds() * 1000
    
    @property
    def ok(self) -> bool:
        return self.status == OrchestrationStatus.COMPLETED
    
    def summary(self) -> Dict:
        """Résumé de l'orchestration."""
        return {
            "status": self.status.value,
            "scenarios_executed": len(self.executions),
            "scenarios_succeeded": sum(1 for e in self.executions if e.ok),
            "scenarios_failed": sum(1 for e in self.executions if e.status == "failed"),
            "missing_info_count": len(self.missing_info),
            "hypotheses_count": len(self.hypotheses),
            "duration_ms": self.duration_ms
        }
    
    def add_log(self, message: str):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        self.logs.append(f"{timestamp} [ORCHESTRATE] {message}")


# =============================================================================
# CATALOGUE DE SCÉNARIOS
# =============================================================================

@dataclass
class ScenarioCatalogEntry:
    """Entrée du catalogue de scénarios."""
    id: str
    name: str
    description: str
    request_types: List[RequestType]     # Types de requêtes supportés
    input_schema: Dict[str, Any]         # Schéma d'entrée attendu
    output_schema: Dict[str, Any]        # Schéma de sortie
    tags: List[str] = field(default_factory=list)
    priority: int = 0                    # Priorité en cas de match multiple
    requires: List[str] = field(default_factory=list)  # Scénarios prérequis
    provides: List[str] = field(default_factory=list)  # Ce que le scénario produit
    
    def matches_request(self, request_type: RequestType, context: Dict) -> float:
        """Calcule un score de correspondance (0.0 - 1.0)."""
        if request_type not in self.request_types:
            return 0.0
        
        score = 0.5  # Base pour le type correspondant
        
        # Bonus pour les tags matchés
        context_tags = context.get("tags", [])
        matched_tags = set(self.tags) & set(context_tags)
        if matched_tags:
            score += 0.2 * (len(matched_tags) / max(len(self.tags), 1))
        
        # Bonus pour la priorité
        score += 0.1 * min(self.priority / 10, 1.0)
        
        # Vérifier les inputs requis
        for key in self.input_schema.get("required", []):
            if key in context:
                score += 0.05
        
        return min(score, 1.0)


class ScenarioCatalog:
    """Catalogue des scénarios disponibles."""
    
    def __init__(self):
        self._entries: Dict[str, ScenarioCatalogEntry] = {}
        self._by_type: Dict[RequestType, List[str]] = {t: [] for t in RequestType}
        self._register_default_scenarios()
    
    def register(self, entry: ScenarioCatalogEntry):
        """Enregistre un scénario dans le catalogue."""
        self._entries[entry.id] = entry
        for rt in entry.request_types:
            if entry.id not in self._by_type[rt]:
                self._by_type[rt].append(entry.id)
    
    def get(self, scenario_id: str) -> Optional[ScenarioCatalogEntry]:
        """Récupère une entrée du catalogue."""
        return self._entries.get(scenario_id)
    
    def find_best_match(
        self, 
        request_type: RequestType, 
        context: Dict
    ) -> Optional[str]:
        """Trouve le meilleur scénario pour une requête."""
        candidates = self._by_type.get(request_type, [])
        if not candidates:
            return None
        
        scored = []
        for sid in candidates:
            entry = self._entries[sid]
            score = entry.matches_request(request_type, context)
            if score > 0:
                scored.append((sid, score))
        
        if not scored:
            return None
        
        # Trier par score décroissant
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[0][0]
    
    def find_all_matches(
        self, 
        request_type: RequestType, 
        context: Dict,
        min_score: float = 0.3
    ) -> List[Tuple[str, float]]:
        """Trouve tous les scénarios correspondants."""
        candidates = self._by_type.get(request_type, [])
        matches = []
        
        for sid in candidates:
            entry = self._entries[sid]
            score = entry.matches_request(request_type, context)
            if score >= min_score:
                matches.append((sid, score))
        
        matches.sort(key=lambda x: x[1], reverse=True)
        return matches
    
    def list_scenarios(self) -> List[str]:
        """Liste tous les scénarios."""
        return list(self._entries.keys())
    
    def _register_default_scenarios(self):
        """Enregistre les scénarios par défaut."""
        
        # Scénario principal: ProjetEURKAI
        self.register(ScenarioCatalogEntry(
            id="Scenario.ProjetEURKAI",
            name="Projet EURKAI",
            description="Transforme une idée en projet EURKAI structuré",
            request_types=[RequestType.IDEA, RequestType.BRIEF],
            input_schema={
                "type": "object",
                "required": ["data"],
                "properties": {
                    "data": {"type": "string", "description": "Idée ou brief"}
                }
            },
            output_schema={"type": "object"},
            tags=["project", "creation", "core"],
            priority=10,
            provides=["project"]
        ))
        
        # Scénario d'analyse
        self.register(ScenarioCatalogEntry(
            id="Scenario.AnalyzeObject",
            name="Analyse d'objet",
            description="Analyse un objet EURKAI et produit un rapport",
            request_types=[RequestType.ANALYZE],
            input_schema={
                "type": "object",
                "required": ["object_id"],
                "properties": {
                    "object_id": {"type": "string"}
                }
            },
            output_schema={"type": "object"},
            tags=["analysis", "object"],
            priority=5,
            provides=["analysis_report"]
        ))
        
        # Scénario de validation
        self.register(ScenarioCatalogEntry(
            id="Scenario.ValidateProject",
            name="Validation de projet",
            description="Valide la cohérence d'un projet EURKAI",
            request_types=[RequestType.VALIDATE],
            input_schema={
                "type": "object",
                "required": ["project"],
                "properties": {
                    "project": {"type": "object"}
                }
            },
            output_schema={"type": "object"},
            tags=["validation", "project"],
            priority=5,
            requires=["project"],
            provides=["validation_report"]
        ))
        
        # Scénario de squelette de projet
        self.register(ScenarioCatalogEntry(
            id="Scenario.CreateProjectSkeleton",
            name="Créer squelette de projet",
            description="Crée la structure de fichiers d'un projet",
            request_types=[RequestType.GENERATE],
            input_schema={
                "type": "object",
                "required": ["project"],
                "properties": {
                    "project": {"type": "object"},
                    "target_path": {"type": "string"}
                }
            },
            output_schema={"type": "object"},
            tags=["generation", "skeleton", "files"],
            priority=5,
            requires=["project"],
            provides=["project_skeleton"]
        ))
        
        # Scénario d'enrichissement
        self.register(ScenarioCatalogEntry(
            id="Scenario.EnrichProject",
            name="Enrichir projet",
            description="Ajoute des objets/relations à un projet existant",
            request_types=[RequestType.ENRICH],
            input_schema={
                "type": "object",
                "required": ["project", "additions"],
                "properties": {
                    "project": {"type": "object"},
                    "additions": {"type": "object"}
                }
            },
            output_schema={"type": "object"},
            tags=["enrichment", "project"],
            priority=5,
            requires=["project"],
            provides=["project"]
        ))
        
        # Scénario de transformation
        self.register(ScenarioCatalogEntry(
            id="Scenario.TransformProject",
            name="Transformer projet",
            description="Applique une transformation à un projet",
            request_types=[RequestType.TRANSFORM],
            input_schema={
                "type": "object",
                "required": ["project", "transformation"],
                "properties": {
                    "project": {"type": "object"},
                    "transformation": {"type": "object"}
                }
            },
            output_schema={"type": "object"},
            tags=["transform", "project"],
            priority=5,
            requires=["project"],
            provides=["project"]
        ))
        
        # Scénario de déploiement
        self.register(ScenarioCatalogEntry(
            id="Scenario.DeployProject",
            name="Déployer projet",
            description="Prépare et déploie un projet",
            request_types=[RequestType.DEPLOY],
            input_schema={
                "type": "object",
                "required": ["project", "target"],
                "properties": {
                    "project": {"type": "object"},
                    "target": {"type": "string"}
                }
            },
            output_schema={"type": "object"},
            tags=["deploy", "project"],
            priority=5,
            requires=["project", "project_skeleton"],
            provides=["deployment"]
        ))


# =============================================================================
# SÉLECTEUR DE SCÉNARIOS
# =============================================================================

class ScenarioSelector:
    """Logique de sélection de scénarios basée sur le contexte."""
    
    def __init__(self, catalog: ScenarioCatalog):
        self.catalog = catalog
        self._patterns: List[Tuple[str, RequestType]] = [
            # Patterns de détection de type de requête (ordre important: spécifiques d'abord)
            (r"(transform|convert|modifi|chang)", RequestType.TRANSFORM),
            (r"(enrichi|ajout|add|extend|étendre|ajouter)", RequestType.ENRICH),
            (r"(analy[sz]|examin|inspect|étudi)", RequestType.ANALYZE),
            (r"(valid|vérifi|check|test)", RequestType.VALIDATE),
            (r"(génér|generat|produi|create.*code)", RequestType.GENERATE),
            (r"(deploy|déploy|déploie|publish|release)", RequestType.DEPLOY),
            (r"(brief|cahier des charges|spec)", RequestType.BRIEF),
            (r"(créer?|nouveau|new|create|make).*?(projet|project|app)", RequestType.IDEA),
            (r"(je veux|i want|build|construire)", RequestType.IDEA),
        ]
    
    def detect_request_type(self, request: Any) -> RequestType:
        """Détecte le type de requête."""
        # Si c'est un dict avec un type explicite
        if isinstance(request, dict):
            if "type" in request:
                try:
                    return RequestType(request["type"])
                except ValueError:
                    pass
            
            # Détecter par structure
            if "project" in request and "transformation" in request:
                return RequestType.TRANSFORM
            if "project" in request and "additions" in request:
                return RequestType.ENRICH
            if "project" in request and "target" in request:
                return RequestType.DEPLOY
            if "object_id" in request:
                return RequestType.ANALYZE
            if "brief" in request or len(str(request)) > 200:
                return RequestType.BRIEF
        
        # Analyser le texte
        text = str(request).lower()
        
        for pattern, req_type in self._patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return req_type
        
        # Par défaut: idée simple
        if len(text) < 200:
            return RequestType.IDEA
        
        return RequestType.BRIEF
    
    def select_scenarios(
        self, 
        request: Any,
        context: Dict = None
    ) -> OrchestrationPlan:
        """
        Sélectionne les scénarios à exécuter.
        
        Returns:
            OrchestrationPlan avec les scénarios sélectionnés
        """
        context = context or {}
        request_type = self.detect_request_type(request)
        
        # Mettre à jour le contexte avec la requête
        if isinstance(request, dict):
            context.update(request)
        elif isinstance(request, str):
            context["data"] = request
        
        # Trouver les scénarios correspondants
        matches = self.catalog.find_all_matches(request_type, context)
        
        if not matches:
            # Fallback sur ProjetEURKAI pour IDEA/BRIEF
            if request_type in [RequestType.IDEA, RequestType.BRIEF]:
                return OrchestrationPlan.simple("Scenario.ProjetEURKAI")
            return OrchestrationPlan(
                scenarios=[],
                dependencies={},
                conditions={},
                fallbacks={},
                parallel_groups=[]
            )
        
        # Construire le plan
        primary = matches[0][0]
        entry = self.catalog.get(primary)
        
        # Vérifier les prérequis
        scenarios = []
        dependencies = {}
        
        if entry and entry.requires:
            # Ajouter les scénarios prérequis
            for req in entry.requires:
                # Chercher un scénario qui fournit ce prérequis
                for sid, e in self.catalog._entries.items():
                    if req in e.provides and sid != primary:
                        if sid not in scenarios:
                            scenarios.append(sid)
                        break
        
        scenarios.append(primary)
        
        # Définir les dépendances
        if len(scenarios) > 1:
            dependencies[primary] = scenarios[:-1]
        
        return OrchestrationPlan(
            scenarios=scenarios,
            dependencies=dependencies,
            conditions={},
            fallbacks={},
            parallel_groups=[]
        )


# =============================================================================
# GESTIONNAIRE D'ERREURS
# =============================================================================

class ErrorHandler:
    """Gestion intelligente des erreurs."""
    
    def __init__(self, catalog: ScenarioCatalog):
        self.catalog = catalog
        self.max_retries = 2
        self._retry_counts: Dict[str, int] = {}
    
    def handle_error(
        self,
        scenario_id: str,
        error: str,
        context: Dict
    ) -> Tuple[ErrorRecoveryAction, Optional[Dict]]:
        """
        Détermine l'action de récupération appropriée.
        
        Returns:
            (action, données_additionnelles)
        """
        # Vérifier le nombre de retries
        key = f"{scenario_id}:{hash(error)}"
        self._retry_counts[key] = self._retry_counts.get(key, 0) + 1
        
        if self._retry_counts[key] <= self.max_retries:
            # Analyser l'erreur pour décider
            error_lower = error.lower()
            
            # Erreur de données manquantes
            if any(kw in error_lower for kw in ["missing", "required", "manquant", "requis", "undefined"]):
                missing = self._extract_missing_field(error)
                if missing:
                    return ErrorRecoveryAction.REQUEST_INFO, {"missing": missing}
            
            # Erreur de validation
            if any(kw in error_lower for kw in ["invalid", "validation", "invalide"]):
                return ErrorRecoveryAction.PROPOSE_HYPOTHESIS, {"error": error}
            
            # Erreur temporaire (retry)
            if any(kw in error_lower for kw in ["timeout", "connection", "temporary"]):
                return ErrorRecoveryAction.RETRY, None
        
        # Chercher un fallback
        entry = self.catalog.get(scenario_id)
        if entry:
            # Chercher un scénario alternatif
            for alt_id, alt_entry in self.catalog._entries.items():
                if (alt_id != scenario_id and 
                    set(entry.provides) & set(alt_entry.provides) and
                    set(entry.request_types) & set(alt_entry.request_types)):
                    return ErrorRecoveryAction.FALLBACK, {"fallback_id": alt_id}
        
        # En dernier recours
        return ErrorRecoveryAction.ABORT, {"error": error}
    
    def _extract_missing_field(self, error: str) -> Optional[MissingInfo]:
        """Extrait les informations sur le champ manquant."""
        patterns = [
            r"missing[:\s]+['\"]?(\w+)['\"]?",
            r"required[:\s]+['\"]?(\w+)['\"]?",
            r"['\"](\w+)['\"].*(?:is required|manquant)",
        ]
        
        for pattern in patterns:
            match = re.search(pattern, error, re.IGNORECASE)
            if match:
                field = match.group(1)
                return MissingInfo(
                    field=field,
                    description=f"Le champ '{field}' est requis",
                    required=True
                )
        
        return None
    
    def reset_retries(self, scenario_id: str = None):
        """Réinitialise les compteurs de retry."""
        if scenario_id:
            keys = [k for k in self._retry_counts if k.startswith(scenario_id)]
            for k in keys:
                del self._retry_counts[k]
        else:
            self._retry_counts.clear()


# =============================================================================
# ORCHESTRATEUR PRINCIPAL
# =============================================================================

class Orchestrate:
    """
    SuperTool Orchestrate: Chef d'orchestre des scénarios GEVR.
    
    Orchestrate est le contrôleur central qui:
    - Analyse les requêtes entrantes
    - Sélectionne les scénarios appropriés
    - Gère l'exécution séquentielle/parallèle
    - Traite les erreurs intelligemment
    - Demande des compléments si nécessaire
    
    Usage:
        orchestrate = Orchestrate(engine)
        result = orchestrate.run("Je veux un blog sur la créativité")
        
        if result.ok:
            project = result.final_output
        elif result.status == OrchestrationStatus.WAITING_INPUT:
            missing = result.missing_info
            # Demander les infos manquantes à l'utilisateur
    """
    
    VERSION = "1.0.0"
    
    def __init__(
        self,
        engine = None,
        options: Dict[str, Any] = None
    ):
        """
        Initialise l'Orchestrateur.
        
        Args:
            engine: Instance de GEVREngine (optionnel)
            options: Options de configuration
                - strict: Mode strict (erreur = arrêt)
                - auto_hypothesis: Proposer des hypothèses automatiquement
                - max_retries: Nombre max de retries par scénario
                - timeout: Timeout global en secondes
        """
        self.engine = engine
        self.options = options or {}
        
        # Configuration
        self.strict = self.options.get("strict", False)
        self.auto_hypothesis = self.options.get("auto_hypothesis", True)
        self.max_retries = self.options.get("max_retries", 2)
        self.timeout = self.options.get("timeout", 300)
        
        # Composants
        self.catalog = ScenarioCatalog()
        self.selector = ScenarioSelector(self.catalog)
        self.error_handler = ErrorHandler(self.catalog)
        
        # État
        self._current_result: Optional[OrchestrationResult] = None
    
    def run(self, request: Any) -> OrchestrationResult:
        """
        Point d'entrée principal de l'Orchestrateur.
        
        Args:
            request: La requête à traiter, peut être:
                - Une chaîne (idée ou brief)
                - Un dict (requête structurée)
                - Un dict avec {"project": ..., "transformation": ...}
                
        Returns:
            OrchestrationResult complet
        """
        # Initialiser le résultat
        result = OrchestrationResult(
            status=OrchestrationStatus.PLANNING,
            request_type=RequestType.UNKNOWN
        )
        self._current_result = result
        
        result.add_log(f"Démarrage Orchestrate v{self.VERSION}")
        result.add_log(f"Requête reçue: {type(request).__name__}")
        
        try:
            # Phase 1: Détection du type de requête
            request_type = self.selector.detect_request_type(request)
            result.request_type = request_type
            result.add_log(f"Type de requête détecté: {request_type.value}")
            
            # Phase 2: Sélection des scénarios
            context = self._build_context(request)
            plan = self.selector.select_scenarios(request, context)
            result.plan = plan
            
            if not plan.scenarios:
                result.add_log("Aucun scénario trouvé pour cette requête")
                result.status = OrchestrationStatus.FAILED
                result.errors.append("Aucun scénario applicable trouvé")
                result.completed_at = datetime.now()
                return result
            
            result.add_log(f"Plan d'exécution: {' -> '.join(plan.scenarios)}")
            
            # Phase 3: Exécution des scénarios
            result.status = OrchestrationStatus.RUNNING
            self._execute_plan(plan, context, result)
            
            # Phase 4: Finalisation
            if result.status == OrchestrationStatus.RUNNING:
                if all(e.ok for e in result.executions):
                    result.status = OrchestrationStatus.COMPLETED
                elif any(e.ok for e in result.executions):
                    result.status = OrchestrationStatus.PARTIAL
                else:
                    result.status = OrchestrationStatus.FAILED
            
            # Extraire la sortie finale
            if result.executions:
                last_success = next(
                    (e for e in reversed(result.executions) if e.ok),
                    None
                )
                if last_success:
                    result.final_output = last_success.result
            
            result.add_log(f"Orchestration terminée: {result.status.value}")
            
        except Exception as e:
            result.status = OrchestrationStatus.FAILED
            result.errors.append(f"Erreur d'orchestration: {str(e)}")
            result.add_log(f"ERREUR: {str(e)}")
            if self.options.get("debug"):
                result.add_log(traceback.format_exc())
        
        result.completed_at = datetime.now()
        return result
    
    def _build_context(self, request: Any) -> Dict:
        """Construit le contexte d'exécution."""
        if isinstance(request, dict):
            return dict(request)
        elif isinstance(request, str):
            return {"data": request, "input_text": request}
        else:
            return {"data": request}
    
    def _execute_plan(
        self,
        plan: OrchestrationPlan,
        context: Dict,
        result: OrchestrationResult
    ):
        """Exécute le plan d'orchestration."""
        executed: Set[str] = set()
        
        for scenario_id in plan.scenarios:
            # Vérifier les dépendances
            deps = plan.dependencies.get(scenario_id, [])
            if not all(d in executed for d in deps):
                result.add_log(f"Dépendances non satisfaites pour {scenario_id}")
                continue
            
            # Vérifier la condition
            condition = plan.conditions.get(scenario_id)
            if condition and not self._evaluate_condition(condition, context):
                result.add_log(f"Condition non satisfaite pour {scenario_id}")
                result.executions.append(ScenarioExecution(
                    scenario_id=scenario_id,
                    status="skipped",
                    logs=[f"Condition non satisfaite: {condition}"]
                ))
                continue
            
            # Exécuter le scénario
            execution = self._execute_scenario(scenario_id, context)
            result.executions.append(execution)
            result.logs.extend(execution.logs)
            
            if execution.ok:
                executed.add(scenario_id)
                # Mettre à jour le contexte avec le résultat
                if isinstance(execution.result, dict):
                    context.update(execution.result)
                    # Si c'est un projet, le stocker spécifiquement
                    if "project_id" in execution.result or "projectId" in execution.result:
                        context["project"] = execution.result
            else:
                # Gérer l'erreur
                action, data = self.error_handler.handle_error(
                    scenario_id, 
                    execution.error or "Unknown error",
                    context
                )
                
                self._handle_recovery(action, data, scenario_id, plan, context, result)
                
                if action == ErrorRecoveryAction.ABORT:
                    break
                elif action == ErrorRecoveryAction.REQUEST_INFO:
                    result.status = OrchestrationStatus.WAITING_INPUT
                    break
    
    def _execute_scenario(
        self,
        scenario_id: str,
        context: Dict
    ) -> ScenarioExecution:
        """Exécute un scénario individuel."""
        execution = ScenarioExecution(
            scenario_id=scenario_id,
            status="running"
        )
        
        start_time = time.time()
        execution.logs.append(f"Exécution de {scenario_id}")
        
        try:
            if self.engine:
                # Utiliser le moteur GEVR
                result = self.engine.run_scenario(scenario_id, context)
                
                if result.get("status") == "completed":
                    execution.status = "success"
                    execution.result = result.get("output")
                else:
                    execution.status = "failed"
                    execution.error = result.get("errors", ["Unknown error"])[0] if result.get("errors") else "Scenario failed"
            else:
                # Mode simulation (sans moteur)
                execution.status = "success"
                execution.result = self._simulate_scenario(scenario_id, context)
                execution.logs.append(f"[SIMULATION] {scenario_id} simulé")
        
        except Exception as e:
            execution.status = "failed"
            execution.error = str(e)
            execution.logs.append(f"ERREUR: {str(e)}")
        
        execution.duration_ms = (time.time() - start_time) * 1000
        execution.completed_at = datetime.now()
        execution.logs.append(f"Terminé: {execution.status} ({execution.duration_ms:.1f}ms)")
        
        return execution
    
    def _simulate_scenario(self, scenario_id: str, context: Dict) -> Dict:
        """Simule l'exécution d'un scénario (pour tests)."""
        entry = self.catalog.get(scenario_id)
        
        if scenario_id == "Scenario.ProjetEURKAI":
            # Simulation basique d'un projet
            data = context.get("data", context.get("input_text", "Unknown"))
            return {
                "project_id": f"Project.{hash(data) % 10000}",
                "name": f"Project from '{data[:30]}...'",
                "objects": [
                    {"id": "Agent.Main", "type": "Agent"},
                    {"id": "View.Main", "type": "View"}
                ],
                "relations": [
                    {"source": "Agent.Main", "target": "View.Main", "type": "renders"}
                ],
                "scenarios": [],
                "simulated": True
            }
        
        return {
            "scenario_id": scenario_id,
            "simulated": True,
            "context_keys": list(context.keys())
        }
    
    def _evaluate_condition(self, condition: str, context: Dict) -> bool:
        """Évalue une condition dans le contexte."""
        try:
            # Condition simple: "key exists"
            if " exists" in condition:
                key = condition.replace(" exists", "").strip()
                return key in context
            
            # Condition: "key == value"
            if "==" in condition:
                parts = condition.split("==")
                key = parts[0].strip()
                value = parts[1].strip().strip("'\"")
                return str(context.get(key)) == value
            
            return True
        except:
            return False
    
    def _handle_recovery(
        self,
        action: ErrorRecoveryAction,
        data: Optional[Dict],
        scenario_id: str,
        plan: OrchestrationPlan,
        context: Dict,
        result: OrchestrationResult
    ):
        """Gère la récupération après une erreur."""
        
        if action == ErrorRecoveryAction.REQUEST_INFO:
            missing = data.get("missing") if data else None
            if missing:
                result.missing_info.append(missing)
                result.add_log(f"Information manquante: {missing.field}")
        
        elif action == ErrorRecoveryAction.PROPOSE_HYPOTHESIS:
            if self.auto_hypothesis:
                hypothesis = self._generate_hypothesis(
                    scenario_id, 
                    data.get("error", ""),
                    context
                )
                if hypothesis:
                    result.hypotheses.append(hypothesis)
                    result.add_log(f"Hypothèse proposée: {hypothesis.field} = {hypothesis.value}")
        
        elif action == ErrorRecoveryAction.FALLBACK:
            fallback_id = data.get("fallback_id") if data else None
            if fallback_id:
                result.add_log(f"Fallback vers {fallback_id}")
                fallback_exec = self._execute_scenario(fallback_id, context)
                result.executions.append(fallback_exec)
        
        elif action == ErrorRecoveryAction.RETRY:
            result.add_log(f"Retry de {scenario_id}")
            retry_exec = self._execute_scenario(scenario_id, context)
            result.executions.append(retry_exec)
    
    def _generate_hypothesis(
        self,
        scenario_id: str,
        error: str,
        context: Dict
    ) -> Optional[Hypothesis]:
        """Génère une hypothèse pour résoudre une erreur."""
        entry = self.catalog.get(scenario_id)
        if not entry:
            return None
        
        # Analyser les champs requis manquants
        required = entry.input_schema.get("required", [])
        for field in required:
            if field not in context:
                # Proposer une valeur par défaut
                default = self._infer_default(field, context)
                if default:
                    return Hypothesis(
                        field=field,
                        value=default,
                        confidence=0.6,
                        reasoning=f"Valeur inférée à partir du contexte"
                    )
        
        return None
    
    def _infer_default(self, field: str, context: Dict) -> Any:
        """Infère une valeur par défaut pour un champ."""
        # Quelques heuristiques simples
        if field == "domain":
            return "generic"
        if field == "name" and "data" in context:
            # Extraire un nom du texte
            text = str(context["data"])
            words = text.split()
            if len(words) >= 2:
                return "".join(w.capitalize() for w in words[:2])
        if field == "target_path":
            return "./output"
        return None
    
    # =========================================================================
    # API PUBLIQUE
    # =========================================================================
    
    def register_scenario(self, entry: ScenarioCatalogEntry):
        """Enregistre un nouveau scénario dans le catalogue."""
        self.catalog.register(entry)
    
    def list_scenarios(self) -> List[str]:
        """Liste les scénarios disponibles."""
        return self.catalog.list_scenarios()
    
    def get_scenario_info(self, scenario_id: str) -> Optional[Dict]:
        """Récupère les informations d'un scénario."""
        entry = self.catalog.get(scenario_id)
        if entry:
            return {
                "id": entry.id,
                "name": entry.name,
                "description": entry.description,
                "request_types": [rt.value for rt in entry.request_types],
                "tags": entry.tags,
                "requires": entry.requires,
                "provides": entry.provides
            }
        return None
    
    def can_handle(self, request: Any) -> bool:
        """Vérifie si l'Orchestrate peut traiter une requête."""
        request_type = self.selector.detect_request_type(request)
        context = self._build_context(request)
        matches = self.catalog.find_all_matches(request_type, context)
        return len(matches) > 0
    
    def suggest_scenarios(self, request: Any) -> List[Tuple[str, float]]:
        """Suggère les scénarios pour une requête."""
        request_type = self.selector.detect_request_type(request)
        context = self._build_context(request)
        return self.catalog.find_all_matches(request_type, context)


# =============================================================================
# API SIMPLIFIÉE
# =============================================================================

# Instance globale
_default_orchestrate: Optional[Orchestrate] = None


def get_orchestrate(engine=None) -> Orchestrate:
    """Obtient l'instance globale de l'Orchestrateur."""
    global _default_orchestrate
    if _default_orchestrate is None:
        _default_orchestrate = Orchestrate(engine=engine)
    elif engine is not None:
        _default_orchestrate.engine = engine
    return _default_orchestrate


def run(request: Any, options: Dict = None) -> Dict:
    """
    API centrale pour exécuter une orchestration.
    
    Args:
        request: La requête (idée, brief, transformation, etc.)
        options: Options d'exécution
        
    Returns:
        Dict avec status, logs, result
    """
    orchestrate = get_orchestrate()
    if options:
        orchestrate.options.update(options)
    result = orchestrate.run(request)
    return result.to_dict()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Classes principales
    "Orchestrate",
    "OrchestrationResult",
    "OrchestrationPlan",
    "OrchestrationStatus",
    
    # Types et énums
    "RequestType",
    "ErrorRecoveryAction",
    
    # Structures
    "ScenarioExecution",
    "MissingInfo",
    "Hypothesis",
    
    # Catalogue
    "ScenarioCatalog",
    "ScenarioCatalogEntry",
    "ScenarioSelector",
    "ErrorHandler",
    
    # API
    "get_orchestrate",
    "run"
]
