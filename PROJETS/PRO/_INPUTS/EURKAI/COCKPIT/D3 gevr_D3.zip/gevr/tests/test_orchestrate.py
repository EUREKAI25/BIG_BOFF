"""
Tests D3/6 — SuperTool Orchestrate
===================================

Tests complets pour le module Orchestrate:
- Détection de type de requête
- Sélection de scénarios
- Exécution et chaînage
- Gestion des erreurs
- Gestion des infos manquantes
- Cas de test end-to-end

Version: D3/6
"""

import pytest
from datetime import datetime
import sys
import os

# Ajouter le chemin pour les imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from orchestrate import (
    Orchestrate,
    OrchestrationResult,
    OrchestrationPlan,
    OrchestrationStatus,
    RequestType,
    ErrorRecoveryAction,
    ScenarioExecution,
    MissingInfo,
    Hypothesis,
    ScenarioCatalog,
    ScenarioCatalogEntry,
    ScenarioSelector,
    ErrorHandler,
    get_orchestrate,
    run
)


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture
def orchestrate():
    """Instance d'Orchestrate pour les tests."""
    return Orchestrate()


@pytest.fixture
def catalog():
    """Instance de ScenarioCatalog pour les tests."""
    return ScenarioCatalog()


@pytest.fixture
def selector(catalog):
    """Instance de ScenarioSelector pour les tests."""
    return ScenarioSelector(catalog)


# =============================================================================
# TESTS: DÉTECTION DU TYPE DE REQUÊTE
# =============================================================================

class TestRequestTypeDetection:
    """Tests de détection du type de requête."""
    
    def test_detect_idea_simple(self, selector):
        """Détecte une idée simple."""
        assert selector.detect_request_type("Je veux un blog") == RequestType.IDEA
        assert selector.detect_request_type("Créer une application") == RequestType.IDEA
        assert selector.detect_request_type("New project for CRM") == RequestType.IDEA
    
    def test_detect_brief(self, selector):
        """Détecte un brief structuré."""
        long_text = "Voici le cahier des charges pour notre application. " * 20
        assert selector.detect_request_type(long_text) == RequestType.BRIEF
        assert selector.detect_request_type({"brief": "Détails du projet..."}) == RequestType.BRIEF
    
    def test_detect_transform(self, selector):
        """Détecte une transformation."""
        assert selector.detect_request_type({
            "project": {"id": "P1"},
            "transformation": {"action": "add_feature"}
        }) == RequestType.TRANSFORM
        
        assert selector.detect_request_type("Transformer le projet") == RequestType.TRANSFORM
    
    def test_detect_enrich(self, selector):
        """Détecte un enrichissement."""
        assert selector.detect_request_type({
            "project": {"id": "P1"},
            "additions": {"objects": []}
        }) == RequestType.ENRICH
        
        assert selector.detect_request_type("Ajouter une feature au projet") == RequestType.ENRICH
    
    def test_detect_analyze(self, selector):
        """Détecte une analyse."""
        assert selector.detect_request_type({
            "object_id": "Agent.Main"
        }) == RequestType.ANALYZE
        
        assert selector.detect_request_type("Analyser ce composant") == RequestType.ANALYZE
    
    def test_detect_validate(self, selector):
        """Détecte une validation."""
        assert selector.detect_request_type("Valider le projet") == RequestType.VALIDATE
        assert selector.detect_request_type("Vérifier la cohérence") == RequestType.VALIDATE
    
    def test_detect_generate(self, selector):
        """Détecte une génération."""
        assert selector.detect_request_type("Générer le code") == RequestType.GENERATE
        assert selector.detect_request_type("Create code for this") == RequestType.GENERATE
    
    def test_detect_deploy(self, selector):
        """Détecte un déploiement."""
        assert selector.detect_request_type({
            "project": {"id": "P1"},
            "target": "production"
        }) == RequestType.DEPLOY
        
        assert selector.detect_request_type("Déployer l'application") == RequestType.DEPLOY
    
    def test_detect_explicit_type(self, selector):
        """Détecte un type explicite."""
        assert selector.detect_request_type({"type": "analyze"}) == RequestType.ANALYZE
        assert selector.detect_request_type({"type": "validate"}) == RequestType.VALIDATE


# =============================================================================
# TESTS: SÉLECTION DE SCÉNARIOS
# =============================================================================

class TestScenarioSelection:
    """Tests de sélection de scénarios."""
    
    def test_select_for_idea(self, selector):
        """Sélectionne le bon scénario pour une idée."""
        plan = selector.select_scenarios("Je veux un blog")
        assert "Scenario.ProjetEURKAI" in plan.scenarios
    
    def test_select_for_brief(self, selector):
        """Sélectionne le bon scénario pour un brief."""
        plan = selector.select_scenarios({"brief": "Application CRM complète..."})
        assert "Scenario.ProjetEURKAI" in plan.scenarios
    
    def test_select_for_analysis(self, selector):
        """Sélectionne le bon scénario pour une analyse."""
        plan = selector.select_scenarios({"object_id": "Agent.Main"})
        assert "Scenario.AnalyzeObject" in plan.scenarios
    
    def test_select_for_validation(self, selector):
        """Sélectionne le bon scénario pour une validation."""
        plan = selector.select_scenarios({
            "project": {"id": "P1"},
            "type": "validate"
        })
        assert "Scenario.ValidateProject" in plan.scenarios
    
    def test_plan_with_dependencies(self, selector):
        """Vérifie que les dépendances sont incluses."""
        plan = selector.select_scenarios({
            "project": {"id": "P1"},
            "type": "generate"
        })
        # Le scénario de génération nécessite un projet
        assert len(plan.scenarios) >= 1


# =============================================================================
# TESTS: CATALOGUE DE SCÉNARIOS
# =============================================================================

class TestScenarioCatalog:
    """Tests du catalogue de scénarios."""
    
    def test_default_scenarios_registered(self, catalog):
        """Vérifie que les scénarios par défaut sont enregistrés."""
        assert catalog.get("Scenario.ProjetEURKAI") is not None
        assert catalog.get("Scenario.AnalyzeObject") is not None
        assert catalog.get("Scenario.ValidateProject") is not None
    
    def test_register_custom_scenario(self, catalog):
        """Enregistre un scénario personnalisé."""
        entry = ScenarioCatalogEntry(
            id="Scenario.Custom",
            name="Custom Scenario",
            description="Test scenario",
            request_types=[RequestType.ANALYZE],
            input_schema={"type": "object"},
            output_schema={"type": "object"},
            tags=["test"]
        )
        catalog.register(entry)
        
        assert catalog.get("Scenario.Custom") is not None
        assert catalog.get("Scenario.Custom").name == "Custom Scenario"
    
    def test_find_best_match(self, catalog):
        """Trouve le meilleur match."""
        best = catalog.find_best_match(RequestType.IDEA, {"tags": ["project"]})
        assert best == "Scenario.ProjetEURKAI"
    
    def test_find_all_matches(self, catalog):
        """Trouve tous les matchs."""
        matches = catalog.find_all_matches(RequestType.IDEA, {})
        assert len(matches) >= 1
        assert matches[0][0] == "Scenario.ProjetEURKAI"


# =============================================================================
# TESTS: EXÉCUTION DE L'ORCHESTRATION
# =============================================================================

class TestOrchestration:
    """Tests d'exécution de l'orchestration."""
    
    def test_run_simple_idea(self, orchestrate):
        """Exécute une orchestration simple (idée)."""
        result = orchestrate.run("Je veux un blog sur la créativité")
        
        assert result.status in [
            OrchestrationStatus.COMPLETED,
            OrchestrationStatus.PARTIAL
        ]
        assert result.request_type == RequestType.IDEA
        assert result.plan is not None
        assert len(result.executions) >= 1
    
    def test_run_with_brief(self, orchestrate):
        """Exécute une orchestration avec brief."""
        result = orchestrate.run({
            "brief": "Application de gestion de tâches",
            "tags": ["saas", "task"]
        })
        
        assert result.request_type in [RequestType.BRIEF, RequestType.IDEA]
        assert result.plan is not None
    
    def test_result_contains_output(self, orchestrate):
        """Vérifie que le résultat contient une sortie."""
        result = orchestrate.run("Blog simple")
        
        if result.ok:
            assert result.final_output is not None
    
    def test_result_contains_logs(self, orchestrate):
        """Vérifie que le résultat contient des logs."""
        result = orchestrate.run("Test project")
        
        assert len(result.logs) > 0
    
    def test_result_summary(self, orchestrate):
        """Vérifie le résumé du résultat."""
        result = orchestrate.run("API REST")
        summary = result.summary()
        
        assert "status" in summary
        assert "scenarios_executed" in summary
        assert "duration_ms" in summary
    
    def test_orchestrate_chain(self, orchestrate):
        """Teste le chaînage de scénarios."""
        # Le plan ProjetEURKAI est un scénario simple
        result = orchestrate.run("Je veux une API avec validation")
        
        # Vérifie que le plan a été exécuté
        assert result.plan is not None
        assert len(result.plan.scenarios) >= 1


# =============================================================================
# TESTS: GESTION DES ERREURS
# =============================================================================

class TestErrorHandling:
    """Tests de gestion des erreurs."""
    
    def test_error_handler_missing_field(self, catalog):
        """Gère une erreur de champ manquant."""
        handler = ErrorHandler(catalog)
        
        action, data = handler.handle_error(
            "Scenario.Test",
            "Missing required field: 'name'",
            {}
        )
        
        assert action == ErrorRecoveryAction.REQUEST_INFO
        assert data is not None
        assert "missing" in data
    
    def test_error_handler_validation_error(self, catalog):
        """Gère une erreur de validation."""
        handler = ErrorHandler(catalog)
        
        action, data = handler.handle_error(
            "Scenario.Test",
            "Invalid value for field X",
            {}
        )
        
        assert action in [
            ErrorRecoveryAction.PROPOSE_HYPOTHESIS,
            ErrorRecoveryAction.ABORT
        ]
    
    def test_error_handler_retry(self, catalog):
        """Gère une erreur temporaire avec retry."""
        handler = ErrorHandler(catalog)
        
        action, data = handler.handle_error(
            "Scenario.Test",
            "Connection timeout",
            {}
        )
        
        assert action == ErrorRecoveryAction.RETRY
    
    def test_max_retries_exceeded(self, catalog):
        """Arrête après trop de retries."""
        handler = ErrorHandler(catalog)
        handler.max_retries = 1
        
        # Premier essai
        action1, _ = handler.handle_error("Scenario.Test", "Timeout", {})
        assert action1 == ErrorRecoveryAction.RETRY
        
        # Deuxième essai
        action2, _ = handler.handle_error("Scenario.Test", "Timeout", {})
        # Après max_retries, devrait fallback ou abort
        assert action2 in [ErrorRecoveryAction.FALLBACK, ErrorRecoveryAction.ABORT]


# =============================================================================
# TESTS: GESTION DES INFOS MANQUANTES
# =============================================================================

class TestMissingInfoHandling:
    """Tests de gestion des informations manquantes."""
    
    def test_detect_missing_info(self, orchestrate):
        """Détecte les informations manquantes."""
        # On simule un scénario qui échoue par manque d'info
        # En mode simulation, ça devrait réussir
        result = orchestrate.run({
            "type": "deploy",
            "project": None  # Projet manquant
        })
        
        # Vérifie que le résultat est soit complété soit en attente
        assert result.status in [
            OrchestrationStatus.COMPLETED,
            OrchestrationStatus.PARTIAL,
            OrchestrationStatus.WAITING_INPUT,
            OrchestrationStatus.FAILED
        ]
    
    def test_missing_info_structure(self):
        """Vérifie la structure MissingInfo."""
        missing = MissingInfo(
            field="project",
            description="Le projet est requis",
            required=True,
            suggestions=["Créez d'abord un projet"],
            default=None
        )
        
        d = missing.to_dict()
        assert d["field"] == "project"
        assert d["required"] == True
        assert "suggestions" in d


# =============================================================================
# TESTS: HYPOTHÈSES
# =============================================================================

class TestHypotheses:
    """Tests de génération d'hypothèses."""
    
    def test_hypothesis_structure(self):
        """Vérifie la structure Hypothesis."""
        hyp = Hypothesis(
            field="domain",
            value="web",
            confidence=0.8,
            reasoning="Détecté à partir du brief"
        )
        
        d = hyp.to_dict()
        assert d["field"] == "domain"
        assert d["value"] == "web"
        assert d["confidence"] == 0.8
    
    def test_auto_hypothesis_generation(self, orchestrate):
        """Teste la génération automatique d'hypothèses."""
        orchestrate.auto_hypothesis = True
        
        # L'orchestrateur peut proposer des hypothèses en cas d'erreur
        result = orchestrate.run("Blog simple")
        
        # Les hypothèses sont optionnelles, dépendent du contexte
        assert isinstance(result.hypotheses, list)


# =============================================================================
# TESTS: PLANS D'ORCHESTRATION
# =============================================================================

class TestOrchestrationPlan:
    """Tests des plans d'orchestration."""
    
    def test_simple_plan(self):
        """Crée un plan simple."""
        plan = OrchestrationPlan.simple("Scenario.Test")
        
        assert plan.scenarios == ["Scenario.Test"]
        assert plan.dependencies == {}
    
    def test_chain_plan(self):
        """Crée un plan chaîné."""
        plan = OrchestrationPlan.chain("S1", "S2", "S3")
        
        assert plan.scenarios == ["S1", "S2", "S3"]
        assert "S2" in plan.dependencies
        assert plan.dependencies["S2"] == ["S1"]
        assert plan.dependencies["S3"] == ["S2"]
    
    def test_plan_to_dict(self):
        """Sérialise un plan."""
        plan = OrchestrationPlan.chain("S1", "S2")
        d = plan.to_dict()
        
        assert "scenarios" in d
        assert "dependencies" in d


# =============================================================================
# TESTS: API SIMPLIFIÉE
# =============================================================================

class TestSimplifiedAPI:
    """Tests de l'API simplifiée."""
    
    def test_run_function(self):
        """Teste la fonction run()."""
        result = run("Je veux un blog")
        
        assert isinstance(result, dict)
        assert "status" in result
        assert "logs" in result
    
    def test_get_orchestrate(self):
        """Teste get_orchestrate()."""
        o1 = get_orchestrate()
        o2 = get_orchestrate()
        
        # Devrait retourner la même instance
        assert o1 is o2


# =============================================================================
# TESTS: EXEMPLES END-TO-END
# =============================================================================

class TestEndToEnd:
    """Tests end-to-end complets."""
    
    def test_example_blog_project(self, orchestrate):
        """Exemple: Créer un projet de blog."""
        result = orchestrate.run("Je veux un blog EURKAI sur la créativité")
        
        assert result.request_type == RequestType.IDEA
        assert result.plan is not None
        
        if result.ok:
            output = result.final_output
            assert output is not None
    
    def test_example_api_project(self, orchestrate):
        """Exemple: Créer un projet d'API."""
        result = orchestrate.run({
            "brief": "API REST pour gestion de clients",
            "tags": ["api", "rest", "crm"]
        })
        
        assert result.plan is not None
        assert len(result.executions) >= 1
    
    def test_example_saas_project(self, orchestrate):
        """Exemple: Créer un projet SaaS."""
        result = orchestrate.run({
            "data": "Application SaaS de gestion de tâches avec équipes",
            "tags": ["saas", "task", "team"]
        })
        
        assert result.status in [
            OrchestrationStatus.COMPLETED,
            OrchestrationStatus.PARTIAL
        ]
    
    def test_example_with_error_recovery(self, orchestrate):
        """Exemple: Orchestration avec récupération d'erreur."""
        # On force un scénario qui n'existe pas
        orchestrate.catalog.register(ScenarioCatalogEntry(
            id="Scenario.WillFail",
            name="Will Fail",
            description="Test scenario that will fail",
            request_types=[RequestType.ANALYZE],
            input_schema={"type": "object", "required": ["missing_field"]},
            output_schema={"type": "object"},
            priority=100  # Haute priorité pour être sélectionné
        ))
        
        result = orchestrate.run({"type": "analyze", "data": "test"})
        
        # Devrait avoir des logs sur le traitement de l'erreur
        assert len(result.logs) > 0


# =============================================================================
# TESTS: CAS LIMITES
# =============================================================================

class TestEdgeCases:
    """Tests des cas limites."""
    
    def test_empty_request(self, orchestrate):
        """Gère une requête vide."""
        result = orchestrate.run("")
        
        # Ne devrait pas planter
        assert result.status in [
            OrchestrationStatus.COMPLETED,
            OrchestrationStatus.PARTIAL,
            OrchestrationStatus.FAILED
        ]
    
    def test_none_request(self, orchestrate):
        """Gère une requête None."""
        result = orchestrate.run(None)
        
        # Ne devrait pas planter
        assert result is not None
    
    def test_very_long_request(self, orchestrate):
        """Gère une requête très longue."""
        # Texte long sans patterns spécifiques pour être détecté comme brief
        long_text = "Description détaillée du système: " + "spécification technique détaillée " * 50
        result = orchestrate.run(long_text)
        
        assert result.request_type == RequestType.BRIEF
        assert result.status is not None
    
    def test_special_characters(self, orchestrate):
        """Gère les caractères spéciaux."""
        result = orchestrate.run("Projet avec émojis 🚀 et accénts àéïöü")
        
        assert result is not None
        assert result.status is not None


# =============================================================================
# TESTS: MÉTRIQUES ET DURÉE
# =============================================================================

class TestMetrics:
    """Tests des métriques."""
    
    def test_duration_calculated(self, orchestrate):
        """Vérifie le calcul de durée."""
        result = orchestrate.run("Test rapide")
        
        assert result.completed_at is not None
        assert result.duration_ms >= 0
    
    def test_execution_duration(self, orchestrate):
        """Vérifie la durée d'exécution par scénario."""
        result = orchestrate.run("Blog simple")
        
        for exec in result.executions:
            assert exec.duration_ms >= 0
            assert exec.started_at is not None


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
