ERK Bootstrap Catalogs (seed)
Generated: 2026-02-21T06:06:44Z

Structure:
  Object/<Type>/<Type>Catalog.json

Types included:
  Object, Method, Scenario, Rule, Policy, Resource, Hook

Notes:
  - This is a minimal bootstrap seed. Fill/extend catalogs as your fractal grows.
  - Scenarios are skeletons with hooks; MRG runs only what/how prepared beforehand.
