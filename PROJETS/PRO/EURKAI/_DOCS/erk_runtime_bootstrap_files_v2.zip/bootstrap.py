# bootstrap.py
# Minimal ERK bootstrap loader (catalog-first)
#
# Loads JSON catalogs from a "Catalogs/" directory structured like:
#   Catalogs/<Type>/<Type>Catalog.json
# and/or direct files:
#   Catalogs/<Type>Catalog.json
#
# Example:
#   Catalogs/Object/ObjectCatalog.json
#   Catalogs/Method/MethodCatalog.json
#   Catalogs/Scenario/ScenarioCatalog.json
#
# No business logic: only loads + indexes by lineage.

from __future__ import annotations

import json
from pathlib import Path


class Fractal:
    def __init__(self):
        self.catalogs: dict[str, dict] = {}
        self.index: dict[str, dict] = {}

    def index_build(self) -> None:
        self.index.clear()
        for payload in self.catalogs.values():
            for item in payload.get("item_list", []):
                lineage = item.get("lineage")
                if lineage:
                    self.index[lineage] = item

    def resolve(self, lineage: str) -> dict:
        return self.index[lineage]


class Bootstrap:
    def __init__(self, catalogs_root: str | Path):
        self.catalogs_root = Path(catalogs_root)

    def run(self) -> Fractal:
        if not self.catalogs_root.exists():
            raise FileNotFoundError(f"Catalogs root not found: {self.catalogs_root}")

        fractal = Fractal()

        # 1) Load nested catalogs: Catalogs/<Type>/*Catalog.json
        for type_dir in sorted(p for p in self.catalogs_root.iterdir() if p.is_dir()):
            for json_file in sorted(type_dir.glob("*Catalog.json")):
                payload = self._json_load(json_file)
                name = payload.get("catalog") or json_file.stem
                fractal.catalogs[name] = payload

        # 2) Load flat catalogs: Catalogs/*Catalog.json (optional)
        for json_file in sorted(self.catalogs_root.glob("*Catalog.json")):
            payload = self._json_load(json_file)
            name = payload.get("catalog") or json_file.stem
            fractal.catalogs[name] = payload

        fractal.index_build()
        return fractal

    @staticmethod
    def _json_load(path: Path) -> dict:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
