# run.py
# Minimal runtime entrypoint for bootstrap

from __future__ import annotations

import sys
from pathlib import Path

from bootstrap import Bootstrap


def main() -> int:
    # Default assumes:
    #   ./Catalogs/...
    # You may pass a different catalogs root:
    #   python run.py /path/to/Catalogs
    if len(sys.argv) > 1:
        catalogs_root = Path(sys.argv[1]).expanduser().resolve()
    else:
        catalogs_root = (Path(__file__).parent / "Catalogs").resolve()

    fractal = Bootstrap(catalogs_root).run()

    print("BOOTSTRAP_OK")
    print("Catalogs loaded:", sorted(fractal.catalogs.keys()))
    print("Indexed elements:", len(fractal.index))

    # tiny probe if present (won't fail hard if missing)
    for probe in ("Object:Config", "CentralMethod:Read", "SecondaryMethod:Load", "Scenario:Load"):
        if probe in fractal.index:
            print("probe:", probe, "OK")
        else:
            print("probe:", probe, "MISSING")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
