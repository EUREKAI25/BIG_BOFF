import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { briefsApi, projectsApi } from '../api/client'
import { useToast } from '../App'

function StatusBadge({ status }) {
  const statusClasses = {
    pending: 'badge-pending',
    running: 'badge-running',
    success: 'badge-success',
    failed: 'badge-failed',
  }
  
  return (
    <span className={`badge ${statusClasses[status] || 'badge-pending'}`}>
      <span className="badge-dot" />
      {status}
    </span>
  )
}

export default function BriefsPage() {
  const [briefs, setBriefs] = useState([])
  const [projects, setProjects] = useState({})
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('')
  const { addToast } = useToast()
  
  const loadData = async () => {
    try {
      setLoading(true)
      const [briefsRes, projectsRes] = await Promise.all([
        briefsApi.list(),
        projectsApi.list(),
      ])
      setBriefs(briefsRes.data || [])
      
      // Create project lookup map
      const projectMap = {}
      ;(projectsRes.data || []).forEach(p => {
        projectMap[p.id] = p
      })
      setProjects(projectMap)
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadData()
  }, [])
  
  const filteredBriefs = briefs.filter(brief => {
    if (!filter) return true
    const searchLower = filter.toLowerCase()
    return (
      brief.title.toLowerCase().includes(searchLower) ||
      brief.goal?.toLowerCase().includes(searchLower) ||
      brief.tags?.some(t => t.toLowerCase().includes(searchLower))
    )
  })
  
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">All Briefs</h1>
        <p className="page-subtitle">Browse all briefs across projects</p>
      </div>
      
      <div className="actions-bar">
        <input
          type="text"
          className="form-input"
          placeholder="Filter briefs..."
          value={filter}
          onChange={e => setFilter(e.target.value)}
          style={{ maxWidth: '300px' }}
        />
        <span className="text-muted text-sm">
          {filteredBriefs.length} brief{filteredBriefs.length !== 1 ? 's' : ''}
        </span>
      </div>
      
      {loading ? (
        <div className="empty-state">
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : filteredBriefs.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
              <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" />
            </svg>
          </div>
          <h3 className="empty-state-title">
            {filter ? 'No matching briefs' : 'No briefs yet'}
          </h3>
          <p>
            {filter 
              ? 'Try adjusting your filter' 
              : 'Create a brief from a project page'}
          </p>
        </div>
      ) : (
        <div className="card">
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Project</th>
                  <th>Tags</th>
                  <th>Updated</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filteredBriefs.map(brief => (
                  <tr key={brief.id} className="clickable-row">
                    <td>
                      <Link 
                        to={`/briefs/${brief.id}`} 
                        style={{ color: 'inherit', textDecoration: 'none' }}
                      >
                        <strong>{brief.title}</strong>
                        {brief.goal && (
                          <div className="text-xs text-muted" style={{ marginTop: '0.25rem' }}>
                            {brief.goal}
                          </div>
                        )}
                      </Link>
                    </td>
                    <td>
                      <Link 
                        to={`/projects/${brief.project_id}`}
                        className="text-sm"
                        style={{ color: 'var(--accent-primary)', textDecoration: 'none' }}
                      >
                        {projects[brief.project_id]?.name || 'Unknown'}
                      </Link>
                    </td>
                    <td>
                      <div className="tag-list">
                        {(brief.tags || []).slice(0, 3).map(tag => (
                          <span key={tag} className="tag">{tag}</span>
                        ))}
                      </div>
                    </td>
                    <td className="text-mono text-xs text-muted">
                      {new Date(brief.updated_at).toLocaleDateString()}
                    </td>
                    <td>
                      <Link to={`/briefs/${brief.id}`} className="btn btn-secondary btn-sm">
                        View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
