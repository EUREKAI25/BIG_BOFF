import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { briefsApi, runsApi } from '../api/client'
import { useToast } from '../App'

function StatusBadge({ status }) {
  const statusClasses = {
    pending: 'badge-pending',
    running: 'badge-running',
    success: 'badge-success',
    failed: 'badge-failed',
  }
  
  return (
    <span className={`badge ${statusClasses[status] || 'badge-pending'}`}>
      <span className="badge-dot" />
      {status}
    </span>
  )
}

function RunDetailModal({ run, isOpen, onClose, onDelete }) {
  const [deleting, setDeleting] = useState(false)
  
  if (!isOpen || !run) return null
  
  const handleDelete = async () => {
    if (!confirm('Delete this run?')) return
    setDeleting(true)
    try {
      await onDelete(run.id)
      onClose()
    } finally {
      setDeleting(false)
    }
  }
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '700px' }}>
        <div className="modal-header">
          <h2 className="modal-title">Run Details</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <div className="flex items-center gap-md mb-md">
            <StatusBadge status={run.status} />
            {run.duration_ms && (
              <span className="text-mono text-sm text-muted">
                {run.duration_ms}ms
              </span>
            )}
            {run.model && (
              <span className="text-mono text-sm text-muted">
                Model: {run.model}
              </span>
            )}
          </div>
          
          <div className="form-group">
            <label className="form-label">Run ID</label>
            <div className="text-mono text-sm">{run.id}</div>
          </div>
          
          <div className="form-group">
            <label className="form-label">Brief</label>
            <Link 
              to={`/briefs/${run.brief_id}`}
              style={{ color: 'var(--accent-primary)' }}
            >
              {run.brief_id}
            </Link>
          </div>
          
          <div className="form-group">
            <label className="form-label">Created</label>
            <div className="text-sm">{new Date(run.created_at).toLocaleString()}</div>
          </div>
          
          {run.finished_at && (
            <div className="form-group">
              <label className="form-label">Finished</label>
              <div className="text-sm">{new Date(run.finished_at).toLocaleString()}</div>
            </div>
          )}
          
          {run.output && (
            <div className="form-group">
              <label className="form-label">Output</label>
              <div className="code-block">{run.output}</div>
            </div>
          )}
          
          {run.logs && (
            <div className="form-group">
              <label className="form-label">Logs</label>
              <div className="code-block" style={{ maxHeight: '200px', overflow: 'auto' }}>
                {run.logs}
              </div>
            </div>
          )}
        </div>
        <div className="modal-footer">
          <button 
            className="btn btn-danger btn-sm" 
            onClick={handleDelete}
            disabled={deleting}
          >
            {deleting ? <span className="spinner" /> : 'Delete Run'}
          </button>
          <button className="btn btn-secondary" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  )
}

export default function RunsPage() {
  const [runs, setRuns] = useState([])
  const [briefs, setBriefs] = useState({})
  const [loading, setLoading] = useState(true)
  const [selectedRun, setSelectedRun] = useState(null)
  const [statusFilter, setStatusFilter] = useState('')
  const { addToast } = useToast()
  
  const loadData = async () => {
    try {
      setLoading(true)
      
      const briefsRes = await briefsApi.list()
      const allBriefs = briefsRes.data || []
      
      const briefsMap = {}
      allBriefs.forEach(b => { briefsMap[b.id] = b })
      setBriefs(briefsMap)
      
      const allRuns = []
      for (const brief of allBriefs) {
        try {
          const runsRes = await briefsApi.listRuns(brief.id)
          ;(runsRes.data || []).forEach(run => {
            allRuns.push({ ...run, briefTitle: brief.title })
          })
        } catch (e) {
          // Brief might have no runs
        }
      }
      
      allRuns.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      setRuns(allRuns)
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadData()
  }, [])
  
  const handleDeleteRun = async (runId) => {
    try {
      await runsApi.delete(runId)
      addToast('Run deleted')
      loadData()
    } catch (err) {
      addToast(err.message, 'error')
    }
  }
  
  const viewRunDetail = async (runId) => {
    try {
      const result = await runsApi.get(runId)
      setSelectedRun(result.data)
    } catch (err) {
      addToast(err.message, 'error')
    }
  }
  
  const filteredRuns = runs.filter(run => {
    if (!statusFilter) return true
    return run.status === statusFilter
  })
  
  const statusCounts = {
    all: runs.length,
    pending: runs.filter(r => r.status === 'pending').length,
    running: runs.filter(r => r.status === 'running').length,
    success: runs.filter(r => r.status === 'success').length,
    failed: runs.filter(r => r.status === 'failed').length,
  }
  
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Runs</h1>
        <p className="page-subtitle">Execution history across all briefs</p>
      </div>
      
      <div className="actions-bar">
        <div className="flex gap-sm">
          <button 
            className={`btn btn-sm ${!statusFilter ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setStatusFilter('')}
          >
            All ({statusCounts.all})
          </button>
          <button 
            className={`btn btn-sm ${statusFilter === 'pending' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setStatusFilter('pending')}
          >
            Pending ({statusCounts.pending})
          </button>
          <button 
            className={`btn btn-sm ${statusFilter === 'running' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setStatusFilter('running')}
          >
            Running ({statusCounts.running})
          </button>
          <button 
            className={`btn btn-sm ${statusFilter === 'success' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setStatusFilter('success')}
          >
            Success ({statusCounts.success})
          </button>
          <button 
            className={`btn btn-sm ${statusFilter === 'failed' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setStatusFilter('failed')}
          >
            Failed ({statusCounts.failed})
          </button>
        </div>
        <button className="btn btn-secondary btn-sm" onClick={loadData}>
          Refresh
        </button>
      </div>
      
      {loading ? (
        <div className="empty-state">
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : filteredRuns.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          </div>
          <h3 className="empty-state-title">No runs yet</h3>
          <p>Run a brief to see execution history here</p>
        </div>
      ) : (
        <div className="card">
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Status</th>
                  <th>Brief</th>
                  <th>Model</th>
                  <th>Duration</th>
                  <th>Created</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filteredRuns.map(run => (
                  <tr key={run.id} className="clickable-row" onClick={() => viewRunDetail(run.id)}>
                    <td>
                      <StatusBadge status={run.status} />
                    </td>
                    <td>
                      <Link 
                        to={`/briefs/${run.brief_id}`}
                        onClick={e => e.stopPropagation()}
                        style={{ color: 'var(--accent-primary)', textDecoration: 'none' }}
                      >
                        {run.briefTitle || run.brief_id.slice(0, 8)}
                      </Link>
                    </td>
                    <td className="text-mono text-sm text-muted">
                      {run.model || '—'}
                    </td>
                    <td className="text-mono text-sm">
                      {run.duration_ms ? `${run.duration_ms}ms` : '—'}
                    </td>
                    <td className="text-mono text-xs text-muted">
                      {new Date(run.created_at).toLocaleString()}
                    </td>
                    <td>
                      <button 
                        className="btn btn-secondary btn-sm"
                        onClick={(e) => { e.stopPropagation(); viewRunDetail(run.id) }}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      <RunDetailModal
        run={selectedRun}
        isOpen={!!selectedRun}
        onClose={() => setSelectedRun(null)}
        onDelete={handleDeleteRun}
      />
    </div>
  )
}
