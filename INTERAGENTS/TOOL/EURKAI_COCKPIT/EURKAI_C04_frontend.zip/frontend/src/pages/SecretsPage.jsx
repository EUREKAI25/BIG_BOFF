import { useState, useEffect } from 'react'
import { secretsApi, projectsApi } from '../api/client'
import { useToast } from '../App'

function PasswordModal({ isOpen, onClose, onSubmit, title }) {
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  
  if (!isOpen) return null
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!password) return
    
    setLoading(true)
    try {
      await onSubmit(password)
      setPassword('')
      onClose()
    } catch (err) {
      // Error handled by parent
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '400px' }}>
        <div className="modal-header">
          <h2 className="modal-title">{title}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Master Password</label>
              <input
                type="password"
                className="form-input"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Enter master password"
                autoFocus
              />
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading || !password}>
              {loading ? <span className="spinner" /> : 'Unlock'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

function CreateSecretModal({ isOpen, onClose, onCreate, projects }) {
  const [key, setKey] = useState('')
  const [value, setValue] = useState('')
  const [projectId, setProjectId] = useState('')
  const [loading, setLoading] = useState(false)
  
  if (!isOpen) return null
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!key.trim() || !value.trim()) return
    
    setLoading(true)
    try {
      await onCreate({
        key: key.trim(),
        value: value.trim(),
        project_id: projectId || null,
      })
      setKey('')
      setValue('')
      setProjectId('')
      onClose()
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Create Secret</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Key *</label>
              <input
                type="text"
                className="form-input"
                value={key}
                onChange={e => setKey(e.target.value)}
                placeholder="API_KEY"
                autoFocus
              />
            </div>
            <div className="form-group">
              <label className="form-label">Value *</label>
              <input
                type="password"
                className="form-input"
                value={value}
                onChange={e => setValue(e.target.value)}
                placeholder="Secret value"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Project (optional)</label>
              <select
                className="form-select"
                value={projectId}
                onChange={e => setProjectId(e.target.value)}
              >
                <option value="">Global (all projects)</option>
                {projects.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button 
              type="submit" 
              className="btn btn-primary" 
              disabled={loading || !key.trim() || !value.trim()}
            >
              {loading ? <span className="spinner" /> : 'Create Secret'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function SecretsPage() {
  const [secrets, setSecrets] = useState([])
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [createModalOpen, setCreateModalOpen] = useState(false)
  const [copyTarget, setCopyTarget] = useState(null)
  const [copiedValue, setCopiedValue] = useState(null)
  const { addToast } = useToast()
  
  const loadData = async () => {
    try {
      setLoading(true)
      const [secretsRes, projectsRes] = await Promise.all([
        secretsApi.list(),
        projectsApi.list(),
      ])
      setSecrets(secretsRes.data || [])
      setProjects(projectsRes.data || [])
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadData()
  }, [])
  
  const handleCreate = async (data) => {
    try {
      await secretsApi.create(data)
      addToast('Secret created')
      loadData()
    } catch (err) {
      addToast(err.message, 'error')
      throw err
    }
  }
  
  const handleCopy = async (secretId) => {
    setCopyTarget(secretId)
  }
  
  const handleUnlockAndCopy = async (password) => {
    try {
      // Unlock session
      const unlockRes = await secretsApi.unlock(password)
      const sessionToken = unlockRes.data.session_token
      
      // Copy secret value
      const copyRes = await secretsApi.copy(copyTarget, sessionToken)
      const value = copyRes.data.value
      
      // Copy to clipboard
      await navigator.clipboard.writeText(value)
      addToast('Secret copied to clipboard')
      
      // Briefly show the value
      setCopiedValue({ id: copyTarget, value })
      setTimeout(() => setCopiedValue(null), 3000)
      
    } catch (err) {
      addToast(err.message, 'error')
      throw err
    }
  }
  
  const handleDelete = async (secretId) => {
    if (!confirm('Delete this secret?')) return
    
    try {
      await secretsApi.delete(secretId)
      addToast('Secret deleted')
      loadData()
    } catch (err) {
      addToast(err.message, 'error')
    }
  }
  
  const projectsMap = {}
  projects.forEach(p => { projectsMap[p.id] = p })
  
  return (
    <div>
      <div className="page-header">
        <div className="actions-bar">
          <div>
            <h1 className="page-title">Secrets</h1>
            <p className="page-subtitle">Encrypted key-value storage</p>
          </div>
          <button className="btn btn-primary" onClick={() => setCreateModalOpen(true)}>
            + New Secret
          </button>
        </div>
      </div>
      
      <div className="card mb-md" style={{ 
        background: 'var(--accent-glow)', 
        borderColor: 'rgba(16, 185, 129, 0.3)' 
      }}>
        <div className="flex items-center gap-sm">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ width: 20, height: 20 }}>
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
            <path d="M7 11V7a5 5 0 0110 0v4" />
          </svg>
          <span className="text-sm">
            <strong>Gated Copy:</strong> Each copy action requires master password verification
          </span>
        </div>
      </div>
      
      {loading ? (
        <div className="empty-state">
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : secrets.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0110 0v4" />
            </svg>
          </div>
          <h3 className="empty-state-title">No secrets yet</h3>
          <p>Store API keys and sensitive data securely</p>
          <button className="btn btn-primary mt-md" onClick={() => setCreateModalOpen(true)}>
            + New Secret
          </button>
        </div>
      ) : (
        <div className="card">
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Key</th>
                  <th>Scope</th>
                  <th>Value</th>
                  <th>Updated</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {secrets.map(secret => (
                  <tr key={secret.id}>
                    <td>
                      <strong className="text-mono">{secret.key}</strong>
                    </td>
                    <td>
                      {secret.project_id ? (
                        <span className="badge badge-success">
                          {projectsMap[secret.project_id]?.name || 'Project'}
                        </span>
                      ) : (
                        <span className="badge badge-pending">Global</span>
                      )}
                    </td>
                    <td>
                      {copiedValue?.id === secret.id ? (
                        <span className="text-mono text-success">
                          {copiedValue.value.slice(0, 8)}...
                        </span>
                      ) : (
                        <span className="secret-value">••••••••••••</span>
                      )}
                    </td>
                    <td className="text-mono text-xs text-muted">
                      {new Date(secret.updated_at).toLocaleDateString()}
                    </td>
                    <td>
                      <div className="flex gap-sm">
                        <button 
                          className="btn btn-secondary btn-sm"
                          onClick={() => handleCopy(secret.id)}
                        >
                          Copy
                        </button>
                        <button 
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDelete(secret.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      <CreateSecretModal
        isOpen={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        onCreate={handleCreate}
        projects={projects}
      />
      
      <PasswordModal
        isOpen={!!copyTarget}
        onClose={() => setCopyTarget(null)}
        onSubmit={handleUnlockAndCopy}
        title="Unlock Secret"
      />
    </div>
  )
}
