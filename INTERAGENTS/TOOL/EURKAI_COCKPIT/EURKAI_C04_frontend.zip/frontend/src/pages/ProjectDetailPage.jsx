import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { projectsApi, briefsApi } from '../api/client'
import { useToast } from '../App'

function CreateBriefModal({ isOpen, onClose, onCreate, projectId }) {
  const [title, setTitle] = useState('')
  const [userPrompt, setUserPrompt] = useState('')
  const [goal, setGoal] = useState('')
  const [loading, setLoading] = useState(false)
  
  if (!isOpen) return null
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!title.trim() || !userPrompt.trim()) return
    
    setLoading(true)
    try {
      await onCreate({
        project_id: projectId,
        title: title.trim(),
        user_prompt: userPrompt.trim(),
        goal: goal.trim() || null,
      })
      setTitle('')
      setUserPrompt('')
      setGoal('')
      onClose()
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Create Brief</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Title *</label>
              <input
                type="text"
                className="form-input"
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Brief title"
                autoFocus
              />
            </div>
            <div className="form-group">
              <label className="form-label">Goal</label>
              <input
                type="text"
                className="form-input"
                value={goal}
                onChange={e => setGoal(e.target.value)}
                placeholder="What should this brief achieve?"
              />
            </div>
            <div className="form-group">
              <label className="form-label">User Prompt *</label>
              <textarea
                className="form-textarea"
                value={userPrompt}
                onChange={e => setUserPrompt(e.target.value)}
                placeholder="Enter the prompt to send..."
                rows={5}
              />
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button 
              type="submit" 
              className="btn btn-primary" 
              disabled={loading || !title.trim() || !userPrompt.trim()}
            >
              {loading ? <span className="spinner" /> : 'Create Brief'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

function StatusBadge({ status }) {
  const statusClasses = {
    pending: 'badge-pending',
    running: 'badge-running',
    success: 'badge-success',
    failed: 'badge-failed',
  }
  
  return (
    <span className={`badge ${statusClasses[status] || 'badge-pending'}`}>
      <span className="badge-dot" />
      {status}
    </span>
  )
}

function BriefRow({ brief }) {
  const updatedDate = new Date(brief.updated_at).toLocaleDateString()
  
  return (
    <tr className="clickable-row">
      <td>
        <Link to={`/briefs/${brief.id}`} style={{ color: 'inherit', textDecoration: 'none' }}>
          <strong>{brief.title}</strong>
          {brief.goal && (
            <div className="text-xs text-muted" style={{ marginTop: '0.25rem' }}>
              {brief.goal}
            </div>
          )}
        </Link>
      </td>
      <td>
        <div className="tag-list">
          {(brief.tags || []).slice(0, 3).map(tag => (
            <span key={tag} className="tag">{tag}</span>
          ))}
        </div>
      </td>
      <td className="text-mono text-xs text-muted">{updatedDate}</td>
      <td>
        <Link to={`/briefs/${brief.id}`} className="btn btn-secondary btn-sm">
          View
        </Link>
      </td>
    </tr>
  )
}

export default function ProjectDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addToast } = useToast()
  
  const [project, setProject] = useState(null)
  const [briefs, setBriefs] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)
  
  const loadData = async () => {
    try {
      setLoading(true)
      const [projectRes, briefsRes] = await Promise.all([
        projectsApi.get(id),
        briefsApi.list(id),
      ])
      setProject(projectRes.data)
      setBriefs(briefsRes.data || [])
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadData()
  }, [id])
  
  const handleCreateBrief = async (data) => {
    try {
      await briefsApi.create(data)
      addToast('Brief created successfully')
      loadData()
    } catch (err) {
      addToast(err.message, 'error')
      throw err
    }
  }
  
  const handleDelete = async () => {
    if (!confirm(`Delete project "${project.name}" and all its briefs?`)) return
    
    setDeleting(true)
    try {
      await projectsApi.delete(id)
      addToast('Project deleted')
      navigate('/projects')
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setDeleting(false)
    }
  }
  
  if (loading) {
    return (
      <div className="empty-state">
        <div className="spinner" style={{ margin: '0 auto' }} />
      </div>
    )
  }
  
  if (!project) {
    return (
      <div className="empty-state">
        <p className="text-danger">Project not found</p>
        <Link to="/projects" className="btn btn-secondary mt-md">
          Back to Projects
        </Link>
      </div>
    )
  }
  
  return (
    <div>
      <div className="page-header">
        <div className="actions-bar">
          <div>
            <div className="flex items-center gap-sm mb-md">
              <Link to="/projects" className="text-muted text-sm" style={{ textDecoration: 'none' }}>
                ← Projects
              </Link>
            </div>
            <h1 className="page-title">{project.name}</h1>
            {project.description && (
              <p className="page-subtitle">{project.description}</p>
            )}
          </div>
          <div className="flex gap-sm">
            <button 
              className="btn btn-danger btn-sm" 
              onClick={handleDelete}
              disabled={deleting}
            >
              {deleting ? <span className="spinner" /> : 'Delete'}
            </button>
            <button className="btn btn-primary" onClick={() => setModalOpen(true)}>
              + New Brief
            </button>
          </div>
        </div>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Briefs ({briefs.length})</h3>
        </div>
        
        {briefs.length === 0 ? (
          <div className="empty-state">
            <p>No briefs in this project yet</p>
            <button className="btn btn-primary btn-sm mt-md" onClick={() => setModalOpen(true)}>
              + Create First Brief
            </button>
          </div>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Tags</th>
                  <th>Updated</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {briefs.map(brief => (
                  <BriefRow key={brief.id} brief={brief} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      <div className="card mt-md">
        <div className="card-header">
          <h3 className="card-title">Details</h3>
        </div>
        <div className="text-sm">
          <p><strong>ID:</strong> <span className="text-mono">{project.id}</span></p>
          <p className="mt-md">
            <strong>Created:</strong> {new Date(project.created_at).toLocaleString()}
          </p>
          <p className="mt-md">
            <strong>Updated:</strong> {new Date(project.updated_at).toLocaleString()}
          </p>
        </div>
      </div>
      
      <CreateBriefModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onCreate={handleCreateBrief}
        projectId={id}
      />
    </div>
  )
}
