import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { projectsApi } from '../api/client'
import { useToast } from '../App'

function CreateProjectModal({ isOpen, onClose, onCreate }) {
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  
  if (!isOpen) return null
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!name.trim()) return
    
    setLoading(true)
    try {
      await onCreate({ name: name.trim(), description: description.trim() || null })
      setName('')
      setDescription('')
      onClose()
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Create Project</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Project Name *</label>
              <input
                type="text"
                className="form-input"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="My Awesome Project"
                autoFocus
              />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea
                className="form-textarea"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="What is this project about?"
                rows={3}
              />
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading || !name.trim()}>
              {loading ? <span className="spinner" /> : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

function ProjectCard({ project }) {
  const createdDate = new Date(project.created_at).toLocaleDateString()
  
  return (
    <Link to={`/projects/${project.id}`} className="card" style={{ textDecoration: 'none' }}>
      <div className="card-header">
        <h3 className="card-title">{project.name}</h3>
        <span className="card-meta">{createdDate}</span>
      </div>
      {project.description && (
        <p className="text-sm text-muted" style={{ marginTop: '0.5rem' }}>
          {project.description}
        </p>
      )}
      <div style={{ marginTop: '1rem' }}>
        <span className="text-mono text-xs text-muted">
          ID: {project.id.slice(0, 8)}...
        </span>
      </div>
    </Link>
  )
}

export default function ProjectsPage() {
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalOpen, setModalOpen] = useState(false)
  const { addToast } = useToast()
  
  const loadProjects = async () => {
    try {
      setLoading(true)
      const response = await projectsApi.list()
      setProjects(response.data || [])
      setError(null)
    } catch (err) {
      setError(err.message)
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadProjects()
  }, [])
  
  const handleCreate = async (data) => {
    try {
      await projectsApi.create(data)
      addToast('Project created successfully')
      loadProjects()
    } catch (err) {
      addToast(err.message, 'error')
      throw err
    }
  }
  
  return (
    <div>
      <div className="page-header">
        <div className="actions-bar">
          <div>
            <h1 className="page-title">Projects</h1>
            <p className="page-subtitle">Organize your briefs into projects</p>
          </div>
          <button className="btn btn-primary" onClick={() => setModalOpen(true)}>
            + New Project
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="empty-state">
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : error ? (
        <div className="empty-state">
          <p className="text-danger">{error}</p>
          <button className="btn btn-secondary mt-md" onClick={loadProjects}>
            Retry
          </button>
        </div>
      ) : projects.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z" />
            </svg>
          </div>
          <h3 className="empty-state-title">No projects yet</h3>
          <p>Create your first project to get started</p>
          <button className="btn btn-primary mt-md" onClick={() => setModalOpen(true)}>
            + New Project
          </button>
        </div>
      ) : (
        <div className="grid-2">
          {projects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      )}
      
      <CreateProjectModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onCreate={handleCreate}
      />
    </div>
  )
}
