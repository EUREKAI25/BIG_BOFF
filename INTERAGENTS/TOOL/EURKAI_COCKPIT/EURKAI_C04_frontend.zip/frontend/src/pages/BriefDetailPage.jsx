import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { briefsApi, runsApi } from '../api/client'
import { useToast } from '../App'

function StatusBadge({ status }) {
  const statusClasses = {
    pending: 'badge-pending',
    running: 'badge-running',
    success: 'badge-success',
    failed: 'badge-failed',
  }
  
  return (
    <span className={`badge ${statusClasses[status] || 'badge-pending'}`}>
      <span className="badge-dot" />
      {status}
    </span>
  )
}

function RunDetailModal({ run, isOpen, onClose }) {
  if (!isOpen || !run) return null
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '700px' }}>
        <div className="modal-header">
          <h2 className="modal-title">Run Details</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <div className="flex items-center gap-md mb-md">
            <StatusBadge status={run.status} />
            {run.duration_ms && (
              <span className="text-mono text-sm text-muted">
                {run.duration_ms}ms
              </span>
            )}
            {run.model && (
              <span className="text-mono text-sm text-muted">
                Model: {run.model}
              </span>
            )}
          </div>
          
          <div className="form-group">
            <label className="form-label">Run ID</label>
            <div className="text-mono text-sm">{run.id}</div>
          </div>
          
          <div className="form-group">
            <label className="form-label">Created</label>
            <div className="text-sm">{new Date(run.created_at).toLocaleString()}</div>
          </div>
          
          {run.finished_at && (
            <div className="form-group">
              <label className="form-label">Finished</label>
              <div className="text-sm">{new Date(run.finished_at).toLocaleString()}</div>
            </div>
          )}
          
          {run.output && (
            <div className="form-group">
              <label className="form-label">Output</label>
              <div className="code-block">{run.output}</div>
            </div>
          )}
          
          {run.logs && (
            <div className="form-group">
              <label className="form-label">Logs</label>
              <div className="code-block" style={{ maxHeight: '200px', overflow: 'auto' }}>
                {run.logs}
              </div>
            </div>
          )}
        </div>
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  )
}

export default function BriefDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addToast } = useToast()
  
  const [brief, setBrief] = useState(null)
  const [runs, setRuns] = useState([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [running, setRunning] = useState(false)
  const [selectedRun, setSelectedRun] = useState(null)
  
  // Form state
  const [title, setTitle] = useState('')
  const [goal, setGoal] = useState('')
  const [systemPrompt, setSystemPrompt] = useState('')
  const [userPrompt, setUserPrompt] = useState('')
  const [expectedOutput, setExpectedOutput] = useState('')
  const [tags, setTags] = useState('')
  
  const loadData = async () => {
    try {
      setLoading(true)
      const [briefRes, runsRes] = await Promise.all([
        briefsApi.get(id),
        briefsApi.listRuns(id),
      ])
      
      const b = briefRes.data
      setBrief(b)
      setRuns(runsRes.data || [])
      
      // Populate form
      setTitle(b.title || '')
      setGoal(b.goal || '')
      setSystemPrompt(b.system_prompt || '')
      setUserPrompt(b.user_prompt || '')
      setExpectedOutput(b.expected_output || '')
      setTags((b.tags || []).join(', '))
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadData()
  }, [id])
  
  const handleSave = async () => {
    setSaving(true)
    try {
      await briefsApi.update(id, {
        title: title.trim(),
        goal: goal.trim() || null,
        system_prompt: systemPrompt.trim() || null,
        user_prompt: userPrompt.trim(),
        expected_output: expectedOutput.trim() || null,
        tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      })
      addToast('Brief saved')
      loadData()
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setSaving(false)
    }
  }
  
  const handleRun = async () => {
    setRunning(true)
    try {
      const result = await briefsApi.run(id)
      addToast(`Run started: ${result.data.run_id}`)
      loadData()
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setRunning(false)
    }
  }
  
  const handleDelete = async () => {
    if (!confirm('Delete this brief and all its runs?')) return
    
    try {
      await briefsApi.delete(id)
      addToast('Brief deleted')
      navigate('/briefs')
    } catch (err) {
      addToast(err.message, 'error')
    }
  }
  
  const viewRunDetail = async (runId) => {
    try {
      const result = await runsApi.get(runId)
      setSelectedRun(result.data)
    } catch (err) {
      addToast(err.message, 'error')
    }
  }
  
  if (loading) {
    return (
      <div className="empty-state">
        <div className="spinner" style={{ margin: '0 auto' }} />
      </div>
    )
  }
  
  if (!brief) {
    return (
      <div className="empty-state">
        <p className="text-danger">Brief not found</p>
        <Link to="/briefs" className="btn btn-secondary mt-md">
          Back to Briefs
        </Link>
      </div>
    )
  }
  
  return (
    <div>
      <div className="page-header">
        <div className="actions-bar">
          <div>
            <div className="flex items-center gap-sm mb-md">
              <Link to="/briefs" className="text-muted text-sm" style={{ textDecoration: 'none' }}>
                ← Briefs
              </Link>
              <span className="text-muted text-sm">/</span>
              <Link 
                to={`/projects/${brief.project_id}`} 
                className="text-sm"
                style={{ color: 'var(--accent-primary)', textDecoration: 'none' }}
              >
                Project
              </Link>
            </div>
            <h1 className="page-title">{brief.title}</h1>
          </div>
          <div className="flex gap-sm">
            <button 
              className="btn btn-danger btn-sm" 
              onClick={handleDelete}
            >
              Delete
            </button>
            <button 
              className="btn btn-secondary" 
              onClick={handleSave}
              disabled={saving}
            >
              {saving ? <span className="spinner" /> : 'Save'}
            </button>
            <button 
              className="btn btn-primary" 
              onClick={handleRun}
              disabled={running}
            >
              {running ? <span className="spinner" /> : '▶ Run'}
            </button>
          </div>
        </div>
      </div>
      
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 'var(--space-lg)' }}>
        {/* Editor */}
        <div>
          <div className="card">
            <div className="form-group">
              <label className="form-label">Title</label>
              <input
                type="text"
                className="form-input"
                value={title}
                onChange={e => setTitle(e.target.value)}
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Goal</label>
              <input
                type="text"
                className="form-input"
                value={goal}
                onChange={e => setGoal(e.target.value)}
                placeholder="What should this brief achieve?"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">System Prompt</label>
              <textarea
                className="form-textarea"
                value={systemPrompt}
                onChange={e => setSystemPrompt(e.target.value)}
                placeholder="System instructions (optional)"
                rows={3}
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">User Prompt *</label>
              <textarea
                className="form-textarea"
                value={userPrompt}
                onChange={e => setUserPrompt(e.target.value)}
                placeholder="The main prompt to send"
                rows={6}
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Expected Output</label>
              <textarea
                className="form-textarea"
                value={expectedOutput}
                onChange={e => setExpectedOutput(e.target.value)}
                placeholder="What output is expected? (for validation)"
                rows={3}
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Tags (comma separated)</label>
              <input
                type="text"
                className="form-input"
                value={tags}
                onChange={e => setTags(e.target.value)}
                placeholder="tag1, tag2, tag3"
              />
            </div>
          </div>
          
          <div className="card mt-md">
            <div className="card-header">
              <h3 className="card-title">Policy</h3>
            </div>
            <div className="text-sm">
              <p>
                <strong>Passes in a row:</strong> {brief.policy?.passes_in_a_row || 2}
              </p>
              <p className="mt-md">
                <strong>Max iterations:</strong> {brief.policy?.max_iters || 8}
              </p>
            </div>
          </div>
        </div>
        
        {/* Runs sidebar */}
        <div>
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Runs ({runs.length})</h3>
            </div>
            
            {runs.length === 0 ? (
              <div className="empty-state">
                <p className="text-sm">No runs yet</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)' }}>
                {runs.map(run => (
                  <div 
                    key={run.id}
                    className="card"
                    style={{ 
                      padding: 'var(--space-sm) var(--space-md)',
                      cursor: 'pointer',
                    }}
                    onClick={() => viewRunDetail(run.id)}
                  >
                    <div className="flex items-center justify-between">
                      <StatusBadge status={run.status} />
                      <span className="text-mono text-xs text-muted">
                        {new Date(run.created_at).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-mono text-xs text-muted mt-md">
                      {run.id.slice(0, 8)}...
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="card mt-md">
            <div className="card-header">
              <h3 className="card-title">Details</h3>
            </div>
            <div className="text-sm">
              <p><strong>ID:</strong></p>
              <p className="text-mono text-xs">{brief.id}</p>
              <p className="mt-md">
                <strong>Created:</strong><br />
                {new Date(brief.created_at).toLocaleString()}
              </p>
              <p className="mt-md">
                <strong>Updated:</strong><br />
                {new Date(brief.updated_at).toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <RunDetailModal
        run={selectedRun}
        isOpen={!!selectedRun}
        onClose={() => setSelectedRun(null)}
      />
    </div>
  )
}
