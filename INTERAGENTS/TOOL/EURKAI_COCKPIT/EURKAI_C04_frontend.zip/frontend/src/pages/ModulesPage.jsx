import { useState, useEffect } from 'react'
import { modulesApi } from '../api/client'
import { useToast } from '../App'

function ModuleDetailModal({ module, isOpen, onClose, onDelete }) {
  const [deleting, setDeleting] = useState(false)
  
  if (!isOpen || !module) return null
  
  const handleDelete = async () => {
    if (!confirm(`Delete module "${module.name}"?`)) return
    setDeleting(true)
    try {
      await onDelete(module.id)
      onClose()
    } finally {
      setDeleting(false)
    }
  }
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '700px' }}>
        <div className="modal-header">
          <h2 className="modal-title">{module.name}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <div className="flex items-center gap-md mb-md">
            <span className="badge badge-success">v{module.version}</span>
            <div className="tag-list">
              {(module.tags || []).map(tag => (
                <span key={tag} className="tag">{tag}</span>
              ))}
            </div>
          </div>
          
          {module.description && (
            <p className="text-sm mb-md">{module.description}</p>
          )}
          
          <div className="form-group">
            <label className="form-label">Inputs</label>
            {module.inputs?.length > 0 ? (
              <div className="code-block">
                {JSON.stringify(module.inputs, null, 2)}
              </div>
            ) : (
              <p className="text-muted text-sm">No inputs defined</p>
            )}
          </div>
          
          <div className="form-group">
            <label className="form-label">Outputs</label>
            {module.outputs?.length > 0 ? (
              <div className="code-block">
                {JSON.stringify(module.outputs, null, 2)}
              </div>
            ) : (
              <p className="text-muted text-sm">No outputs defined</p>
            )}
          </div>
          
          {module.constraints && Object.keys(module.constraints).length > 0 && (
            <div className="form-group">
              <label className="form-label">Constraints</label>
              <div className="code-block">
                {JSON.stringify(module.constraints, null, 2)}
              </div>
            </div>
          )}
          
          <div className="form-group">
            <label className="form-label">Full Manifest</label>
            <div className="code-block" style={{ maxHeight: '200px', overflow: 'auto' }}>
              {JSON.stringify(module, null, 2)}
            </div>
          </div>
        </div>
        <div className="modal-footer">
          <button 
            className="btn btn-danger btn-sm" 
            onClick={handleDelete}
            disabled={deleting}
          >
            {deleting ? <span className="spinner" /> : 'Remove from Registry'}
          </button>
          <button className="btn btn-secondary" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  )
}

function RegisterModuleModal({ isOpen, onClose, onRegister }) {
  const [manifestJson, setManifestJson] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  
  if (!isOpen) return null
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    
    let manifest
    try {
      manifest = JSON.parse(manifestJson)
    } catch (err) {
      setError('Invalid JSON format')
      return
    }
    
    setLoading(true)
    try {
      await onRegister(manifest)
      setManifestJson('')
      onClose()
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }
  
  const exampleManifest = {
    name: 'my-module',
    version: '1.0.0',
    description: 'Module description',
    inputs: [
      { name: 'text', type: 'string', required: true }
    ],
    outputs: [
      { name: 'result', type: 'object' }
    ],
    tags: ['example']
  }
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '600px' }}>
        <div className="modal-header">
          <h2 className="modal-title">Register Module</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Manifest JSON</label>
              <textarea
                className="form-textarea"
                value={manifestJson}
                onChange={e => setManifestJson(e.target.value)}
                placeholder={JSON.stringify(exampleManifest, null, 2)}
                rows={12}
              />
              {error && (
                <p className="text-danger text-sm mt-md">{error}</p>
              )}
            </div>
            <button 
              type="button" 
              className="btn btn-secondary btn-sm"
              onClick={() => setManifestJson(JSON.stringify(exampleManifest, null, 2))}
            >
              Load Example
            </button>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading || !manifestJson.trim()}>
              {loading ? <span className="spinner" /> : 'Register'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

function CompatibilityChecker({ modules }) {
  const [fromModule, setFromModule] = useState('')
  const [toModule, setToModule] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const { addToast } = useToast()
  
  const handleCheck = async () => {
    if (!fromModule || !toModule) return
    
    setLoading(true)
    try {
      const res = await modulesApi.checkCompatibility(fromModule, toModule)
      setResult(res.data)
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="card">
      <div className="card-header">
        <h3 className="card-title">Compatibility Check</h3>
      </div>
      
      <div className="flex gap-md items-center mb-md">
        <select 
          className="form-select" 
          value={fromModule}
          onChange={e => setFromModule(e.target.value)}
          style={{ flex: 1 }}
        >
          <option value="">Source module...</option>
          {modules.map(m => (
            <option key={m.id} value={m.name}>{m.name}</option>
          ))}
        </select>
        
        <span className="text-muted">→</span>
        
        <select 
          className="form-select" 
          value={toModule}
          onChange={e => setToModule(e.target.value)}
          style={{ flex: 1 }}
        >
          <option value="">Target module...</option>
          {modules.map(m => (
            <option key={m.id} value={m.name}>{m.name}</option>
          ))}
        </select>
        
        <button 
          className="btn btn-primary"
          onClick={handleCheck}
          disabled={loading || !fromModule || !toModule}
        >
          {loading ? <span className="spinner" /> : 'Check'}
        </button>
      </div>
      
      {result && (
        <div className={`card ${result.compatible ? 'text-success' : 'text-danger'}`} style={{ 
          background: result.compatible ? 'var(--accent-glow)' : 'var(--danger-glow)',
          borderColor: result.compatible ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'
        }}>
          <p className="mb-md">
            <strong>{result.compatible ? '✓ Compatible' : '✗ Not Compatible'}</strong>
          </p>
          
          {result.mappings?.length > 0 && (
            <div className="mb-md">
              <p className="text-sm"><strong>Mappings:</strong></p>
              <ul className="text-sm">
                {result.mappings.map((m, i) => (
                  <li key={i}>{m.from} → {m.to} ({m.type})</li>
                ))}
              </ul>
            </div>
          )}
          
          {result.missing_required?.length > 0 && (
            <div>
              <p className="text-sm"><strong>Missing required inputs:</strong></p>
              <ul className="text-sm">
                {result.missing_required.map(m => (
                  <li key={m}>{m}</li>
                ))}
              </ul>
            </div>
          )}
          
          {result.suggestion && (
            <p className="text-sm text-muted mt-md">{result.suggestion}</p>
          )}
        </div>
      )}
    </div>
  )
}

export default function ModulesPage() {
  const [modules, setModules] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedModule, setSelectedModule] = useState(null)
  const [registerModalOpen, setRegisterModalOpen] = useState(false)
  const { addToast } = useToast()
  
  const loadModules = async () => {
    try {
      setLoading(true)
      const response = await modulesApi.list()
      setModules(response.data || [])
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadModules()
  }, [])
  
  const handleRegister = async (manifest) => {
    try {
      await modulesApi.register(manifest)
      addToast(`Module "${manifest.name}" registered`)
      loadModules()
    } catch (err) {
      addToast(err.message, 'error')
      throw err
    }
  }
  
  const handleDelete = async (moduleId) => {
    try {
      await modulesApi.delete(moduleId)
      addToast('Module removed from registry')
      loadModules()
    } catch (err) {
      addToast(err.message, 'error')
    }
  }
  
  const viewModuleDetail = async (moduleId) => {
    try {
      const result = await modulesApi.get(moduleId)
      setSelectedModule(result.data)
    } catch (err) {
      addToast(err.message, 'error')
    }
  }
  
  return (
    <div>
      <div className="page-header">
        <div className="actions-bar">
          <div>
            <h1 className="page-title">Modules Registry</h1>
            <p className="page-subtitle">Registered module manifests</p>
          </div>
          <button className="btn btn-primary" onClick={() => setRegisterModalOpen(true)}>
            + Register Module
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="empty-state">
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : (
        <>
          {modules.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z" />
                </svg>
              </div>
              <h3 className="empty-state-title">No modules registered</h3>
              <p>Register your first module manifest</p>
              <button className="btn btn-primary mt-md" onClick={() => setRegisterModalOpen(true)}>
                + Register Module
              </button>
            </div>
          ) : (
            <>
              <div className="grid-3 mb-md">
                {modules.map(module => (
                  <div 
                    key={module.id}
                    className="card"
                    style={{ cursor: 'pointer' }}
                    onClick={() => viewModuleDetail(module.id)}
                  >
                    <div className="card-header">
                      <h3 className="card-title">{module.name}</h3>
                      <span className="badge badge-success">v{module.version}</span>
                    </div>
                    
                    {module.description && (
                      <p className="text-sm text-muted mb-md">{module.description}</p>
                    )}
                    
                    <div className="flex gap-md text-xs text-muted">
                      <span>
                        {module.inputs?.length || 0} inputs
                      </span>
                      <span>
                        {module.outputs?.length || 0} outputs
                      </span>
                    </div>
                    
                    {module.tags?.length > 0 && (
                      <div className="tag-list mt-md">
                        {module.tags.slice(0, 3).map(tag => (
                          <span key={tag} className="tag">{tag}</span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              <CompatibilityChecker modules={modules} />
            </>
          )}
        </>
      )}
      
      <ModuleDetailModal
        module={selectedModule}
        isOpen={!!selectedModule}
        onClose={() => setSelectedModule(null)}
        onDelete={handleDelete}
      />
      
      <RegisterModuleModal
        isOpen={registerModalOpen}
        onClose={() => setRegisterModalOpen(false)}
        onRegister={handleRegister}
      />
    </div>
  )
}
