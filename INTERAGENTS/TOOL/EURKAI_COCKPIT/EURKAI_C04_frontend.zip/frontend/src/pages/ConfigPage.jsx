import { useState, useEffect } from 'react'
import { configApi } from '../api/client'
import { useToast } from '../App'

const DEFAULT_CONFIGS = [
  { key: 'ai_provider', label: 'AI Provider', placeholder: 'anthropic / openai / local' },
  { key: 'ai_model', label: 'Default Model', placeholder: 'claude-3-opus-20240229' },
  { key: 'ai_api_key_env', label: 'API Key Env Variable', placeholder: 'ANTHROPIC_API_KEY' },
  { key: 'backup_path', label: 'Backup Path', placeholder: '/path/to/backups' },
  { key: 'log_level', label: 'Log Level', placeholder: 'info / debug / warning' },
]

function ConfigRow({ configKey, label, value, placeholder, onSave }) {
  const [editValue, setEditValue] = useState(value || '')
  const [saving, setSaving] = useState(false)
  const [dirty, setDirty] = useState(false)
  
  useEffect(() => {
    setEditValue(value || '')
    setDirty(false)
  }, [value])
  
  const handleChange = (e) => {
    setEditValue(e.target.value)
    setDirty(e.target.value !== (value || ''))
  }
  
  const handleSave = async () => {
    setSaving(true)
    try {
      await onSave(configKey, editValue)
      setDirty(false)
    } finally {
      setSaving(false)
    }
  }
  
  return (
    <tr>
      <td>
        <div>
          <strong>{label}</strong>
          <div className="text-mono text-xs text-muted">{configKey}</div>
        </div>
      </td>
      <td>
        <input
          type="text"
          className="form-input"
          value={editValue}
          onChange={handleChange}
          placeholder={placeholder}
        />
      </td>
      <td style={{ width: '100px' }}>
        <button 
          className="btn btn-primary btn-sm"
          onClick={handleSave}
          disabled={!dirty || saving}
        >
          {saving ? <span className="spinner" /> : 'Save'}
        </button>
      </td>
    </tr>
  )
}

export default function ConfigPage() {
  const [configs, setConfigs] = useState({})
  const [loading, setLoading] = useState(true)
  const { addToast } = useToast()
  
  const loadConfigs = async () => {
    try {
      setLoading(true)
      const response = await configApi.list()
      const configMap = {}
      ;(response.data || []).forEach(c => {
        configMap[c.key] = c.value
      })
      setConfigs(configMap)
    } catch (err) {
      addToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    loadConfigs()
  }, [])
  
  const handleSave = async (key, value) => {
    try {
      await configApi.update(key, value)
      addToast(`Config "${key}" saved`)
      setConfigs(prev => ({ ...prev, [key]: value }))
    } catch (err) {
      addToast(err.message, 'error')
      throw err
    }
  }
  
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Configuration</h1>
        <p className="page-subtitle">System settings and paths</p>
      </div>
      
      {loading ? (
        <div className="empty-state">
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : (
        <div className="card">
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th style={{ width: '200px' }}>Setting</th>
                  <th>Value</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {DEFAULT_CONFIGS.map(cfg => (
                  <ConfigRow
                    key={cfg.key}
                    configKey={cfg.key}
                    label={cfg.label}
                    value={configs[cfg.key]}
                    placeholder={cfg.placeholder}
                    onSave={handleSave}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      <div className="card mt-md">
        <div className="card-header">
          <h3 className="card-title">All Configurations</h3>
        </div>
        <div className="code-block">
          {JSON.stringify(configs, null, 2)}
        </div>
      </div>
      
      <div className="card mt-md">
        <div className="card-header">
          <h3 className="card-title">Environment</h3>
        </div>
        <div className="text-sm">
          <p><strong>API Base URL:</strong></p>
          <p className="text-mono">{import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'}</p>
          <p className="mt-md text-muted text-xs">
            Configure via VITE_API_BASE_URL in .env file
          </p>
        </div>
      </div>
    </div>
  )
}
