import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen } from '@testing-library/react'
import { BrowserRouter } from 'react-router-dom'
import App from '../App'

// Mock fetch globally
global.fetch = vi.fn()

function mockApiResponse(data) {
  return Promise.resolve({
    ok: true,
    status: 200,
    json: () => Promise.resolve({ success: true, data, meta: { timestamp: new Date().toISOString(), version: '1.0.0' } })
  })
}

beforeEach(() => {
  vi.clearAllMocks()
  
  // Default mock: empty responses
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/projects')) {
      return mockApiResponse([])
    }
    if (url.includes('/api/briefs')) {
      return mockApiResponse([])
    }
    if (url.includes('/api/config')) {
      return mockApiResponse([])
    }
    if (url.includes('/api/secrets')) {
      return mockApiResponse([])
    }
    if (url.includes('/api/modules')) {
      return mockApiResponse([])
    }
    return mockApiResponse([])
  })
})

describe('App', () => {
  it('renders the sidebar navigation', async () => {
    render(
      <BrowserRouter>
        <App />
      </BrowserRouter>
    )
    
    // Check navigation items exist (use getAllByText since items appear multiple places)
    expect(screen.getAllByText('Projects').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Briefs').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Runs').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Secrets').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Modules').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Config').length).toBeGreaterThan(0)
  })
  
  it('renders the EURKAI logo', () => {
    render(
      <BrowserRouter>
        <App />
      </BrowserRouter>
    )
    
    expect(screen.getByText('EURKAI')).toBeInTheDocument()
  })
})

describe('API Client', () => {
  it('handles successful responses', async () => {
    global.fetch.mockImplementationOnce(() => mockApiResponse([
      { id: '1', name: 'Test Project' }
    ]))
    
    const response = await fetch('/api/projects')
    const data = await response.json()
    
    expect(data.success).toBe(true)
    expect(data.data).toHaveLength(1)
    expect(data.data[0].name).toBe('Test Project')
  })
  
  it('handles error responses', async () => {
    global.fetch.mockImplementationOnce(() => Promise.resolve({
      ok: false,
      status: 404,
      json: () => Promise.resolve({
        success: false,
        error: { code: 'ERR_NOT_FOUND', message: 'Not found' },
        meta: { timestamp: new Date().toISOString(), version: '1.0.0' }
      })
    }))
    
    const response = await fetch('/api/projects/invalid')
    const data = await response.json()
    
    expect(data.success).toBe(false)
    expect(data.error.code).toBe('ERR_NOT_FOUND')
  })
})

describe('Smoke Tests', () => {
  it('can render projects page', async () => {
    global.fetch.mockImplementation(() => mockApiResponse([]))
    
    render(
      <BrowserRouter>
        <App />
      </BrowserRouter>
    )
    
    // Default route should show projects (appears multiple times: nav + title)
    expect(screen.getAllByText('Projects').length).toBeGreaterThan(0)
  })
})
