/**
 * EURKAI Cockpit — API Client
 * Communicates with C03 FastAPI backend
 */

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

/**
 * Generic API fetch wrapper with error handling
 */
async function apiFetch(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  };
  
  // Add auth token if configured
  const token = localStorage.getItem('eurkai_token');
  if (token) {
    config.headers['X-EURKAI-TOKEN'] = token;
  }
  
  try {
    const response = await fetch(url, config);
    
    // Handle 204 No Content
    if (response.status === 204) {
      return { success: true, data: null };
    }
    
    const data = await response.json();
    
    if (!response.ok) {
      throw {
        status: response.status,
        code: data.error?.code || 'ERR_UNKNOWN',
        message: data.error?.message || 'Unknown error',
        details: data.error?.details,
      };
    }
    
    return data;
  } catch (error) {
    if (error.status) {
      throw error;
    }
    throw {
      status: 0,
      code: 'ERR_NETWORK',
      message: 'Network error - is the backend running?',
    };
  }
}

// ============================================================================
// Projects API
// ============================================================================

export const projectsApi = {
  list: () => apiFetch('/api/projects'),
  
  get: (id) => apiFetch(`/api/projects/${id}`),
  
  create: (data) => apiFetch('/api/projects', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  
  update: (id, data) => apiFetch(`/api/projects/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  
  delete: (id) => apiFetch(`/api/projects/${id}`, {
    method: 'DELETE',
  }),
};

// ============================================================================
// Briefs API
// ============================================================================

export const briefsApi = {
  list: (projectId = null) => {
    const query = projectId ? `?project_id=${projectId}` : '';
    return apiFetch(`/api/briefs${query}`);
  },
  
  get: (id) => apiFetch(`/api/briefs/${id}`),
  
  create: (data) => apiFetch('/api/briefs', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  
  update: (id, data) => apiFetch(`/api/briefs/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  
  delete: (id) => apiFetch(`/api/briefs/${id}`, {
    method: 'DELETE',
  }),
  
  run: (id) => apiFetch(`/api/briefs/${id}/run`, {
    method: 'POST',
  }),
  
  listRuns: (id) => apiFetch(`/api/briefs/${id}/runs`),
};

// ============================================================================
// Runs API
// ============================================================================

export const runsApi = {
  get: (id) => apiFetch(`/api/runs/${id}`),
  
  delete: (id) => apiFetch(`/api/runs/${id}`, {
    method: 'DELETE',
  }),
};

// ============================================================================
// Config API
// ============================================================================

export const configApi = {
  list: () => apiFetch('/api/config'),
  
  update: (key, value) => apiFetch(`/api/config/${key}`, {
    method: 'PUT',
    body: JSON.stringify({ value }),
  }),
};

// ============================================================================
// Secrets API
// ============================================================================

export const secretsApi = {
  list: (projectId = null) => {
    const query = projectId ? `?project_id=${projectId}` : '';
    return apiFetch(`/api/secrets${query}`);
  },
  
  create: (data) => apiFetch('/api/secrets', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  
  update: (id, value) => apiFetch(`/api/secrets/${id}`, {
    method: 'PUT',
    body: JSON.stringify({ value }),
  }),
  
  delete: (id) => apiFetch(`/api/secrets/${id}`, {
    method: 'DELETE',
  }),
  
  unlock: (masterPassword) => apiFetch('/api/secrets/unlock', {
    method: 'POST',
    body: JSON.stringify({ master_password: masterPassword }),
  }),
  
  copy: (id, sessionToken) => apiFetch(`/api/secrets/${id}/copy`, {
    headers: {
      'X-Session-Token': sessionToken,
    },
  }),
};

// ============================================================================
// Modules API
// ============================================================================

export const modulesApi = {
  list: () => apiFetch('/api/modules'),
  
  get: (id) => apiFetch(`/api/modules/${id}`),
  
  register: (manifest) => apiFetch('/api/modules', {
    method: 'POST',
    body: JSON.stringify(manifest),
  }),
  
  delete: (id) => apiFetch(`/api/modules/${id}`, {
    method: 'DELETE',
  }),
  
  checkCompatibility: (fromModule, toModule) => 
    apiFetch(`/api/modules/compatible?from=${fromModule}&to=${toModule}`),
};

// ============================================================================
// Backups API
// ============================================================================

export const backupsApi = {
  list: () => apiFetch('/api/backups'),
  
  trigger: (notes = null) => apiFetch('/api/backups', {
    method: 'POST',
    body: notes ? JSON.stringify({ notes }) : '{}',
  }),
  
  dryRun: (notes = null) => apiFetch('/api/backups/dry-run', {
    method: 'POST',
    body: notes ? JSON.stringify({ notes }) : '{}',
  }),
};
