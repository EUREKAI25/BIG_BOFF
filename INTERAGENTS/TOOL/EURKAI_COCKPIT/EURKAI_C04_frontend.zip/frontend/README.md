# EURKAI Cockpit — Frontend

**Version** : 1.0.0  
**Chantier** : C04  
**Stack** : Vite + React 18

---

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- Backend C03 running on `http://localhost:8000`

### Installation

```bash
# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Start development server
npm run dev
```

The app will be available at `http://localhost:5173`

---

## 📁 Structure

```
frontend/
├── src/
│   ├── api/
│   │   └── client.js       # API client for C03 backend
│   ├── pages/
│   │   ├── ProjectsPage.jsx      # Projects list/create
│   │   ├── ProjectDetailPage.jsx # Project detail + briefs
│   │   ├── BriefsPage.jsx        # All briefs list
│   │   ├── BriefDetailPage.jsx   # Brief editor + runs
│   │   ├── RunsPage.jsx          # Runs history
│   │   ├── ConfigPage.jsx        # System configuration
│   │   ├── SecretsPage.jsx       # Secrets management
│   │   └── ModulesPage.jsx       # Module registry
│   ├── styles/
│   │   └── global.css      # Global styles
│   ├── test/
│   │   ├── setup.js        # Test setup
│   │   └── App.test.jsx    # Basic tests
│   ├── App.jsx             # Main app + routing
│   └── main.jsx            # Entry point
├── public/
│   └── favicon.svg
├── index.html
├── package.json
├── vite.config.js
└── .env.example
```

---

## 🖥️ Screens

| Screen | Route | Description |
|--------|-------|-------------|
| Projects | `/projects` | List/create projects |
| Project Detail | `/projects/:id` | View project + briefs |
| Briefs | `/briefs` | All briefs across projects |
| Brief Detail | `/briefs/:id` | Edit brief, run, view history |
| Runs | `/runs` | Execution history |
| Config | `/config` | System settings |
| Secrets | `/secrets` | Encrypted secrets (gated copy) |
| Modules | `/modules` | Module registry + compatibility |

---

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `VITE_API_BASE_URL` | `http://localhost:8000` | Backend API URL |

### Backend Requirements

The frontend expects the C03 API to be running. Start it with:

```bash
cd ../backend
pip install -r requirements.txt
uvicorn backend.app:app --reload --port 8000
```

---

## 🧪 Testing

```bash
# Run tests once
npm test

# Run tests in watch mode
npm run test:watch
```

---

## 🏗️ Building

```bash
# Production build
npm run build

# Preview production build
npm run preview
```

Output will be in `dist/` directory.

---

## 🎨 Design

The UI follows an **industrial terminal aesthetic**:

- Dark background with green accents
- JetBrains Mono for code/IDs
- Outfit for display text
- Minimal, utilitarian design
- Status badges with animated indicators

---

## 📝 Acceptance Criteria (C04)

- [x] Projects list/create screen
- [x] Project detail with briefs list/create
- [x] Runs/logs list with detail modal
- [x] Config screen (ai_provider + paths)
- [x] Secrets list/create with copy gated UI
- [x] Modules registry with manifest viewer
- [x] Full flow: create project → create brief → trigger run → view run

---

## 🔗 API Integration

The frontend communicates with C03 endpoints:

| Endpoint | Used By |
|----------|---------|
| `/api/projects` | ProjectsPage, ProjectDetailPage |
| `/api/briefs` | BriefsPage, BriefDetailPage |
| `/api/briefs/:id/run` | BriefDetailPage |
| `/api/runs` | RunsPage |
| `/api/config` | ConfigPage |
| `/api/secrets` | SecretsPage |
| `/api/secrets/unlock` | SecretsPage (copy gated) |
| `/api/modules` | ModulesPage |
| `/api/modules/compatible` | ModulesPage |

---

## Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2025-01-12 | Initial frontend (C04) |
